/**
Various code utilities for working with J2SE security and JAAS.
*/
package cc.security;
