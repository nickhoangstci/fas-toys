/**
XML utilities.
*/
package cc.xml;
