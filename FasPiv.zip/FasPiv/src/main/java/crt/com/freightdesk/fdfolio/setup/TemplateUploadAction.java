package crt.com.freightdesk.fdfolio.setup;

import crt.com.freightdesk.fdfolio.dao.TemplateUploadDAO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.freightdesk.fdcommons.SessionStore;
import com.freightdesk.fdcommons.Credentials;

//import org.apache.struts.Globals;
//import org.apache.struts.action.ActionForm;
//import org.apache.struts.action.ActionForward;
//import org.apache.struts.action.ActionMapping;
//import org.apache.struts.config.ControllerConfig;
//import org.apache.struts.config.ModuleConfig;
//import org.apache.struts.upload.FormFile;
import crt.com.freightdesk.fdfolio.setup.form.FormFile;
import com.opensymphony.xwork2.ActionSupport;
import org.apache.struts2.interceptor.ServletRequestAware;

import com.freightdesk.fdcommons.Credentials;
import com.freightdesk.fdcommons.asyncprocess.AsyncProcessManager;
import com.freightdesk.fdcommons.asyncprocess.AsyncProcessingLogModel;
import com.freightdesk.fdcommons.SessionKey;
import crt.com.freightdesk.fdfolio.setup.model.TemplateUploadModel;
import crt.com.ntelx.nxcommons.NxUtils;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.apache.struts2.ServletActionContext;
import org.apache.log4j.Logger;
import com.freightdesk.fdcommons.ActionMessage;
import com.freightdesk.fdcommons.ActionMessages;

public class TemplateUploadAction extends ActionSupport implements ServletRequestAware {
    protected Logger logger = Logger.getLogger(getClass());
    HttpServletRequest request = ServletActionContext.getRequest();

    public static String usTemplateName = "Air Carrier US Template";
    public static String nonusTemplateName = "Air Carrier Non-US Template";
    public static String iacTemplateName = "IAC Template";
    public static String icsfTemplateName = "ICSF Template";
    public static String shipTemplateName = "Shipper Template";
    public static String usTemplateFileName = "acTemplate.xlsx";
    public static String nonusTemplateFileName = "inboundTemplate.xlsx";
    public static String iacTemplateFileName = "iacTemplate.xlsx";
    public static String icsfTemplateFileName = "icsfTemplate.xlsx";
    public static String shipTemplateFileName = "shipTemplate.xlsx";
    
    private static final long serialVersionUID = 1L;
    private FormFile usFile;    
    private FormFile nonusFile;
    private FormFile iacFile;
    private FormFile icsfFile;
    private FormFile shipFile;
    private String maxRequestSize;
    private String btnUpLoad;
    private String btnCancel;
    private String usLastUpdatedBy;
    private String nonusLastUpdatedBy;
    private String iacLastUpdatedBy;
    private String icsfLastUpdatedBy;
    private String shipLastUpdatedBy;
    private String usLastUpdatedDate;
    private String nonusLastUpdatedDate;
    private String iacLastUpdatedDate;
    private String icsfLastUpdatedDate;
    private String shipLastUpdatedDate;

    public String execute() throws Exception {
        logger.debug("Inside EventUploadAction.");
        HttpServletRequest request = ServletActionContext.getRequest();
        HttpSession session = request.getSession(false);
        SessionStore store = SessionStore.getInstance(session);
        Credentials credentials = (Credentials) store.get(SessionKey.CREDENTIALS);

        TemplateUploadDAO tempDAO = new TemplateUploadDAO();

        if ( getBtnUpLoad() != null) {
            logger.debug("BtnUpload = " + getBtnUpLoad());
        } else if (getBtnCancel() != null) {
            logger.debug("BtnCancel = " + getBtnCancel());
        }

        // Send error message to user if upload is larger than configured limit
//        ModuleConfig ac = (ModuleConfig) request.getAttribute(Globals.MODULE_KEY);
//        ControllerConfig cc = ac.getControllerConfig();
        // assuming file size limit in struts-config is in format of number then 'M'
//        int maxRequestSize = Integer.parseInt(cc.getMaxFileSize().substring(0, cc.getMaxFileSize().length() - 1));
        int maxRequestSize = 5; // 5MB

        // set on the form for display to user in instruction panel
        setMaxRequestSize(maxRequestSize + " MB");

        int requestSize = request.getContentLength() / 1024 / 1024;
        logger.debug("Request Size = " + requestSize + "MB");

        if (requestSize >= maxRequestSize) {
            logger.debug("Request is greater than upload limit.");
            setActionMessage(request, createLimitMessage(requestSize, maxRequestSize));
            return "display";
        }

        if (getBtnCancel() != null) {
            logger.debug("Returning to setupHome.");
            setActionMessage(request, new String[]{"setup.operation.cancel"});
            return "setupHome";
        } else if (getBtnUpLoad() != null) {
            logger.debug("Uploading file(s)");

            int numFiles = 0;
            List<TemplateUploadModel> templateUploadList = new ArrayList<TemplateUploadModel>();

            FormFile usTempFile = getUsFile();
            FormFile nonusTempFile = getNonusFile();
            FormFile iacTempFile = getIacFile();
            FormFile icsfTempFile = getIcsfFile();
            FormFile shipTempFile = getShipFile();

            if (!isEmptyFile(usTempFile)) {
                logger.info("File found not to be null.");
                templateUploadList.add(createModel(credentials, tempDAO.retrieveTemplate(usTemplateName), usTemplateName, usTempFile));
                numFiles++;
            }

            if (!isEmptyFile(nonusTempFile)) {
                logger.info("File found not to be null.");
                templateUploadList.add(createModel(credentials, tempDAO.retrieveTemplate(nonusTemplateName), nonusTemplateName, nonusTempFile));
                numFiles++;
            }

            if (!isEmptyFile(iacTempFile)) {
                logger.info("File found not to be null.");
                templateUploadList.add(createModel(credentials, tempDAO.retrieveTemplate(iacTemplateName), iacTemplateName, iacTempFile));
                numFiles++;
            }

            if (!isEmptyFile(icsfTempFile)) {
                logger.info("File found not to be null.");
                templateUploadList.add(createModel(credentials, tempDAO.retrieveTemplate(icsfTemplateName), icsfTemplateName, icsfTempFile));
                numFiles++;
            }

            if (!isEmptyFile(shipTempFile)) {
                logger.info("File found not to be null.");
                templateUploadList.add(createModel(credentials, tempDAO.retrieveTemplate(shipTemplateName), shipTemplateName, shipTempFile));
                numFiles++;
            }

            tempDAO.persist(templateUploadList);

            logAction(credentials, templateUploadList);

            //asyncRequestManager.logResult(asyncLogModel, true, "Successfully uploaded " + " records.", "execute");
            // create the success message for the user
            setActionMessage(request, createMessage(numFiles));

        }

        // display information on main template upload page
        setFormFromDB(tempDAO.retrieveAll());

        return "display";
    }

    private String[] createMessage(int num) {
        if (num > 0) {
            return createSuccessMessage(num);
        }
        // if there were 0 records, create any empty message
        String messageKey = "common.templateUpload.empty";
        String[] messageKeyObject = new String[1];
        messageKeyObject[0] = messageKey;
        return messageKeyObject;
    }

    private String[] createSuccessMessage(int num) {
        String messageKey = "";
        String[] messageKeyObject = new String[2];
        messageKey = "common.templateUpload.success";
        messageKeyObject[0] = messageKey;
        messageKeyObject[1] = Integer.toString(num);
        return messageKeyObject;
    }

    private String[] createLimitMessage(int fileSize, int maxSize) {
        String messageKey = "";
        String[] messageKeyObject = new String[3];
        messageKey = "common.fileUpload.limit";
        messageKeyObject[0] = messageKey;
        messageKeyObject[1] = Integer.toString(fileSize);
        messageKeyObject[2] = Integer.toString(maxSize);
        return messageKeyObject;

    }

    private boolean isEmptyFile(FormFile templateFile) {
        boolean isEmpty;

        if (templateFile != null
                && templateFile.getFileName() != null
                && templateFile.getFileName().length() > 0) {
            isEmpty = false;
        } else {
            isEmpty = true;
        }

        return isEmpty;
    }

    private TemplateUploadModel createModel(Credentials credentials, TemplateUploadModel existingModel, String templateName, FormFile formFile) throws Exception {
        TemplateUploadModel model = new TemplateUploadModel();
        TemplateUploadDAO tempDAO = new TemplateUploadDAO();

        try {
            Calendar date = Calendar.getInstance();
            if (existingModel != null) {
                model.setCreateTimeStamp(existingModel.getCreateTimeStamp());
                model.setCreateUserID(existingModel.getCreateUserID());
                model.setCrtTemplateID(existingModel.getCrtTemplateID());
            } else {
                model.setCreateTimeStamp(new java.sql.Timestamp(date.getTimeInMillis()));
                model.setCreateUserID(credentials.getUserId());
                model.setCrtTemplateID(tempDAO.getNextID("crttemplateid"));
            }

            model.setLastUpdateTimeStamp(new java.sql.Timestamp(date.getTimeInMillis()));
            model.setLastUpdateUserID(credentials.getUserId());
            model.setDomainName(credentials.getDomainName());
            model.setStatus("ACTIVE");
            model.setTemplateData(formFile.getFileData());
            model.setTemplateName(templateName);
        } catch (Exception ex) {
            logger.error("Unexpected exception in execute(): ", ex);
            throw ex;
        }

        return model;
    }

    private void setFormFromDB(List<TemplateUploadModel> tempModelList) {
        logger.debug("Setting form data.");
        logger.debug("Size of list: " + tempModelList.size());

        for (TemplateUploadModel model : tempModelList) {
            logger.debug("Looping through models... model name: " + model.getTemplateName());

            if (usTemplateName.equals(model.getTemplateName())) {
                setUsLastUpdatedBy(NxUtils.isEmptyOrBlank(model.getLastUpdateUserID())
                        ? model.getDomainName() + "." + model.getCreateUserID()
                        : model.getDomainName() + "." + model.getLastUpdateUserID());
                setUsLastUpdatedDate(model.getLastUpdateTimeStamp() != null
                        ? TemplateUploadDAO.outputDateFormat.format(model.getLastUpdateTimeStamp())
                        : TemplateUploadDAO.outputDateFormat.format(model.getCreateTimeStamp()));
            }
            if (nonusTemplateName.equals(model.getTemplateName())) {
                setNonusLastUpdatedBy(NxUtils.isEmptyOrBlank(model.getLastUpdateUserID())
                        ? model.getDomainName() + "." + model.getCreateUserID()
                        : model.getDomainName() + "." + model.getLastUpdateUserID());
                setNonusLastUpdatedDate(model.getLastUpdateTimeStamp() != null
                        ? TemplateUploadDAO.outputDateFormat.format(model.getLastUpdateTimeStamp())
                        : TemplateUploadDAO.outputDateFormat.format(model.getCreateTimeStamp()));
            }
            if (iacTemplateName.equals(model.getTemplateName())) {
                setIacLastUpdatedBy(NxUtils.isEmptyOrBlank(model.getLastUpdateUserID())
                        ? model.getDomainName() + "." + model.getCreateUserID()
                        : model.getDomainName() + "." + model.getLastUpdateUserID());
                setIacLastUpdatedDate(model.getLastUpdateTimeStamp() != null
                        ? TemplateUploadDAO.outputDateFormat.format(model.getLastUpdateTimeStamp())
                        : TemplateUploadDAO.outputDateFormat.format(model.getCreateTimeStamp()));
            }
            if (icsfTemplateName.equals(model.getTemplateName())) {
                setIcsfLastUpdatedBy(NxUtils.isEmptyOrBlank(model.getLastUpdateUserID())
                        ? model.getDomainName() + "." + model.getCreateUserID()
                        : model.getDomainName() + "." + model.getLastUpdateUserID());
                setIcsfLastUpdatedDate(model.getLastUpdateTimeStamp() != null
                        ? TemplateUploadDAO.outputDateFormat.format(model.getLastUpdateTimeStamp())
                        : TemplateUploadDAO.outputDateFormat.format(model.getCreateTimeStamp()));
            }
            if (shipTemplateName.equals(model.getTemplateName())) {
                setShipLastUpdatedBy(NxUtils.isEmptyOrBlank(model.getLastUpdateUserID())
                        ? model.getDomainName() + "." + model.getCreateUserID()
                        : model.getDomainName() + "." + model.getLastUpdateUserID());
                setShipLastUpdatedDate(model.getLastUpdateTimeStamp() != null
                        ? TemplateUploadDAO.outputDateFormat.format(model.getLastUpdateTimeStamp())
                        : TemplateUploadDAO.outputDateFormat.format(model.getCreateTimeStamp()));
            }
        }
    }

    private void logAction(Credentials credentials, List<TemplateUploadModel> models) {
        AsyncProcessingLogModel asyncLogModel = new AsyncProcessingLogModel();
        AsyncProcessManager asyncManager = new AsyncProcessManager();

        String module = "TEMPLATE UPLOAD";
        String action = "TEMPLATE UPLOAD";
        String feedback;
        String completedFeedback;

        try {
            for (TemplateUploadModel model : models) {
                feedback = model.getTemplateName() + " is being updated by " + credentials.getDomainName() + "." + credentials.getUserId();
                completedFeedback = model.getTemplateName() + " was updated by " + credentials.getDomainName() + "." + credentials.getUserId();

                // Record attempted logins in the ASYNCPROCESSINGLOG table
                asyncLogModel.init(credentials.getUserId(), credentials.getDomainName(), action, module, feedback, credentials.getIpAddress());

                // Record successful login in the ASYNCPROCESSINGLOG table
                asyncLogModel = asyncManager.createAsyncProcessLog(asyncLogModel);
                asyncManager.logResult(asyncLogModel, true, completedFeedback, "logAction");
            }
        } catch (Exception ex) {
            asyncManager.logResult(asyncLogModel, false, "Failed on Template Upload.", "Exception");
        }
    }
    
    public FormFile getUsFile() {
        return usFile;
    }

    public void setUsFile(FormFile usFile) {
        this.usFile = usFile;
    }

    public FormFile getNonusFile() {
        return nonusFile;
    }

    public void setNonusFile(FormFile nonusFile) {
        this.nonusFile = nonusFile;
    }

    public FormFile getIacFile() {
        return iacFile;
    }

    public void setIacFile(FormFile iacFile) {
        this.iacFile = iacFile;
    }

    public FormFile getIcsfFile() {
        return icsfFile;
    }

    public void setIcsfFile(FormFile icsfFile) {
        this.icsfFile = icsfFile;
    }

    public FormFile getShipFile() {
        return shipFile;
    }

    public void setShipFile(FormFile shipFile) {
        this.shipFile = shipFile;
    }

    public String getMaxRequestSize() {
        return maxRequestSize;
    }

    public void setMaxRequestSize(String maxRequestSize) {
        this.maxRequestSize = maxRequestSize;
    }

    public String getBtnUpLoad() {
        return btnUpLoad;
    }

    public void setBtnUpLoad(String btnUpLoad) {
        this.btnUpLoad = btnUpLoad;
    }

    public String getBtnCancel() {
        return btnCancel;
    }

    public void setBtnCancel(String btnCancel) {
        this.btnCancel = btnCancel;
    }
    
     public String getUsLastUpdatedBy() {
        return usLastUpdatedBy;
    }

    public void setUsLastUpdatedBy(String usLastUpdatedBy) {
        this.usLastUpdatedBy = usLastUpdatedBy;
    }

    public String getNonusLastUpdatedBy() {
        return nonusLastUpdatedBy;
    }

    public void setNonusLastUpdatedBy(String nonusLastUpdatedBy) {
        this.nonusLastUpdatedBy = nonusLastUpdatedBy;
    }

    public String getIacLastUpdatedBy() {
        return iacLastUpdatedBy;
    }

    public void setIacLastUpdatedBy(String iacLastUpdatedBy) {
        this.iacLastUpdatedBy = iacLastUpdatedBy;
    }

    public String getIcsfLastUpdatedBy() {
        return icsfLastUpdatedBy;
    }

    public void setIcsfLastUpdatedBy(String icsfLastUpdatedBy) {
        this.icsfLastUpdatedBy = icsfLastUpdatedBy;
    }

    public String getShipLastUpdatedBy() {
        return shipLastUpdatedBy;
    }

    public void setShipLastUpdatedBy(String shipLastUpdatedBy) {
        this.shipLastUpdatedBy = shipLastUpdatedBy;
    }

    public String getUsLastUpdatedDate() {
        return usLastUpdatedDate;
    }

    public void setUsLastUpdatedDate(String usLastUpdatedDate) {
        this.usLastUpdatedDate = usLastUpdatedDate;
    }

    public String getNonusLastUpdatedDate() {
        return nonusLastUpdatedDate;
    }

    public void setNonusLastUpdatedDate(String nonusLastUpdatedDate) {
        this.nonusLastUpdatedDate = nonusLastUpdatedDate;
    }

    public String getIacLastUpdatedDate() {
        return iacLastUpdatedDate;
    }

    public void setIacLastUpdatedDate(String iacLastUpdatedDate) {
        this.iacLastUpdatedDate = iacLastUpdatedDate;
    }

    public String getIcsfLastUpdatedDate() {
        return icsfLastUpdatedDate;
    }

    public void setIcsfLastUpdatedDate(String icsfLastUpdatedDate) {
        this.icsfLastUpdatedDate = icsfLastUpdatedDate;
    }

    public String getShipLastUpdatedDate() {
        return shipLastUpdatedDate;
    }

    public void setShipLastUpdatedDate(String shipLastUpdatedDate) {
        this.shipLastUpdatedDate = shipLastUpdatedDate;
    }
    
    public void setServletRequest(HttpServletRequest request) {
        this.request = request;
    }

    public HttpServletRequest getServletRequest() {
        return request;
    }
    
    public void setActionMessage(HttpServletRequest request, String[] messageKeyObject) {
        int length = messageKeyObject.length;
        logger.debug("messageKeyObject.length = " + length);
        ActionMessage actionMessage = null;
        switch (length) {
            case 2:
                logger.debug("messagekeyvalues" + messageKeyObject[0]);
                actionMessage = new ActionMessage(messageKeyObject[0], (Object) messageKeyObject[1]);
                break;
            case 3:
                actionMessage = new ActionMessage(messageKeyObject[0], messageKeyObject[1], messageKeyObject[2]);
                break;
            case 4:
                actionMessage = new ActionMessage(messageKeyObject[0], messageKeyObject[1], messageKeyObject[2], messageKeyObject[3]);
                break;
            case 5:
                actionMessage = new ActionMessage(messageKeyObject[0], messageKeyObject[1], messageKeyObject[2], messageKeyObject[3], messageKeyObject[4]);
                break;
            default:
                actionMessage = new ActionMessage(messageKeyObject[0]);
        }

        ActionMessages messages = new ActionMessages();
        messages.add(ActionMessages.GLOBAL_MESSAGE, actionMessage);

        logger.debug("message has been set on request");
    }
}
