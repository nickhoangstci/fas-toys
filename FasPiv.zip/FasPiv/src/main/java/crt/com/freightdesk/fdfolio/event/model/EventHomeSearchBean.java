package crt.com.freightdesk.fdfolio.event.model;

import java.sql.Timestamp;
import java.util.List;

public class EventHomeSearchBean {
	
	private List<EventHomeModel> eventList;
	private Timestamp startDate;
	private Timestamp endDate;
	int currentPage;
	int totalEventCount;
	int totalPages;
	
	
	public int getCurrentPage() {
		return currentPage;
	}

	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}

	public int getTotalPages() {
		return totalPages;
	}

	public void setTotalPages(int totalPages) {
		this.totalPages = totalPages;
	}

	public Timestamp getStartDate() {
		return startDate;
	}

	public void setStartDate(Timestamp startDate2) {
		this.startDate = startDate2;
	}

	public Timestamp getEndDate() {
		return endDate;
	}

	public void setEndDate(Timestamp endDate2) {
		this.endDate = endDate2;
	}

	public int getPage() {
		return currentPage;
	}

	public void setPage(int page) {
		this.currentPage = page;
	}

	public int getTotalEventCount() {
		return totalEventCount;
	}

	public void setTotalEventCount(int totalEventCount) {
		this.totalEventCount = totalEventCount;
	}



	public void setEventList(List<EventHomeModel> eventList) {
		this.eventList = eventList;
	}

	public List<EventHomeModel> getEventList() {
		return eventList;
	}

}
