/**
 * 
 */
package crt.com.freightdesk.fdfolio.common;

import crt.com.freightdesk.fdfolio.common.ErrorHandler;
import org.apache.log4j.Logger;
//import org.apache.struts.action.ActionErrors;
//import org.apache.struts.action.ActionMessage;
import com.freightdesk.fdcommons.ActionErrors;
import com.freightdesk.fdcommons.ActionMessage;

/**
 * @author jhansford
 *
 */
public class StrutsDelayedErrorHandler implements ErrorHandler 
{
	private Logger logger = Logger.getLogger( StrutsDelayedErrorHandler.class );

	private ActionErrors actionErrors  =  new ActionErrors();
	private String       errorKey;
	private String       msgKey;
	
	
	public String getMsgKey() {
		return msgKey;
	}

	public void setMsgKey(String msgKey) {
		this.msgKey = msgKey;
	}

	public String getErrorKey() {
		return errorKey;
	}

	public void setErrorKey(String errorKey) {
		this.errorKey = errorKey;
	}

	/* (non-Javadoc)
	 * @see com.freightdesk.fdfolio.common.ErrorHandler#handleError(java.lang.Exception)
	 */
	@Override
	public void handleError(Exception e) 
	{
		logger.debug( "Adding Action Error: " + e.getMessage() );
		actionErrors.add( errorKey, new ActionMessage( msgKey , e.getMessage() ) );
	}

	/* (non-Javadoc)
	 * @see com.freightdesk.fdfolio.common.ErrorHandler#handleError(java.lang.String)
	 */
	@Override
	public void handleError(String s) 
	{
		logger.debug( "Adding Action Error: " + s );
		actionErrors.add( errorKey ,new ActionMessage( msgKey , s ) );
	}

   /**
    * Returns Errors that this error handlers have handled.	
    * @return ActionErrors
    */
	public ActionErrors getErrors()
	{
		return actionErrors;
	}
}
