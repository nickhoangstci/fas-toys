package crt.com.freightdesk.fdfolio.common;

import java.io.IOException;
import java.sql.Timestamp;
import java.util.List;
import java.util.Map;
import java.util.Random;

import javax.servlet.jsp.JspWriter;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

import com.freightdesk.fdcommons.ApplicationProperties;
import com.freightdesk.fdcommons.Credentials;
import com.freightdesk.fdcommons.FormatDate;
import com.freightdesk.fdfolio.addressbook.model.OrganizationChartModel;

import crt.com.ntelx.nxcommons.NxUtils;

public class IncludesUtil {
	private static Logger logger = Logger.getLogger(IncludesUtil.class);

	public static final Long millisInDay = 86400000L;

	public static String getExpireMsg(Credentials credentials) {
		String expireMsg = "";
		Timestamp expDate = credentials.getExpirationDate();

		// don't do anything if there is no expiration date
		if (expDate == null) {
			return expireMsg;
		}

		// password.warnExpire is in days, convert to millis
		Long timeToWarn = Long.parseLong(ApplicationProperties.getProperty("password.warnExpire")) * millisInDay;               
		Long timeToExpiration = expDate.getTime() - System.currentTimeMillis();

		// Show warning message?
		if (timeToExpiration < timeToWarn) {
			expireMsg = "Your Password is going to expire on <span style='color:red;'> " + FormatDate.format(expDate, credentials.getDateFormat()) + " </span>. Click Setup to change password";
		}
		return expireMsg;
	}

	public static String getWelcomeMsg(Credentials credentials) {
		String welcomeMsg = "";
		try {
			int numFailedLogin = credentials.getNumFailedLogin();

			// only show the welcomeMsg once
                        // Updated: 10/7/2013 - Removed check.  UAT thought it was a "bug".	
                            if (credentials.getLastLoginTime() != null) {
                                    welcomeMsg = "Your last login was <span style='color:blue;'>" + credentials.getLastLoginTime() + "</span>.<br>You are logged in as a "+credentials.getSystemRoleName()+".<br>";
                            }
							if (numFailedLogin > 0) {					        
                                    welcomeMsg = welcomeMsg + "  There have been <span style='color:red;'>" + numFailedLogin + "</span> failed login attempt(s) since your last login.";
                            }
		} catch (Exception ex) {			
			logger.error("Exception while trying to set welcome message from credentials.  Returning empty String: " + ex.getMessage());
		}

		return welcomeMsg;
	}

	/*
	 * pass the number of days to go back and this function returns that time in
	 * millis. useful to use as input to date creation
	 */
	public static long getDateBackInMillis(int numDays) {
		Long now = System.currentTimeMillis();
		Long timeToGoBack = numDays * millisInDay;
		return now - timeToGoBack;
	}

	/*
	 * Used to print the yui treeview inside of jsp.  Called from Tree.jspf
	 */
	public static void printTree(OrganizationChartModel chartModel, JspWriter out, javax.servlet.http.HttpServletRequest request, long currentOrgId, boolean highLighted) throws IOException {
		
		if (chartModel == null) {
			return;
		}

		String html = "";
		String cssClasses = "";
		String type = "";
		String fullName = "";
		String name = "";
		String status = "";
		String href = "";
		String link = "";
		String orgId = "";
		
		// patch.  Should either be editing or viewing.
		String context = request.getParameter("context");
		
		if(context == null)
			context = "VIEW";
		
		if(context.equalsIgnoreCase("ADD")) {
			logger.debug("Changing context from ADD to EDIT.");
			context = "EDIT";
		}
		// end patch
		
		out.println("");
		out.println("<ul>");

		List<OrganizationChartModel> childList = chartModel.getChildOrgChartModelList();
		for (int i = 0; i < childList.size(); i++) {
			type = childList.get(i).getOrgHierarchyTypeCode().toLowerCase();
			fullName = StringEscapeUtils.escapeHtml(NxUtils.upperFirst(childList.get(i).getOrgName()));
			orgId = Long.toString(childList.get(i).getOrgId());
			status = childList.get(i).getStatus();
						

			// fix visual bug with background repeating on long names
			if (fullName.length() > 23)
				name = fullName.substring(0, 23);
			else
				name = fullName;

			cssClasses = "";

			href = "orghierarchy.do?context="+context+"&"+"id="+orgId;

			
			// If this node is this page's org then add the css to highlight it
			if (childList.get(i).getOrgId() == currentOrgId) {
				cssClasses += "ygtvfocus";
				highLighted = true;
			}
			
			
			// status is not active, grey out item in tree
			if(!status.equalsIgnoreCase("ACTIVE")) {
				cssClasses += " inactive";
				type += "-inactive";
			}
			
			// If node not a contact and nothing is highLighted, expand the node
			if (!type.equals("con") && !highLighted)
				cssClasses += " expanded";

			
			// If this node is the page's entity, make no onclick action
			if (childList.get(i).getOrgId() == currentOrgId)
				link = "<span class='" + type + "'>" + name + "</span>";
			else
				link = "<span class='" + type + "' onClick=\"location.href='" + href + "';\">" + name + "</span>";
			
			
			
			if (cssClasses.trim().equals(""))
				html = "<li title='" + fullName + "'>" + link;
			else
				html = "<li title='" + fullName + "' class='" + cssClasses + "'>" + link;


			out.println(html);

			printTree(childList.get(i), out, request, currentOrgId, highLighted);
			out.println("</li>");
		}
		out.println("</ul>");
	}
	
    public static String convertMapListToJsonString(List<Map> list) {

		JSONArray ja = new JSONArray();
	    JSONObject jo = null;
		String dataStr = null;
	
	    try {
	        if (null != list && !list.isEmpty()) {
	
				for (Map<String, String> map : list) {
			      jo = new JSONObject();
			      for (Map.Entry<String, String> entry : map.entrySet()) {
			    	  jo.put(entry.getKey(), entry.getValue());
			      }
			      ja.put (jo);
	           }
				dataStr = ja.toString ();
				//logger.info(dataStr);
	        }
	    } catch(Exception e) {
	      logger.error ("Exception JSON conversion" + e);
	    }
	    return dataStr;
    
    }
	
    public static String getNewCsrfToken() {
    	
	    final String SALTCHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
	    StringBuilder salt = new StringBuilder();
	    Random rnd = new Random();

	    while (salt.length() < 18) { // length of the random string.
	        int index = (int) (rnd.nextFloat() * SALTCHARS.length());
	        salt.append(SALTCHARS.charAt(index));
	    }
	    logger.info(salt);
	    
	    return salt.toString();

    }
	
}
