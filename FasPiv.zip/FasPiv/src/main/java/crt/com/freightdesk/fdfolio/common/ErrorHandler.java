/**
 * 
 */
package crt.com.freightdesk.fdfolio.common;

/**
 * @author jhansford
 *
 */
public interface ErrorHandler 
{
	public void handleError( Exception e );
	public void handleError( String    s ); 
}
