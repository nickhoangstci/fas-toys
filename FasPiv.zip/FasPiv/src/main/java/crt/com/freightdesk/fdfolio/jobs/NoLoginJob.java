package crt.com.freightdesk.fdfolio.jobs;

import java.sql.SQLException;

import javax.sql.DataSource;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import crt.com.freightdesk.fdfolio.dao.QuartzDao;
import org.apache.log4j.Logger;

public class NoLoginJob implements Job
{
	protected QuartzDao quartzDao = null; 
    protected Logger logger = Logger.getLogger (getClass());

	@Override
	public void execute( JobExecutionContext exeContext ) throws JobExecutionException
	{
		logger.info( "NoLoginJob Fired" );
		
		try
		{
			DataSource dataSource = (DataSource) exeContext.getMergedJobDataMap().get( "dataSource" );
			
			quartzDao = new QuartzDao();			
			quartzDao.setConnection( dataSource.getConnection() );
			
			int rowCount = quartzDao.deactiveNotLoggedIn();
			
			logger.info( "NoLoginJob deactivated: " + rowCount );			
		}		
		catch ( SQLException sqlEx )
		{
			throw new JobExecutionException( "Had Problem with connection: " + sqlEx.getMessage() );
		}
	}

}
