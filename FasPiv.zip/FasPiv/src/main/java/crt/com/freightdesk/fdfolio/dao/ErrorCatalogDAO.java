package crt.com.freightdesk.fdfolio.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.freightdesk.fdcommons.BaseDao;
import com.freightdesk.fdcommons.ConnectionUtil;
import crt.com.freightdesk.fdfolio.errorcatalog.model.ErrorCatalogModel;




public class ErrorCatalogDAO extends BaseDao
{
	
	public ErrorCatalogModel create(ErrorCatalogModel ecm) throws SQLException
	{
		Connection connection = null;
        try
        {
            connection = getConnection();
            String query = "INSERT INTO errorcatalog (errorcatalogid, filename, filedirname," +
            		"filestatus, errortype, outputdir, xml, status," +
            		"createuserid, createtimestamp, " +
            		"domainname) VALUES(ERRORCATALOGID.NEXTVAL, ?, ?, ?, ?, ?, ?, ?, ?, SYSDATE," +
            		"?)";
            PreparedStatement pStmt = null;
            pStmt = connection.prepareStatement(query);
            pStmt.setString(1, ecm.getFileName());
            pStmt.setString(2, ecm.getFileDirName());
            pStmt.setString(3, ecm.getFileStatus());
            pStmt.setString(4, ecm.getErrorType());
            pStmt.setString(5, ecm.getPostProcessLocation());
            pStmt.setString(6, ecm.getXml());
            pStmt.setString(7, ecm.getStatus());
            pStmt.setString(8, ecm.getCreateUserId());
            pStmt.setString(9, ecm.getDomainName());
            
            pStmt.executeUpdate();
        }
        catch (SQLException sqEx)
        {
            logger.error("ErrorCatalogDAO[create(ecm)] -> ", sqEx);
            throw sqEx;
        }		
        finally
        {
            ConnectionUtil.closeResources(connection, null, null);
        }
		return ecm;
	}
	
	public ErrorCatalogModel getErrorCatalogModelByID(int id) throws SQLException
	{
		ErrorCatalogModel ecm = null;
		Connection connection = null;
        try
        {
            connection = getConnection();
            String query = "SELECT errorcatalogid, filename, filedirname," +
            		"filestatus, errortype, outputdir, xml, status," +
            		"createuserid, createtimestamp, " +
            		"domainname FROM errorcatalog WHERE errorcatalogid = ?";
            		
            PreparedStatement pStmt = null;
            pStmt = connection.prepareStatement(query);
            pStmt.setInt(1, id);
            
            ResultSet rs = pStmt.executeQuery();
            
            if (rs.next())
            {
            	ecm = new ErrorCatalogModel();
            	ecm.setErrorCatalogId(rs.getInt(1));
            }
        }
        catch (SQLException sqEx)
        {
            logger.error("ErrorCatalogDAO[create(ecm)] -> ", sqEx);
            throw sqEx;
        }		
        finally
        {
            ConnectionUtil.closeResources(connection, null, null);
        }
		return ecm;
	}
}