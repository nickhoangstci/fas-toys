/**
 * Copyright (c) NTELX
 *  All rights reserved. 
 *
 * This software is the confidential and proprietary information of NTELX
 * ("Confidential Information").  You shall not disclose such Confidential Information
 * and shall use it only in accordance with the terms of the license agreement you entered
 * into with NTELX. 
 *
 *
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolio/legcontainer/util/Attic/DeviceSearchResult.java,v 1.1 2007/02/13 05:31:56 atripathi Exp $
 *
 *  Modification History:
 *  $Log: DeviceSearchResult.java,v $
 *  Revision 1.1  2007/02/13 05:31:56  atripathi
 *  database paging implemented
 *
 */
package crt.com.freightdesk.fdfolio.securitydevice.util;

import java.util.ArrayList;
import java.util.List;

public class DeviceSearchResult {
private List deviceList;
private long count;

/** Creates an instance of deviceList. */
public DeviceSearchResult(){
	deviceList=new ArrayList();
}
/** 
 * Creates an instance of deviceList.
 * @param deviceList List of security devices
 * @param count 
 */
public DeviceSearchResult(List deviceList, long count) {
    this.deviceList = deviceList;
    this.count = count;
}
public long getCount() {
	return count;
}
public void setCount(long count) {
	this.count = count;
}
public List getDeviceList() {
	return deviceList;
}
public void setDeviceList(List deviceList) {
	this.deviceList = deviceList;
}

}
