/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package crt.com.freightdesk.fdfolio.orghierarchy;

import crt.com.freightdesk.fdfolioweb.orghierarchy.form.OrgAssocForm;
// import com.freightdesk.fdfolioweb.orghierarchy.form.OrghierarchyForm;
import crt.com.ntelx.nxcommons.FasConstants;
import com.freightdesk.fdcommons.FormatDate;
import crt.com.ntelx.nxcommons.NxUtils;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.List;
//import org.apache.struts.action.ActionErrors;
//import org.apache.struts.action.ActionMessage;
import com.freightdesk.fdcommons.ActionErrors;
import com.freightdesk.fdcommons.ActionMessage;
import com.freightdesk.fdcommons.ActionMessages;
import com.freightdesk.fdfolioweb.orghierarchy.action.OrghierarchyAction.OrgFormFieldBean;

/**
 *
 * @author mbegley
 */
public class OrgOrgAssocValidator {

    private OrgOrgAssocValidator() {
    }

    /**
     * entry point method.
     *
     * validation performed only on orgRoleCode "CAR"
     *
     * called by OrghierarchyManager
     *
     * @param form
     * @return any Validation Errors...
     */
    public static ActionErrors validateCar(OrgFormFieldBean form) {
        ActionErrors errors = new ActionErrors();

        for (OrgAssocForm assocForm : form.getOrgAssocList()) {

            // validations common to all types.
            if (NxUtils.isEmptyOrBlank(assocForm.getRelationShipType())) {
                errors.add("error.filecontent", new ActionMessage("error.file.content", "A Relationship Type must be set for each Association."));
            }

            if (!isAirportSet(assocForm)) {
                errors.add("error.filecontent", new ActionMessage("error.file.content", "An Airport must be set for each Associations."));
            }


            if (!NxUtils.isEmptyOrBlank(assocForm.getRelationShipType())) {

                // validate NCSP only
                if (assocForm.getRelationShipType().equalsIgnoreCase("NCSP")) {
                    validateNcsp(assocForm, form, errors);
                }
                // validate SEAS only
                if (assocForm.getRelationShipType().equalsIgnoreCase("SEAS")) {
                    validateSeas(assocForm, form, errors);
                }
                // validate RSUB only
                if (assocForm.getRelationShipType().equalsIgnoreCase("RSUB")) {
                    validateRsub(assocForm, form, errors);
                }

            }

        }

        return errors;
    }

    private static void validateRsub(OrgAssocForm rsubForm, OrgFormFieldBean form, ActionErrors errors) {
        if (NxUtils.isEmptyOrBlank(rsubForm.getBeginDate())) {
            errors.add("error.filecontent", new ActionMessage("error.file.content", "A Start Date must exist for each Required to Submit association."));
        }
    }

    /**
     * Validates a OrgOrgAssoc of type "NCSP",
     *
     * only side effect of this method is adding errors to the ActionErrors
     * param.
     *
     * @param ncspForm
     * @param form
     * @param errors
     */
    private static void validateNcsp(OrgAssocForm ncspForm, OrgFormFieldBean form, ActionErrors errors) {
        // validate both start and end date exist.
        if (!isStartAndEndDateExist(ncspForm)) {
            errors.add("error.filecontent", new ActionMessage("error.file.content", "Both Start and End Dates must exist for each NCSP association."));
        }
        // NCSP validations only
        // falls within ANY rsub scope.
        if (!isValidNcsp(form.getOrgAssocList(), ncspForm)) {
            errors.add("error.filecontent", new ActionMessage("error.file.content", "NCSP Association was found without a valid Required to Submit association and encompassing date range for that airport."));
        }
        
     // validate both start and end date exist.
        if (form.getNcspMember() == null || form.getNcspMember().isEmpty()) {
            errors.add("error.filecontent", new ActionMessage("error.file.content", "Carrier must be an NCSP Member before having an NCSP amendment."));
        }

    }

    /**
     * Validates a OrgOrgAssoc of type "SEAS",
     *
     * only side effect of this method is adding errors to the ActionErrors
     * param.
     *
     * @param seasForm
     * @param form
     * @param errors
     */
    private static void validateSeas(OrgAssocForm seasForm, OrgFormFieldBean form, ActionErrors errors) {

        // validate both start and end date exist.
        if (!isStartAndEndDateExist(seasForm)) {
            errors.add("error.filecontent", new ActionMessage("error.file.content", "Both Start and End Dates must exist for each Seasonal association."));
        }

        // SEAS validations only
        // only requires RSUB
        if (!isValidSeas(form.getOrgAssocList(), seasForm)) {
            errors.add("error.filecontent", new ActionMessage("error.file.content", "Seasonal Association was found without a valid Required to Submit association for that airport."));
        }




    }

    private static boolean isAirportSet(OrgAssocForm assocForm) {
        if (!NxUtils.isEmptyOrBlank(assocForm.getDestOrgId()) && !NxUtils.isEmptyOrBlank(assocForm.getDestOrgName())) {
            return true;
        }
        return false;
    }

    private static boolean isStartAndEndDateExist(OrgAssocForm assocForm) {
        if (NxUtils.isEmptyOrBlank(assocForm.getBeginDate())) {
            return false;
        }
        if (NxUtils.isEmptyOrBlank(assocForm.getEndDate())) {
            return false;
        }
        return true;
    }

    /**
     * An NCSP requires an RSUB with matching destOrgId and an encompassing date
     * range range.
     *
     * @param assocList
     * @param ncspModel
     * @return
     */
    private static boolean isValidNcsp(List<OrgAssocForm> assocList, OrgAssocForm ncspModel) {
        for (OrgAssocForm assocForm : assocList) {
            if (assocForm.getRelationShipType().equalsIgnoreCase("RSUB")) {
                if (isWithinDateRange(assocForm, ncspModel) && isAirportIdMatch(assocForm, ncspModel)) {
                    return true;
                }
            }

        }
        return false;
    }

    /**
     * An SEAS requires an RSUB with matching destOrgId - dates don't matter.
     * range range.
     *
     * @param assocList
     * @param ncspModel
     * @return
     */
    private static boolean isValidSeas(List<OrgAssocForm> assocList, OrgAssocForm ncspModel) {
        for (OrgAssocForm assocForm : assocList) {
            if (assocForm.getRelationShipType().equalsIgnoreCase("RSUB")) {
                if (isAirportIdMatch(assocForm, ncspModel)) {
                    return true;
                }
            }

        }
        return false;
    }

    private static boolean isAirportIdMatch(OrgAssocForm src, OrgAssocForm trg) {
        if (src.getDestOrgId().equalsIgnoreCase(trg.getDestOrgId())) {
            return true;
        }
        return false;
    }

    private static boolean isWithinDateRange(OrgAssocForm assocForm, OrgAssocForm testedModel) {

//        if (!isStartAndEndDateExist(assocForm) || !isStartAndEndDateExist(testedModel)) {
    	if (!isStartAndEndDateExist(testedModel)) {
            return false;
        }

        Timestamp t_startTimestamp = FormatDate.parse(testedModel.getBeginDate(), FasConstants.simpleDateFormat);
        t_startTimestamp = addDaysToTimestamp(t_startTimestamp, 1);
        Timestamp t_endTimestamp = FormatDate.parse(testedModel.getEndDate(), FasConstants.simpleDateFormat);
        t_endTimestamp = addDaysToTimestamp(t_endTimestamp, -1);


        Timestamp startTimestamp = FormatDate.parse(assocForm.getBeginDate(), FasConstants.simpleDateFormat);
        Timestamp endTimestamp = assocForm.getEndDate() == null ? null : FormatDate.parse(assocForm.getEndDate(), FasConstants.simpleDateFormat);

        if ((startTimestamp.before(t_startTimestamp) && endTimestamp == null) ||
        	(startTimestamp.before(t_startTimestamp) && endTimestamp.after(t_endTimestamp))) {
            return true;
        }

        return false;
    }

    private static Timestamp addDaysToTimestamp(Timestamp timestamp, int daysToAdd) {
        Calendar c = Calendar.getInstance();
        c.setTime(timestamp);
        c.add(Calendar.DATE, daysToAdd);  // number of days to add
        Timestamp s = new Timestamp(c.getTimeInMillis());
        return s;
    }
}
