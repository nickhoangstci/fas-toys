package crt.com.freightdesk.fdfolioweb.setup;

import org.apache.log4j.Logger;

public class PasswordStatus {
	
	protected static Logger logger = Logger.getLogger("PasswordStatus");
	
	private boolean isValidLength;
	private boolean hasLowerCase;
	private boolean hasUpperCase;
	private boolean hasNumber;
	private boolean hasSpecial;
	private boolean newPassConfirmPassMatch;
	private boolean newPassNotEqualOldPass;
	private boolean curPassCorrect;
	private boolean newPassNotInHistory;

	public PasswordStatus() {
	}

	public boolean isValidLength() {
		return isValidLength;
	}

	public void setValidLength(boolean isValidLength) {
		this.isValidLength = isValidLength;
	}

	public boolean isHasLowerCase() {
		return hasLowerCase;
	}

	public void setHasLowerCase(boolean hasLowerCase) {
		this.hasLowerCase = hasLowerCase;
	}

	public boolean isHasUpperCase() {
		return hasUpperCase;
	}

	public void setHasUpperCase(boolean hasUpperCase) {
		this.hasUpperCase = hasUpperCase;
	}

	public boolean isHasNumber() {
		return hasNumber;
	}

	public void setHasNumber(boolean hasNumber) {
		this.hasNumber = hasNumber;
	}

	public boolean isHasSpecial() {
		return hasSpecial;
	}

	public void setHasSpecial(boolean hasSpecial) {
		this.hasSpecial = hasSpecial;
	}

	public boolean isNewPassConfirmPassMatch() {
		return newPassConfirmPassMatch;
	}

	public void setNewPassConfirmPassMatch(boolean newPassConfirmPassMatch) {
		this.newPassConfirmPassMatch = newPassConfirmPassMatch;
	}

	public boolean isNewPassNotEqualOldPass() {
		return newPassNotEqualOldPass;
	}

	public void setNewPassNotEqualOldPass(boolean newPassNotEqualOldPass) {
		this.newPassNotEqualOldPass = newPassNotEqualOldPass;
	}

	public boolean isCurPassCorrect() {
		return curPassCorrect;
	}

	public void setCurPassCorrect(boolean curPassCorrect) {
		this.curPassCorrect = curPassCorrect;
	}

	public boolean isNewPassNotInHistory() {
		return newPassNotInHistory;
	}

	public void setNewPassNotInHistory(boolean newPassNotInHistory) {
		this.newPassNotInHistory = newPassNotInHistory;
	}

	public String toString() {
		return "PasswordStatus [isValidLength=" + isValidLength + ", hasLowerCase=" + hasLowerCase + ", hasUpperCase=" + hasUpperCase + ", hasNumber=" + hasNumber + ", hasSpecial=" + hasSpecial
				+ ", confirmMatch=" + newPassConfirmPassMatch + ", newPassUnique=" + newPassNotEqualOldPass + ", curPassCorrect=" + curPassCorrect + ", notInHistory=" + newPassNotInHistory + "]";
	}
	
	/*
	 * Returns true if all member variables are true
	 */
	public boolean allTrue() {
		if(!complexityAndConfirmTrue())
			return false;
		
		if(!newPassNotEqualOldPass)
			return false;
		
		if(!curPassCorrect)
			return false;
		
		if(!newPassNotInHistory)
			return false;
		
		logger.debug("all member variables are true.");
		return true;
	}
	
	/*
	 * Returns true if new password passes complexity and matches confirm pass
	 */
	public boolean complexityAndConfirmTrue() {
		if(!isValidLength)
			return false;
		
		if(!hasLowerCase)
			return false;
		
		if(!hasUpperCase)
			return false;
		
		if(!hasNumber)
			return false;
		
		if(!hasSpecial)
			return false;
		
		if(!newPassConfirmPassMatch)
			return false;
		
		logger.debug("passed complexity and confirm match");
		return true;
	}
}
