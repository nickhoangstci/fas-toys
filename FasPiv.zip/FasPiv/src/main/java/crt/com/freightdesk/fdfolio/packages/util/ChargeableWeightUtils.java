/** 
 * 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolio/packages/util/ChargeableWeightUtils.java,v 1.1.10.1 2010/08/22 23:08:44 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: ChargeableWeightUtils.java,v $
 *  Revision 1.1.10.1  2010/08/22 23:08:44  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.1  2004/09/15 13:25:34  ranand
 *  2.6 Baseline
 *
 * 
 */

package crt.com.freightdesk.fdfolio.packages.util;

import org.apache.log4j.Logger;



public class ChargeableWeightUtils
{

	protected transient Logger logger = Logger.getLogger (getClass());
	
	

	/*public static double calculateGrossVolumne(String uom,double length,double width, double height)
	{
		double grossVolume =0.0;
		if("ENGL".equalsIgnoreCase(uom))
		{
		   grossVolume=(length*0.0833333)*(width*0.0833333)*(height*0.0833333);
		   
		} 
		else
		{
		   grossVolume=(length*width*height)/1000000;
		}   
 				
	return grossVolume;
	}*/
		 
	public static double calculateChargeableWeight(String uom,double length,double width, double height,double grossWeight)
	{
		 
		double chargeableWeight =0.0;
		if("ENGL".equalsIgnoreCase(uom))
		{
		   chargeableWeight= (length * width * height )/194 ;
		}  
		else 
		{	
			chargeableWeight = (length * width * height )/7000 ;
        }  
              
	    if( grossWeight > chargeableWeight)
	    {
	       chargeableWeight = grossWeight;
	    }    
	  return chargeableWeight;		
	}
 } 
