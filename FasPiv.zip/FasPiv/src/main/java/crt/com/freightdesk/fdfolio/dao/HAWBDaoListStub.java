package crt.com.freightdesk.fdfolio.dao;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import crt.com.ntelx.awb.model.HAWB;

public class HAWBDaoListStub
{
	private static String [] shippers  = { "ACME", "BEEKON", "Domestic Shipper", "International Shippers" };
	private static String [] consignee = { "Bob's Burgers", "Coakleys Cokes", "Xeces", "ECD-9000", "Fish n' Chips", "Hampton Crabs" };
	private static String [] commodity = { "Electronics", "Produce/Grains", "Seafood/Meats", "Misc Goods", "Machine Parts", "Fresh Flowers"  };
	private static String [] airCodes  = { "JFK", "DCA", "LAG", "BWI", "DUL" }; 
	private static String [] dims      = { "12x12", "4X10", "30X30", "10X12" };
	private static String [] addrLine  = { "310 Sugar Lane", "33 Aaron Ave", "659 Whittier Road", "3939 Hollie Street" };
	private static String [] zips      = { "21075", "48201", "48202", "14428" };
	private static String [] cities    = { "Batimore", "Detroit", "Detroit", "Rochester" };
	private static String [] states    = { "Maryland", "Michigan", "Michigan", "New York" };
	private static String [] stateCodes= { "MD", "MI", "MI", "NY" };
	
	
	private static String [] refNums   = { "1Z 8A5 E94 03 4210 376 2", "3H 235 EE2 U9 4EC0 789 4", "4H 115 W32 E9 4EW0 719 2", "21 115 EE2 U9 4EW0 719 2",   
		                                   "44 1E5 542 3H 432E 7VD 4" };
	
	public static Map<Long, HAWB> getRandomHAWBMap()
	{
		Map<Long,HAWB> hawbList = new HashMap<Long,HAWB>();
		
		HAWB hawb = null;
		for ( int i = 0; i < 15; i++  )
		{
			hawb = getRandomHAWB();
			hawbList.put( hawb.getHawbID(), hawb );
		}
		
		return hawbList; 
	}
	
	protected static HAWB getRandomHAWB( )
	{
		HAWB hawb = new HAWB();
		
		int index = 0;
		
		Random rand = new Random();
		
		hawb.setDecValue( rand.nextInt( 10000 ) );
		
		hawb.setHawbID( rand.nextInt( 100001 ) );
		
		index = rand.nextInt( shippers.length   );
		hawb.setShipperName ( shippers[ index ] );
		
		index = rand.nextInt ( consignee.length   );
		hawb.setConsigneeName( consignee[ index ] );
		
		index = rand.nextInt ( commodity.length   );
		hawb.setCommodityName( commodity[ index ] );
		
		index = rand.nextInt   ( airCodes.length   );
		hawb.setLoadAirportCode( airCodes[ index ] );
		
		index = rand.nextInt        ( airCodes.length   );
		hawb.setDischargeAirportCode( airCodes[ index ] );
		
		hawb.setNumPackages( rand.nextInt( 5001 ) );
		
		hawb.setSubmissionDate( new Timestamp( System.currentTimeMillis() ) );
		
		index = rand.nextInt( refNums.length   );
		hawb.setRefNum      ( refNums[ index ] );
		
		return hawb;
	}
}
