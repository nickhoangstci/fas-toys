/** 
 * 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolio/common/Attic/SecurityProperties.java,v 1.4.4.2 2010/12/01 21:57:01 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: SecurityProperties.java,v $
 *  Revision 1.4.4.2  2010/12/01 21:57:01  mechevarria
 *  use just runtime home
 *
 *  Revision 1.4.4.1  2010/08/22 23:08:26  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.4  2006/04/19 22:47:49  ranand
 *  change the LCP_RUNTIME_HOME to FD_RUNTIME_HOME
 *
 *  Revision 1.3  2004/09/15 13:03:45  ranand
 *  2.6 Baseline
 *
 * 
 */


package crt.com.freightdesk.fdfolio.common;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.StringTokenizer;
import org.apache.log4j.Logger;

/**
 * @author  Biju Joseph
 */
public class SecurityProperties {

    protected static Logger logger = Logger.getLogger("crt.com.freightdesk.fdfolio.common.SecurityProperties");
    /**
     * The (only) instance of this Singleton
     */
    protected static SecurityProperties _instance;

    /**
     * The interal data structure used to store the properties
     */
    private Properties inner;

    /**
     * Gets the file URI for the given property.  The returned
     * URI has the correct file separator and uses the system
     * property LCP_RUNTIME_HOME the file root, and uses the property specified
     * in security.properties as the relative URL off of the LCP_RUNTIME_HOME.
     *
     * @param key The key for the property in security.properties
     * @return The URI for the file property corresponding to the key
     */
    public static String getURI (String key)
    {
        String uri = System.getProperty ("RUNTIME_HOME") + File.separator + getProperty (key);
        logger.info ("uri (" + key + "): " + uri);
        return uri;
    }

    /**
     * Gets the property using the given key
     * @param key The key for the mapping
     * @return The property corresponding to the key
     */
    public static String getProperty (String key) {
        return getInstance().inner.getProperty(key);
    }
    
    /**
     * Requires a secret to be initialized.
     */
    public synchronized static void load (InputStream inputStream, int secret) 
        throws IOException 
    {
        if (secret != 187568912) {
            logger.error ("Where are you coming from?");
            throw new RuntimeException ("Unauthorized access to SecurityProperties.load()");
        }
        getInstance().inner.load(inputStream);
    }    

    /**
     * Only constructor is declared private.
     */
    private SecurityProperties() {
        inner = new Properties();
    }
    
    /**
     * The getInstance() method for this Singleton.
     * Creates an instance if necessary.
     */
    private static SecurityProperties getInstance() {
        if (_instance == null) {
            _instance = new SecurityProperties();
        }
        return _instance;
    }
    
	public static String doesItExist(String it,String propertyName) {
		String propertyValue = getProperty(propertyName);
		StringTokenizer stringTokenizer = new StringTokenizer(propertyValue,",");
		while(stringTokenizer.hasMoreTokens()) {
			String token = stringTokenizer.nextToken();			
			if(it.equalsIgnoreCase(token)) {
				return "Y";
			}
		}
		return "N";		
	}
}
