/**
 * 
 */
package crt.com.freightdesk.fdfolio.common;

import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;

import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;


/**
 * @author jhansford
 *
 */
/**
 * @author jhansford
 *
 */
public class ExcelDataContainer 
{
	private static final int MAX_EXCEL_COLUMNS = 256;
	
	private InputStream inStream =  null;            // Input Stream of the Excel File itself 
	
	private FormulaEvaluator evaluator = null;   // Evaluates Formulas in Excel Cells.  Used in conversion to string.
	private Workbook         wb        = null;   // Represents Excel Workbook
	
	private ArrayList< ArrayList<String > > data = null;
	
	private  ExcelContinueIterTester iterTester = null;
	
   /**
    * Constructor for ExcelDataContainer
    * @param inStream
    */
	public ExcelDataContainer( InputStream inStream )
	{
		this.inStream = inStream;
	}
	
	// Open Workbook
	//  
	//   Open workbooks and set Workbook and Evaluator member variables 
	//
	public void openWorkbook(/*InputStream inStream */) throws ExcelContainerWBOpenException
	{		
		try
		{			
			wb = WorkbookFactory.create( inStream ); 			
			evaluator = wb.getCreationHelper().createFormulaEvaluator();
		}
		catch ( Exception e )
		{
			e.printStackTrace();
			throw new ExcelContainerWBOpenException();
		}
	}
	
	public int indexOfSheet( String sheetname )
	{
		if ( wb != null )
			return wb.getSheetIndex( sheetname );
		else
			return -2;
	}
	
	public String sheetNamesToString() {
		String names = "";
		for(int i=0; i < wb.getNumberOfSheets(); i++) {
			names = names + " '"+wb.getSheetName(i)+"'";
		}
		return names;
	}
	
   /**
    * Loads data as strings from excel into this class
    * 	
    * @param sheetNum
    * @throws IOException
    */
	public void loadData( int sheetNum ) throws IOException, ExcelContainerGetValueException
	{
		//openWorkbook( inStream );
		Sheet sheet = wb.getSheetAt( sheetNum );
		
		data = new ArrayList< ArrayList<String> >();
		internalLoadData( sheetNum, 0, sheet.getPhysicalNumberOfRows(), 0, MAX_EXCEL_COLUMNS -1 );
	}
	
   /**
    *  Loads Data from Excel as strings into this class from startRow to endRow and 
    *  startCol to endCol.  Note that rows and columns are zero based, where Excel is one based.
    * 
    * @param startRow first row to start collecting data.  Zero based.
    * @param endRow   last row to collect data from.  Zero based.  Inclusive.
    * @param startCol first column to start collect data from. Zero based.
    * @param endCol   last column to collect data from. Zero based. Inclusive.
    */
	public void loadData( int sheetNum, int startRow, int endRow, int startCol, int endCol ) throws IOException, ExcelContainerGetValueException
	{
		//openWorkbook( inStream );
		
		data = new ArrayList< ArrayList<String> >();
		internalLoadData(sheetNum, startRow, endRow, startCol, endCol);
	}
	
	
	/**
	 *  Remove all data 
	 */
	public void clearData()
	{
		for ( ArrayList<String> l : data )
		{
			l.clear();
		}
		
		data.clear();
	}

   /**
    * Set Continue Iteration Tester. If you need to abort iterating through all of the data in excel sheet, create a
    * ExcelContinueIterTester and set it here.	
    * @param iterTester
    */
	public void setContinueIterTester(  ExcelContinueIterTester iterTester )
	{
		this.iterTester = iterTester;
	}
	
	// Continue Iteration
	//
	//   If an ExcelContinueIterTester has been set, consult it about contining.  Otherwise just return true.
	//
	protected boolean continueIter( Row row  )
	{
		if ( iterTester != null )
			return iterTester.continueIter(row );
		
		return true;
	}

	// Internal Load Data
	//
	//   Internal Version of load data to be shared among public versions
	//
	private void internalLoadData(int sheetNum, int startRow, int endRow,
			int startCol, int endCol) throws ExcelContainerGetValueException
	{
		Sheet sheet = wb.getSheetAt( sheetNum );
		Cell  cell  = null;
		Row   row   = null;
		
		// Here we loop through the rows of the sheet with the row iterator and 
		//   check to be sure that we only add values to the data container if we are 
		//   in the specified range.  Using the iterator prevents us from 
		//   storing unused cells. Note counter i is incremented in for loop 
		//
		int i = 0;
		for ( Iterator<Row> rowIter = sheet.rowIterator(); rowIter.hasNext(); i++ )
		{
			if ( i >= startRow && i <= endRow)
			{
				// Get the excel row and make room for it in our Excel Container. 
				//
				row = rowIter.next();
				
				// We may need to abort iteration early, to be efficent.
				//
				if ( !continueIter( row ) )
				{
					break;
				}	
				
				data.add( new ArrayList<String>() );
				
				// Similar to above we use the cell iterator and check our bounds with the counter 
				//   j that is used in the for loop
				//
				int j = 0;
				for ( Iterator<Cell> cellIter = row.cellIterator(); cellIter.hasNext(); j++ )
				{
					cell = cellIter.next();
					
					int gap;
					for ( gap = j; gap < cell.getColumnIndex(); gap++ ) 
						data.get( i ).add( "" );
					j = gap;
					
					if ( j >= startCol && j <= endCol )
					{	
						try 
						{
							data.get( i ).add( getStrFromCell( cell ) );
						}
						catch ( Exception e )
						{
							e.printStackTrace();
							
							ExcelContainerGetValueException exp = new ExcelContainerGetValueException(); 
							exp.setRow( i );
							exp.setCol( cell.getColumnIndex() );

							throw exp;

						}
					}					
				}
			}
		}
	}
	
	// Get String From Cell
	//
	//   This converts whatever is in this cell to a string and returns said value
	//
	protected String getStrFromCell( Cell cell )
	{

		if ( cell == null )
			return "";
		
		String returnVal = null;
		switch ( cell.getCellType() )
		{
			case Cell.CELL_TYPE_NUMERIC : 
				returnVal = String.valueOf( cell.getNumericCellValue() );
		    	break;
		    case Cell.CELL_TYPE_STRING : 
		    	returnVal = cell.getRichStringCellValue().toString();
		    	break;
		    case Cell.CELL_TYPE_FORMULA :
		    	returnVal = getStrFromCell(evaluator.evaluateInCell(cell));
		    	break;
		    default:
		    	returnVal = "";
		}
		
		return returnVal;
	}
	
	// Get Date Format From Double
	//
	//    Convert a double into a date in string format.  This is necessary because excel stores dates as numbers
	//    and we store everything as strings in our lists.  So if the user requests a date this conversion is necessary.
	//
	protected String getDateFromDouble( double excelNumericValue, String dateFormat  )
	{
		Date             dateValue     = DateUtil.getJavaDate( excelNumericValue );
		SimpleDateFormat dateFormatter = new SimpleDateFormat( dateFormat );
		
		return dateFormatter.format(dateValue);
	}
	
   /**
    * Get value at row and col.  Zero based.
    * @param row Which row.  Zero Based.
    * @param col
    * @return String at cell row and col
    */
	public String getValue( int row, int col ) throws ExcelContainerGetValueException
	{
		try
		{
			return data.get( row ).get( col );
		}
		catch ( Exception e )
		{
			// debug
			e.printStackTrace();
			
			ExcelContainerGetValueException exp = new ExcelContainerGetValueException(); 
			exp.setRow( row );
			exp.setCol( col );

			throw exp;
		}
	}
	
   /**
    * Get this value in date format	
    * @param row  Which row.  Zero Based.
    * @param col Which Col. Zero Based.
    * @return
    */
	public String getDate( int row, int col, String dateFormat )
	{
		String result = null;
		try
		{
			Double d = Double.parseDouble( data.get( row ).get( col ) );
			result = getDateFromDouble( d, dateFormat );
		}
		catch ( Exception e )
		{
			result = "";
		}
		
		return result;
	}
	
   /**
    * Returns number of rows.  Note that load data need so be called before this to get a meaningful result.	
    * @return number of rows.
    */
    public int getNumRows()
    {
    	return data.size();
    }
    
}
