package crt.com.freightdesk.fdfolio.jobs;

import java.sql.Connection;
import java.util.List;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import crt.com.freightdesk.fdfolio.dao.QuartzDao;
import com.freightdesk.fdcommons.FDSuiteProperties;
import com.freightdesk.fdcommons.asyncprocess.AsyncProcessManager;
import com.freightdesk.fdcommons.asyncprocess.AsyncProcessingLogModel;
import crt.com.ntelx.nxcommons.email.EmailUtil;
import com.freightdesk.fdfolio.useraccess.model.SystemUserModel;

public class passExpireWarnJob implements Job {

	protected QuartzDao quartzDao = null;
	protected Logger logger = Logger.getLogger("passExpireWarnJob");

	@Override
	public void execute(JobExecutionContext exeContext) throws JobExecutionException {
		logger.debug("Job start");
		Connection connection = null;

		try {
			String sendEmails = FDSuiteProperties.getProperty("ENABLE_SENDMAIL");
			
			DataSource dataSource = (DataSource) exeContext.getMergedJobDataMap().get("dataSource");

			connection = dataSource.getConnection();

			quartzDao = new QuartzDao();
			quartzDao.setConnection(connection);

			// list of users to receive email warning
			List<SystemUserModel> loginList = quartzDao.getPasswordExpireUsers();
			
			if (sendEmails.equalsIgnoreCase("true")) {
				// for security logging
				AsyncProcessingLogModel asyncLogModel = new AsyncProcessingLogModel();
				AsyncProcessManager asyncRequestManager = new AsyncProcessManager();

				for (SystemUserModel login : loginList) {
					// initialize log
					asyncLogModel.init("QUARTZ", "PUBLIC", "EMAIL", "ADMIN", "Attempting to send email to " + login.getEmail(), "0.0.0.0");

					boolean sentEmail = EmailUtil.sentPasswordExpireEmail(login);

					// log result
					if (sentEmail)
						asyncRequestManager.logResult(asyncLogModel, true, "Emailed login expiration warning to " + login.getEmail(), "doPasswordExpireWarn");
					else
						asyncRequestManager.logResult(asyncLogModel, false, "Failed to email login expiration warning to " + login.getEmail(), "doPasswordExpireWarn");
				}

			}
			

		} catch (Exception ex) {
			//ex.printStackTrace();
			logger.error("Exception : " + ex.getMessage());
		}
		logger.debug("Job complete.");
	}

}
