/** 
 * 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolioweb/setup/form/Attic/PasswordChangeForm.java,v 1.2.2.2 2010/08/22 23:08:39 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: PasswordChangeForm.java,v $
 *  Revision 1.2.2.2  2010/08/22 23:08:39  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.2.2.1  2009/08/27 15:11:44  mechevarria
 *  todo cleanup
 *
 *  Revision 1.2  2006/12/11 19:58:08  ranand
 *  added new property product
 *
 *  Revision 1.1  2004/09/15 13:36:28  asingh
 *  2.6 Baseline
 *
 * 
 */


package crt.com.freightdesk.fdfolioweb.setup.form;

import com.freightdesk.fdfolio.common.BasicButtonsForm;


public class PasswordChangeForm extends BasicButtonsForm 
{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
     * 
     */
    private String oldPassword;
    private String newPassword;
    private String confirmPassword;
	private String process;
	private String systemUserId;
    
    // This property is used when user logged in first time and forced to changed the password.
    // User will be redirected to the product for which he loggedIn.  
    private String product;
    
    public PasswordChangeForm()
    {
        super();
    }
    /**
     * @return
     */
    public String getConfirmPassword()
    {
        return confirmPassword;
    }

    /**
     * @return
     */
    public String getNewPassword()
    {
        return newPassword;
    }

    /**
     * @return
     */
    public String getOldPassword()
    {
        return oldPassword;
    }

    /**
     * @param confirmPassword
     */
    public void setConfirmPassword(String confirmPassword)
    {
        this.confirmPassword = confirmPassword;
    }

    /**
     * @param newPassword
     */
    public void setNewPassword(String newPassword)
    {
        this.newPassword = newPassword;
    }

    /**
     * @param oldPassword
     */
    public void setOldPassword(String oldPassword)
    {
        this.oldPassword = oldPassword;
    }

	public void setProcess(String process)
    {
        this.process = process;
    }

	public String getProcess()
    {
        return process;
    }

	public void setSystemUserId(String systemUserId)
    {
        this.systemUserId = systemUserId;
    }

	public String getSystemUserId()
    {
        return systemUserId;
    }
    public String getProduct()
    {
        return product;
    }
    public void setProduct(String product)
    {
        this.product = product;
    }
    
    public void reset() {
    	oldPassword = "";
        newPassword = "";
        confirmPassword = "";
    }
}
