package crt.com.freightdesk.fdfolio.orghierarchy;

import java.io.Serializable;
import java.util.Comparator;

import org.apache.log4j.Logger;

import com.freightdesk.fdfolio.orghierarchy.model.OrghierarchyModel;

public class OrgComparator implements Comparator<OrghierarchyModel>, Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Logger logger = Logger.getLogger(OrgComparator.class);
	private boolean ascending;
	private String colName;

	public OrgComparator(String colName, boolean ascending) {
		this.ascending = ascending;
		this.colName = colName;
	}

	@SuppressWarnings("unchecked")
	public int compare(OrghierarchyModel o1, OrghierarchyModel o2) {
		int result = 0;

		try {
			Object value1 = null;
			Object value2 = null;

			
			if (colName.equalsIgnoreCase("orgName")) {
				value1 = o1.getOrgName();
				value2 = o2.getOrgName();
			} else if (colName.equalsIgnoreCase("parentOrgName")) {
				value1 = o1.getParentOrgName();
				value2 = o2.getParentOrgName();
			} else if (colName.equalsIgnoreCase("HierarchyTypeCode")) {
				value1 = o1.getOrgHierarchyTypeCode();
				value2 = o2.getOrgHierarchyTypeCode();
			} else if (colName.equalsIgnoreCase("city")) {
				value1 = o1.getCity();
				value2 = o2.getCity();
			} else if (colName.equalsIgnoreCase("stateProvinceCode")) {
				value1 = o1.getStateProvinceCode();
				value2 = o2.getStateProvinceCode();
			} else if (colName.equalsIgnoreCase("CountryName")) {
				value1 = o1.getCountryName();
				value2 = o2.getCountryName();
			} else {
				logger.warn("Could not map " + colName + " to class attribute");
			}

			// Null is lesser than anything else.
			if ((value1 == null) && (value2 == null)) {
				result = 0;
			} else if ((value1 == null) && (value2 != null)) {
				result = -1;
			} else if ((value1 != null) && (value2 == null)) {
				result = 1;
			} else if (value1 instanceof Comparable) {
				// the attribute values are Comparable, we have hit the JackPot.  We have absolutely nothing intelligent to do
				@SuppressWarnings("rawtypes")
				Comparable comp1 = (Comparable) value1;
				@SuppressWarnings("rawtypes")
				Comparable comp2 = (Comparable) value2;
				result = comp1.compareTo(comp2);
			} else {
				logger.warn("Dont know how to sort by " + colName);
			}

			if (result == 0) {
				result = -1; // to help in table sort
			}

			if (!ascending) {
				result = 0 - result;
			}

		} catch (Exception ex) {
			//ex.printStackTrace();
			logger.error("Exception : " + ex.getMessage());
		}

		return result;
	}

}
