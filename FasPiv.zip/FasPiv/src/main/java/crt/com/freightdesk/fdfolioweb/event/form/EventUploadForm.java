package crt.com.freightdesk.fdfolioweb.event.form;

//import org.apache.struts.action.ActionForm;
//import org.apache.struts.upload.FormFile;
import crt.com.freightdesk.fdfolio.setup.form.FormFile;

public class EventUploadForm {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private FormFile formFile;
    private String maxRequestSize;
    private String btnUpLoad;
    private String btnCancel;
    
	public FormFile getFormFile() {
		return formFile;
	}
	public void setFormFile(FormFile formFile) {
		this.formFile = formFile;
	}
	public String getMaxRequestSize() {
		return maxRequestSize;
	}
	public void setMaxRequestSize(String maxRequestSize) {
		this.maxRequestSize = maxRequestSize;
	}
	public String getBtnUpLoad() {
		return btnUpLoad;
	}
	public void setBtnUpLoad(String btnUpLoad) {
		this.btnUpLoad = btnUpLoad;
	}
	public String getBtnCancel() {
		return btnCancel;
	}
	public void setBtnCancel(String btnCancel) {
		this.btnCancel = btnCancel;
	}
}
