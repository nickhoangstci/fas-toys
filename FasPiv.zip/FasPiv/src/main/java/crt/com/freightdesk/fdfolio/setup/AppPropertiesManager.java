package crt.com.freightdesk.fdfolio.setup;

import java.sql.SQLException;
import java.util.List;
import java.util.Properties;

import org.apache.log4j.Logger;

import crt.com.freightdesk.fdfolio.dao.FasAppPropertiesDAO;
import crt.com.freightdesk.fdfolio.setup.model.FasAppProperties;
import com.freightdesk.fdcommons.ApplicationProperties;

public class AppPropertiesManager
{
	private static Logger logger = Logger.getLogger(AppPropertiesManager.class);

	public void resetAppProperties() throws SQLException
	{
		FasAppPropertiesDAO propsDAO = new FasAppPropertiesDAO();
		List<FasAppProperties> appPropsList = propsDAO.readAll();

		Properties props = new Properties();

		logger.debug("Reading Props: ");
		for (FasAppProperties appProp : appPropsList)
		{
			logger.debug("Adding Prop: " + appProp.getKey() + " --- "
					+ appProp.getValue());
			props.setProperty(appProp.getKey(), appProp.getValue());
		}

		ApplicationProperties.reset();
		ApplicationProperties.setProps(props);

	}
	
	public void setAppProperty( String key, String value, String userID, String domainname ) throws SQLException
	{
		logger.debug("setAppProperty Begin(): ");
		
		FasAppPropertiesDAO propsDAO = new FasAppPropertiesDAO();
		propsDAO.setProperty( key , value, userID, domainname );
		ApplicationProperties.getProps().setProperty( key , value );
	}
	
	public FasAppProperties getLastUpdateInfo() throws SQLException
	{
		FasAppPropertiesDAO propsDAO = new FasAppPropertiesDAO();
		return propsDAO.getLastUpdateInfo();
	}

}
