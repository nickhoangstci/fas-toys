/** 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolioweb/setup/action/EditDataAction.java,v 1.11.2.3 2010/08/22 23:08:38 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: EditDataAction.java,v $
 *  Revision 1.11.2.3  2010/08/22 23:08:38  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.11.2.2  2009/09/23 18:02:17  mechevarria
 *  import clean via eclipse
 *
 *  Revision 1.11.2.1  2009/01/23 15:10:34  mechevarria
 *  updated code to be compatible with struts 1.3.10
 *
 *  Revision 1.11  2007/01/03 07:25:59  atripathi
 *  redundant message removed
 *
 *  Revision 1.10  2006/09/12 11:34:23  dkumar
 *  called setActionMessage method from within try block rather than
 *  after catch block.(bug 1763)
 *
 *  Revision 1.9  2006/05/11 22:18:46  aarora
 *  Small change as the SessionKey class has been added to com.freightdesk.fdfolio.commons
 *
 *  Revision 1.8  2006/04/19 22:49:28  ranand
 *  Changes to support composite primary key
 *
 *  Revision 1.7  2006/04/18 13:29:21  dkumar
 *  changed line 267 to remove "invokedFrom" parameter from being processed for update
 *
 *  Revision 1.6  2006/04/12 23:37:11  aarora
 *  Organized imports
 *
 *  Revision 1.5  2006/03/28 21:22:59  aarora
 *  Repackaging of fdcommons
 *
 *  Revision 1.4  2006/03/28 13:27:43  uvasundhara
 *  setActionMethod is called
 *
 *  Revision 1.3  2006/02/17 11:44:02  pjain
 *  Messages for edit data
 *
 *  Revision 1.2  2005/10/12 20:01:13  pjain
 *  excluded process from metadata
 *
 *  Revision 1.1  2005/10/01 16:07:01  pjain
 *  refactored edit data
 *
 *  Revision 1.7  2005/10/01 15:51:26  amrinder
 *  Added access control logic for reference data reload
 *
 *  Revision 1.6  2005/09/15 14:11:45  pjain
 *  Baseline
 *
 */

package crt.com.freightdesk.fdfolioweb.setup.action;

import java.sql.SQLException;
import java.util.Enumeration;
import java.util.HashMap;
import com.freightdesk.fdfolio.common.LcpReferenceData;
import com.freightdesk.fdcommons.OptionBean;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import crt.com.freightdesk.fdfolio.common.IncludesUtil;
import com.freightdesk.fdcommons.ActionErrors;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.log4j.Logger;
import com.opensymphony.xwork2.ActionSupport;
import org.apache.struts2.ServletActionContext;
import com.freightdesk.fdcommons.Credentials;
import com.freightdesk.fdcommons.SessionKey;
import com.freightdesk.fdcommons.SessionStore;
import crt.com.freightdesk.fdfolio.dao.EditDataDAO;
import java.util.List;
import java.util.Map;
import java.util.*;

/**
 * The Struts Action class associated with EditData.jsp and the EditDataForm.
 * 
 * @author Pankaj Jain
 * @author Rajender Anand
 * @author Amrinder Arora
 */
public class EditDataAction extends ActionSupport implements ServletRequestAware
{
    private String loginTimeRoleMsg;
    protected Logger logger = Logger.getLogger(getClass());
    private String process;
    private String lastUpdateUserId;
    
    private String table;
    private String tableName;
    private String primaryKeyColumn;
    Map metaData = null;
    List primaryKeys = null;
    List<String> primaryKeysStrList = null;
    private String primaryKey;
    private String save;
    private String addrow;
    private String delrow;
    List referenceTableList;
    List<String> referenceTableStrList;
    private String invokedFrom;
    private String systemCode;
    private String systemName;
    private String systemDesc;
    private String domainName;
    private String status;
    private String createUserId;
    private String createTimestamp;
    private String lastUpdateTimestamp;
    private String basicBtnClicked;
    private String action;
    
    private String messageKey;
	
    HttpServletRequest request = ServletActionContext.getRequest();
    HttpSession session = request.getSession();
    SessionStore store = SessionStore.getInstance(session);
    Credentials credentials = (Credentials) store.get(SessionKey.CREDENTIALS);

	
	
	/** 
     *  Process the specified HTTP request.
     */
	public String execute() throws Exception {
	
	request = ServletActionContext.getRequest();
        session = request.getSession();
        store = SessionStore.getInstance(session);
        credentials = (Credentials) store.get(SessionKey.CREDENTIALS);
                
	logger.debug("entering editDataAction: execute.");       
        
        loginTimeRoleMsg = IncludesUtil.getWelcomeMsg(credentials)+ "<br>" + IncludesUtil.getExpireMsg(credentials);
	   
	String[] messageKeyObject=new String[1];
	messageKey=" ";
        
        String[] tableNameArray = getTableName().split("\\s*,\\s*");
        setTableName(tableNameArray[(tableNameArray.length)-1]); 
        
        if ("refreshData".equalsIgnoreCase(getProcess())) {
            return refreshData();
        }
        
        String tableName = getTableName();
        if (tableName == null) {
            return displayPage();
        }
        Map data = null;
        EditDataDAO dataDAO = new EditDataDAO();

        try {
            String primaryKeyColumn = dataDAO.getPrimaryKeyColumnName(tableName);
            setPrimaryKeyColumn(primaryKeyColumn);
            logger.debug("primaryKeyColumn:"+primaryKeyColumn);
            List keys = dataDAO.retrieveAllPrimaryKeys(tableName);
            logger.debug("keys:"+keys);
            
            setPrimaryKeys(keys);
            setPrimaryKeysStrList(convertPrimaryKeysToStringList(primaryKeys));
            String addrow = getAddrow();
            String delrow = getDelrow(); 

            if (addrow == null) {
                if(request.getParameter("primaryKey") != null) {
                    primaryKey = request.getParameter("primaryKey");
                    if(request.getParameter("save") != null) {
                        try {
                            dataDAO.update(tableName, getData(request, credentials), primaryKey, primaryKeyColumn);
                            refreshReferenceData(request.getSession(), credentials.getDomainName());
                            messageKey="setuphome.editdata.update.success";
                            messageKeyObject[0]=messageKey;
							addActionMessage(getText("setuphome.editdata.save.success"));
                        }
                        catch(Exception e) {
                            ActionErrors actionErrors = new ActionErrors();                         
                            addActionError(getText("errors.header"));
							addActionError(getText("setuphome.editdata.update.error"));                           
                            logger.error("Error while updating record :"+e);
                        }                      
                    } else if (delrow != null && "true".equalsIgnoreCase(delrow)) {
                        try {
                            dataDAO.delete(tableName, primaryKey, primaryKeyColumn);
                            refreshReferenceData(request.getSession(), credentials.getDomainName());
                            keys = dataDAO.retrieveAllPrimaryKeys(tableName);
                            setPrimaryKeys(keys);
                            if(keys != null && !keys.isEmpty()) {
                                primaryKey = keys.get(0) + "";
                                data = dataDAO.retrieve(tableName,primaryKey, primaryKeyColumn);
                                setMetaData(data);
                                setPrimaryKey(primaryKey);
								setPrimaryKeysStrList(convertPrimaryKeysToStringList(primaryKeys));
                            } else {
                                setMetaData(null);
                                setPrimaryKey(null);
                            }
                            setDelrow(null);
                            messageKey="setuphome.editdata.delete.success";
                            messageKeyObject[0]=messageKey;                            
							addActionMessage(getText("setuphome.editdata.delete.success"));
							                         
                            
                            return "display";
                        }
                        catch(Exception e) {
                            ActionErrors actionErrors = new ActionErrors();                           
                            addActionError(getText("setuphome.editdata.delete.error"));
                            
                            logger.error("Error while deleting record :"+e);
                        }
                    }
                    data = dataDAO.retrieve(tableName, primaryKey, primaryKeyColumn);
                    setMetaData(data);
                    setPrimaryKey(primaryKey);
					setPrimaryKeysStrList(convertPrimaryKeysToStringList(primaryKeys));
                    return "display";
                }
                if(keys != null && !keys.isEmpty()) {
                    String primaryKey = keys.get(0) + "";
                    data = dataDAO.retrieve(tableName,primaryKey, primaryKeyColumn);
                    setMetaData(data);
                    setPrimaryKey(primaryKey);
					setPrimaryKeysStrList(convertPrimaryKeysToStringList(primaryKeys));
                    processMetaData(data);
                }
            } else {
                if (request.getParameter("save") != null) {
                    try {
                        dataDAO.insert(tableName, getData(request, credentials));
                        refreshReferenceData(request.getSession(), credentials.getDomainName());
                        messageKey="setuphome.editdata.save.success";
                        messageKeyObject[0]=messageKey;
                        
                        addActionMessage(getText("setuphome.editdata.save.success"));
                    } catch(Exception e) {
                        addActionError(getText("setuphome.editdata.save.error"));
                        logger.error("Error while inserting record :"+e);
                    }					                
                }
                data = dataDAO.retrieve(tableName);
                setMetaData(data);
            }


        }catch(SQLException sqEx){
            logger.error("  Exception in execute  " + sqEx.getMessage());
        }
        return displayPage();
    }

    public String displayPage() throws Exception {
        setReferenceTableList(EditDataDAO.getReferenceTableList());
        
        referenceTableStrList = convertReferenceTableListToStringList ((List<OptionBean>) referenceTableList);
        
        setPrimaryKeysStrList ( convertPrimaryKeysToStringList (primaryKeys));
        
        return "display";
    }

    public String refreshData() throws Exception {
        logger.debug ("refreshData(): begin");
        
        request = ServletActionContext.getRequest();
        session = request.getSession();
        store = SessionStore.getInstance(session);
        credentials = (Credentials) store.get(SessionKey.CREDENTIALS);
        
        refreshReferenceData (request.getSession(), null);
        
        
        Map data = null;
        EditDataDAO dataDAO = new EditDataDAO();
        
        String[] tableNameArray = getTableName().split("\\s*,\\s*");
        String[] primaryKeyArray = getPrimaryKey().split("\\s*,\\s*");
        String[] primaryKeyColumnArray = getPrimaryKeyColumn().split("\\s*,\\s*");
        
        List keys = dataDAO.retrieveAllPrimaryKeys(tableNameArray[(tableNameArray.length)-1]);
        setPrimaryKeys(keys);
        String primaryKey = primaryKeyArray[(primaryKeyArray.length)-1] + "";
        
        data = dataDAO.retrieve(tableNameArray[(tableNameArray.length)-1], primaryKeyArray[(primaryKeyArray.length)-1], getPrimaryKeyColumn());
        setMetaData(data);
        setPrimaryKey(primaryKey);
        processMetaData(data);
        
        return displayPage();
    }

    /**
     * Refreshes the refrence data by delegating call to LcpReferenceData.
     *
     * @param request HttpServletRequest
     * @param domain The domain for which the reference data should be loaded. 
     * If domain is null, reference data is loaded for all domains
     */
    private void refreshReferenceData(HttpSession session, String domain) {
        logger.debug ("refreshReferenceData(): begin, for domain: " + domain);
        SessionStore sessionStore = SessionStore.getInstance (session);
        
        HashMap<String, String> accessControlList = (HashMap<String, String>) sessionStore.get(SessionKey.ACCESS_CONTROL_LIST);
        LcpReferenceData lcpRefData = LcpReferenceData.getInstance(credentials.getDomainName());
        if (domain == null) {
            if (accessControlList.containsKey("ADM31")) {               
                lcpRefData.clearReferenceData ();
            }
        } else if ((accessControlList.containsKey("ADM31")) ||  (accessControlList.containsKey("ADM32"))) {
            lcpRefData.clearReferenceData (domain);
        }
    }

    private Map getData(HttpServletRequest request, Credentials credentials) {
        Map data = new HashMap();
        Enumeration paramNames = request.getParameterNames();
        while (paramNames.hasMoreElements()) {
            String paramName = (String)paramNames.nextElement();
            if(!"save".equals(paramName) && !"primaryKey".equals(paramName)&& !"tableName".equals(paramName) 
                    && !"addrow".equals(paramName) && !"delrow".equals(paramName) 
                    && !"referenceTableList".equals(paramName) && !"process".equals(paramName)&& !"invokedFrom".equals(paramName))
            {
                String value = request.getParameter(paramName);

                // Override CREATEUSERID, LASTUPDATEUSERID
                if (EditDataDAO.CREATEUSERID.equals(paramName) || EditDataDAO.LASTUPDATEUSERID.equals(paramName))
                    value = credentials.getUserId();

                if("".equals(value) || value == null)
                {
                    data.put(paramName, "NULL");
                }else{
                    data.put(paramName, "'"+value+"'");
                }
            }
        }

        return data;
    }
	
    public String getLoginTimeRoleMsg() {
        return loginTimeRoleMsg;
    }

    public void setLoginTimeRoleMsg(String loginTimeRoleMsg) {
        this.loginTimeRoleMsg = loginTimeRoleMsg;
    }
	
    public void setServletRequest(HttpServletRequest request) {
        this.request = request;
    }

    public HttpServletRequest getServletRequest() {
        return this.request;
    }
    
    public String getAction() {
        return action;
    }
    
    public void setAction(String action) {
        this.action = action;
    }
	
    public String getTable() {
        return table;
    }
    
    public void setTable(String table) {
        this.table = table;
    }
    
    public String getTableName() {
        if (tableName == null) {
            return "";
        } else {
            return tableName;
        }
    }
    
    public void setTableName(String tableName) {
        this.tableName = tableName;
    }
    
    public String getPrimaryKeyColumn() {
        return primaryKeyColumn;
    }
   
    public void setPrimaryKeyColumn(String primaryKeyColumn) {
        this.primaryKeyColumn = primaryKeyColumn;
    }
    
    public void setMetaData (Map metaData){
        this.metaData = metaData;
    }

    public Map getMetaData(){
        return metaData;
    }
    
    public void setPrimaryKeys (List primaryKeys){
        this.primaryKeys = primaryKeys;
    }
    
    public List getPrimaryKeys (){
        return primaryKeys;
    }
    
    public void setPrimaryKeysStrList (List<String> primaryKeysStrList){
        this.primaryKeysStrList = primaryKeysStrList;
    }
    
    public List<String> getPrimaryKeysStrList (){
        return primaryKeysStrList;
    }

    public String getPrimaryKey() {
	return primaryKey;
    }
	
    public void setPrimaryKey(String primaryKey) {
	this.primaryKey = primaryKey;
    }
    
    public String getSave() {
	return save;
    }
	
    public void setSave(String save) {
	this.save = save;
    }
    
    public String getAddrow() {
        return addrow;
    }
   
    public void setAddrow(String addrow) {
        this.addrow = addrow;
    }
    
    public String getDelrow() {
        return delrow;
    }
   
    public void setDelrow(String delrow) {
        this.delrow = delrow;
    }
    
    public void setReferenceTableList(List referenceTableList) {
        this.referenceTableList = referenceTableList;
    }
    
    public List getReferenceTableList() {
        return referenceTableList;
    }
    
    public void setReferenceTableStrList(List<String> referenceTableStrList) {
        this.referenceTableStrList = referenceTableStrList;
    }
    
    public List<String> getReferenceTableStrList() {
        return referenceTableStrList;
    }
    
    public String getProcess() {
	return process;
    }
	
    public void setProcess(String process) {
	this.process = process;
    }
    
    public String getSystemCode() {
	return systemCode;
    }
	
    public void setSystemCode(String systemCode) {
	this.systemCode = systemCode;
    }
    
    public String getSystemName() {
	return systemName;
    }
	
    public void setSystemName(String systemName) {
	this.systemName = systemName;
    }
    
    public String getSystemDesc() {
	return systemDesc;
    }
	
    public void setSystemDesc(String systemDesc) {
	this.systemDesc = systemDesc;
    }
    
    public String getDomainName() {
	return domainName;
    }
	
    public void setDomainName(String domainName) {
	this.domainName = domainName;
    }
    
    public String getStatus() {
	return status;
    }
	
    public void setStatus(String status) {
	this.status = status;
    }
    
    public String getCreateUserId() {
	return createUserId;
    }
	
    public void setCreateUserId(String createUserId) {
	this.createUserId = createUserId;
    }
    
    public String getLastUpdateUserId() {
	return lastUpdateUserId;
    }
	
    public void setLastUpdateUserId(String lastUpdateUserId) {
	this.lastUpdateUserId = lastUpdateUserId;
    }
    
    public String getCreateTimestamp() {
	return createTimestamp;
    }
	
    public void setCreateTimestamp(String createTimestamp) {
	this.createTimestamp = createTimestamp;
    }
    
    public String getLastUpdateTimestamp() {
	return lastUpdateTimestamp;
    }
	
    public void setLastUpdateTimestamp(String lastUpdateTimestamp) {
	this.lastUpdateTimestamp = lastUpdateTimestamp;
    }
    
    public String getInvokedFrom() {
	return invokedFrom;
    }
    public void setInvokedFrom(String invokedFrom) {
	this.invokedFrom = invokedFrom;
    }
    
    public String getBasicBtnClicked() {
        return basicBtnClicked;
    }

    public void setBasicBtnClicked(String basicBtnClicked) {
        this.basicBtnClicked = basicBtnClicked;
    }
	
    private List<String> convertReferenceTableListToStringList (List<OptionBean> referenceTableBeanList) {
        List<String> theReferenceTableStrList = new ArrayList<String>();
        
        Iterator<OptionBean> itrReferenceTable = referenceTableBeanList.iterator();
        OptionBean optBean = new OptionBean();
        while (itrReferenceTable.hasNext()) {
            optBean = itrReferenceTable.next();
            theReferenceTableStrList.add(optBean.getLabel());            
        }
        
        return theReferenceTableStrList;
    }
    
    private List<String> convertPrimaryKeysToStringList (List primaryKeysList) {
        List<String> thePrimaryKeysStrList = new ArrayList<String>();
        
        Iterator<?> itrPrimaryKeys = primaryKeysList.iterator();
        String optStr = new String();
        while (itrPrimaryKeys.hasNext()) {
            optStr = (String)itrPrimaryKeys.next();
            thePrimaryKeysStrList.add(optStr);
        }
        
        return thePrimaryKeysStrList;
    }
    
    private void processMetaData(Map data) {
        Iterator iterator = data.keySet().iterator();
        StringBuffer primaryField   = new StringBuffer("");
        StringBuffer typeNameField   = new StringBuffer("");
        StringBuffer restOfField   = new StringBuffer("");
        StringBuffer domainAndStatusField   = new StringBuffer("");
        StringBuffer readOnlyFields = new StringBuffer("");
        while(iterator.hasNext()){
            String columnName = (String)iterator.next();
            String value = (String)data.get(columnName);
            String readonly = "readonly";
            if(value == null)
                value = "";
            if ("".equals(value))
                readonly="";
            
            if (columnName.equalsIgnoreCase("SYSTEMROLECODE"))
                systemCode = value;
            else if (columnName.equalsIgnoreCase("SYSTEMROLENAME"))
                systemName = value;
            else if (columnName.equalsIgnoreCase("SYSTEMFUNCTIONCODE"))
                systemCode = value;
            else if (columnName.equalsIgnoreCase("SYSTEMFUNCTIONNAME"))
                systemName = value;
            else if (columnName.equalsIgnoreCase("SYSTEMFUNCTIONDESC"))
                systemDesc = value;
            else if (columnName.equalsIgnoreCase("DOMAINNAME"))
                domainName = value;
            else if (columnName.equalsIgnoreCase("STATUS"))
                status = value;
            else if (columnName.equalsIgnoreCase("CREATEUSERID"))
                createUserId = value;
            else if (columnName.equalsIgnoreCase("CREATETIMESTAMP"))
                createTimestamp = value;
            else if (columnName.equalsIgnoreCase("LASTUPDATEUSERID"))
                lastUpdateUserId = value;
            else if (columnName.equalsIgnoreCase("LASTUPDATETIMESTAMP"))
                lastUpdateTimestamp = value;
        }
        return;
    }
} 
