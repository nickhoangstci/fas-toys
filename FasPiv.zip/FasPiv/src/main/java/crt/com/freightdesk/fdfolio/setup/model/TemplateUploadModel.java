/**
 * Copyright (c) NTELX All rights reserved.
 *
 * This software is the confidential and proprietary information of NTELX
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the license
 * agreement you entered into with NTELX.
 *
 */
package crt.com.freightdesk.fdfolio.setup.model;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * TemplateUploadModel associated with TemplateUploadAction. This class is a
 * Value Object to transfer the data from presentation layer to the Database.
 *
 * May have to transfer to DTO in the future.
 *
 * @author Tom Chang
 */
@Entity
@Table(name = "CRTTEMPLATE")
public class TemplateUploadModel implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    private long crtTemplateID;
    @Column(name = "TEMPLATENAME")
    private String templateName;
    @Column(name = "TEMPLATEDATA")
    private byte[] templateData;
    @Column(name = "STATUS")
    private String status;
    @Column(name = "CREATEUSERID")
    private String createUserID;
    @Column(name = "CREATETIMESTAMP")
    private java.sql.Timestamp createTimeStamp;
    @Column(name = "LASTUPDATEUSERID")
    private String lastUpdateUserID;
    @Column(name = "LASTUPDATETIMESTAMP")
    private java.sql.Timestamp lastUpdateTimeStamp;
    @Column(name = "DOMAINNAME")
    private String domainName;

    public long getCrtTemplateID() {
        return crtTemplateID;
    }

    public void setCrtTemplateID(long crtTemplateID) {
        this.crtTemplateID = crtTemplateID;
    }

    public String getTemplateName() {
        return templateName;
    }

    public void setTemplateName(String templateName) {
        this.templateName = templateName;
    }

    public byte[] getTemplateData() {
        return templateData;
    }

    public void setTemplateData(byte[] templateData) {
        this.templateData = templateData;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCreateUserID() {
        return createUserID;
    }

    public void setCreateUserID(String createUserID) {
        this.createUserID = createUserID;
    }

    public java.sql.Timestamp getCreateTimeStamp() {
        return createTimeStamp;
    }

    public void setCreateTimeStamp(java.sql.Timestamp createTimeStamp) {
        this.createTimeStamp = createTimeStamp;
    }

    public String getLastUpdateUserID() {
        return lastUpdateUserID;
    }

    public void setLastUpdateUserID(String lastUpdateUserID) {
        this.lastUpdateUserID = lastUpdateUserID;
    }

    public java.sql.Timestamp getLastUpdateTimeStamp() {
        return lastUpdateTimeStamp;
    }

    public void setLastUpdateTimeStamp(java.sql.Timestamp lastUpdateTimeStamp) {
        this.lastUpdateTimeStamp = lastUpdateTimeStamp;
    }

    public String getDomainName() {
        return domainName;
    }

    public void setDomainName(String domainName) {
        this.domainName = domainName;
    }
}
