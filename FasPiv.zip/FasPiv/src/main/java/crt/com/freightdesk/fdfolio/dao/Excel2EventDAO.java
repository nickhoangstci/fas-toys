package crt.com.freightdesk.fdfolio.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.freightdesk.fdcommons.ConnectionUtil;

public class Excel2EventDAO implements OrgIDLookup {
	private Logger logger = Logger.getLogger(Excel2EventDAO.class);
	
	
	
	
	@Override
	public String getAirportName(String airportID)
	{		
		return "";
	}

	public Excel2EventDAO() 
	{
	}
		
	/* (non-Javadoc)
	 * @see com.freightdesk.fdfolio.dao.OrgIDLookup#getCarrierId(java.lang.String)
	 */
	public long getCarrierId(String scac) {
		// scaccode is set to 4 characters in DB
		String paddedScac = scac;
		while(paddedScac.length() < 4) {
			paddedScac = paddedScac + " ";
		}
		// end padding
		Connection connection = null;
		PreparedStatement pStmt = null;
		ResultSet rs = null;
		String query = "SELECT ORGID FROM ORGHIERARCHY WHERE SCACCODE=?";
		long carrierId = 0;
		try {
			connection = ConnectionUtil.getConnection();
			pStmt = connection.prepareStatement(query);
			pStmt.setString(1, paddedScac.toUpperCase());
			rs = pStmt.executeQuery();

			if (rs.next()) {
				carrierId = rs.getLong(1);
				logger.debug("ORGID for scaccode " + paddedScac + " is " + carrierId);
			} else {
				logger.debug("Failed to find carrier for code " + paddedScac);
			}
			rs.close();
			pStmt.close();
			connection.close();
		} catch (SQLException ex) {
			logger.error("Exception while looking up ORGID for carrier.", ex);
		}
		return carrierId;
	}
	
	/* (non-Javadoc)
	 * @see com.freightdesk.fdfolio.dao.OrgIDLookup#getAirportId(java.lang.String)
	 */
	public long getAirportId(String iata) {
		Connection connection = null;
		PreparedStatement pStmt = null;
		ResultSet rs = null;
		String query = "SELECT ORGID FROM ORGHIERARCHY WHERE STATUS='ACTIVE' AND DOMAINNAME='PUBLIC' AND PORTCODE=?";
		long airportId = 0;
		try {
			connection = ConnectionUtil.getConnection();
			pStmt = connection.prepareStatement(query);
			pStmt.setString(1, iata.toUpperCase());
			rs = pStmt.executeQuery();

			if (rs.next()) {
				airportId = rs.getLong(1);
				logger.debug("ORGID for IATA code " + iata + " is " + airportId);
			} else {
				logger.debug("Failed to find airport for iata code " + iata);
			}
			rs.close();
			pStmt.close();
			connection.close();
		} catch (SQLException ex) {
			logger.error("Exception while looking up ORGID for IATA.", ex);
		}
		return airportId;
	}

	@Override
	public long getSecurityDeviceID(String deviceName) {
		
		return 0L;
	}

	@Override
	public String getChainOfCustodyTypeCode(String chainOfCustodyTypeName) {
		
		return "";
	}

	@Override
	public String getAlarmTypeCode(String alarmTypeName) {
		
		return null;
	}

	@Override
	public String getCommodityClassCode(String commodityClassName) {
		
		return null;
	}

	@Override
	public String getInspectionOrCheckTypeCode(String inspectionTypeName) {
		return null;
	}

	@Override
	public String getPackagingCode(String packagingName) {
		return null;
	}

	@Override
	public String getExtPackagingTypeCode(String extPackagingTypeName) {
		return null;
	}

	@Override
	public String getFillerTypeCode(String fillerTypeCodename) {
		return null;
	}
	
	
	
	
	
}

