package crt.com.freightdesk.fdfolio.common;

import java.util.ArrayList;
import java.util.List;

import crt.com.freightdesk.fdfolio.common.ErrorHandler;

public class SimpleErrorHandler implements ErrorHandler 
{

	List<Exception> exceptions = new ArrayList<Exception>();
	List<String>    strings    = new ArrayList<String>();
	
	@Override
	public void handleError(Exception e) 
	{
	
		exceptions.add( e );
		
	}

	@Override
	public void handleError(String s) 
	{	
		strings.add( s );
	}

	public List<Exception> getExceptions() {
		return exceptions;
	}

	public void setExceptions(List<Exception> exceptions) {
		this.exceptions = exceptions;
	}

	public List<String> getStrings() {
		return strings;
	}

	public void setStrings(List<String> strings) {
		this.strings = strings;
	}

	
	
}
