/**
 * 
 */
package crt.com.freightdesk.fdfolio.dao;

/**
 * @author jhansford
 *
 */
public class OrgIDLookupStub implements OrgIDLookup 
{
	
	/* (non-Javadoc)
	 * @see com.freightdesk.fdfolio.dao.OrgIDLookup#getAirportId(java.lang.String)
	 */
	@Override
	public long getAirportId(String iata) 
	{
		return 1L;
	}

	/* (non-Javadoc)
	 * @see com.freightdesk.fdfolio.dao.OrgIDLookup#getCarrierId(java.lang.String)
	 */
	@Override
	public long getCarrierId(String scac) {
		return 2L;
	}

	/* (non-Javadoc)
	 * @see com.freightdesk.fdfolio.dao.OrgIDLookup#getSecurityDeviceID(java.lang.String)
	 */
	@Override
	public long getSecurityDeviceID(String deviceName) 
	{
		return 3L;
	}
	

	@Override
	public String getAlarmTypeCode(String alarmTypeName) 
	{
		return alarmTypeName; //"ALARMCODE";
	}

	@Override
	public String getCommodityClassCode(String commodityClassName) 
	{
		return commodityClassName; //"COMMODITYCODE";
	}

	@Override
	public String getInspectionOrCheckTypeCode(String inspectionTypeName) 
	{
		return  inspectionTypeName; //"INSPECTIONCODE";
	}

	@Override
	public String getPackagingCode(String packagingName) 
	{
		return packagingName; //"PACKAGINGCODE";
	}

	@Override
	public String getChainOfCustodyTypeCode(String chainOfCustodyTypeName) 
	{
		return chainOfCustodyTypeName; //"AA";
	}

	@Override
	public String getExtPackagingTypeCode(String extPackagingTypeName) 
	{
		return extPackagingTypeName; //"ExtPackagingTypeCode".toUpperCase();
	}

	@Override
	public String getFillerTypeCode(String fillerTypeCodename) 
	{
		return fillerTypeCodename; //"getFillerTypeCode".toUpperCase();
	}

	@Override
	public String getAirportName(String airportID)
	{
		return "AirportName";
	}
	
	
	

}
