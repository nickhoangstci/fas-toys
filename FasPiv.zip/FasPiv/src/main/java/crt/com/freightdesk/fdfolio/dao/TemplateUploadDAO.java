/**
 * Copyright (c) NTELX All rights reserved.
 *
 * This software is the confidential and proprietary information of NTELX
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the license
 * agreement you entered into with NTELX.
 *
 */
package crt.com.freightdesk.fdfolio.dao;

import org.apache.log4j.Logger;
import java.sql.SQLException;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;

import com.freightdesk.fdfolio.common.SessionFactoryUtil;
import crt.com.freightdesk.fdfolio.setup.model.TemplateUploadModel;
import com.freightdesk.fdcommons.BaseDao;
import java.text.SimpleDateFormat;
import org.hibernate.criterion.Restrictions;

/**
 * The Data Access Object to insert/update/delete Event Model objects. Also
 * contains functionality to insert/update/delete some sub objects.
 *
 * @author Mike Echevarria
 */
public class TemplateUploadDAO extends BaseDao {

    private Logger logger = Logger.getLogger("TemplateUploadDAO");
	public static SimpleDateFormat inputDateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
    public static SimpleDateFormat outputDateFormat = new SimpleDateFormat("MM/dd/yyyy, hh:mm:ss");
    public static SimpleDateFormat dbDateFormat = new SimpleDateFormat("dd-MMM-yy hh:mm:ss");


    // Used in FAS
    /**
     * Creates a DB record corresponding to the given model.
     */
    public TemplateUploadModel persist(TemplateUploadModel templateUploadModel) throws SQLException {
        Session session = null;
        try {
            session = SessionFactoryUtil.getSession();
            session.beginTransaction();

            session.saveOrUpdate(templateUploadModel);
        } catch (Exception e) {
            session.getTransaction().rollback();
            //e.printStackTrace();
			logger.error("Exception : " + e.getMessage());
            throw (SQLException) new SQLException().initCause(e);
        } finally {
            session.getTransaction().commit();
            session.close();
        }
        return templateUploadModel;
    }

    /**
     * create
     *
     * @param eventList
     * @throws SQLException
     */
    public boolean persist(List<TemplateUploadModel> templateUploadList) {
        logger.debug("Persisting " + templateUploadList.size() + " events to the database");
        Session session = null;
        boolean saved = false;
        try {
            session = SessionFactoryUtil.getSession();
            session.beginTransaction();

            for (TemplateUploadModel model : templateUploadList) {
                session.saveOrUpdate(model);
            }
            saved = true;
        } catch (Exception ex) {
            session.getTransaction().rollback();
            logger.error("Failed to persist list of templates.  Rolling back transaction.", ex);
        } finally {
            session.getTransaction().commit();
            session.close();
        }
        return saved;
    }

    public List<TemplateUploadModel> retrieveAll() throws SQLException {
        Session session = null;
        try {
            session = SessionFactoryUtil.getSession();
            Criteria criteria = session.createCriteria(TemplateUploadModel.class);

//            List<TemplateUploadModel> results = formatDates((List<TemplateUploadModel>) criteria.list());
            List<TemplateUploadModel> results = (List<TemplateUploadModel>) criteria.list();

            return results;
        } catch (Exception e) {
            logger.error("Exception in retrieving upload models. " + e);
            throw (SQLException) new SQLException().initCause(e);
        } finally {
            session.close();
        }
    }

    public TemplateUploadModel retrieveTemplate(String templateName) throws SQLException {
        Session session = null;
        try {
            session = SessionFactoryUtil.getSession();
            Criteria criteria = session.createCriteria(TemplateUploadModel.class);
            criteria.add(Restrictions.eq("templateName", templateName));

            TemplateUploadModel templateUploadModel = (TemplateUploadModel) criteria.uniqueResult();


            return templateUploadModel;
        } catch (Exception e) {
            logger.error("Exception in retrieving upload model: " + templateName + ". " + e);
            throw (SQLException) new SQLException().initCause(e);
        } finally {
            session.close();
        }
    }
}
