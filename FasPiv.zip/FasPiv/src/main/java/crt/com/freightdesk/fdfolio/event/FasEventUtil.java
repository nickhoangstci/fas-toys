package crt.com.freightdesk.fdfolio.event;

import java.math.BigInteger;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.measure.Measure;
import javax.measure.converter.UnitConverter;
import javax.measure.unit.NonSI;
import javax.measure.unit.SI;

import org.apache.log4j.Logger;

import crt.com.freightdesk.fdfolio.event.model.EventHomeModel;
import com.freightdesk.fdfolio.event.model.EventModel;
import com.freightdesk.fdcommons.ApplicationProperties;
import com.freightdesk.fdcommons.Credentials;
import crt.com.ntelx.nxcommons.FasConstants;
import com.freightdesk.fdcommons.OptionBean;

public class FasEventUtil {
	private static Logger logger = Logger.getLogger(FasEventUtil.class);

	public static boolean doLookupCert(String category, String action) {
		boolean lookupCert = false;

		if (action.equalsIgnoreCase("AddIacEvent") || action.equalsIgnoreCase("AddIcsfEvent") || action.equalsIgnoreCase("AddShipEvent")) {
			lookupCert = true;
		} else if (action.equalsIgnoreCase("eventEdit")
				&& (category.equalsIgnoreCase(FasConstants.iacCategory) || category.equalsIgnoreCase(FasConstants.icsfCategory) || category.equalsIgnoreCase(FasConstants.shipCategory))) {
			lookupCert = true;
		}

		return lookupCert;
	}


	public static Calendar getCutOffCal(Date startDate) {
		Calendar cutOffCal = Calendar.getInstance();

		cutOffCal.setTime(startDate);

//		int submissionDeadline = Integer.valueOf(ApplicationProperties.getProperty("readonly.monthdaycuttoff.default"));// 10;
//		cutOffCal.set(Calendar.DAY_OF_MONTH, submissionDeadline + 1);

		cutOffCal.add(Calendar.MONTH, 1);
		cutOffCal.set(Calendar.DAY_OF_MONTH, cutOffCal.getActualMaximum(Calendar.DAY_OF_MONTH));

//		cutOffCal.add(Calendar.MONTH, 2);
//		cutOffCal.set(Calendar.DAY_OF_MONTH, 3);

		
		return cutOffCal;
	}

	public static boolean isPastCutoff(Date startDate, Calendar cutOffCal, long now) {
		Calendar nowCal = Calendar.getInstance();
		nowCal.setTime(new Date(now));
//		nowCal.add(Calendar.MONTH, 1);
		nowCal.set(Calendar.HOUR_OF_DAY, 0);
		nowCal.set(Calendar.MINUTE, 0);
	    nowCal.set(Calendar.SECOND, 0);
	    nowCal.set(Calendar.MILLISECOND, 0);
		
		// don't do this if the cutoff is in the future
		if (cutOffCal.after(nowCal) || cutOffCal.equals(nowCal))
		{
			logger.debug("Cut off date entered (" + cutOffCal.get(Calendar.MONTH) + "/" + cutOffCal.get(Calendar.DATE) + "/" + cutOffCal.get(Calendar.YEAR) + ") is after/equal to now (" + nowCal.get(Calendar.MONTH) + "/" + nowCal.get(Calendar.DATE) + "/" + nowCal.get(Calendar.YEAR) + ")");
			return false;			
		}

		Calendar eventCal = Calendar.getInstance();
		eventCal.setTime(startDate);

		if (eventCal.before(cutOffCal))
		{
			logger.debug("Event Cal date (" + eventCal.get(Calendar.MONTH) + "/" + eventCal.get(Calendar.DATE) + "/" + eventCal.get(Calendar.YEAR) + ") is before the cut off (" + cutOffCal.get(Calendar.MONTH) + "/" + cutOffCal.get(Calendar.DATE) + "/" + cutOffCal.get(Calendar.YEAR) + ")");
			return true;
		}
		else
			return false;
	}

	/**
	 * Calulate Car Compliance Rate for weight.
	 * 
	 * @return compliance rate
	 */
	public static double calcWeightPercentScreened(EventModel model) {

		double weightScreened = model.getScreenWeight();
		double altScreened = model.getAltWgt();
		double totalScreened = model.getTotalWgt();

		logger.debug("Weight Screen % = ( " + weightScreened + " + " + altScreened + " ) / " + totalScreened);
		return (weightScreened + altScreened) / totalScreened;
	}
	
	/**
	 * Calulate Car Compliance Rate.
	 * 
	 * @return compliance rate
	 */
	public static double calcAwbPercentScreened(EventModel model) {

		double numScreened = model.getScreenAwb();
		double altScreened = model.getAltAwb();
		double totalScreened = model.getTotalAwb();

		logger.debug("AWB screen % = ( " + numScreened + " + " + altScreened + " ) / " + totalScreened);
		return (numScreened + altScreened) / totalScreened;
	}
	
	public static double getWeightPerDay(EventModel model) {
		double weightPerDay = 0;
		
		weightPerDay = model.getTotalWgt()/(daysBetween(model.getEventDateTime(),model.getEventEndDateTime()));
		
		logger.debug("Weight per day is "+weightPerDay);
		return weightPerDay;
	}
	
	public static int getWaybillPerDay(EventModel model) {
		int waybillPerDay = 0;
		
		waybillPerDay = model.getTotalAwb()/(daysBetween(model.getEventDateTime(),model.getEventEndDateTime()));
		
		logger.debug("Air waybill per day is "+waybillPerDay);
		return waybillPerDay;
	}
	
	public static int daysBetween(Date start, Date end) {
		int daysBetween = (int) Math.ceil(( end.getTime() - start.getTime() ) / 86400000.0) + 1;
		return daysBetween;
	}
	
	/**
	 * Calulate Inb compliance Rate.  Compliance is on weight instead of air waybills for Non-US screening
	 * 
	 * @return compliance rate
	 */
	public static double calcINBComplianceRate(EventModel model) {

		double wgtScreened = model.getScreenWeight();
		double altScreened = model.getAltWgt();
		double totalScreened = model.getTotalWgt();

		logger.debug("CompRate = ( " + wgtScreened + " + " + altScreened + " ) / " + totalScreened);
		return (wgtScreened + altScreened) / totalScreened;
	}

	/**
	 * Calulate IAC compliance Rate.
	 * 
	 * @return compliance rate
	 */
	public static double calcIACComplianceRate(EventModel model) {

		double fiftyPercScreened = model.getPartScreenWgt();
		double hundredPercScreened = model.getScreenWeight();
		double totalScreened = model.getTotalWgt();

		logger.debug("CompRate = ( 0.5 * " + fiftyPercScreened + " + " + hundredPercScreened + " ) / " + totalScreened);
		return (0.5 * fiftyPercScreened + hundredPercScreened) / totalScreened;
	}

	public static long safeParseLong(String s) {
		if (s == null || s.trim().equals(""))
			return 0L;
		else {
			long l = 0;
			try {
				l = Long.parseLong(s);
			} catch (Exception e) {
				l = (long) Double.parseDouble(s);
			}

			return l;
		}
	}

	public static double getDoubleFromString(String value) {
		double convertedValue = 0.0;
		try {
			convertedValue = Double.parseDouble(value);
		} catch (Exception ex) {
			// if there is a parse or null value exception, just return zero.
			logger.debug("Error while parsing double value from " + value);
		}
		return convertedValue;
	}
	
	public static int getIntFromString(String value) {
		int convertedValue = 0;
		try {
			convertedValue = (int)Float.parseFloat(value);
			//logger.debug("!! Converted value is "+ convertedValue);
		} catch (Exception ex) {
			logger.debug("Failed to convert "+value+" to integer");
		}
		return convertedValue;
	}

	public static String getNameFromOptionsBeanList(List<OptionBean> list, BigInteger id) {
		String idStr = id.toString();
		for (OptionBean ob : list) {
			if (idStr.equalsIgnoreCase(ob.getValue())) {
				return ob.getLabel();
			}
		}

		return "N/A";
	}

	public static boolean isPastEditDate(Timestamp eventDate) {

		int cutOffDate = Integer.valueOf(ApplicationProperties.getProperty("readonly.monthdaycuttoff.default"));// 10;
		//logger.debug("Cut off date is " + cutOffDate);

		java.util.Calendar eventCal = java.util.GregorianCalendar.getInstance();

		java.util.Calendar nowCal = java.util.GregorianCalendar.getInstance();

		nowCal.setTime(new Date());

		eventCal.setTime(eventDate);

		double nowMonthNum = nowCal.get(GregorianCalendar.YEAR) + nowCal.get(GregorianCalendar.MONTH) / 12.0;
		double eventMonthNum = eventCal.get(GregorianCalendar.YEAR) + eventCal.get(GregorianCalendar.MONTH) / 12.0;
		double oneMonth = 1 / 12.0;

		// logger.debug( "Month Difference: " + (int) (( nowMonthNum -
		// eventMonthNum ) * 12) );
		if (nowMonthNum - eventMonthNum > oneMonth + 0.001) {
			// logger.debug( "Greater than 1 month difference " );
			return true;
		} else if (Math.abs(nowMonthNum - eventMonthNum) < 0.001) {
			// logger.debug( "same month difference " );
			return false;
		} else if (nowMonthNum - eventMonthNum < 0) {
			// logger.debug( "negative month difference " );
			return false;
		} else {
			// logger.debug( "1 month difference " );
			if (nowCal.get(GregorianCalendar.DAY_OF_MONTH) > cutOffDate)
				return true;
			else
				return false;
		}

	}

	public static boolean doCertNumReadOnly(boolean doReadOnly, String certNum) {
		boolean certReadOnly = doReadOnly;
		if (certNum != null && !certNum.trim().equals("")) {
			certReadOnly = true;
		}
		return certReadOnly;
	}

	public static boolean doCarrierReadOnly(boolean doReadOnly, String airportOrgID) {
		if (airportOrgID != null && !airportOrgID.trim().equals("")) {
			return true;
		}
		return doReadOnly;
	}

	public static String getNameAndAirport(EventHomeModel model) {
		String concatName = model.getCompanyName();
		String airport = model.getAirportName();

		// adds the airport code to the company name for non-ccsfs
		if (model.getCertNum() == null && airport.length() > 3) {
			concatName = concatName + "(" + airport.substring(0, 3) + ")";
		}

		return concatName;
	}

	public static Double convertKGtoLB(Double value) {
		
		UnitConverter toPounds = SI.KILOGRAM.getConverterTo(NonSI.POUND);
		double convertedValue = toPounds.convert(Measure.valueOf(value, SI.KILOGRAM).doubleValue(SI.KILOGRAM));
		
		logger.debug("[Original in KILOGRAM = "+value+"], [Converted in POUND = "+convertedValue+"]");

		return convertedValue;
	}
	
	public static Double getLbs(Double value, String uom) {
		if(uom.equalsIgnoreCase("METR"))
			return convertKGtoLB(value);
		else
			return value;
	}
	
	public static Double getWeightInUom(Double value, String uom) {
		if (uom.equalsIgnoreCase("METR"))
			return convertLBtoKG(value);
		else 
			return value;
	}

	public static Double convertLBtoKG(Double value) {

		UnitConverter toPounds = NonSI.POUND.getConverterTo(SI.KILOGRAM);
		double convertedValue = toPounds.convert(Measure.valueOf(value, NonSI.POUND).doubleValue(NonSI.POUND));
		
		logger.debug("[Original in POUND = "+value+"], [Converted in KILOGRAM = "+convertedValue+"]");

		return convertedValue;
	}

	public static boolean isWrongFormat(String cert) {
		// The number is period separated: airport code, certification type (IAC=C, Shipper=S, ICSF=I), certification date, random 3 numbers
		// An example certifcation number is DCA.I.02.11.2010.123
		String certRegex = "[a-z]{3}\\.[ics]{1}\\.\\d{2}\\.\\d{2}\\.\\d{4}\\.\\d{3}";
		return noMatchRegex(certRegex, cert);
	}

	public static boolean isBadDomainName(String domainName) {
		// proper domain names should just be letters.
		String domainRegex = "[a-z]*";
		return noMatchRegex(domainRegex, domainName);
	}

	public static boolean isBadUserId(String userId) {
		// userids should be only be words
		String userIdRegex = "\\w*";
		return noMatchRegex(userIdRegex, userId);
	}

	private static boolean noMatchRegex(String regex, String value) {
		if (value == null)
			value = "";

		boolean noMatch = true;
		try {
			Pattern pattern = Pattern.compile(regex, Pattern.CASE_INSENSITIVE);
			Matcher matcher = pattern.matcher(value);

			if (matcher.matches())
				noMatch = false;

			logger.debug(value + " does not match regex of " + regex + " : " + noMatch);
		} catch (Exception ex) {
			//logger.error("Failed to match regex to value");
			//ex.printStackTrace();
			logger.error("Exception Failed to match regex to value: " + ex.getMessage());
		}
		return noMatch;
	}

	public static String getWeightUom(Credentials credentials) {
		String name = "";
		try {
			if (credentials.getUomCode().equals("METR"))
				name = "KILOGRAMS";
			else
				// defaults to pounds unless set otherwise
				name = "POUNDS";
		} catch (Exception ex) {
			logger.error("Failed to read uomCode from credentials.");
		}
		return name;
	}
}
