/**
 * 
 */
package crt.com.freightdesk.fdfolio.common;

import org.apache.poi.ss.usermodel.Row;


/**
 * @author jhansford
 *
 */
public interface ExcelContinueIterTester 
{
   /**
    * Continue Iteration.  Determines if we should break iteration of the ExcelDataContainer before this row.	
    * @param row the row under test.
    * @return true if we should contine, false otherwise.
    */
	public boolean continueIter( Row   row );
}
