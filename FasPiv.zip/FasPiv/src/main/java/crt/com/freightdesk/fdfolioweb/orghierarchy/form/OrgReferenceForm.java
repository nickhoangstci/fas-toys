package crt.com.freightdesk.fdfolioweb.orghierarchy.form;

/*
 * To be used with OrghierarchyForm
 */
public class OrgReferenceForm {
	private String refId;
	private String refType;
	private String refValue;

	public String getRefId() {
		return refId;
	}

	public void setRefId(String refId) {
		this.refId = refId;
	}

	public String getRefType() {
		if (refType == null)
			return "";
		else
			return refType.toUpperCase();
	}

	public void setRefType(String refType) {
		this.refType = refType;
	}

	public String getRefValue() {
		if (refValue == null)
			return "";
		else
			return refValue.toUpperCase();
	}

	public void setRefValue(String refValue) {
		this.refValue = refValue;
	}

	public OrgReferenceForm() {

	}

	public OrgReferenceForm(String type, String value, String id) {
		refId = id;
		refType = type;
		refValue = value;
	}
}
