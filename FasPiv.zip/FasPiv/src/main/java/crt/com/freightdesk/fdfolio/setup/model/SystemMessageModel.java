package crt.com.freightdesk.fdfolio.setup.model;

import com.freightdesk.fdcommons.BaseModel;

public class SystemMessageModel extends BaseModel {
	
	private String messageText;
	private String faqTxt;
	
	public String getFaqTxt() {
		return faqTxt;
	}

	public void setFaqTxt(String faqTxt) {
		this.faqTxt = faqTxt;
	}

	// one row table
	public long getPrimaryKey() {
		return 0;
	}

	public String getMessageText() {
		return messageText;
	}

	public void setMessageText(String messageText) {
		this.messageText = messageText;
	}

}
