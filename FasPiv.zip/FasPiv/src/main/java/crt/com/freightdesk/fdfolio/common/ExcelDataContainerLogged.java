/**
 * 
 */
package crt.com.freightdesk.fdfolio.common;

import java.io.IOException;
import java.io.InputStream;

import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;

/**
 * @author jhansford
 *
 */
public class ExcelDataContainerLogged extends ExcelDataContainer 
{	
	private Logger logger = Logger.getLogger(ExcelDataContainerLogged.class);
	
	public ExcelDataContainerLogged(InputStream inStream) 
	{
		super(inStream);
	}
	
	
	// Log openWorkbook calls
	//
	protected void openWorkbook( InputStream inStream ) throws ExcelContainerWBOpenException
	{
		logger.debug( "Opening InputStream: " + inStream );
		super.openWorkbook( );
		logger.debug( "Opening InputStream completed" );
	}

	
	public void loadData( int sheetNum ) throws IOException, ExcelContainerGetValueException
	{
		logger.debug( "loadData with sheetNum: " + sheetNum );
		super.loadData( sheetNum );
		logger.debug( "loadData complete" );
	}

	// Log getStrFromCell calls
	//
	protected String getStrFromCell( Cell cell )
	{
		String result = null;
		
		//logger.debug( "Converting cell[" +  cell.getRowIndex() + "," + cell.getColumnIndex() + " ] to string " );
		
		result = super.getStrFromCell( cell );
		
		//logger.debug( "Converting cell complete " );
		return result;
	}
	
    
	public void loadData( int sheetNum, int startRow, int endRow, int startCol, int endCol ) throws IOException, ExcelContainerGetValueException
	{
		logger.debug( "loadData( sheetNum = " + sheetNum + ", startRow = " + startRow + 
				      ", endRow " + endRow + ", startCol = " + startCol + ", endCol = " + endCol ); 
		
		super.loadData(  sheetNum, startRow, endRow, startCol, endCol );
		
		logger.debug( "loadData Completed " );
	}
	
	public String getValue( int row, int col ) throws ExcelContainerGetValueException
	{
		logger.debug( "Excel Data Container get: " + row + ", " + col );
		return super.getValue( row, col );
	}
	

}
