package crt.com.freightdesk.fdfolio.jobs;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import org.apache.log4j.Logger;

public class LogJob implements Job
{
    protected Logger logger = Logger.getLogger (getClass());
    
	@Override
	public void execute(JobExecutionContext arg0) throws JobExecutionException
	{
		logger.debug( "Lob Job Ran!" );
	}

}
