package crt.com.freightdesk.fdfolio.orghierarchy;

import java.math.BigInteger;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.*; 
import java.text.SimpleDateFormat;

import org.apache.log4j.Logger;
import org.hibernate.Session;

import com.freightdesk.fdfolio.common.SessionFactoryUtil;
import com.freightdesk.fdfolio.dao.OrghierarchyDAO;
import com.freightdesk.fdfolio.event.model.EventModel;
import com.freightdesk.fdfolio.orghierarchy.model.OrgReferenceModel;
import com.freightdesk.fdfolio.orghierarchy.model.OrghierarchyModel;
import crt.com.freightdesk.fdfolio.setup.UserSetupManager;
import crt.com.freightdesk.fdfolioweb.event.form.EventForm;
import com.freightdesk.fdfolioweb.orghierarchy.action.OrghierarchyAction;
import crt.com.freightdesk.fdfolioweb.orghierarchy.form.OrgAssocForm;
import crt.com.freightdesk.fdfolioweb.orghierarchy.form.OrgReferenceForm;

import com.freightdesk.fdcommons.Credentials;
import crt.com.ntelx.nxcommons.FasConstants;
import com.freightdesk.fdcommons.FormatDate;
import crt.com.ntelx.nxcommons.NxUtils;
import com.freightdesk.fdcommons.OptionBean;
import crt.com.ntelx.nxcommons.model.OrgAssocModel;
import crt.com.ntelx.nxcommons.reporting.OptionCollectionManager;
import com.freightdesk.fdfolioweb.orghierarchy.action.OrghierarchyAction.OrgFormFieldBean;
import crt.com.freightdesk.fdfolioweb.event.form.EventForm;

public class OrghierarchyBeanManager {

    private static Logger logger = Logger.getLogger(OrghierarchyBeanManager.class);
    OrghierarchyDAO orgDAO = new OrghierarchyDAO();
    OptionCollectionManager optionManager = OptionCollectionManager.getInstance();

    public OrghierarchyModel form2model(OrgFormFieldBean form, OrghierarchyModel model, Credentials credentials) {
        logger.debug("form2model Copying FORM values to MODEL");       

        model.setOrgHierarchyTypeCode(form.getOrgHierarchyTypeCode());
        logger.debug("form.getOrgHierarchyTypeCode() " + form.getOrgHierarchyTypeCode());

        logger.debug("form2model form parentorgid: " + form.getParentOrgId());
        logger.debug("form2model form parentorgname: " + form.getParentOrgName());
        
        
        if (!NxUtils.isEmptyOrBlank(form.getParentOrgId()))
        {
            BigInteger parentOrgId = new BigInteger(form.getParentOrgId());
            model.setParentOrgId(parentOrgId);
        }
        else
        {
            model.setParentOrgId(null);
        }

        logger.debug("form.getCreateUserId() " + form.getCreateUserId());
        model.setCreateUserId(form.getCreateUserId());

        logger.debug("form.getCreateTimestamp() " + form.getCreateTimestamp());
        Timestamp cTimestamp=null;
        final String NEW_FORMAT = "yyyy-MM-dd HH:mm:ss.SSS";

        try{
            SimpleDateFormat dateFormat = new SimpleDateFormat(NEW_FORMAT);
            Date parsedDate = dateFormat.parse(form.getCreateTimestamp());
            logger.debug("Timestamp cTimestamp " + parsedDate.toString());
            cTimestamp = new java.sql.Timestamp(parsedDate.getTime());
        } catch(Exception e){//this generic but you can control another types of exception           
			logger.error("Exception: " + e.getMessage());
        }
        
        
        model.setCreateTimestamp(cTimestamp);
        logger.debug("FormatDate getCreateTimestamp() " + FormatDate.parse(form.getCreateTimestamp(), FasConstants.dateTimeFormat));
        model.setRequiredReporting(form.getRequiredReporting());
        model.setNcspMember(form.getNcspMember());

        // saving so set update to current user info and time
        logger.debug("credentials.getUserId() " + credentials.getUserId());
        model.setDomainName(com.freightdesk.fdcommons.GlobalConstants.FAS_DOMAIN);
        model.setLastUpdateUserId(credentials.getUserId());
        model.setLastUpdateTimestamp(new Timestamp(System.currentTimeMillis()));

        logger.debug("form.getOrgRoleCode() " + form.getOrgRoleCode());
        model.setOrgRoleCode(form.getOrgRoleCode());
        model.setContactSalutationCode(form.getContactSalutationCode());

        if (model.getOrgHierarchyTypeCode().equalsIgnoreCase("CON")) {
            model.setOrgName(form.getContactLastName());
        } else {
            model.setOrgName(form.getOrgName());
        }

        logger.debug("form.getDUNSNumber() " + form.getDUNSNumber());
        model.setDUNSNumber(form.getDUNSNumber());
        model.setSCACCode(form.getSCACCode());
        model.setEINNumber(form.getEINNumber());
        model.setStp(form.getStp());
        logger.debug("form.getPortCode() " + form.getPortCode());
        model.setPortCode(form.getPortCode());
        model.setRemarks(form.getRemarks());
        model.setStatus(form.getStatus());

        logger.debug("form.getContactFirstName() " + form.getContactFirstName());
        model.setContactFirstName(form.getContactFirstName());
        model.setContactLastName(form.getContactLastName());
        logger.debug("%%%%% !!!!! form.getContactTitle() " + form.getContactTitle());
        model.setContactTitle(form.getContactTitle());
        logger.debug("%%%%% !!!!! form.getRegion() " + form.getRegion());
        model.setRegionCode(form.getRegion());

        logger.debug("form.getEmail() " + form.getEmail());
        model.setEmail(form.getEmail());
        model.setPhone(form.getPhone());
        
        logger.debug("form.getAddressTypeCode() " + form.getAddressTypeCode());
        model.setAddressTypeCode(form.getAddressTypeCode());
        model.setCountryCode(form.getCountryCode());
        model.setTimeZoneId(form.getTimeZoneId());
        logger.debug("form.getAddressLine1() " + form.getAddressLine1());
        model.setAddressLine1(form.getAddressLine1());
        model.setAddressLine2(form.getAddressLine2());
        logger.debug("form.getCity() " + form.getCity());
        model.setCity(form.getCity());
        model.setStateProvince(form.getStateProvince());
        model.setStateProvinceCode(form.getStateProvinceCode());
        logger.debug("form.getZipPostCode() " + form.getZipPostCode());
        model.setZipPostCode(form.getZipPostCode());
        model.setLatitude(form.getLatitude());
        model.setLongitude(form.getLongitude());
        logger.debug("form.getLongitude() " + form.getLongitude());
        // end address setting

        // copy the orgRefs to the model
        List<OrgReferenceForm> orgRefForms = form.getOrgRefs();
        Set<OrgReferenceModel> orgModels = new HashSet<OrgReferenceModel>();

        for (OrgReferenceForm orgForm : orgRefForms) {
            try {

                if (NxUtils.isEmptyOrBlank(orgForm.getRefId())) {
                    // new orgReference
                    logger.debug("new orgReference ");
                    OrgReferenceModel refModel = new OrgReferenceModel();
                    refModel.setOrghierarchy(model);
                    logger.debug("new orgReference orgForm.getRefValue() " + orgForm.getRefValue());
                    refModel.setOrgReferenceValue(orgForm.getRefValue());
                    logger.debug("new orgReference orgForm.getRefType() " + orgForm.getRefType());
                    refModel.setOrgReferenceTypeCode(orgForm.getRefType());
                    refModel.setStatus(form.getStatus());
                    refModel.setDomainName(com.freightdesk.fdcommons.GlobalConstants.FAS_DOMAIN);
                    refModel.setCreateUserId(form.getCreateUserId());
                    refModel.setCreateTimestamp(new Timestamp(System.currentTimeMillis()));

                    orgModels.add(refModel);
                } else {
                    // update orgReference
                    long id = Long.parseLong(orgForm.getRefId());

                    OrgReferenceModel refModel = model.getOrgReference(id);
                    refModel.setOrghierarchy(model);
                    logger.debug("update orgForm.getRefValue() " + orgForm.getRefValue());
                    refModel.setOrgReferenceValue(orgForm.getRefValue());
                    logger.debug("update orgReference orgForm.getRefType() " + orgForm.getRefType());
                    refModel.setOrgReferenceTypeCode(orgForm.getRefType());
                    refModel.setStatus(form.getStatus());
                    refModel.setLastUpdateTimestamp(new Timestamp(System.currentTimeMillis()));

                    orgModels.add(refModel);
                }

            } catch (Exception ex) {
                logger.debug("Not setting OrgReference model for id = " + orgForm.getRefId());                
            }

        }

        model.setOrgReferenceList(orgModels);

        // end orgRef copy

        logger.debug("return form2model ");
        return model;
    }

    public void model2form(OrgFormFieldBean form, OrghierarchyModel model) {
        logger.debug("model2form Copying MODEL values to FORM");       
        
                
        // for lazying loading opening a hibernate session
        Session session = null;
        try {
            session = SessionFactoryUtil.getSession();
            // re-attach object if you are editing or viewing
            if (!form.getContext().equalsIgnoreCase("ADD")) {
                session.update(model);
            }
            
            logger.debug("model2form model.getOrgId() " + model.getOrgId());

            if (model.getOrgId() > 0L) {
                form.setOrgId(model.getOrgId());
            }

            BigInteger parentOrgId = model.getParentOrgId();

            if (parentOrgId != null) {
                form.setParentOrgId(model.getParentOrgId().toString());
                logger.debug("model2form model.getParentOrgId().toString() " + model.getParentOrgId().toString());
                form.setParentOrgName(orgDAO.retrieveOrgNameByOrgID(parentOrgId.longValue()));
                form.setParentOrgType(orgDAO.getOrgType(parentOrgId.longValue()));
            }
            
            
            if ("ORG".equals(model.getOrgHierarchyTypeCode()) && "CAR".equals(model.getOrgRoleCode()) && parentOrgId != null)
            {
                // subsidiaries are carrier locations.  shown in the screen as subsidiaries but matches all other locations in the db.
                form.setOrgHierarchyTypeName(OrghierarchyAction.subsidiaryName);
            }
            else
            {
                form.setOrgHierarchyTypeName(getOrgTypeName(model.getOrgHierarchyTypeCode()));
            }
            logger.debug("model2form model.getOrgHierarchyTypeCode() " + model.getOrgHierarchyTypeCode());
            logger.debug("model2form getOrgTypeName " + getOrgTypeName(model.getOrgHierarchyTypeCode()));
            
            form.setCreateUserId(model.getCreateUserId());
            form.setCreateTimestamp(FormatDate.format(model.getCreateTimestamp(), FasConstants.dateTimeFormat));
            form.setDomainName(model.getDomainName());
            form.setLastUpdateUserId(model.getLastUpdateUserId());
            form.setLastUpdateTimestamp(FormatDate.format(model.getLastUpdateTimestamp(), FasConstants.dateTimeFormat));

            form.setOrgRoleCode(model.getOrgRoleCode());
            form.setContactSalutationCode(model.getContactSalutationCode());
            form.setOrgHierarchyTypeCode(model.getOrgHierarchyTypeCode());
            form.setRequiredReporting(model.getRequiredReporting());
            form.setNcspMember(model.getNcspMember());

            form.setOrgName(model.getOrgName());
            form.setDUNSNumber(model.getDUNSNumber());
            form.setSCACCode(model.getSCACCode());
            form.setEINNumber(model.getEINNumber());
            form.setStp(model.getStp());
            form.setPortCode(model.getPortCode());
            form.setRemarks(model.getRemarks());
            form.setStatus(model.getStatus());

            form.setContactFirstName(model.getContactFirstName());
            form.setContactLastName(model.getContactLastName());
            form.setContactTitle(model.getContactTitle());
            form.setRegion(model.getRegionCode());

            form.setEmail(model.getEmail());
            form.setPhone(model.getPhone());

            form.setAddressTypeCode(model.getAddressTypeCode());
            form.setCountryCode(model.getCountryCode());
            form.setTimeZoneId(model.getTimeZoneId());
            form.setAddressLine1(model.getAddressLine1());
            form.setAddressLine2(model.getAddressLine2());
            form.setCity(model.getCity());
            form.setStateProvince(model.getStateProvince());
            form.setStateProvinceCode(model.getStateProvinceCode());
            form.setZipPostCode(model.getZipPostCode());
            form.setLatitude(model.getLatitude());
            form.setLongitude(model.getLongitude());

            // copy the orgRefs to the form
            List<OrgReferenceForm> orgRefList = new ArrayList<OrgReferenceForm>();
            for (OrgReferenceModel orgRef : model.getOrgReferenceList()) {
                OrgReferenceForm orgForm = new OrgReferenceForm(orgRef.getOrgReferenceTypeCode(), orgRef.getOrgReferenceValue(), String.valueOf(orgRef.getOrgReferenceId()));
                orgRefList.add(orgForm);
            }

            form.setOrgRefs(orgRefList);

            // add login list. for contacts only
            if (form.getOrgHierarchyTypeCode().equalsIgnoreCase("CON")) {
                // should be hibernate in the future..
                try {
                    UserSetupManager userSetupManager = new UserSetupManager();
                    form.setLoginList(userSetupManager.getAllSystemUsers(model.getOrgId()));
                } catch (Exception ex) {                    
					logger.error("Exception: " + ex.getMessage());
                }
            }

            // add contact list. NOT for contacts
            if (!form.getOrgHierarchyTypeCode().equalsIgnoreCase("CON")) {
                List<OrghierarchyModel> contactList = orgDAO.retrieveChildOrgs(model.getOrgId(), "CON");
                form.setContactList(contactList);
            }

            // add location list. For ORG only
            if (form.getOrgHierarchyTypeCode().equalsIgnoreCase("ORG")) {
                List<OrghierarchyModel> locList = orgDAO.retrieveChildOrgs(model.getOrgId(), "LOC");
                form.setLocationList(locList);
            }
           

            // add events
            List<EventForm> eventList = new ArrayList<EventForm>();
            for (EventModel eventModel : model.getEventModelList()) {
                EventForm eventForm = new EventForm();
                eventForm.setEventId(String.valueOf(eventModel.getEventId()));
                eventForm.setEventCategoryCode(eventModel.getEventCategoryCode());
                eventForm.setEventTypeCode(eventModel.getEventTypeCode());
                eventForm.setEventDateTime(FormatDate.format(eventModel.getEventDateTime(), FasConstants.simpleDateFormat));
                eventForm.setEventEndDateTime(FormatDate.format(eventModel.getEventEndDateTime(), FasConstants.simpleDateFormat));
                eventForm.setRemarks(eventModel.getRemarks());

                eventList.add(eventForm);
            }
            form.setEventList(eventList);
            // end add events

            // add associations
            List<OrgAssocForm> orgAssocList = new ArrayList<OrgAssocForm>();
            List<OrgAssocForm> orgApAcAssocList = new ArrayList<OrgAssocForm>();
            for (OrgAssocModel orgAssocModel : model.getOrgAssocList()) {

                OrgAssocForm orgAssocForm = new OrgAssocForm();
                orgAssocForm.setRemarks(orgAssocModel.getComments());
                orgAssocForm.setOrgAssocId(String.valueOf(orgAssocModel.getOrgOrgAssocId()));
                orgAssocForm.setRelationShipType(orgAssocModel.getRelationshipTypeCode());
                orgAssocForm.setDestOrgId(orgAssocModel.getDestOrgId().toString());
                orgAssocForm.setDestOrgName(orgDAO.retrieveOrgNameByOrgID(orgAssocModel.getDestOrgId().longValue()));
                orgAssocForm.setBeginDate(FormatDate.format(orgAssocModel.getBeginDate(), FasConstants.simpleDateFormat));
                orgAssocForm.setEndDate(FormatDate.format(orgAssocModel.getEndDate(), FasConstants.simpleDateFormat));
                orgAssocList.add(orgAssocForm);
            }
            form.setOrgAssocList(orgAssocList);
            // end add associations
        } catch (Exception ex) {           
			logger.error("Exception: " + ex.getMessage());
        } finally {
            session.close();
        }
    }

    private String getOrgTypeName(String type) {
        List<OptionBean> orgTypeList = optionManager.getCollection("orgTypeList");
        String orgTypeName = "";

        for (OptionBean option : orgTypeList) {
            if (option.getValue().equalsIgnoreCase(type)) {
                orgTypeName = option.getLabel();
            }
        }

        orgTypeName = NxUtils.upperFirst(orgTypeName);

        return orgTypeName;
    }

    private void copyOrgAssocList(List<OrgAssocForm> assocFormList, OrghierarchyModel model, OrgFormFieldBean form, Set<OrgAssocModel> assocModelList) {

        for (OrgAssocForm orgAssocForm : assocFormList) {
            try {

                if (NxUtils.isEmptyOrBlank(orgAssocForm.getOrgAssocId())) {
                    // new org assocication
                    OrgAssocModel orgAssocModel = new OrgAssocModel();
                    orgAssocModel.setOrghierarchy(model);

                    orgAssocModel.setDestOrgId(new BigInteger(orgAssocForm.getDestOrgId()));

                    orgAssocModel.setRelationshipTypeCode(orgAssocForm.getRelationShipType());
                    orgAssocModel.setBeginDate(FormatDate.parse(orgAssocForm.getBeginDate(), FasConstants.simpleDateFormat));
                    orgAssocModel.setEndDate(FormatDate.parse(orgAssocForm.getEndDate(), FasConstants.simpleDateFormat));
                    orgAssocModel.setStatus(form.getStatus());
                    orgAssocModel.setDomainName(com.freightdesk.fdcommons.GlobalConstants.FAS_DOMAIN);
                    orgAssocModel.setCreateUserId(form.getCreateUserId());
                    orgAssocModel.setCreateTimestamp(new Timestamp(System.currentTimeMillis()));
                    orgAssocModel.setComments(orgAssocForm.getRemarks());

                    assocModelList.add(orgAssocModel);
                } else {
                    // update org association
                    long id = Long.parseLong(orgAssocForm.getOrgAssocId());

                    OrgAssocModel orgAssocModel = model.getAssociation(id);
                    orgAssocModel.setOrghierarchy(model);

                    orgAssocModel.setDestOrgId(new BigInteger(orgAssocForm.getDestOrgId()));

                    orgAssocModel.setRelationshipTypeCode(orgAssocForm.getRelationShipType());
                    orgAssocModel.setBeginDate(FormatDate.parse(orgAssocForm.getBeginDate(), FasConstants.simpleDateFormat));
                    orgAssocModel.setEndDate(FormatDate.parse(orgAssocForm.getEndDate(), FasConstants.simpleDateFormat));
                    orgAssocModel.setStatus(form.getStatus());
                    orgAssocModel.setLastUpdateTimestamp(new Timestamp(System.currentTimeMillis()));
                    orgAssocModel.setComments(orgAssocForm.getRemarks());
                    assocModelList.add(orgAssocModel);
                }

            } catch (Exception ex) {
                logger.debug("Not setting OrgAssocModel Model for id = " + orgAssocForm.getOrgAssocId());
            }

        }
    }
}
