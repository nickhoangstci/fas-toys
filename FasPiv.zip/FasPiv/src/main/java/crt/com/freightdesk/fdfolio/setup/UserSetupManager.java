/**
 * Copyright (c) NTELX
 *  All rights reserved.
 *
 * This software is the confidential and proprietary information of NTELX
 * ("Confidential Information").  You shall not disclose such Confidential Information
 * and shall use it only in accordance with the terms of the license agreement you entered
 * into with NTELX.
 *
 *
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolio/setup/UserSetupManager.java,v 1.6.4.15 2010/12/02 15:54:27 jhansford Exp $
 *
 *  Modification History:
 *  $Log: UserSetupManager.java,v $
 *  Revision 1.6.4.15  2010/12/02 15:54:27  jhansford
 *  Add UserID search
 *
 *  Revision 1.6.4.14  2010/09/23 19:35:26  mechevarria
 *  remove ejb layer for instantiating objects.  direct calls to bean class now made
 *
 *  Revision 1.6.4.13  2010/08/22 23:08:40  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.6.4.12  2010/06/21 22:14:57  mechevarria
 *  removed checkruleconformance
 *
 *  Revision 1.6.4.11  2010/02/11 22:12:44  mechevarria
 *  moved systemusermodel to commons
 *
 *  Revision 1.6.4.10  2009/12/21 17:08:05  mechevarria
 *  add list of logins on contact page
 *
 *  Revision 1.6.4.9  2009/09/23 18:02:23  mechevarria
 *  import clean via eclipse
 *
 *  Revision 1.6.4.8  2009/09/22 19:32:43  mechevarria
 *  updated user management
 *
 *  Revision 1.6.4.7  2009/08/12 18:16:02  jhansford
 *  Added Pull Down to switch domains on edit user page.
 *
 *  Revision 1.6.4.6  2008/06/03 14:50:18  mechevarria
 *  correct logging typo
 *
 *  Revision 1.6.4.5  2007/08/16 13:12:43  mechevarria
 *  added async logging to user deletion
 *
 *  Revision 1.6.4.4  2007/08/15 15:09:17  mechevarria
 *  added credentials to function parameters to support async logging of user creation and user updates
 *
 *  Revision 1.6.4.3  2007/06/01 16:15:43  mechevarria
 *  removed password check for xml foliox messages
 *
 *  Revision 1.6.4.2  2007/04/02 16:16:45  mechevarria
 *  updates to role creation permissions
 *
 *  Revision 1.10  2007/03/30 22:17:19  aarora
 *  Corrected the check access method
 *
 *  Revision 1.9  2007/03/30 15:22:13  nsehra
 *  new method added checkaccess
 *
 *  Revision 1.8  2007/03/21 13:50:11  nsehra
 *  change method for access control
 *
 *  Revision 1.7  2007/03/19 09:17:44  atripathi
 *  bug 2121 fixed
 *
 *  Revision 1.6  2006/04/12 23:42:11  aarora
 *  Organized imports
 *
 *  Revision 1.5  2006/03/28 21:23:07  aarora
 *  Repackaging of fdcommons
 *
 *  Revision 1.4  2005/09/14 00:48:09  amrinder
 *  Fixing broken build
 *
 *  Revision 1.3  2005/09/13 13:15:47  nsehra
 *  role to permission mapping changes
 *
 *  Revision 1.2  2005/09/09 00:33:28  amrinder
 *  Now extending BaseManager
 *
 *  Revision 1.1  2004/09/21 08:42:29  ranand
 *  package changed from folioweb to folio
 *
 *  Revision 1.1  2004/09/15 13:36:28  asingh
 *  2.6 Baseline
 */

package crt.com.freightdesk.fdfolio.setup;

import org.apache.log4j.Logger;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import com.freightdesk.fdfolio.common.BaseManager;
import com.freightdesk.fdfolio.useraccess.ejb.UserAccessSLSBean;
import com.freightdesk.fdcommons.Credentials;
import com.freightdesk.fdcommons.GenericComparator;
import com.freightdesk.fdcommons.LcpConstants;
import com.freightdesk.fdfolio.useraccess.model.SystemUserModel;

/**
 * The business logic facade for Setup user functionality. This class contains
 * method to create, update, delete, and sort an user. Deletion is not virtual
 * it is physical deletion of user from the database. Make sure that user which
 * you are trying to delete is the correct user.
 * 
 * @author Sangeeta Taneja
 */
public class UserSetupManager extends BaseManager {
	/** An instance of UserAccessSLS home object */
	
    private Logger logger = Logger.getLogger("UserSetupManaget");
	
	public UserSetupManager() {

	}

	
	
	public List<SystemUserModel> searchSystemUsers(String userID, String lName, String domain, String email,Credentials credentials ) 
	{
		logger.debug("userId="+userID+", lName="+lName+", domain="+domain+", email="+email);
                
		List<SystemUserModel> usersList = new ArrayList<SystemUserModel>();
		try 
		{
			UserAccessSLSBean userAccessSLS = new UserAccessSLSBean();
			usersList = userAccessSLS.searchSystemUsers( userID, lName, domain, email,credentials);
		} catch (Exception e) {
			
			logger.error("Exception : " + e.getMessage());
		}
		logger.debug("Returning " + usersList.size() + " users");
                
		return usersList;
	}
	
	/*
	 * for listing users by orgid
	 */
	public List<SystemUserModel> getAllSystemUsers(Long contactOrgId) throws Exception {
		logger.debug("getAllSystemUsers(): begin");
		List<SystemUserModel> usersList = new ArrayList<SystemUserModel>();
		try {
			UserAccessSLSBean userAccessSLS = new UserAccessSLSBean();
			usersList = userAccessSLS.getAllSystemUsers(null, contactOrgId);
		} catch (Exception e) {
			logger.error("Exception in getAllSystemUsers()", e);
			throw e;
		}
		return usersList;
	}


	/**
	 * Creates a new user.
	 * 
	 * @param systemUserModel
	 *            This wraps system users details.
	 * 
	 * @throws java.lang.Exception
	 *             If any system error occurs.
	 */
	public void createUser(SystemUserModel systemUserModel, Credentials credentials) throws Exception {
		logger.debug("CreateUser(): begin");
		try {
			UserAccessSLSBean userAccessSLS = new UserAccessSLSBean();
			userAccessSLS.createUser(systemUserModel, credentials);
		} catch (Exception e) {
			logger.error("Exception in createUser()", e);
			throw e;
		}
	}

	/**
	 * Updates an existing user.
	 * 
	 * @param systemUserModel
	 *            This wraps system users details.
	 * 
	 * @return SystemUserModel Wrapper of system user data.
	 * 
	 * @throws java.lang.Exception
	 *             If any system error occurs.
	 */
	public SystemUserModel editUser(SystemUserModel systemUserModel, Credentials credentials) throws Exception {
		try {
			logger.debug("editUser(): begin");
			UserAccessSLSBean userAccessSLS = new UserAccessSLSBean();
			return userAccessSLS.updateUser(systemUserModel, credentials);
		} catch (Exception e) {
			logger.error("Exception in  editUser()", e);
			throw e;
		}
	}

	/**
	 * Deletes an existing user.
	 * 
	 * @param systemUserModel
	 *            This wraps system users details.
	 * 
	 * @throws java.lang.Exception
	 *             If any system error occurs.
	 */
	public void deleteUser(SystemUserModel systemUserModel, Credentials credentials) throws Exception {
		try {
			logger.debug("deleteUser(): orgId: " + systemUserModel.getOrgId() + ", userId: " + systemUserModel.getUserId());
			UserAccessSLSBean userAccessSLS = new UserAccessSLSBean();
			userAccessSLS.deleteUser(systemUserModel, credentials);
		} catch (Exception e) {
			logger.error("Exception in deleteUser() method::", e);
			throw e;
		}
	}

	/**
	 * Retrieves the user details.
	 * 
	 * @param systemUserModel
	 *            This wraps system users details.
	 * 
	 * @return SystemUserModel Wrapper of system user data.
	 * 
	 * @throws java.lang.Exception
	 *             If any system error occurs.
	 */
	public SystemUserModel getUserDetails(SystemUserModel systemUserModel) throws Exception {
		try {
			logger.debug("getUserDetails()" + systemUserModel.getOrgId() + "::" + systemUserModel.getUserId());
			UserAccessSLSBean userAccessSLS = new UserAccessSLSBean();
			systemUserModel = userAccessSLS.getUserDetails(systemUserModel);
		} catch (Exception e) {
			logger.error("Exception in getUserDetails()", e);
			throw e;
		}
		return systemUserModel;
	}

	/**
	 * Sorts the user list by a given attribute and in given order.
	 * 
	 * @param usersList
	 *            Contains user details.
	 * @param sortingAttribute
	 *            The attribute of the user access on which the sort is done.
	 * @param isAscending
	 *            True/false.
	 */
	public void doSortByColumn(List usersList, String sortingAttribute, boolean isAscending) {
		java.util.Collections.sort(usersList, new GenericComparator(SystemUserModel.class, sortingAttribute, isAscending));
	}

	public Map loadUserPreferences(long systemUserId) throws Exception {
		try {
			UserAccessSLSBean userAccessSLS = new UserAccessSLSBean();
			Map preferenceMap = userAccessSLS.loadUserPreferences(systemUserId);
			return preferenceMap;
		} catch (Exception e) {
			logger.error("Exception in loadUserPreferences()", e);
			throw e;
		}
	}

	public SystemUserModel getUserPreferenceDetails(long systemUserId) throws Exception {
		SystemUserModel systemUserModel = new SystemUserModel();
		try {
			UserAccessSLSBean userAccessSLS = new UserAccessSLSBean();
			systemUserModel = userAccessSLS.getUserPreferenceDetails(systemUserId);
		} catch (Exception e) {
			logger.error("Exception in getUserPreferenceDetails()", e);
			throw e;
		}
		return systemUserModel;
	}

	public void updateUserPreferences(SystemUserModel systemUserModel) throws Exception {
		UserAccessSLSBean userAccessSLS = new UserAccessSLSBean();
		userAccessSLS.updateUserPreferences(systemUserModel);
	}

	public Hashtable getFDRolePermissionList(List roleList, String domain) throws Exception {
		UserAccessSLSBean userAccessSLS = new UserAccessSLSBean();
		return userAccessSLS.getFDRolePermissionList(roleList, domain);
	}

	public void deleteSystemRoleFunction(String roleName) throws Exception {
		UserAccessSLSBean userAccessSLS = new UserAccessSLSBean();
		userAccessSLS.deleteSystemRoleFunction(roleName);
	}

	public void createSystemRoleFunction(String[] systemFunctionCodes, String roleName, String createdBy) throws Exception {
		UserAccessSLSBean userAccessSLS = new UserAccessSLSBean();
		userAccessSLS.createSystemRoleFunction(systemFunctionCodes, roleName, createdBy);
	}

	/**
	 * Checks whether the role list has the access to create a user with the
	 * given systemRoleCode.
	 * 
	 * @param roleList
	 *            The list of the roles which the actor has
	 * @param systemRoleCode
	 *            The target system role that the actor wants to assign to the
	 *            new/existing user
	 * @return true if the access is OK, false otherwise
	 */
	public boolean checkAccess(String role, String systemRoleCode) {
		if (role == null) {
			logger.debug("roleList is null, returning false");
			return false;
		}

		// Only sysadmin can create a sysadmin
		if (systemRoleCode.equalsIgnoreCase(LcpConstants.SystemRole.SYSTEM_ADMINISTRATOR)) {
			if (role.equalsIgnoreCase(LcpConstants.SystemRole.SYSTEM_ADMINISTRATOR))
				return true;
			else
				return false;
		}

		// Only sysadmin or domain admin can create a domain admin
		if (systemRoleCode.equalsIgnoreCase(LcpConstants.SystemRole.DOMAIN_ADMINISTRATOR)) {
			if (role.equalsIgnoreCase(LcpConstants.SystemRole.DOMAIN_ADMINISTRATOR) || role.equalsIgnoreCase(LcpConstants.SystemRole.SYSTEM_ADMINISTRATOR)) {
				return true;
			} else {
				return false;
			}
		}
		return true;
	}

}
