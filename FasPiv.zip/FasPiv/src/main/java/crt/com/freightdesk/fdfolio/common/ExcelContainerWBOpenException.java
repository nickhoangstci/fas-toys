package crt.com.freightdesk.fdfolio.common;

public class ExcelContainerWBOpenException extends Exception {

}
