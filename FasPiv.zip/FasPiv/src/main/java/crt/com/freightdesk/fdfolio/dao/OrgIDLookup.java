package crt.com.freightdesk.fdfolio.dao;

public interface OrgIDLookup 
{

	public long getCarrierId(String scac);

	public long getAirportId(String iata); 
	
	public long getSecurityDeviceID( String deviceName );

	public String getAirportName( String airportID );
	
	public String getChainOfCustodyTypeCode( String chainOfCustodyTypeName );
	
	public String getPackagingCode( String packagingName );
	
	public String getCommodityClassCode( String commodityClassName );
	
	public String getAlarmTypeCode( String alarmTypeName );
	
	public String getInspectionOrCheckTypeCode( String inspectionTypeName );
	
	public String getFillerTypeCode( String fillerTypeCodename );
	
	public String getExtPackagingTypeCode( String extPackagingTypeName );

	
}