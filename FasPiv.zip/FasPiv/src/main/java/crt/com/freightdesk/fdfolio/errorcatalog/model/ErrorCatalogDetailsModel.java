package crt.com.freightdesk.fdfolio.errorcatalog.model;

import java.sql.Date;

public class ErrorCatalogDetailsModel
{
	private int errorCatalogDetailsId;
	private int errorCatalogId;
	private char errorCode;
	private String referenceIdentifier;
	private String referenceCode;
	private String referenceValue;
	private String errorStatus;
	private String errorMessage;
	private Date resolvedTimestamp;
	private String status;
	private String createUserId;
	private Date createTimestamp;
	private String lastUpdateUserId;
	private Date lastUpdateTimestamp;
	private String domainName;
	

	public String getDomainName()
	{
		return domainName;
	}
	
	public void setDomainName(String val)
	{
		domainName = val;
	}
	
	
	public String getLastUpdateUserId()
	{
		return lastUpdateUserId;
	}
	
	public void setLastUpdateUserId(String val)
	{
		lastUpdateUserId = val;
	}
	
	
	
	public Date getLastUpdateTimestamp()
	{
		return lastUpdateTimestamp;
	}
	
	public void setLastUpdateTimestamp(Date val)
	{
		lastUpdateTimestamp = val;
	}
	
	
	public Date getCreateTimestamp()
	{
		return createTimestamp;
	}
	
	public void setCreateTimestamp(Date val)
	{
		createTimestamp = val;
	}
	
	
	public String getCreateUserId()
	{
		return createUserId;
	}
	
	public void setCreateUserId(String val)
	{
		createUserId = val;
	}
	
	
	public String getStatus()
	{
		return status;
	}
	
	public void setStatus(String val)
	{
		status = val;
	}
	
	
	public Date getResolvedTimestamp()
	{
		return resolvedTimestamp;
	}
	
	public void setResolvedTimestamp(Date val)
	{
		resolvedTimestamp = val;
	}
	
	
	public String getErrorMessage()
	{
		return errorMessage;
	}
	
	public void setErrorMessage(String val)
	{
		errorMessage = val;
	}
	
	
	public String getErrorStatus()
	{
		return errorStatus;
	}
	
	public void setErrorStatus(String val)
	{
		errorStatus = val;
	}
	
	public String getReferenceValue()
	{
		return referenceValue;
	}
	
	public void setReferenceValue(String val)
	{
		referenceValue = val;
	}
	
	
	public String getReferenceCode()
	{
		return referenceCode;
	}
	
	public void setReferenceCode(String val)
	{
		referenceCode = val;
	}
	
	
	public String getReferenceIdentifier()
	{
		return referenceIdentifier;
	}
	
	public void setReferenceIdentifier(String val)
	{
		referenceIdentifier = val;
	}
	
	
	public char getErrorCode()
	{
		return errorCode;
	}
	
	public void setErrorCode(char val)
	{
		errorCode = val;
	}
	
	
	public int getErrorCatalogId()
	{
		return errorCatalogId;
	}
	
	public void setErrorCatalogId(int val)
	{
		errorCatalogId = val;
	}
	
	
	public int getErrorCatalogDetailsId()
	{
		return errorCatalogDetailsId;
	}
	
	public void setErrorCatalogDetailsId(int val)
	{
		errorCatalogDetailsId = val;
	}
}