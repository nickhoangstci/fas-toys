/** 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolioweb/setup/form/AssignRoleForm.java,v 1.2.6.1 2010/08/22 23:08:39 mechevarria Exp $ 
 * 
 *  Modification History:
 *  $Log: AssignRoleForm.java,v $
 *  Revision 1.2.6.1  2010/08/22 23:08:39  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.2  2006/04/12 23:32:12  aarora
 *  Organized imports
 *
 *  Revision 1.1  2005/09/13 13:21:41  nsehra
 *  first version
 *
 */
package crt.com.freightdesk.fdfolioweb.setup.form;

import java.util.Hashtable;
import java.util.List;

import com.freightdesk.fdfolio.common.BasicButtonsForm;

/**
 * @author Nitin Sehra
 *
 */
public class AssignRoleForm
	extends BasicButtonsForm 
{
	private List roleList;
	private String systemRoleCode;
	private List systemFunctionList;
	private String hdnProcess;
	private String roleName;
	private Hashtable systemFunctionByRole;
	
    /**
     * @return
     */
    public List getRoleList()
    {
        return roleList;
    }

    /**
     * @return
     */
    public List getSystemFunctionList()
    {
        return systemFunctionList;
    }

    /**
     * @param list
     */
    public void setRoleList(List list)
    {
        roleList = list;
    }

    /**
     * @param list
     */
    public void setSystemFunctionList(List list)
    {
        systemFunctionList = list;
    }

    /**
     * @return
     */
    public String getSystemRoleCode()
    {
        return systemRoleCode;
    }

    /**
     * @param string
     */
    public void setSystemRoleCode(String string)
    {
        systemRoleCode = string;
    }

    /**
     * @return
     */
    public String getHdnProcess()
    {
        return hdnProcess;
    }

    /**
     * @param string
     */
    public void setHdnProcess(String string)
    {
        hdnProcess = string;
    }

    /**
     * @return
     */
    public String getRoleName()
    {
        return roleName;
    }

    /**
     * @param string
     */
    public void setRoleName(String string)
    {
        roleName = string;
    }

   /**
     * @return
     */
    public Hashtable getSystemFunctionByRole()
    {
        return systemFunctionByRole;
    }

    /**
     * @param hashtable
     */
    public void setSystemFunctionByRole(Hashtable hashtable)
    {
        systemFunctionByRole = hashtable;
    }

}
