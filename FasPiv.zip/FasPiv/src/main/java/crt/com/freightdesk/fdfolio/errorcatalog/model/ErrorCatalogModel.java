package crt.com.freightdesk.fdfolio.errorcatalog.model;

import java.sql.Date;

public class ErrorCatalogModel
{
	private int errorCatalogId;

	private String fileName;
	private String fileDirName;
	private String fileStatus;
	private String errorType;
	private String postProcessLocation;
	private String xml;
	private Date closedTimestamp;
	private String status;
	private String createUserId;
	private Date createTimestamp;
	private String lastUpdateUserId;
	private Date lastUpdateTimestamp;
	private String domainName;
	private String messageType;
	
	public void setDomainName(String str)
	{
		domainName = str;
	}

	public String getDomainName()
	{
		return domainName;
	}

	public void setLastUpdateTimestamp(Date ts)
	{
		lastUpdateTimestamp = ts;
	}

	public Date getLastUpdateTimestamp()
	{
		return lastUpdateTimestamp;
	}


	public void setLastUpdateUserId(String str)
	{
		lastUpdateUserId = str;
	}

	public String getLastUpdateUserId()
	{
		return lastUpdateUserId;
	}

	public void setCreateTimestamp(Date ts)
	{
		createTimestamp = ts;
	}

	public Date getCreateTimestamp()
	{
		return createTimestamp;
	}

	public void setCreateUserId(String str)
	{
		createUserId = str;
	}

	public String getCreateUserId()
	{
		return createUserId;
	}

	public void setStatus(String str)
	{
		status = str;
	}

	public String getStatus()
	{
		return status;
	}


	public void setClosedTimestamp(Date ts)
	{
		closedTimestamp = ts;
	}

	public Date getClosedTimestamp()
	{
		return closedTimestamp;
	}

	public void setXml(String str)
	{
		xml = str;
	}

	public String getXml()
	{
		return xml;
	}

	public void setPostProcessLocation(String str)
	{
		postProcessLocation = str;
	}

	public String getPostProcessLocation()
	{
		return postProcessLocation;
	}



	public void setErrorType(String str)
	{
		errorType = str;
	}

	public String getErrorType()
	{
		return errorType;
	}


	public void setFileStatus(String str)
	{
		fileStatus = str;
	}

	public String getFileStatus()
	{
		return fileStatus;
	}


	public void setFileDirName(String str)
	{
		fileDirName = str;
	}

	public String getFileDirName()
	{
		return fileDirName;
	}


	public void setFileName(String str)
	{
		fileName = str;
	}

	public String getFileName()
	{
		return fileName;
	}


	public void setErrorCatalogId(int id)
	{
		errorCatalogId = id;
	}

	public int getErrorCatalogId()
	{
		return errorCatalogId;
	}


	public String getMessageType() 
	{
		return messageType;
	}


	public void setMessageType(String str) 
	{
		messageType = str;
	}
}