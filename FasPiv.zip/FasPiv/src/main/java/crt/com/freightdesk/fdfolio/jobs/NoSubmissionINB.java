package crt.com.freightdesk.fdfolio.jobs;

import java.sql.Connection;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import crt.com.freightdesk.fdfolio.dao.QuartzDao;
import com.freightdesk.fdcommons.ConnectionUtil;
import com.freightdesk.fdcommons.FDSuiteProperties;

public class NoSubmissionINB implements Job {

	protected QuartzDao quartzDao = null;
	protected Logger logger = Logger.getLogger(getClass());

	public void execute(JobExecutionContext exeContext) throws JobExecutionException {
		Connection connection = null;

		try {
			DataSource dataSource = (DataSource) exeContext.getMergedJobDataMap().get("dataSource");
			String sendEmails = FDSuiteProperties.getProperty("ENABLE_SENDMAIL");

			connection = dataSource.getConnection();

			quartzDao = new QuartzDao();
			quartzDao.setConnection(connection);
			
			// TODO get system user list
			
			// TODO process list for sendmail

		} catch (Exception ex) {
			throw new JobExecutionException(ex.getMessage());
		} finally {
			ConnectionUtil.closeResources(connection, null, null);
		}

	}
}
