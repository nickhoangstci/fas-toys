package crt.com.ntelx.nxcommons.reporting;
import java.util.ArrayList;
import java.util.List;

import com.freightdesk.fdcommons.OptionBean;


public class OptionCollection {
	private String name;
	private String query;
	private List<OptionBean> optionBeans;
	
	public OptionCollection() {
		name = "";
		query = "";
		optionBeans = new ArrayList<OptionBean>();
	}
	
	public String getQuery() {
		return query;
	}

	public void setQuery(String query) {
		this.query = query;
	}

	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public List<OptionBean> getOptionBeans() {
		return optionBeans;
	}
	
	public void setOptionBeans(List<OptionBean> optionBeans) {
		this.optionBeans = optionBeans;
	}
	
	public void loadOptionBeansFromDB() {
		OptionCollectionDAO collectionDAO = new OptionCollectionDAO();
		optionBeans.addAll(collectionDAO.getOptionCollectionFromDB(query));
	}
	
}
