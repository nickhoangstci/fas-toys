/**
 *
 * Copyright (c) 2000-2002 NTELX
 *  All rights reserved.
 *
 * This software is the confidential and proprietary information of NTELX
 * ("Confidential Information").  You shall not disclose such Confidential Information
 * and shall use it only in accordance with the terms of the license agreement you entered
 * into with NTELX.
 *
 *
 *  $Header: /usr2/cvs/fdt/core/src/FDSuite/src/com/freightdesk/fdsuite/common/CookieManager.java,v 1.2.2.1 2007/05/17 15:45:29 mechevarria Exp $
 *
 *  Modification History:
 *  $Log: CookieManager.java,v $
 *  Revision 1.2.2.1  2007/05/17 15:45:29  mechevarria
 *  merge changes with main branch
 *
 *  Revision 1.3  2007/04/12 16:03:49  dkumar
 *  using Symmetric Cipher with encryption Manager
 *
 *  Revision 1.2  2006/12/12 10:26:48  dkumar
 *  recpackaging of encryptionManager from suite to fdcommons
 *
 *  Revision 1.1  2006/08/11 20:51:41  dkumar
 *  chages for making fdsuite struts based application
 *
 *  Revision 1.1  2004/09/15 13:05:24  ranand
 *  2.6 Baseline
 *
 *
 */

package crt.com.ntelx.fdsuite.common;

import com.freightdesk.fdsuite.common.Marshaller;
import org.apache.log4j.Logger;

import com.freightdesk.fdcommons.EncryptionManager;


/**
 * @author Amrinder Arora
 */
public class CookieManager {

    /**
     * A logger
     */
    protected Logger logger = Logger.getLogger (getClass());

    /**
     * A marshaller to aid in packaging and unpackaging user information
     * and converting ascii strings to/from bytes.
     */
    protected Marshaller marshaller = new Marshaller(".");

    /**
     * An encryption manager to aid in encrypting and decrypting cookie values
     */
    protected EncryptionManager encryptionManager = new EncryptionManager();


    public void processCookieValue (String cookieValue, StringBuffer userBuf,
            StringBuffer passwordBuf, StringBuffer inetBuf)
    {
        try {
            logger.info ("processCookieValue(): begin");
            byte[] unmarshalled = marshaller.unmarshall (cookieValue);
            byte[] decryptedBytes = encryptionManager.decryptWithSC(unmarshalled);
            String decrypted = new String (decryptedBytes);
            marshaller.unmarshall (decrypted, userBuf, passwordBuf, inetBuf);
        } catch (Exception e) {
            logger.error ("Exception processing cookie value", e);
            throw new IllegalArgumentException ("Cookie value is not good");
        }
    }

    /**
     * Gets a valid cookie value that can be stored in an HTTP cookie.
     *
     * @param userId The user id of the user in the form DOMAINN.LOGIN
     * @param password The password of the user
     * @param inetAddr The remote address
     */
    public String getCookieValue (String userId, String password, String inetAddr)
    {
        logger.info ("getCookieValue(): begin");
        String marshalled = marshaller.marshall (userId, password, inetAddr);
        byte[] marshalledBytes = marshalled.getBytes();
        byte[] encryptedBytes = encryptionManager.encryptWithSC(marshalledBytes);
        String cookieValue = marshaller.marshall (encryptedBytes);
        return cookieValue;
    }
}

