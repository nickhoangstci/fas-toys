package crt.com.ntelx.nxcommons.email;

public class NoSubCCSFEmailBody extends AbstractEmailBody
{
	private String contact   = "";
	private String orgName   = "";
	private String certNum   = "";
	private String sysdate   = "";
	private String dueDate   = "";
	
	public String getSysDate()
	{
		return sysdate;
	}
	public void setSysDate(String sysdate)
	{
		this.sysdate = sysdate;
	}
	public String getDueDate()
	{
		return dueDate;
	}
	public void setDueDate(String dueDate)
	{
		this.dueDate = dueDate;
	}
	public String getContact()
	{
		return contact;
	}
	public void setContact(String contact)
	{
		this.contact = contact;
	}
	
	public String getOrgName()
	{
		return orgName;
	}
	public void setOrgName(String orgName)
	{
		this.orgName = orgName;
	}

	public String getCertNum()
	{
		return certNum;
	}
	public void setCertNum(String certNum)
	{
		this.certNum = certNum;
	}
	
	public String getBody() {
		String body = null;

		body = replaceGDPattern(template, "<contact>",   contact );
		body = replaceGDPattern(body,     "<cert>",      certNum );
		body = replaceGDPattern(body,     "<orgname>",   orgName );
		body = replaceGDPattern(body,     "<duedate>",   dueDate );
		body = replaceGDPattern(body,     "<sysdate>",   sysdate );
		
		return body;
	}
	
	
}
