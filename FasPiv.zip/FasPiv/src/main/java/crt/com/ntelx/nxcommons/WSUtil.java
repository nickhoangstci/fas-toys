package crt.com.ntelx.nxcommons;

/**
 * @author Mike Echevarria
 */

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

public class WSUtil {

  private final static String TMP_DIR_SYSTEM_PROPERTY_NAME = "java.io.tmpdir";

  private static Logger logger = Logger.getLogger("crt.com.ntelx.nxcommons.WSUtil");
  /**
   * 	method for dealing with items from the properties file
   */
  public static String getProperty(Properties properties, String propertyName, String defaultPropertyValue) {
    String propertyValue = properties.getProperty(propertyName);

    if (null == propertyValue) {
      propertyValue = defaultPropertyValue;
      logger.error("Cannot find " + propertyName + " in properties file, " + "using default property value of: " +
                   defaultPropertyValue);
    }

    return propertyValue;
  }

  /**
   * 	method for dealing with items that are directories from the properties file
   */
  public static String getPropertyForDir(Properties properties, String propertyName, String relativeDefaultDirName) {
    String dir = properties.getProperty(propertyName);

    //if cannot find the directory in the properties file
    if (null == dir) {
      dir = getAlternateDir(relativeDefaultDirName);

      logger.error("Cannot find " + propertyName + " in properties file, using: " + dir);
    }

    return dir;
  }

  /**
   * 	method for returning an alternative directory
   */
  public static String getAlternateDir(String relativeDirName) {
    //initialize dir to temp dir
    String dir = System.getProperty(TMP_DIR_SYSTEM_PROPERTY_NAME) + relativeDirName;

    //attempt to create the directory if it doesnt currently exist
    if (createDirs(dir) == false) {
      logger.error("Could not create alternate dir of " + dir);
    }
    ;

    return dir;
  }

  /**
   * create hierarchy of directories
   */
  public static boolean createDirs(String createDirsPath) {
    File createDirs = new File(createDirsPath);

    int numAttempts = 0;
    final int MAX_ATTEMPTS = 20;
    while (!createDirs.exists() && numAttempts < MAX_ATTEMPTS) {
      boolean success = createDirs.mkdirs();
      numAttempts++;

      //report retries
      if (!success) {
        logger.error("Directory creation of " + createDirs.getAbsolutePath() + " failed, retry #" + numAttempts);
      }
    }

    //if dir(s) still don't exist ...
    if (!createDirs.exists()) {
      logger.error("Creation of directory " + createDirs.getAbsolutePath() + "has failed the maximum of " +
                   MAX_ATTEMPTS + " attempts!");
      return false;
    }
    else { //dir(s) finally exist
      return true;
    }
  }

  public static String getUtcTimeStamp(Date original) {
    SimpleDateFormat tsaFasFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ");
    String timeStamp = tsaFasFormat.format(original);
    // Insert : before last two zeroes.
    // Example: -0400 to -04:00
    timeStamp = timeStamp.substring(0, timeStamp.length() - 2) + ":" +
        timeStamp.substring(timeStamp.length() - 2, timeStamp.length());
    return timeStamp;
  }

  public static String convertFileToString(String fileName) {
    try {
      FileInputStream file = new FileInputStream(fileName);
      byte[] b = new byte[file.available()];
      file.read(b);
      file.close();
      String result = new String(b);
      return result;
    }
    catch (Exception e) {
      logger.error("Error converting file to a String:" + e);

    }
    return null;
  }

  public static String findReplaceString(String search, String find, String replace) {

    String result = null;
    try {
      String str = "(" + find + ")";
      Pattern pattern = Pattern.compile(str, Pattern.CASE_INSENSITIVE);
      Matcher matcher = pattern.matcher(search);
      result = matcher.replaceAll(replace);
      return result;
    }
    catch (Exception ex) {
      logger.warn("error in findReplaceString() response templates might be malformed");
      return search;
    }

  }

  public static String getAWBSerialNumber(String AWBXml) {

    Pattern p = Pattern.compile("\\<AWBSerialNumber>([^\\<>]++)\\</AWBSerialNumber>");

    Matcher m = p.matcher(AWBXml);
    try {
      m.find(); // find only the first instance
      return m.group(1); // group 1 is just the value matched
    }
    catch (Exception ex) {
      logger.error("The input XML is missing the <AWBSerialNumber> tag! details:" + ex);
      return " ";
    }
  }

  public static String getDomainUser(String AWBXml) {
    Pattern p = Pattern.compile("\\<UserName>([^\\<>]++)\\</UserName>");

    Matcher m = p.matcher(AWBXml);
    try {
      m.find(); // find only the first instance
      return m.group(1); // group 1 is just the value matched
    }
    catch (Exception ex) {
      logger.error("The input XML is missing the <UserName> tag! details:" + ex);
      return " ";
    }
  }

  public static String getAccountNumber(String AWBXml) {

    Pattern p = Pattern.compile("\\<AccountNumber>([^\\<>]++)\\</AccountNumber>");

    Matcher m = p.matcher(AWBXml);
    try {
      m.find(); // find only the first instance
      return m.group(1); // group 1 is just the value matched
    }
    catch (Exception ex) {
      logger.error("The input XML is missing the <AccountNumber> tag! details:" + ex);
      return " ";
    }
  }


  public static String getConsignmentDetails(String inputXML) {
    String consignmentdetails = "";

    try {
      consignmentdetails = inputXML.substring(inputXML.indexOf("<AWBConsignmentDetails>") +
                                              "<AWBConsignmentDetails>".length(),
                                              inputXML.indexOf("</AWBConsignmentDetails>"));
      return consignmentdetails;
    }
    catch (Exception e) {
      logger.error("The input XML is missing the <AWBConsignmentDetails> tag! details:" + e);
      return "";
    }
  }

  public static void createFileFromString(String str, String filename) {
    File outputFile = new File(filename);
    FileWriter out = null;
    try {
      out = new FileWriter(outputFile);
      out.write(str);
      out.close();

    }
    catch (IOException ex) {
      //logger.error("unable to write response file to the output dir:");
      //ex.printStackTrace();
	  logger.error("Exception - unable to write response file to the output dir: " + ex.getMessage());
    }
  }

  public static String getFilenameWithoutExt(String fileName) { // gets filename without extension
    int dot = fileName.lastIndexOf(".");
    return fileName.substring(0, dot);
  }

  public void deleteItem(String absoluteFilePath) {
    File itemToDelete = new File(absoluteFilePath);

    if (itemToDelete.exists()) {
      boolean success = itemToDelete.delete();

      if (success) {
        System.out.println(itemToDelete.getAbsolutePath() + " has been deleted");
      }
      else {
        System.out.println(itemToDelete.getAbsolutePath() + " was unable to be deleted");
      }
    }
    else { //could not delete item
      System.out.println(itemToDelete.getAbsolutePath() + " does not exist!");
    }
  }
  
  public static void saveContentsToFile(String contents, String path) {
	try {
	  // Create file.
	  File output = new File(path);

	  // Write to file
	  BufferedWriter out = new BufferedWriter(new FileWriter(output));
	  // Add the message contents
	  out.write(contents);
	  out.close();
	}
	catch (IOException ex) {
	   //ex.printStackTrace();
	   logger.error("Exception: " + ex.getMessage());
	}
  }
  
  // Takes an array of Strings and combines into one string with newlines.
  public static String rebuildString(String[] array) {
    String combined = "";
    for (int i = 0; i < array.length; i++) {
      if (i == 0) {
        combined = array[i];
      }
      else {
        combined = combined + "\n" + array[i];
      }
    }
    return combined;
  }
}
