package crt.com.ntelx.inbox;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.apache.log4j.Logger;


public class BogusRuleGridDAO
{
    protected static Logger logger = Logger.getLogger ( BogusRuleGridDAO.class );
    
	private static Map<Long, ArrayList<FasGridLine>> db = getRandomDB();
	
	private static ArrayList<FasGridLine> randomLines = null;
	
	public static Map<Long, ArrayList<FasGridLine>> getRandomDB()
	{
		Map<Long, ArrayList<FasGridLine>> db = new HashMap<Long, ArrayList<FasGridLine> >();
		
		if ( randomLines == null )
			randomLines = setRandGridLines();
			
		try
		{
			ArrayList<FasGridLine> lines = null; 
	
			FasInboxDAO fasDao = new FasInboxDAO();
					
			List<FaEntry> faEntries = fasDao.getEntriesOrderedDate(); 
			
			FasGridLine line = null; 
			for ( FaEntry faEntry : faEntries )
			{
				lines = new ArrayList<FasGridLine>();
				
				for ( int i = 0; i < 6; i++ )
				{
					line = getRandomLine();
					if ( i == 0 )
						line.setLineName( "SHIPPER" );
					else if ( i == 1 )
						line.setLineName( "CONSIGNEE" );
					else if ( i == 2 )
						line.setLineName( "CARRIER" );
					else if ( i == 3 )
						line.setLineName( "ROUTE" );
					else if ( i == 4 )
						line.setLineName( "COMMODITY" );
					else if ( i == 5 )
						line.setLineName( "PAYMENT" );					
						  
					logger.debug( "Putting: " + line.getLineName() + " for " + i  );
					lines.add( line );
				}
			
				db.put( faEntry.getEntryid(), lines );
			}
		}
		catch ( Exception e )
		{
			//logger.error( e.getMessage() );
			//e.printStackTrace();
			logger.error("Exception: " + e.getMessage());
			
		}
		
		return db;
	}
	
	
	public ArrayList<FasGridLine> getGridLinesByFaEntryID( long faEntryId )
	{		
		return db.get( faEntryId );
	}
	
	public static ArrayList<FasGridLine> setRandGridLines()
	{

		ArrayList<FasGridLine> lines = new ArrayList<FasGridLine>();
		FasGridLine line = null;
		
		line = new FasGridLine();
		line.setCompliance      ( "20" );
		
		lines.add( line );
	
		line = new FasGridLine();
		line.setRandomization   ( "25" );
		line.setExpectedBehavior( "43" );
		
		lines.add( line );
		
		line = new FasGridLine();
		line.setTransactional   ( "18" );

		
		lines.add( line );
		
		line = new FasGridLine();
	
		line.setExpectedBehavior( "22" );
		
		line = new FasGridLine();		
		line.setExpectedBehavior( "30" );
		
		lines.add( line );
				
		line = new FasGridLine();		
		line.setExpectedBehavior( "30" );
		
		line = new FasGridLine();		
		line.setExpectedBehavior( "30" );
		line.setWatchlist       ( "35" );
		
		lines.add( line );
		
		line = new FasGridLine();
		line.setRandomization   ( "33" );

		lines.add( line );

		line = new FasGridLine();
		line.setRandomization   ( "10" );
		line.setCompliance      ( "25" );
		line.setExpectedBehavior( "12" );
		line.setTransactional   ( "12");
		
		lines.add( line );
		
		line = new FasGridLine();
		line.setRandomization   ( "10" );
		line.setExpectedBehavior( "12" );
		line.setTransactional   ( "12" );
		
		lines.add( line );
		
		return lines;
	}
	
	public static FasGridLine getRandomLine()
	{
		
		Random rand = new Random();
		int size = randomLines.size();
		int index = rand.nextInt( size );
		
		FasGridLine line = randomLines.get(  index  );
		
		FasGridLine newLine = new FasGridLine();
		
		newLine.setCompanyViability( line.getCompanyViability() );
		newLine.setCompliance      ( line.getCompliance()       );
		newLine.setExpectedBehavior( line.getExpectedBehavior() );
		newLine.setRandomization   ( line.getRandomization()    );
		newLine.setTransactional   ( line.getTransactional()    );
		newLine.setWatchlist       ( line.getWatchlist()        );
		
		return  newLine;
		
	}
	
	public BogusRuleGridDAO()
	{
		
	}
	

}
