package crt.com.ntelx.nxcommons.email;

public abstract class AbstractEmailBody
{
	protected String template = "";
		
	public String getTemplate()
	{
		return template;
	}
	
	public void setTemplate(String template)
	{
		this.template = template;
	}

	// This function is necessary because Java is a POS. String.replaceAll( )
	// will fail if the
	// replacement string has a $ in it. No kidding.
	//
	public String replaceGDPattern(String template, String pattern, String replacement) 
	{
		StringBuffer buf = new StringBuffer(template);

		int patternIndex = buf.indexOf(pattern);
		if (patternIndex > -1) {
			buf.replace(patternIndex, patternIndex + pattern.length(), replacement);
		}

		return buf.toString();
	}
		
}
