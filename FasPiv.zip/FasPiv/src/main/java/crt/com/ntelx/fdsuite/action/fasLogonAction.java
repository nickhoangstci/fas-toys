/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/*  Revision 5.0  2015/01/25 13:03:45  ktsou
 *  5.0 Baseline
 */
package crt.com.ntelx.fdsuite.action;

import java.util.HashMap;
import javax.security.auth.login.AccountExpiredException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
//import org.apache.struts.action.ActionErrors;
//import org.apache.struts.action.ActionMessage;
//import org.apache.struts.action.ActionMessages;
import com.freightdesk.fdcommons.ActionErrors;
import com.freightdesk.fdcommons.ActionMessage;
import com.freightdesk.fdcommons.ActionMessages;
import crt.com.ntelx.fdsuite.common.RequestDetails;
import crt.com.ntelx.nxcommons.AuthenticationUtils;
import com.freightdesk.fdcommons.Credentials;
import com.freightdesk.fdcommons.InvalidUserException;
import com.freightdesk.fdcommons.LicenseProperties;
import com.freightdesk.fdcommons.PasswordExpiredException;
import com.freightdesk.fdcommons.SessionKey;
import com.freightdesk.fdcommons.SessionStore;
import com.freightdesk.fdcommons.UserNotActiveException;
import com.freightdesk.fdcommons.asyncprocess.AsyncProcessManager;
import com.freightdesk.fdcommons.asyncprocess.AsyncProcessingLogModel;
import com.opensymphony.xwork2.ActionSupport;

/**
 *
 * @author Kevin.Tsou
 */
public class fasLogonAction extends ActionSupport{
    HttpServletRequest request;
    
    private String userId = "";
    private String password = "";
    private String btnLogin = "";
    private String btnLogout = "";
    private String product = "";
    private String chkRememberMe = "";
    private String defaultProduct = "";
    
    protected Logger logger = Logger.getLogger(getClass());
    
    /**
	 * Processes all requests for the fasLogonAction URL.
	 * 
	 * <UL>
	 * <LI>If the request is from a different page, and the user is not currently logged in, it forwards the user to the login page.
	 * <LI>If the request corresponds to user's clicking Login button, then it validates the credentials, and initializes the session 
         *     for the user and forwards the user to the home page. If the user's credentials cannot be validated, it gives an error message 
         *     and forwards the user back to the login page.
	 * <LI>If the request is for Logout, it invalidates user's current session, and forwards the user back to the login page.
	 * </UL>
	 */
    
    @Override
    public String execute() throws Exception {
        String userName;
	String domainName;
        AsyncProcessingLogModel asyncLogModel = new AsyncProcessingLogModel();
        AsyncProcessManager asyncManager = new AsyncProcessManager();
        HttpSession session;
        SessionStore store;
        Credentials credentials;
        
        System.out.println("fasLogonAction.execute enter execute method   ");
        logger.info("beginning fasLogonAction.execute");
        
        String action = request.getParameter("action");
        
        if ((action != null) && (action.equalsIgnoreCase("logout"))) {
            logger.debug("respondBtnLogout: begin()");
            session = request.getSession();
            store = SessionStore.getInstance(session);
            credentials = (Credentials) store.get(SessionKey.CREDENTIALS);
            try {
                // Log session logouts in the ASYNCPROCESSINGLOG table
                asyncLogModel.init(credentials.getUserId(), credentials.getDomainName(), "LOGOUT", 
                        "SECURITY", "In process logout", request.getRemoteAddr());
                asyncLogModel = asyncManager.createAsyncProcessLog(asyncLogModel);
                // invalidates the session
		store.invalidateSessions(request);
		// record success in the ASYNCPROCESSINGLOG table
		asyncManager.logResult(asyncLogModel, true, "Successful logout of user " + credentials.getDomainName() + "." + 
                        credentials.getUserId(), "respondBtnLogout");
                
            } catch (Exception ex) {
                asyncManager.logResult(asyncLogModel, false, "Failed logout of user, unable to read credentials", "Exception");
		// logger.error ("Unexpected Exception in logout", ex);
            }
            return "display";
        }
        
        if ((action != null) && (action.equalsIgnoreCase("plugins"))) {
            logger.info("preparing to display plugins page");
            setBtnLogin(null);
            return "displayPlugins";
        }
        
        if (!hasValidLicense()) {
            logger.debug("License for FAS is not valid or expired, redirecting to licenseExpired page");
            ActionErrors errors = new ActionErrors();
            errors.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("error.licenseExpired"));
            //this.saveErrors(request, errors);
            return "licenseExpired";
        }
        
        RequestDetails requestDetails = new RequestDetails(request);
        if (requestDetails.browserNotSupported()) {
            logger.debug(requestDetails);
            // forward to not supported page
            return "help";
	}
        
        if ((getBtnLogin() != null) && (getBtnLogin().length() > 0)) {
            // check for valid token
            /*if (isTokenValid(request)==false)
                return "error";
             */
			
            userId = getUserId();
            if (userId != null)
                userId = userId.toUpperCase();
            
            password = getPassword();
            logger.debug("userId, password retrieved from form: " + userId);
            
            /*respondCredentials*/
            try {
                // separates the userName and domainName from userId
		int index = userId.indexOf('.');
                userName = userId.substring(index + 1, userId.length());
                domainName = userId.substring(0, index);
                // The User Name column has max length of 8 characters.
		if (userName.length() > 8) {
                    logger.debug("User name " + userName + " will be truncated to 8 characters in length.");
                    userName = userName.substring(0, 8);
                    // rebuild the userId
                    userId = domainName + "." + userName;
		}
            } catch  (Exception e) {
                logger.error("Exception in parsing username and domain, " + e);
                setActionMessage(request, new String[] { "error.login.generic" });
                return "display";
            }
            
            try {
                // Record attempted logins in the ASYNCPROCESSINGLOG table
                asyncLogModel.init(userName, domainName, "LOGIN", "SECURITY", "In process login", 
                        request.getRemoteAddr());
                // add the browser details to the login
                requestDetails = new RequestDetails(request);
                asyncLogModel.setBrowser(requestDetails.getBrowser().toUpperCase());
                asyncLogModel.setBrowserVersion(requestDetails.getVersion());
		asyncLogModel = asyncManager.createAsyncProcessLog(asyncLogModel);
                
                credentials = AuthenticationUtils.getCredentials(userName, password, 
                        domainName, request.getRemoteAddr());
                session = request.getSession();
                
                // Record successful login in the ASYNCPROCESSINGLOG table
		asyncManager.logResult(asyncLogModel, true, "Successful login", "respondCredentials");
                
                // only for debugging purposes
		session.setAttribute("TimeUserLoggedIn", new java.util.Date());
                
                // Stores the credentials in the SessionStore
		if (credentials.getDateFormat() == null || credentials.getDateFormat().equals(""))
                    credentials.setDateFormat("yyyy-MM-dd");
                
                store = SessionStore.getInstance(session);
		store.put(SessionKey.CREDENTIALS, credentials);
                        
                // Stores the access list in the SessionStore
		HashMap<String, String> accessList = AuthenticationUtils.getNxRolePermissionList(credentials.getRole());
		store.put(SessionKey.ACCESS_CONTROL_LIST, accessList);
                
                AuthenticationUtils.updateLastLoginTimestamp(credentials.getSystemUserId());
                return "success";
                        
            } catch (UserNotActiveException unaEx) {
                logger.info("UserAccess " + userId + ". Login Error " + "User Not Active.");
		logger.error("respondBtnCredentials(): UserNotActiveException");
		asyncManager.logResult(asyncLogModel, false, "Failed login due to user not being active.", "UserNotActiveException");
		setActionMessage(request, new String[] { "error.login.userNotActive" });
            } catch (PasswordExpiredException peEx) {
		logger.info("UserAccess " + userId + ". Login Error " + "Password Expired.");
		logger.error("threw PasswordExpiredException");
		asyncManager.logResult(asyncLogModel, false, "Failed login due to password expiration.", "PasswordExpiredException");
		setActionMessage(request, new String[] { "jsp.login.message" });
            } catch (InvalidUserException ivEx) {
		if (ivEx.getMessage().equals("-1")) {
                    logger.info("UserAccess " + userId + ". Login Error " + "Username Does Not Exist.");
                    asyncManager.logResult(asyncLogModel, false, "Failed login due to unknown user id.", "InvalidUserException");
                    setActionMessage(request, new String[] { "error.login.generic" });
		} else {
                    logger.debug("UserAccess " + userId + ". Login Error " + "Invalid Password.");
                    asyncManager.logResult(asyncLogModel, false, "Failed login due to invalid password.", "InvalidUserException");
                    setActionMessage(request, new String[] { "error.login.generic" });
		}
            } catch (AccountExpiredException auEx) {
		logger.error("UserAccess " + userId + ". Login Error " + "Account Locked.");
		asyncManager.logResult(asyncLogModel, false, "Failed login due to excessive failed login attempts.", "AccountExpiredException");
		setActionMessage(request, new String[] { "error.login.failedLoginExceeded" });
            } catch (RuntimeException ex) {
		logger.error("respondBtnCredentials(): ConnectionException", ex);
		asyncManager.logResult(asyncLogModel, false, "Failed login due to runtime exception.", "RuntimeException");
		setActionMessage(request, new String[] { "error.login.connectionFailed" });
            } catch (Exception systemException) {
		logger.error("respondBtnCredentials(): SystemException", systemException);
		asyncManager.logResult(asyncLogModel, false, "Failed login due to system exception.", "systemException");
		setActionMessage(request, new String[] { "error.serverexception" });
            }
            return "display";
	}
        return "success";
    }
    
    public boolean hasValidLicense() {
        return LicenseProperties.isProductLicensed("FDSuite");
    }
    
    public String getUserId(){
        return userId;
    }
    
    public void setUserId(String theUserid){
        this.userId = theUserid;
    }
    
    public String getPassword(){
        return password;
    }
    
    public void setPassword(String thePassword){
        this.password = thePassword;
    }
    
    public String getBtnLogin(){
        return btnLogin;
    }
    
    public void setBtnLogin(String theBtnLogin){
        this.btnLogin = theBtnLogin;
    }
    
    public String btnLogout(){
        return btnLogout;
    }
    
    public void setBtnLogout(String theBtnLogout){
        this.btnLogout = theBtnLogout;
    }
    
    public String getProduct(){
        return product;
    }
    
    public void setProduct(String theProduct){
        this.product = theProduct;
    }
    
    public String getChkRememberMe(){
        return chkRememberMe;
    }
    
    public void setChkRememberMe(String theChkRememberMe){
        this.chkRememberMe = theChkRememberMe;
    }
    
    public String getDefaultProduct(){
        return defaultProduct;
    }
    
    public void setDefaultProduct(String theDefaultProduct){
        this.defaultProduct = theDefaultProduct;
    }
    
    public void setActionMessage(HttpServletRequest request, String[] messageKeyObject) {
        int length = messageKeyObject.length;
	logger.debug("messageKeyObject.length = " + length);
	ActionMessage actionMessage;
        
	switch (length) {
            case 2:
		logger.debug("messagekeyvalues" + messageKeyObject[0]);
            	actionMessage = new ActionMessage(messageKeyObject[0], (Object) messageKeyObject[1]);
		break;
            case 3:
		actionMessage = new ActionMessage(messageKeyObject[0], messageKeyObject[1], messageKeyObject[2]);
		break;
            case 4:
		actionMessage = new ActionMessage(messageKeyObject[0], messageKeyObject[1], messageKeyObject[2], messageKeyObject[3]);
		break;
            case 5:
		actionMessage = new ActionMessage(messageKeyObject[0], messageKeyObject[1], messageKeyObject[2], messageKeyObject[3], messageKeyObject[4]);
		break;
            default:
		actionMessage = new ActionMessage(messageKeyObject[0]);
        }

        ActionMessages messages = new ActionMessages();
	messages.add(ActionMessages.GLOBAL_MESSAGE, actionMessage);
	/* this.saveMessages(request, messages); */
	logger.debug("message has been set on request");
    }
}
