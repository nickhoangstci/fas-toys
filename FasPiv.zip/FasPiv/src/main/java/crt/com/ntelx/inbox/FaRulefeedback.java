package crt.com.ntelx.inbox;




public class FaRulefeedback extends BaseEntity implements java.io.Serializable {

	private static final long serialVersionUID = 1L;
	private long rulefeedbackid;
	private FaScoredetails faScoredetails;
	
	
	
	private String feedback;
	

	public long getPk() {
		return rulefeedbackid;
	}

	public void setRulefeedbackid(long rulefeedbackid) {
		this.rulefeedbackid = rulefeedbackid;
	}

	public long getRulefeedbackid() {
		return rulefeedbackid;
	}

	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}

	public String getFeedback() {
		return feedback;
	}

	public void setFaScoredetails(FaScoredetails faScoredetails) {
		this.faScoredetails = faScoredetails;
	}

	public FaScoredetails getFaScoredetails() {
		return faScoredetails;
	}

	public String getIdentifier() {
		// TODO Auto-generated method stub
		return null;
	}

}
