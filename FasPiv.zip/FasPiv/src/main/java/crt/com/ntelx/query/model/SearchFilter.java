package crt.com.ntelx.query.model;

public interface SearchFilter {

public enum Disjunction{AND, OR};
	
public enum ValueDataType{
	STRING, LIST, MIN, MAX, BOOLEAN, DATE
}

Disjunction getDisjunction();
Object getPropertyName();
Object getFilterValue();
ValueDataType getDataType();
Predicate getPredicate();
}
