package crt.com.ntelx.nxcommons;

import com.freightdesk.fdcommons.ConnectionUtil;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;

public class UserUtils {
	public static Logger logger = Logger.getLogger("UserUtils");

	public static HashMap<String, Long> getParentTypeById(long contactId) {
		HashMap<String, Long> typeOrgMap = new HashMap<String, Long>();

		String query = "select orghierarchytypecode,orgid from orghierarchy where orgid = (select parentorgid from orghierarchy where orgid = ?) " + 
			           "union " +
			           "select orghierarchytypecode,orgid from orghierarchy where orgid = (select parentorgid from orghierarchy where orgid = (select parentorgid from orghierarchy where orgid = ?))";
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			conn = ConnectionUtil.getConnection();
			pstmt = conn.prepareStatement(query);
			pstmt.setLong(1, contactId);
			pstmt.setLong(2, contactId);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				logger.debug("ParentOrg of "+contactId+" is "+rs.getString("orghierarchytypecode")+", "+rs.getLong("orgid"));
				typeOrgMap.put(rs.getString("orghierarchytypecode"), rs.getLong("orgid"));
			}
			
			rs.close();
			pstmt.close();
			conn.close();
			
		} catch (Exception ex) {
			//ex.printStackTrace();
			logger.error("Exception : " + ex.getMessage());
		} finally {
			ConnectionUtil.closeResources(conn, pstmt, rs);
		}

		return typeOrgMap;
	}

	public static List<Long> getRelatedContacts(long contactId) {
		logger.debug("Calling getRelatedContacts with contactId: " + contactId);
		List<Long> contactList = new ArrayList<Long>();
		List<Long> subLocList = new ArrayList<Long>();

		String query = "select orgid, orghierarchytypecode from orghierarchy where parentorgid = (select parentorgid from orghierarchy where orgid=?)";

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = ConnectionUtil.getConnection();
			pstmt = conn.prepareStatement(query);
			pstmt.setLong(1, contactId);

			rs = pstmt.executeQuery();

			String orgType = null;
			long orgid = -1L;
			while (rs.next()) {
				orgType = rs.getString("orghierarchytypecode");
				orgid = rs.getLong("orgid");
				if (orgType.equals("CON"))
					contactList.add(orgid);
				else if (orgType.equals("LOC")) {

					subLocList = getLocContactsOrgIds(orgid);

					for (long con : subLocList)
						contactList.add(con);
				}

			}
			rs.close();

		} catch (Exception e) {
			logger.error("Exception in getRelatedContacts (" + contactId + " ) ", e);
		} finally {
			ConnectionUtil.closeResources(conn, pstmt, rs);
		}

		// for typecode of LOC, run query again
		return contactList;
	}

	public static List<Long> getLocContactsOrgIds(long locOrgId) {
		logger.debug("Getting contacts for Location with orgid: " + locOrgId);
		String query = "select orgid, orghierarchytypecode from orghierarchy where parentorgid = ?";
		List<Long> subConList = new ArrayList<Long>();

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = ConnectionUtil.getConnection();
			pstmt = conn.prepareStatement(query);
			pstmt.setLong(1, locOrgId);

			rs = pstmt.executeQuery();

			String orgType = null;
			long orgid = -1L;
			while (rs.next()) {
				orgType = rs.getString("orghierarchytypecode");
				orgid = rs.getLong("orgid");
				if (orgType.equals("CON"))
					subConList.add(orgid);
				else if (orgType.equals("LOC")) {
					// a recursive call could be added here if necessary to
					// allow for indefinate height of location/contact tree
				}

			}
			rs.close();

		} catch (Exception e) {
			logger.error("Exception in getLocContactsOrgIds (" + locOrgId + " ) ", e);
		} finally {
			ConnectionUtil.closeResources(conn, pstmt, rs);
		}

		return subConList;
	}

	public static List<String> getUserIds(List<Long> orgIds) {
		List<String> userList = new ArrayList<String>();
		String query = "select userid from systemuser where orgid in (?)";

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			conn = ConnectionUtil.getConnection();
			pstmt = conn.prepareStatement(query);

			for (long orgId : orgIds) {
				pstmt.setLong(1, orgId);

				rs = pstmt.executeQuery();

				String orgType = null;
				while (rs.next()) {
					userList.add(rs.getString("userid"));
				}
				rs.close();
			}
		} catch (Exception e) {
			logger.error("Exception in  getUserIds (" + " ) ", e);
		} finally {
			ConnectionUtil.closeResources(conn, pstmt, rs);
		}

		return userList;
	}
}
