package crt.com.ntelx.nxcommons.reporting;

import java.sql.Timestamp;
import java.util.List;

import org.apache.log4j.Logger;

import crt.com.ntelx.nxcommons.FasConstants;
import com.freightdesk.fdcommons.FormatDate;
import com.freightdesk.fdcommons.reporting.ParamXML;
import com.freightdesk.fdcommons.reporting.ReportXML;
import crt.com.ntelx.nxcommons.NxUtils;

public class ReportParamValidator {

	private Logger logger = Logger.getLogger(ReportParamValidator.class);
	
	private boolean isValid = true;
	
	private ReportXML serverSideReport = null;
	
	public ReportParamValidator(ReportXML reportXML) {
		
		logger.debug("Validating params for " + reportXML.getName());
		
		ReportProperties reportProps = ReportProperties.getInstance();
		serverSideReport = reportProps.getReportsXML().getReportByName(reportXML.getName()); 
		
		List<ParamXML> params = reportXML.getParams();
		boolean validValue = true;
		String type = "";
		String value = "";
		String name = "";
		
		for(ParamXML param : params) {
			
			name = param.getName();
			type = param.getType();
			value = param.getValue();
			name = param.getName();
			
			if(type.equalsIgnoreCase("text"))
				validValue = isValidText(name,value);
			else if(type.equalsIgnoreCase("yuidate")) {
				validValue = isValidDate(name,value);
                                if ( value.equalsIgnoreCase("mm/dd/yyyy"))
                                    param.setValue("");
                        }
			else if(type.equalsIgnoreCase("checkbox"))
				validValue = isValidCheckBox(name,value);
			else if(type.equalsIgnoreCase("collection"))
				validValue = isValidCollection(name,value);
			else
				logger.warn("No validation for type " + value);
			
			if(!validValue) {
				logger.warn("!! Param [name : "+name+"],[value : "+value+"],[type : "+type+"] is invalid");
				isValid = false;
				break;
			}
		}
	}
	
	private boolean isValidText(String name, String value) {
		logger.debug("Validating TEXT [name : "+name+"],[value : "+value+"]");
		// nothing to validate yet?
		return true;
	}
	
	private boolean isValidDate(String name, String value) {
		logger.info("Validating DATE [name : "+name+"],[value : "+value+"]");
		Timestamp dateValue = null ;
		// Make sure is in parsable format
                
                if ( !value.equalsIgnoreCase("mm/dd/yyyy"))
                     dateValue = FormatDate.parse(value, FasConstants.simpleDateFormat);
		if ( value.equalsIgnoreCase("mm/dd/yyyy"))
                   return true;
                else if(dateValue == null)
                    return false;
		else
                    return true;
	}
	
	private boolean isValidCheckBox(String name, String value) {
		logger.debug("Validating CHECKBOX for [name : "+name+"],[value : "+value+"]");
		
		List<ParamXML> serverSideParams = serverSideReport.getParams();
		
		for(ParamXML currParam : serverSideParams) {
			if(currParam.getName().equalsIgnoreCase(name)) {
				// a checkbox is either the value in ReportProperties.xml or is blank/null (unchecked)
				if(value.equalsIgnoreCase(currParam.getValue()) || NxUtils.isEmptyOrBlank(value))
					return true;
			}
		}
		
		logger.debug(value + " for param " + name + " did not match the value in ReportProperties or is NOT blank or null");
		return false;
	}
	
	private boolean isValidCollection(String name, String value) {
		logger.debug("Validating COLLECTION for [name : "+name+"],[value : "+value+"]");
		
		List<ParamXML> serverSideParams = serverSideReport.getParams();
		String collectionName = "";
		
		/*
		 * On the server side, the value of the collection parameter is the name of the collection/pull-down
		 * The value of the param is changed to the selected value in the collection/pull-down when a user selects value in the UI
		 * To get the collection name we need to go through the server side params
		 */
		for(ParamXML currParam : serverSideParams) {
			if(currParam.getName().equalsIgnoreCase(name)) {
				collectionName = currParam.getValue();
				break;
			}
		}
		
		OptionCollectionManager optionManager = OptionCollectionManager.getInstance();
		
		boolean isInCollection = optionManager.isValueInCollection(collectionName, value);
		
		logger.debug("Is value " + value + " in collection " + collectionName +"? " + isInCollection);
		
		return isInCollection;
	}

	public boolean isInvalid() {
		if(isValid)
			return false;
		else
			return true;
	}
}
