package crt.com.ntelx.inbox;

public class FasGridLine implements Cloneable
{
	private String lineName           = "";
	private String typeCode           = "";
	
	private String randomization      = "";
	private String watchlist          = "";
	private String companyViability   = "";
	private String compliance         = "";
	private String expectedBehavior   = "";
	private String transactional      = "";
	
	private String intelligenceDriven = "";
	private String policy             = "";
	private String anomalyDetection   = "";
	private String trackRecord        = "";
	

	
	public String getLineName()
	{
		return lineName;
	}
	public void setLineName(String lineName)
	{
		this.lineName = lineName;
	}
	public String getRandomization()
	{
		return randomization;
	}
	public void setRandomization(String randomization)
	{
		this.randomization = randomization;
	}
	public String getWatchlist()
	{
		return watchlist;
	}
	public void setWatchlist(String watchlist)
	{
		this.watchlist = watchlist;
	}
	public String getCompanyViability()
	{
		return companyViability;
	}
	public void setCompanyViability(String companyViability)
	{
		this.companyViability = companyViability;
	}
	public String getCompliance()
	{
		return compliance;
	}
	public void setCompliance(String compliance)
	{
		this.compliance = compliance;
	}
	public String getExpectedBehavior()
	{
		return expectedBehavior;
	}
	public void setExpectedBehavior(String expectedBehavior)
	{
		this.expectedBehavior = expectedBehavior;
	}
	public String getTransactional()
	{
		return transactional;
	}
	public void setTransactional(String transactional)
	{
		this.transactional = transactional;
	}
	@Override
	protected Object clone() throws CloneNotSupportedException
	{
		return super.clone();
	}
	public String getIntelligenceDriven()
	{
		return intelligenceDriven;
	}
	public void setIntelligenceDriven(String intelligenceDriven)
	{
		this.intelligenceDriven = intelligenceDriven;
	}
	public String getPolicy()
	{
		return policy;
	}
	public void setPolicy(String policy)
	{
		this.policy = policy;
	}
	public String getAnomalyDetection()
	{
		return anomalyDetection;
	}
	public void setAnomalyDetection(String anomalyDetection)
	{
		this.anomalyDetection = anomalyDetection;
	}
	public String getTrackRecord()
	{
		return trackRecord;
	}
	public void setTrackRecord(String trackRecord)
	{
		this.trackRecord = trackRecord;
	}
	public String getTypeCode()
	{
		return typeCode;
	}
	public void setTypeCode(String typeCode)
	{
		this.typeCode = typeCode;
	}
	
	
}
