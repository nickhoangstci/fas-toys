package crt.com.ntelx.awb.model;

import java.sql.Timestamp;

import com.freightdesk.fdfolio.orghierarchy.model.OrghierarchyModel;
import com.freightdesk.fdcommons.BaseModel;

public class HAWB extends BaseModel
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -1306092521166640761L;
	
	private long hawbID      = 0;
	private long shipperID   = 0;
		
	private String depAirCode = "";

	private String shipperName = "";
	private OrghierarchyModel shipperAddress   = new OrghierarchyModel();
	

    private String consigneeName = "";
	private OrghierarchyModel consigneeAddress = new OrghierarchyModel();
	
    private Timestamp submissionDate; 
	
    private String carrierCode = "";
    private String carrierName = "";
	
    private String commodityCode = "";
    private String commodityName = "";
	
    private int numPackages = 0;
	
    private String loadAirportCode = "";
    private String loadAirportName = "";
	
    private String dischargeAirportCode = "";
    private String dischargeAirportName = "";
	
    private String IATACode = "";
    
    private String refNum = "";
    
    private double decValue = 0.0;
    private double height   = 0.0;
    private double length   = 0.0;
    private double width    = 0.0;
    private double weight   = 0.0;
    private double contSize = 0.0;
        
	
	public long getPrimaryKey() 
	{
		return this.hawbID;
	}

	public long getHawbID()
	{
		return hawbID;
	}

	public void setHawbID(long hawbID)
	{
		this.hawbID = hawbID;
	}

	public long getShipperID()
	{
		return shipperID;
	}

	public void setShipperID(long shipperID)
	{
		this.shipperID = shipperID;
	}

	public OrghierarchyModel getShipperAddress()
	{
		return shipperAddress;
	}

	public void setShipperAddress(OrghierarchyModel shipperAddress)
	{
		this.shipperAddress = shipperAddress;
	}

	public OrghierarchyModel getConsigneeAddress()
	{
		return consigneeAddress;
	}

	public void setConsigneeAddress(OrghierarchyModel consigneeAddress)
	{
		this.consigneeAddress = consigneeAddress;
	}

	public String getCarrierCode()
	{
		return carrierCode;
	}

	public void setCarrierCode(String carrierCode)
	{
		this.carrierCode = carrierCode;
	}

	public String getCarrierName()
	{
		return carrierName;
	}

	public void setCarrierName(String carrierName)
	{
		this.carrierName = carrierName;
	}

	public String getConsigneeName()
	{
		return consigneeName;
	}

	public void setConsigneeName(String consigneeName)
	{
		this.consigneeName = consigneeName;
	}

	public String getCommodityCode()
	{
		return commodityCode;
	}

	public void setCommodityCode(String commodityCode)
	{
		this.commodityCode = commodityCode;
	}

	public String getCommodityName()
	{
		return commodityName;
	}

	public void setCommodityName(String commodityName)
	{
		this.commodityName = commodityName;
	}

	public int getNumPackages()
	{
		return numPackages;
	}

	public void setNumPackages(int numPackages)
	{
		this.numPackages = numPackages;
	}

	public String getLoadAirportCode()
	{
		return loadAirportCode;
	}

	public void setLoadAirportCode(String loadAirportCode)
	{
		this.loadAirportCode = loadAirportCode;
	}

	public String getLoadAirportName()
	{
		return loadAirportName;
	}

	public void setLoadAirportName(String loadAirportName)
	{
		this.loadAirportName = loadAirportName;
	}

	public String getDischargeAirportCode()
	{
		return dischargeAirportCode;
	}

	public void setDischargeAirportCode(String dischargeAirportCode)
	{
		this.dischargeAirportCode = dischargeAirportCode;
	}

	public String getDischargeAirportName()
	{
		return dischargeAirportName;
	}

	public void setDischargeAirportName(String dischargeAirportName)
	{
		this.dischargeAirportName = dischargeAirportName;
	}

	public String getIATACode()
	{
		return IATACode;
	}

	public void setIATACode(String iATACode)
	{
		IATACode = iATACode;
	}

	public Timestamp getSubmissionDate()
	{
		return submissionDate;
	}

	public void setSubmissionDate(Timestamp submissionDate)
	{
		this.submissionDate = submissionDate;
	}

	public String getShipperName()
	{
		return shipperName;
	}

	public void setShipperName(String shipperName)
	{
		this.shipperName = shipperName;
	}

	public String getRefNum()
	{
		return refNum;
	}

	public void setRefNum(String refNum)
	{
		this.refNum = refNum;
	}

	public String getDepAirCode()
	{
		return depAirCode;
	}

	public void setDepAirCode(String depAirCode)
	{
		this.depAirCode = depAirCode;
	}

	public double getDecValue()
	{
		return decValue;
	}

	public void setDecValue(double decValue)
	{
		this.decValue = decValue;
	}

	public double getHeight()
	{
		return height;
	}

	public void setHeight(double height)
	{
		this.height = height;
	}

	public double getLength()
	{
		return length;
	}

	public void setLength(double length)
	{
		this.length = length;
	}

	public double getWidth()
	{
		return width;
	}

	public void setWidth(double width)
	{
		this.width = width;
	}

	public double getWeight()
	{
		return weight;
	}

	public void setWeight(double weight)
	{
		this.weight = weight;
	}

	public double getContSize()
	{
		return contSize;
	}

	public void setContSize(double contSize)
	{
		this.contSize = contSize;
	}
	
	
	
	
	
	
	
}
