/** 
 * 
 * Copyright (c) 2000-2002 NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/reporting/ReportPropertiesReader.java,v 1.1.4.3 2010/12/01 21:57:17 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: ReportPropertiesReader.java,v $
 *  Revision 1.1.4.3  2010/12/01 21:57:17  mechevarria
 *  use runtime only
 *
 *  Revision 1.1.4.2  2010/10/01 20:01:28  mechevarria
 *  updated for jboss6
 *
 *  Revision 1.1.4.1  2009/08/06 16:07:33  mechevarria
 *  using the head version for the ability to use role based reports
 *
 *  Revision 1.3  2009/06/16 17:15:42  mbegley
 *  upgraded to Struts 1.3
 *
 *  Revision 1.2  2008/09/11 16:04:34  fdoughty
 *  *** empty log message ***
 *
 *  Revision 1.1  2006/06/21 11:20:25  dkumar
 *  repackaging of ReportUtility to FDCommons
 *
 *  Revision 1.3  2006/04/07 16:15:49  ranand
 *  changed the Path to FD_RUNTIME
 *
 *  Revision 1.2  2005/07/06 05:56:51  ranand
 *  added  functionality for "Company Report" drop down in the home page
 *
 *  Revision 1.1  2004/09/15 13:36:28  asingh
 *  2.6 Baseline
 *
 * 
 */

package crt.com.ntelx.nxcommons.reporting;

import com.freightdesk.fdcommons.reporting.ReportsXML;
import java.io.File;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;

import org.apache.log4j.Logger;

/**
 * Responsible for analyzing Report Properties xml document and prepare
 * corresponding model.
 * 
 * @author Mike Echevarria
 */
public class ReportProperties {
	private static Logger logger = Logger.getLogger(Class.class);
	
	private static ReportsXML reportsXML = null;
	
	protected static ReportProperties _instance = null;
	

	public static ReportProperties getInstance() {
		if (_instance == null) {
			_instance = new ReportProperties();
		}
		return _instance;
	}

	public static void reset() {
		reportsXML = null;
		load();
	}

	private ReportProperties() {
		load();
	}

	/**
	 * Prepare Reports XML Model from xml.
	 * 
	 * @throws Exception
	 *             if No properties file exist for domain passed as an argument.
	 * @return ReportsXML
	 */
	private static void load() {
		logger.info("Loading ReportProperties to ReportsXML");
		Unmarshaller u = null;
		
		String filePath = System.getProperty("RUNTIME_HOME") + File.separator + "ReportProperties.xml";

		try {
			JAXBContext ctx = JAXBContext.newInstance(ReportsXML.class);
			u = ctx.createUnmarshaller();
			reportsXML = (ReportsXML) u.unmarshal(new File(filePath));
		} catch (Exception e) {
			//logger.error("Error occured during ReportProperties unmarshall");
			//e.printStackTrace();
			logger.error("Exception - Error occured during ReportProperties unmarshall: " + e.getMessage());
		}
		logger.debug("Loaded " + reportsXML.getReportXML().size() + " from " + filePath);
	}
	
	public ReportsXML getReportsXML() {
		return reportsXML;
	}
}
