package crt.com.ntelx.query.model;

import java.util.List;

public interface SearchDAO {
	
List<QueryModel> retrieveSearchResults(List<SearchFilter> searchCriteria,
		Sort sorting, Boolean showSubset);
}
