package crt.com.ntelx.nxcommons;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.List;

import net.sf.json.JSON;
import net.sf.json.JSONSerializer;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;

import com.freightdesk.fdfolio.common.SessionFactoryUtil;
import com.freightdesk.fdcommons.ApplicationProperties;
import com.freightdesk.fdcommons.ConnectionUtil;
import com.freightdesk.fdcommons.Credentials;
import com.freightdesk.fdcommons.InvalidUserException;
import com.freightdesk.fdcommons.PasswordHasher;
import crt.com.freightdesk.fdfolioweb.setup.PasswordStatus;

public class PasswordUtils {
	protected static Logger logger = Logger.getLogger("PasswordUtils");

	public static String hashPassword(String password) {
		logger.debug("hashPassword() method - begin ");
		String hashingAlgo = "SHA-1";

		byte[] buf = new byte[password.length()];

		buf = password.getBytes();

		MessageDigest algo = null;

		try {
			algo = MessageDigest.getInstance(hashingAlgo);
		} catch (NoSuchAlgorithmException e) {
			logger.error("Exception in  hashPassword() method::", e);
			throw new RuntimeException(e);
		}
		algo.reset();
		algo.update(buf);

		return new sun.misc.BASE64Encoder().encode(algo.digest());
	}

	/*
	 * copies the current user password into the passwordhist table. Will insert a row if less than the current limit. If at limit, will update oldest record.
	 */
	public static boolean updatePasswordHistory(long systemUserId, String updaterDomain, String updaterUser) {		
		logger.debug("updating password history");
		boolean updated = false;
		Connection connection = null;
		PreparedStatement pStmt = null;
		ResultSet rs = null;
		int count = 0;
		// 1 2
		String userInfoQuery = "select passphrasehash, status, (select count(systemuserid) from fd.userpasswordhist where systemuserid=?) as histcount from systemuser where systemuserid = ?";

		// 1,2,3,4,5,6
		String insertStatement = "INSERT INTO fd.USERPASSWORDHIST (SYSTEMUSERID, PASSPHRASEHASH, STATUS, CREATEUSERID, LASTUPDATEUSERID, DOMAINNAME) VALUES(?,?,?,?,?,?)";

		// 1 2 3 4 5 6 7
		String updateStatement = "update fd.userpasswordhist set passphrasehash=?,status=?,lastupdateuserid=?,lastupdatetimestamp=?,createtimestamp=?,domainname=? where lastupdatetimestamp = (select min(lastupdatetimestamp) from userpasswordhist where systemuserid=?)";

		// used to help debug in the catch statement
		String currQuery = "";
		try {
			// number of entries allowed in password history
			int passLimit = Integer.parseInt(ApplicationProperties.getProperty("password.historyLength"));
			connection = ConnectionUtil.getConnection();
			// get the userinfo
			currQuery = userInfoQuery;
			pStmt = connection.prepareStatement(currQuery);
			pStmt.setLong(1, systemUserId);
			pStmt.setLong(2, systemUserId);

			rs = pStmt.executeQuery();

			if (!rs.next())
				throw new Exception("Did not find user info in database.");

			String passHash = rs.getString("PASSPHRASEHASH");
			String status = rs.getString("STATUS");
			int histCount = rs.getInt("HISTCOUNT");
			// done with resultset and this statement
			rs.close();
			pStmt.close();

			// if less than limit, insert a new row. Otherwise update
			if (histCount < passLimit) {
				currQuery = insertStatement;
				pStmt = connection.prepareStatement(currQuery);
				pStmt.setLong(1, systemUserId);
				pStmt.setString(2, passHash);
				pStmt.setString(3, status);
				pStmt.setString(4, updaterUser);
				pStmt.setString(5, updaterUser);
				pStmt.setString(6, updaterDomain);

				count = pStmt.executeUpdate();
				logger.debug(count + " row inserted into UserPasswordHist");

			} else {
				currQuery = updateStatement;
				pStmt = connection.prepareStatement(currQuery);
				pStmt.setString(1, passHash);
				pStmt.setString(2, status);
				pStmt.setString(3, updaterUser);
				pStmt.setTimestamp(4, new Timestamp(System.currentTimeMillis()));
				pStmt.setTimestamp(5, new Timestamp(System.currentTimeMillis()));
				pStmt.setString(6, updaterDomain);
				pStmt.setLong(7, systemUserId);

				count = pStmt.executeUpdate();
				logger.debug(count + " row updated in UserPasswordHist");
			}

			updated = true;

			pStmt.close();
			connection.close();
		} catch (Exception ex) {	
			logger.error(currQuery + " Exception in current query: " + ex.getMessage());
			
		} finally {
			ConnectionUtil.closeResources(connection, pStmt, rs);
		}
		return updated;
	}

	/*
	 * updates a user password, the temp var indicates whether this is a one day temporary password
	 */
	public static boolean updatePassword(String password, long systemUserId, String userId, boolean temp) {
		logger.debug("updating user password");
		boolean updated = false;
		Connection connection = null;
		PreparedStatement pStmt = null;
		// 1 2 3 4 5 6 7
		String updateQuery = "UPDATE fd.SYSTEMUSER SET PASSPHRASEHASH =?, AUTOEXPIREDAYS =?, LASTUPDATETIMESTAMP =?, LASTLOGINTIMESTAMP=?, LASTUPDATEUSERID=?, NUMFAILEDLOGIN=? WHERE SYSTEMUSERID=?";
		try {
			connection = ConnectionUtil.getConnection();
			pStmt = connection.prepareStatement(updateQuery);

			pStmt.setString(1, (new PasswordHasher()).hashPassword(password));

			if (temp)
				pStmt.setInt(2, 1);
			else
				pStmt.setInt(2, Integer.parseInt(ApplicationProperties.getProperty("password.autoExpire")));

			pStmt.setTimestamp(3, new Timestamp(System.currentTimeMillis()));

			// if this is a temporary password, remove the lastlogintime to
			// prompt user at login to change passwword
			if (temp)
				pStmt.setTimestamp(4, null);
			else
				pStmt.setTimestamp(4, new Timestamp(System.currentTimeMillis()));

			pStmt.setString(5, userId);
			pStmt.setInt(6, 0);
			pStmt.setLong(7, systemUserId);

			// this statement should update only 1 row.
			int rowUpdated = pStmt.executeUpdate();
			logger.debug(rowUpdated + " row updated in SYSTEMUSER");

			if (rowUpdated > 0)
				updated = true;

			pStmt.close();
			connection.close();
		} catch (Exception ex) {
			//logger.error(updateQuery);
			//ex.printStackTrace();
			logger.error(updateQuery + " Exception in update query: " + ex.getMessage());
		} finally {
			ConnectionUtil.closeResources(connection, pStmt, null);
		}

		return updated;
	}

	@SuppressWarnings("unchecked")
	public static boolean curPasswordCorrect(final String oldPassword, Long systemUserId) {
                int currOldPasswordLength = oldPassword.length();
                

		// do not hit database if input is too short
		if (NxUtils.isEmptyOrBlank(oldPassword) ||  currOldPasswordLength < 8) {
			logger.debug("not checking oldPassword against database");
			return false;
		}


		Session session = SessionFactoryUtil.getSession();

		Query query = session.createSQLQuery("select systemuserid from fd.systemuser where passphrasehash=:passPhraseHash and systemuserid=:systemUserId");
                
                String hashPassword = (new PasswordHasher()).hashPassword(oldPassword);

		query.setParameter("passPhraseHash", hashPassword);
		query.setParameter("systemUserId", systemUserId);

		List<Object> result = query.list();

		if (!result.isEmpty()) {
                        return true;
                }
		return false;
	}

	@SuppressWarnings("unchecked")
	public static boolean newPassInHistory(final String newPassword, Long systemUserId) {

                int currNewPasswordLength = newPassword.length();
                
                if (NxUtils.isEmptyOrBlank(newPassword) ||  currNewPasswordLength < 8) {
			logger.debug("not checking password history against database");
			return false;
		}


		Session session = SessionFactoryUtil.getSession();

		Query query = session.createSQLQuery("select systemuserid from fd.userpasswordhist where passphrasehash=:passPhraseHash and systemuserid=:systemUserId");

		query.setParameter("passPhraseHash", (new PasswordHasher()).hashPassword(newPassword));
		query.setParameter("systemUserId", systemUserId);

		List<Object> result = query.list();

		if (result.isEmpty()) {
                        return true;
                }

		return false;
	}

	public static boolean isValidLength(String password) {
		if (NxUtils.isEmptyOrBlank(password) || password.length() < 8)
			return false;
		else
			return true;
	}

	public static boolean hasLowerCase(String password) {
		String regex = ".*[a-z].*";
		return password.matches(regex);
	}

	public static boolean hasUpperCase(String password) {
		String regex = ".*[A-Z].*";
		return password.matches(regex);
	}

	public static boolean hasNumber(String password) {
		String regex = ".*[\\d].*";
		return password.matches(regex);
	}

	public static boolean hasSpecial(String password) {
		String regex = ".*[!,@,#,$,%,^,&,*,?,_,~,.,+,=,<,>].*";
		return password.matches(regex);
	}

	public static boolean passesMatch(String pass1, String pass2) {
		if (NxUtils.isEmptyOrBlank(pass1) || NxUtils.isEmptyOrBlank(pass2))
			return false;
		else
			return pass1.equals(pass2);
	}

	public JSON checkPasswordsForDWR(String newPass, String curPass, String confirmPass) throws Exception {                   
		Credentials credentials = AuthenticationUtils.getCredentialsForDWR();

		if (credentials == null) {    
			throw new InvalidUserException("User credentials not in session");
                }

		PasswordStatus passStatus = checkPasswords(newPass, curPass, confirmPass, credentials.getSystemUserId());          
		
		JSON passStatusJSON = JSONSerializer.toJSON(passStatus);
		logger.debug(passStatusJSON);           
		
		return passStatusJSON;
	}

	public static PasswordStatus checkPasswords(String newPass, String curPass, String confirmPass, Long systemUserId) {          
		PasswordStatus status = new PasswordStatus();

		// Check for at least 8 characters
		status.setValidLength(isValidLength(newPass));

		// Check for one lower case letter
		status.setHasLowerCase(hasLowerCase(newPass));

		// Check for one upper case letter
		status.setHasUpperCase(hasUpperCase(newPass));

		// Check for number
		status.setHasNumber(hasNumber(newPass));

		// Check for special character
		status.setHasSpecial(hasSpecial(newPass));

		// make sure new pass and confirm match
		status.setNewPassConfirmPassMatch(passesMatch(newPass, confirmPass));

		// new pass and current pass cannot be the same
		status.setNewPassNotEqualOldPass(!passesMatch(newPass, curPass));

		// Check new password is not in history
		status.setNewPassNotInHistory(newPassInHistory(newPass, systemUserId));

		// Check current password is correct
		status.setCurPassCorrect(curPasswordCorrect(curPass, systemUserId));

		logger.debug(status);
		return status;
	}

}
