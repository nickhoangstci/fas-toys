package crt.com.ntelx.nxcommons.model;

import java.io.Serializable;
import java.math.BigInteger;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.freightdesk.fdfolio.orghierarchy.model.OrghierarchyModel;
import com.freightdesk.fdcommons.BaseModel;

@Entity
@Table(name = "ORGORGASSOC")
public class OrgAssocModel extends BaseModel implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "ORGORGASSOCID")
    @SequenceGenerator(name = "ORGORGASSOCID", sequenceName = "ORGORGASSOCID")
    private long orgOrgAssocId;
    @ManyToOne
    @JoinColumn(name = "SRCORGID")
    private OrghierarchyModel orghierarchy;
    private BigInteger destOrgId;
    private String relationshipTypeCode;
    private String comments;
    private Timestamp beginDate;
    private Timestamp endDate;

    public OrgAssocModel() {
    }

    public BigInteger getDestOrgId() {
        return destOrgId;
    }

    public void setDestOrgId(BigInteger destOrgId) {
        this.destOrgId = destOrgId;
    }

    public OrghierarchyModel getOrghierarchy() {
        return orghierarchy;
    }

    public void setOrghierarchy(OrghierarchyModel orghierarchy) {
        this.orghierarchy = orghierarchy;
    }

    public long getPrimaryKey() {
        return this.orgOrgAssocId;
    }

    public long getOrgOrgAssocId() {
        return orgOrgAssocId;
    }

    public void setOrgOrgAssocId(long orgOrgAssocId) {
        this.orgOrgAssocId = orgOrgAssocId;
    }

    public String getRelationshipTypeCode() {
        return relationshipTypeCode;
    }

    public void setRelationshipTypeCode(String relationshipTypeCode) {
        this.relationshipTypeCode = relationshipTypeCode;
    }

    public Timestamp getBeginDate() {
        return beginDate;
    }

    public void setBeginDate(Timestamp beginDate) {
        this.beginDate = beginDate;
    }

    public Timestamp getEndDate() {
        return endDate;
    }

    public void setEndDate(Timestamp endDate) {
        this.endDate = endDate;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 47 * hash + (this.destOrgId != null ? this.destOrgId.hashCode() : 0);
        hash = 47 * hash + (this.relationshipTypeCode != null ? this.relationshipTypeCode.hashCode() : 0);
        hash = 47 * hash + (this.comments != null ? this.comments.hashCode() : 0);
        hash = 47 * hash + (this.beginDate != null ? this.beginDate.hashCode() : 0);
        hash = 47 * hash + (this.endDate != null ? this.endDate.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final OrgAssocModel other = (OrgAssocModel) obj;
        if (this.destOrgId != other.destOrgId && (this.destOrgId == null || !this.destOrgId.equals(other.destOrgId))) {
            return false;
        }
        if ((this.relationshipTypeCode == null) ? (other.relationshipTypeCode != null) : !this.relationshipTypeCode.equals(other.relationshipTypeCode)) {
            return false;
        }
        if ((this.comments == null) ? (other.comments != null) : !this.comments.equals(other.comments)) {
            return false;
        }
        if (this.beginDate != other.beginDate && (this.beginDate == null || !this.beginDate.equals(other.beginDate))) {
            return false;
        }
        if (this.endDate != other.endDate && (this.endDate == null || !this.endDate.equals(other.endDate))) {
            return false;
        }
        return true;
    }
    
    
}
