package crt.com.ntelx.inbox;

import java.util.HashMap;
import java.util.Map;

public class BogusCategoryTypeDAO
{
	public static final String [] catCodes = { "INTD", "WATCH", "VIAB", "POLY", "ANDET", "TRACK" };
	
	private static Map<String,String> catMap = fillCatMap();
	
	private static Map<String, String> fillCatMap()
	{
		HashMap<String, String> catMap = new HashMap<String, String>();

		catMap.put( "INTD",  "RANDOMIZATION"     );
		catMap.put( "WATCH", "WATCH LIST"        );
		catMap.put( "VIAB",  "COMPANY VIABILITY" );
		catMap.put( "POLY",  "POLICY"            );
		catMap.put( "ANDET", "ANOMALY DETECTION" );
		catMap.put( "TRACK", "TRACK RECORD"      );
						
		return catMap;
	}
	
	public String getCategory( String code )
	{
		return catMap.get( code );
	}
	
	public String getCategoryCode( String name )
	{
		return null;
	}
	
	public static final String [] typeCodes = { "SHIP", "CONS", "CAR", "ROUTE", "COMM", "PAY" };
	
	private static Map<String,String> typeMap = fillTypeMap();
	
	private static Map<String, String> fillTypeMap()
	{
		HashMap<String, String> typeMap = new HashMap<String, String>();

		typeMap.put( "SHIP",  "SHIPPER"   );
		typeMap.put( "CONS",  "CONSIGNEE" );
		typeMap.put( "CAR",   "CARRIER"   );
		typeMap.put( "ROUTE", "ROUTE"     );
		typeMap.put( "COMM",  "COMMODITY" );
		typeMap.put( "PAY",   "PAYMENT"   );
						
		return typeMap;
	}
	
	public String getType( String code )
	{
		return typeMap.get( code );
	}
	
}
