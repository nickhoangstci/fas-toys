package crt.com.ntelx.nxcommons.email;

import org.apache.log4j.Logger;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;

public class EmailBodyFactory {
	// Instance for Singleton
	protected static EmailBodyFactory _instance = null;
    protected static Logger logger = Logger.getLogger("EmailBodyFactory");
	
	// Location of template file. FD_RUNTIME_HOME property is usually set in
	// start up script
	private String TEMPLATE_FOLDER = System.getProperty("RUNTIME_HOME") + File.separator + "email";
	private String RESET        = "ResetTemplate.html";
	private String USER         = "UserTemplate.html";
	private String PASS         = "PassTemplate.html";
	private String NOSUB_CCSF   = "NoDataTemplate.html";
	private String RECEIPT_CCSF = "ReceiptTemplate.html";
	private String EXPIRE_WARN  = "ExpireWarnTemplate.html";
	
	// Templates to be passed into the email body
	private static String resetTemplate = null;
	private static String userTemplate = null;
	private static String passTemplate = null;
	private static String expireWarnTemplate = null;

	// Protected Getter used purely for testing
	//
	protected String getResetTemplate() {
		return resetTemplate;
	}
	
	protected String getUserTemplate() {
		return userTemplate;
	}
	
	protected String getPassTemplate() {
		return passTemplate;
	}
	
	protected String getExipreWarnTemplate() {
		return expireWarnTemplate;
	}
	
	protected void loadResetTemplate(Reader reader) throws FileNotFoundException, IOException {
		resetTemplate = loadTemplate(reader);
	}
	
	protected void loadUserTemplate(Reader reader) throws FileNotFoundException, IOException {
		userTemplate = loadTemplate(reader);
	}
	
	protected void loadPassTemplate(Reader reader) throws FileNotFoundException, IOException {
		passTemplate = loadTemplate(reader);
	}
	
	protected void loadExpireWarnTemplate(Reader reader) throws FileNotFoundException, IOException {
		expireWarnTemplate = loadTemplate(reader);
	}

	protected String loadTemplate(Reader reader) throws FileNotFoundException, IOException {
		BufferedReader in = new BufferedReader(reader);

		StringBuffer templateBuffer = new StringBuffer();
		String buffer = "";
		while ((buffer = in.readLine()) != null) {
			templateBuffer.append(buffer + "\n");
		}

		return templateBuffer.substring(0, templateBuffer.length() - 1).toString();
	}

	protected EmailBodyFactory() {
	}

	public static EmailBodyFactory getInstance() {
		if (_instance == null) {
			_instance = new EmailBodyFactory();
		}
		return _instance;
	}

	protected Reader getTemplateReader(String templateName) throws IOException {
		String templatePath = TEMPLATE_FOLDER + File.separator + templateName;
		return new FileReader(templatePath);
	}

	public UserEmailBody getPasswordResetEmailBody() {
		try {
			return getEmailBody(RESET);
		} catch(Exception ex) {
			//ex.printStackTrace();
			logger.error("Exception: " + ex.getMessage());
			return null;
		}
	}
	
	public UserEmailBody getNewUserEmailBody() {
		try {
			return getEmailBody(USER);
		} catch(Exception ex) {
			//ex.printStackTrace();
			logger.error("Exception: " + ex.getMessage());
			return null;
		}
	}
	
	public UserEmailBody getUserPassEmailBody() {
		try {
			return getEmailBody(PASS);
		} catch(Exception ex) {
			//ex.printStackTrace();
			logger.error("Exception: " + ex.getMessage());
			return null;
		}
	}
	
	public NoSubCCSFEmailBody getNoSubCCSFEmailBody()
	{
		try
		{
			String template = loadTemplate( getTemplateReader( NOSUB_CCSF ) );
			NoSubCCSFEmailBody body = new NoSubCCSFEmailBody();
			body.setTemplate(template);
			return body;
		}
		catch ( Exception ex )
		{
			//ex.printStackTrace();
			logger.error("Exception: " + ex.getMessage());
			return null;
		}
	}
	
	public ReceiptEmailCCSFBody getReceiptEmailCCSFBody()
	{
		try
		{
			String template = loadTemplate( getTemplateReader( RECEIPT_CCSF ) );
			
			ReceiptEmailCCSFBody body = new ReceiptEmailCCSFBody();
			body.setTemplate(template);
			return body;
		}
		catch ( Exception ex )
		{
			//ex.printStackTrace();
			logger.error("Exception: " + ex.getMessage());
			return null;
		}
	}
	
	public ExpireWarnEmailBody getExpireWarnEmailBody() {
		try {
			String template = loadTemplate(getTemplateReader(EXPIRE_WARN));

			ExpireWarnEmailBody body = new ExpireWarnEmailBody();
			body.setTemplate(template);
			return body;
		} catch (Exception ex) {
			//ex.printStackTrace();
			logger.error("Exception: " + ex.getMessage());
			return null;
		}
	}
	
	public static void reset() {
		resetTemplate = null;
		userTemplate = null;
		passTemplate = null;
		expireWarnTemplate = null;
	}
	
	private UserEmailBody getEmailBody(String templateName) throws FileNotFoundException, IOException {
		UserEmailBody emailBody = new UserEmailBody();
		
		if(templateName.equalsIgnoreCase(RESET)) {
			if(resetTemplate == null)
				loadResetTemplate(getTemplateReader(RESET));
			
			emailBody.setTemplate(resetTemplate);
			
		} else if(templateName.equalsIgnoreCase(USER)) {
			if(userTemplate == null)
				loadUserTemplate(getTemplateReader(USER));
			
			emailBody.setTemplate(userTemplate);
			
		} else if(templateName.equalsIgnoreCase(PASS)) {
			if(passTemplate == null)
				loadPassTemplate(getTemplateReader(PASS));
			
			emailBody.setTemplate(passTemplate);
		} 

		return emailBody;
	}

}
