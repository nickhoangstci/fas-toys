package crt.com.ntelx.dwr;

public class ContribRuleInfo
{

	private String ruleName    = "";	
	private String description = "";
	private String score       = "";
	public String getRuleName()
	{
		return ruleName;
	}
	public void setRuleName(String ruleName)
	{
		this.ruleName = ruleName;
	}
	public String getDescription()
	{
		return description;
	}
	public void setDescription(String description)
	{
		this.description = description;
	}
	public String getScore()
	{
		return score;
	}
	public void setScore(String score)
	{
		this.score = score;
	}
	
	
	
}
