package crt.com.ntelx.inbox;

import java.util.Date;

import javax.persistence.MappedSuperclass;
import javax.persistence.Transient;


@MappedSuperclass
public abstract class BaseEntity implements java.io.Serializable{
	

	private static final long serialVersionUID = 1L;
	private String createuserid;
	private Date createtimestamp;
	private String lastupdateuserid;
	private Date lastupdatetimestamp;
	private String domainname;
	private String status;
	
	@Transient
	private boolean selected = false;
	

	
	
	public String getCreateuserid() {
		return createuserid;
	}

	public void setCreateuserid(String createuserid) {
		this.createuserid = createuserid;
	}

	public Date getCreatetimestamp() {
		return createtimestamp;
	}

	public void setCreatetimestamp(Date createtimestamp) {
		this.createtimestamp = createtimestamp;
	}

	public String getLastupdateuserid() {
		return lastupdateuserid;
	}

	public void setLastupdateuserid(String lastupdateuserid) {
		this.lastupdateuserid = lastupdateuserid;
	}

	public Date getLastupdatetimestamp() {
		return lastupdatetimestamp;
	}

	public void setLastupdatetimestamp(Date lastupdatetimestamp) {
		this.lastupdatetimestamp = lastupdatetimestamp;
	}

	public String getDomainname() {
		return domainname;
	}

	public void setDomainname(String domainname) {
		this.domainname = domainname;
	}

	public void setSelected(boolean selected) {
		this.selected = selected;
	}

	public boolean isSelected() {
		return selected;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getStatus() {
		return status;
	}


	
	

}
