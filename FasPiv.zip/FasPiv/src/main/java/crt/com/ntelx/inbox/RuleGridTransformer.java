package crt.com.ntelx.inbox;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;

public class RuleGridTransformer
{
	private static Logger logger = Logger.getLogger( RuleGridTransformer.class );
	
	BogusCategoryTypeDAO catDao = new BogusCategoryTypeDAO();
	
	protected Map<String, FasGridLine> getEmptyGridMap()
	{		
		String[] types = catDao.typeCodes;

		HashMap<String, FasGridLine> gridMap = new HashMap<String, FasGridLine>();
		
		FasGridLine line = null;
		for ( int i = 0; i < types.length; i++ )
		{
			line = new FasGridLine();
			line.setLineName( catDao.getType( types[i] ) );
			line.setTypeCode( types[i] );
			gridMap.put( types[i], line );
		}
		
		return gridMap;
	}
	
	public List<FasGridLine> getGridForFaEntry( FaEntry faEntry )
	{		
		Set<FaEntryscore> faEntryScoreSet = faEntry.getFaEntryscores();
		
		Map<String, FasGridLine> gridMap = getEmptyGridMap();
		
		FasGridLine line = null; 
		for ( FaEntryscore entryScore : faEntryScoreSet )
		{
			line = gridMap.get( entryScore.getScoretypecode() );		
			mapCatToLine( entryScore.getScorecategorytypecode(),  line, entryScore.getScorevalue() );
		}
		
		return mapToOrderedList( gridMap );
	}
	
	protected void mapCatToLine( String catName, FasGridLine line, BigDecimal val )
	{
		logger.debug( "CatName: " + catName + " -- Line: " + line +  " -- Val " + val );
		String [] cats = catDao.catCodes;
		
		if ( catName.equals( "WATCH" ) )
		{
			line.setWatchlist( val.toString() );
		}
		else if ( catName.equals( "VIAB" ) )
		{
			line.setCompanyViability( val.toString() );
		}
		else if ( catName.equals( "POLY" ) )
		{
			line.setPolicy( val.toString() );
		}
		else if ( catName.equals( "ANDET" ) )
		{
			line.setAnomalyDetection( val.toString() );
		}
		else if ( catName.equals( "TRACK" ) ) 
		{
			line.setTrackRecord( val.toString() );
		}
		
	}
	
	protected ArrayList<FasGridLine> mapToOrderedList( Map<String, FasGridLine> gridMap )
	{
		ArrayList<FasGridLine> lineList = new ArrayList<FasGridLine>();
		
		String[] types = catDao.typeCodes;
		
		for ( int i = 0; i < types.length; i++ )
		{
			lineList.add( gridMap.get( types[i] ) );
		}
		
		return lineList;
	}

	
	
}
