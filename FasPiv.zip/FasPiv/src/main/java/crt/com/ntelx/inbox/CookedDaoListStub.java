package crt.com.ntelx.inbox;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

import org.apache.log4j.Logger;

import crt.com.freightdesk.fdfolio.dao.HAWBDao;
import crt.com.ntelx.awb.model.HAWB;

public class CookedDaoListStub
{
	private static Logger logger = Logger.getLogger( CookedDaoListStub.class );
	
	public static Map<Long, FaEntry> getRandomInbox()
	{
		Map<Long,FaEntry> faEntryList = new HashMap<Long,FaEntry>();
		
		HAWBDao awbDao = new HAWBDao();
		
		List<HAWB> listAwb = awbDao.retrieveForAWBHome(null, false, 0, null, null, "" );

		FaEntry faEntry = null;
		for ( int i = 0; i < listAwb.size() && i < 9; i++ )
		{
			faEntry = getEntryFromHAWB( listAwb.get( i ) );
			faEntry.setEntryid( new Long( i ) );

			if ( i == 0 )
			{				
				//faEntry.setFaEntryscores( getFaEntryscoreSetSentToFas( faEntry, listAwb.get( i ).getShipperAddress().getZipPostCode(), "" )  );
			}
			else if ( i == 1 )
			{
				//faEntry.setFaEntryscores( getFaEntryscoreSetBadConRec( faEntry,  listAwb.get( i ).getShipperAddress().getZipPostCode(), listAwb.get( i ).getConsigneeName() ) );
			}
			else
			{
				faEntry.setFaEntryscores( getFaEntryscoreSetNewShipper( faEntry, listAwb.get( i ).getConsigneeName() ) );				
			}
				
			
			faEntryList.put( new Long( i ), faEntry );
		}		
		
		return faEntryList;

	}
	
	public static FaEntry getEntryFromHAWB( HAWB awb )
	{
		FaEntry faEntry = new FaEntry();
		Random  rand    = new Random();
		
		faEntry.setIdentifier ( awb.getRefNum() );
		faEntry.setScorevalue ( new BigDecimal( rand.nextInt(7) * 10 ) ); 
		faEntry.setDescription( "Temp Description" );
		faEntry.setReceivedtime( new Date() );
		
		Set<FaEntryreference> refSet = new HashSet<FaEntryreference>();
		FaEntryreference entRef = new FaEntryreference();
		
		entRef.setReferencecode ( "HAWBID"            );
		entRef.setReferencevalue( Long.toString( awb.getHawbID() ) );
		
		refSet.add( entRef );
		
		faEntry.setFaEntryreferences( refSet );
		return faEntry;
	}
	
	
	private static Set<FaEntryscore> getFaEntryscoreSet( FaEntry faEntry )
	{
		Set<FaEntryscore> entryScoreSet = new HashSet<FaEntryscore>();
		
		
		
		//entryScoreSet.add( getFaEntryscoreSetHighRiskZip( faEntry ) );
		
		
		/*
		Random rand = new Random();		
		int n = rand.nextInt( 5 ) + 1;
		
		FaEntryscore entScore = null;
		for ( int i = 0; i < n; i++ )
		{
			entScore = getRandomEntryScore();
			entScore.setFaEntry( faEntry );
			entryScoreSet.add( entScore );			
		}		
		*/
		return entryScoreSet;
	}

	
	private static Set<FaEntryscore> getFaEntryscoreSetHighRiskZip( FaEntry faEntry, String zipCode )
	{
		Set<FaEntryscore> entryScoreSet = new HashSet<FaEntryscore>();
		
		FaEntryscore faEntryscore = new FaEntryscore();
		
		faEntryscore.setScorecategorytypecode( "WATCH" );
		faEntryscore.setScoretypecode        ( "SHIP"  );
		
		FaScoredetails details = null;
		
		HashSet<FaScoredetails> detailSet = new HashSet<FaScoredetails>();
		
		details = new FaScoredetails();
		
		details.setDescription(  zipCode + " HIGH RISK ZIPCODE"   );
		details.setRulename   ( "ZIPCODE WATCH"        );
		details.setScorevalue ( new BigDecimal( 5 ) );
		
		detailSet.add( details );
		
		faEntryscore.setFaScoredetailses( detailSet );
		
		faEntryscore.setScorevalue( new BigDecimal( 50 ) );
		faEntry.setScorevalue( new BigDecimal( 50 ) );
		entryScoreSet.add( faEntryscore );

		return entryScoreSet;
	}
	
	
	private static Set<FaEntryscore> getFaEntryscoreSetBadConRec( FaEntry faEntry, String zipCode, String consiName )
	{
		Set<FaEntryscore> entryScoreSet = new HashSet<FaEntryscore>();
		
		FaEntryscore faEntryscore = new FaEntryscore();
		
		FaScoredetails details;
		HashSet<FaScoredetails> detailSet;
		industryFailed(zipCode, entryScoreSet, faEntryscore);	
		
		faEntryscore = new FaEntryscore();
		
		faEntryscore.setScorecategorytypecode( "TRACK" );
		faEntryscore.setScoretypecode        ( "CONS"  );
		
		detailSet = new HashSet<FaScoredetails>();
		
		details = new FaScoredetails();
		
		details.setDescription(  consiName + " HAS BAD TRACK RECORD"   );
		details.setRulename   ( "CONSIGNEE TRACK RECORD"        );
		details.setScorevalue ( new BigDecimal( 5 ) );
		
		detailSet.add( details );
		
		faEntryscore.setFaScoredetailses( detailSet );
		
		faEntryscore.setScorevalue( new BigDecimal( 5) );
		faEntry.setScorevalue( new BigDecimal( 50 ) );
		entryScoreSet.add( faEntryscore );

		return entryScoreSet;
	}
	
	private static Set<FaEntryscore> getFaEntryscoreSetDropBox( FaEntry faEntry, String consiName )
	{
		Set<FaEntryscore> entryScoreSet = new HashSet<FaEntryscore>();
		
		FaEntryscore faEntryscore = new FaEntryscore();
		
		faEntryscore.setScorecategorytypecode( "POLY" );
		faEntryscore.setScoretypecode        ( "ROUTE"  );
		
		FaScoredetails details = null;
		
		HashSet<FaScoredetails> detailSet = new HashSet<FaScoredetails>();
		
		details = new FaScoredetails();
		
		details.setDescription( "SHIPPED VIA DROPBOX"   );
		details.setRulename   ( "DROPBOX"  );
		details.setScorevalue ( new BigDecimal( 40 ) );
		
		detailSet.add( details );
		
		faEntryscore.setFaScoredetailses( detailSet );
		
		faEntryscore.setScorevalue( new BigDecimal( 40 ) );
		faEntry.setScorevalue( new BigDecimal( 40 ) );
		entryScoreSet.add( faEntryscore );

		return entryScoreSet;
	}

	private static Set<FaEntryscore> getFaEntryscoreSetNewShipper( FaEntry faEntry, String consiName )
	{
		Set<FaEntryscore> entryScoreSet = new HashSet<FaEntryscore>();
		
		FaEntryscore faEntryscore = new FaEntryscore();
		
		//faEntryscore = new FaEntryscore();
		
		faEntryscore.setScorecategorytypecode( "POLY" );
		faEntryscore.setScoretypecode        ( "SHIP" );
		

		FaScoredetails details = new FaScoredetails();
		
		details.setDescription( "NO RECORDS ON THIS SHIPPER"   );
		details.setRulename   ( "NEW SHIPPER"  );
		details.setScorevalue ( new BigDecimal( 15 ) );
		
		
		HashSet<FaScoredetails>  detailSet = new HashSet<FaScoredetails>();
		detailSet.add( details );
		
		faEntryscore.setScorevalue( new BigDecimal( 15 ) );
		faEntryscore.setFaScoredetailses( detailSet );
		entryScoreSet.add( faEntryscore );
		
		faEntryscore.setScorevalue( new BigDecimal( 15) );
		faEntry.setScorevalue( new BigDecimal( 15 ) );
		entryScoreSet.add( faEntryscore );

		return entryScoreSet;
	}
	
	private static Set<FaEntryscore> getFaEntryscoreSetSentToFas( FaEntry faEntry, String zipCode, String consiName )
	{
		Set<FaEntryscore> entryScoreSet = new HashSet<FaEntryscore>();
		
		FaEntryscore faEntryscore = new FaEntryscore();
		
		FaScoredetails details;
		HashSet<FaScoredetails> detailSet;
		industryFailed(zipCode, entryScoreSet, faEntryscore);				
		
		// Watch Lists
		//
		faEntryscore = new FaEntryscore();
		
		faEntryscore.setScorecategorytypecode( "WATCH" );
		faEntryscore.setScoretypecode        ( "SHIP" );
		

		details = new FaScoredetails();
		
		details.setDescription( "POTENTIAL MATCH ON OFAC LIST"   );
		details.setRulename   ( "OFAC LIST"  );
		details.setScorevalue ( new BigDecimal( 10 ) );
		
		detailSet = new HashSet<FaScoredetails>();
		detailSet.add( details );		
		
		faEntryscore.setScorevalue( new BigDecimal( 10 ) );
		faEntryscore.setFaScoredetailses( detailSet );
		entryScoreSet.add( faEntryscore );	

		faEntryscore = new FaEntryscore();
		
		faEntryscore.setScorecategorytypecode( "WATCH" );
		faEntryscore.setScoretypecode        ( "CONS"  );
		
		details = new FaScoredetails();
		
		details.setDescription( "POTENTIAL MATCH ON NO FLY LIST"   );
		details.setRulename   ( "NO FLY LIST"  );
		details.setScorevalue ( new BigDecimal( 10 ) );
		
		detailSet = new HashSet<FaScoredetails>();
		detailSet.add( details );		
		
		faEntryscore.setScorevalue( new BigDecimal( 10 ) );
		faEntryscore.setFaScoredetailses( detailSet );
		entryScoreSet.add( faEntryscore );	
		
		
		faEntry.setScorevalue( new BigDecimal( 65 ) );

		return entryScoreSet;
	}

	private static void industryFailed(String zipCode,
			Set<FaEntryscore> entryScoreSet, FaEntryscore faEntryscore)
	{
		faEntryscore.setScorecategorytypecode( "POLY" );
		faEntryscore.setScoretypecode        ( "ROUTE"  );
		
		FaScoredetails details = null;
		
		HashSet<FaScoredetails> detailSet = new HashSet<FaScoredetails>();
		
		details = new FaScoredetails();
		
		details.setDescription( "SHIPPED VIA DROPBOX"   );
		details.setRulename   ( "DROPBOX"  );
		details.setScorevalue ( new BigDecimal( 15 ) );
		
		detailSet.add( details );
		
		details = new FaScoredetails();
		
		details.setDescription( zipCode + " IS A HIGH RISK ZIPCODE"   );
		details.setRulename   ( "HIGH RISK ZIPCODE"  );
		details.setScorevalue ( new BigDecimal( 15 ) );
		
		detailSet.add( details );		
		

		faEntryscore.setScorevalue( new BigDecimal( 30 ) );
		faEntryscore.setFaScoredetailses( detailSet );
		entryScoreSet.add( faEntryscore );

		// New SHIPPER
		
		faEntryscore = new FaEntryscore();
		
		faEntryscore.setScorecategorytypecode( "POLY" );
		faEntryscore.setScoretypecode        ( "SHIP" );
		

		details = new FaScoredetails();
		
		details.setDescription( "NO RECORDS ON THIS SHIPPER"   );
		details.setRulename   ( "NEW SHIPPER"  );
		details.setScorevalue ( new BigDecimal( 15 ) );
		
		detailSet = new HashSet<FaScoredetails>();
		detailSet.add( details );
		
		faEntryscore.setScorevalue( new BigDecimal( 15 ) );
		faEntryscore.setFaScoredetailses( detailSet );
		entryScoreSet.add( faEntryscore );
	}
	
}
