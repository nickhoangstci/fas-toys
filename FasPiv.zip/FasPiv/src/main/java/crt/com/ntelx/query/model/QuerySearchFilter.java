package crt.com.ntelx.query.model;

public class QuerySearchFilter implements SearchFilter{
	
	Object propertyName;
	Object filterValue;
	ValueDataType dataType;
	Predicate predicate;
	Disjunction disjunction;
	
	QuerySearchFilter(Object propertyName, Object filterValue, ValueDataType dataType, Predicate predicate){
		this.propertyName = propertyName;
		this.filterValue = filterValue;
		this.dataType = dataType;
		this.predicate = predicate;	
		this.disjunction = Disjunction.AND;
	}

	QuerySearchFilter(Object propertyName, Object filterValue, ValueDataType dataType, Predicate predicate, Disjunction disjunction){
		this.propertyName = propertyName;
		this.filterValue = filterValue;
		this.dataType = dataType;
		this.predicate = predicate;		
		this.disjunction= disjunction;
	}

	@Override
	public Object getPropertyName() {
		return propertyName;
	}

	@Override
	public Object getFilterValue() {
		// TODO Auto-generated method stub
		return filterValue;
	}

	@Override
	public ValueDataType getDataType() {
		// TODO Auto-generated method stub
		return dataType;
	}

	@Override
	public Predicate getPredicate() {
		// TODO Auto-generated method stub
		return predicate;
	}

	/**
	 * @param columnName the columnName to set
	 */
	public void setPropertyName(Object propertyName) {
		this.propertyName = propertyName;
	}

	/**
	 * @param filterValue the filterValue to set
	 */
	public void setFilterValue(Object filterValue) {
		this.filterValue = filterValue;
	}
	
	/**
	 * @param dataType the dataType to set
	 */
	public void setDataType(ValueDataType dataType) {
		this.dataType = dataType;
	}

	/**
	 * @param predicate the predicate to set
	 */
	public void setPredicate(Predicate predicate) {
		this.predicate = predicate;
	}

	@Override
	public Disjunction getDisjunction() {
		// TODO Auto-generated method stub
		return disjunction;
	}
	

}
