package crt.com.ntelx.query.model;

public class QuerySort implements Sort{

	SortDirection sortType;	
	Object columnName;
	
	QuerySort(Object columnName, SortDirection sortType){
		this.columnName = columnName;
		this.sortType = sortType;
	}
	
	public QuerySort() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public SortDirection getSortType() {
		return sortType;
	}

	@Override
	public Object getColumnName() {
		return columnName;
	}

	/**
	 * @param sortType the sortType to set
	 */
	public void setSortType(SortDirection sortType) {
		this.sortType = sortType;
	}

	/**
	 * @param columnName the columnName to set
	 */
	public void setColumnName(Object columnName) {
		this.columnName = columnName;
	}

	
}
