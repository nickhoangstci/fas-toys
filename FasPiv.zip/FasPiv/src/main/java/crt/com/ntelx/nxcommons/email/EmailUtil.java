package crt.com.ntelx.nxcommons.email;

import com.freightdesk.fdcommons.EmailSender;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

import com.freightdesk.fdcommons.ApplicationProperties;
import crt.com.ntelx.nxcommons.NxUtils;
import com.freightdesk.fdfolio.useraccess.model.SystemUserModel;

public class EmailUtil {
	
	private static Logger logger = Logger.getLogger(EmailUtil.class);
	
	public static void sendPassResetEmail(String contactName, String password, String subject, String emailAddr) throws Exception {
		// The following will read email template form RUNTIME
		//
		EmailBodyFactory eFact = EmailBodyFactory.getInstance();
		UserEmailBody prEmailBody = eFact.getPasswordResetEmailBody();

		// this will replace the given values in email template to create the
		// body
		//
		prEmailBody.setContactName(contactName);
		prEmailBody.setPassword(password);

		EmailSender emailSender = new EmailSender();
		logger.debug("Sending password reset email");
		emailSender.sendMail(emailAddr, subject, new StringBuffer(prEmailBody.getBody()));
	}
	
	/*
	 * Sends two emails to satisfy security.  First email has userId, second email has password.
	 */
	public static void sendNewLoginEmail(String contactName, String userId, String password, String userSubject, String passSubject, String emailAddr) throws Exception {
		// The following will read email template form RUNTIME
		//
		EmailBodyFactory eFact = EmailBodyFactory.getInstance();
		UserEmailBody uEmailBody = eFact.getNewUserEmailBody();
		UserEmailBody pEmailBody = eFact.getUserPassEmailBody();

		// this will replace the given values in email template
		uEmailBody.setContactName(contactName);
		uEmailBody.setUserName(userId);
		
		pEmailBody.setContactName(contactName);
		pEmailBody.setPassword(password);

		EmailSender emailSender = new EmailSender();
		logger.debug("Sending new user email to "+contactName);
		emailSender.sendMail(emailAddr, userSubject, new StringBuffer(uEmailBody.getBody()));
		
		// wait one second before sending the next email
		Thread.sleep(1000);
		
		logger.debug("Sending new password email");
		emailSender.sendMail(emailAddr, passSubject, new StringBuffer(pEmailBody.getBody()));
		
	}
	
	public static void sendNoSubCCSFEmail( String firstName, String lastName, String orgName, String certNum, String sysDate, String dueDate, 
			                               String subject,   String emailAddr ) throws Exception
	{
		logger.debug( "Sending message to : " + emailAddr );
		
		// The following will read email template form RUNTIME
		//
		EmailBodyFactory eFact = EmailBodyFactory.getInstance();
		
		NoSubCCSFEmailBody emailBody = eFact.getNoSubCCSFEmailBody();
		emailBody.setContact  ( firstName +  " " + lastName );
		emailBody.setOrgName  ( orgName   );
		emailBody.setCertNum  ( certNum   );
		emailBody.setSysDate  ( sysDate   );
		emailBody.setDueDate  ( dueDate   );
				
	
		EmailSender emailSender = new EmailSender();
		logger.debug("Sending noSubCCSF email");
		emailSender.sendMail(emailAddr, subject, new StringBuffer( emailBody.getBody()));
	}
	
	public static void sendReceiptCCSFEmail( String firstName, String lastName, List<String> certNums,  
            String subject,   String emailAddr ) throws Exception
	{
		logger.debug( "Sending message to : " + emailAddr );
		
		// The following will read email template form RUNTIME
		//
		EmailBodyFactory eFact = EmailBodyFactory.getInstance();
		
		ReceiptEmailCCSFBody emailBody = eFact.getReceiptEmailCCSFBody();
		emailBody.setContact  ( firstName +  " " + lastName );
		emailBody.setCertList ( certNums );
		
		EmailSender emailSender = new EmailSender();
		logger.debug("Sending Reciept email");
		emailSender.sendMail(emailAddr, subject, new StringBuffer( emailBody.getBody()));
	}
	
	public static boolean sentPasswordExpireEmail(SystemUserModel userModel) {
		try {
			String subject = "Password Expiration Warning";
			String emailAddr = userModel.getEmail();
			String name = NxUtils.upperFirst(userModel.getContactFirstName() + " " +userModel.getContactLastName());
			String login = userModel.getDomainName()+"."+userModel.getUserId();
			String expireDays = ApplicationProperties.getProperty("password.emailWarningDays");
						
			logger.debug("email=" + emailAddr + ", name=" + name + ", login=" + login);
			
			// read template and set values
			EmailBodyFactory eFact = EmailBodyFactory.getInstance();
			ExpireWarnEmailBody emailBody = eFact.getExpireWarnEmailBody();
			emailBody.setContact(name);
			emailBody.setLogin(login);
			emailBody.setExpireDays(expireDays);
			
			// send email
			EmailSender emailSender = new EmailSender();
			emailSender.sendMail(emailAddr, subject, new StringBuffer( emailBody.getBody()));
			
		} catch (Exception ex) {
			//ex.printStackTrace();
			logger.error("Exception : " + ex.getMessage());
			return false;
		}
		return true;
	}
	
	public static boolean isValidEmail(String email) {
		// This is a slightly tweaked version of the regex from http://www.javarmi.com/2010/07/java-regular-expression-to-validate-email-address/
		String emailRegex = "^[\\w]([\\-\\.\\w])+@([\\w\\-]+\\.)+[A-Z]{2,4}$";
		Pattern emailPattern = Pattern.compile(emailRegex, Pattern.CASE_INSENSITIVE);
		Matcher emailMatcher = emailPattern.matcher(email);
		return emailMatcher.matches();
	}
}
