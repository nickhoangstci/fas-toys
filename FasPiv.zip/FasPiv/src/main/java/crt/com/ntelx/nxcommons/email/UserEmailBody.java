/**
 * 
 */
package crt.com.ntelx.nxcommons.email;

/**
 * @author jhansford
 */
public class UserEmailBody extends AbstractEmailBody {
	private String contactName = "";
	private String userName = "";
	private String password = "";

	public String getContactName() {
		return contactName;
	}

	public void setContactName(String contactName) {
		this.contactName = contactName;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}


	public String getBody() {
		String body = null;

		body = replaceGDPattern(getTemplate(), "<password>", password);
		body = replaceGDPattern(body, "<contact>", contactName);
		body = replaceGDPattern(body, "<user>", userName);

		return body;
	}

}
