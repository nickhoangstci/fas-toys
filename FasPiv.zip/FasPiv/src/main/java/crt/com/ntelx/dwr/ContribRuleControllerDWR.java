package crt.com.ntelx.dwr;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.directwebremoting.annotations.RemoteMethod;
import org.directwebremoting.annotations.RemoteProxy;

import crt.com.ntelx.inbox.FaEntry;
import crt.com.ntelx.inbox.FaEntryscore;
import crt.com.ntelx.inbox.FaScoredetails;
import crt.com.ntelx.inbox.FasInboxDAO;

@RemoteProxy
public class ContribRuleControllerDWR
{
	@RemoteMethod
	public List<ContribRuleInfo> getRuleInfoByFaEntryId( int faEntryID, String category, String type )
	{
		FasInboxDAO fasInboxDao = new FasInboxDAO();
		
		FaEntry faEntry = fasInboxDao.getEntryByID( faEntryID );
				 		
		return getRuleContribs( faEntry, category, type );
	}
	
	protected List<ContribRuleInfo> getRuleContribs( FaEntry faEntry, String category, String type )
	{
		Set<FaEntryscore> entryScoreSet = faEntry.getFaEntryscores();
		
		Set<FaScoredetails> detailsSet = null;
		for ( FaEntryscore entScore : entryScoreSet )
		{
			if( entScore.getScoretypecode().equals( type ) )
			{
				if ( entScore.getScorecategorytypecode().equals( category ) )
				{
					detailsSet = entScore.getFaScoredetailses();
				}
			}
		}
		
		List<ContribRuleInfo> ruleList = new ArrayList<ContribRuleInfo>();
		ContribRuleInfo ruleInfo = null;
		if ( detailsSet != null )
		{
			for ( FaScoredetails detail : detailsSet )
			{
				ruleInfo = new ContribRuleInfo();
				ruleInfo.setRuleName   ( detail.getRulename()              );
				ruleInfo.setDescription( detail.getDescription()           );
				ruleInfo.setScore      ( detail.getScorevalue().toString() );
				
				ruleList.add( ruleInfo );
			}
		}
		
		return ruleList;
	}
	
}
