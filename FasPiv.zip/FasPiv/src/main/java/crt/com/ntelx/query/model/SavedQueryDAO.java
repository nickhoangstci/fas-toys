package crt.com.ntelx.query.model;

import org.apache.log4j.Logger;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import com.freightdesk.fdfolio.common.SessionFactoryUtil;

public class SavedQueryDAO{
	
	protected static Logger logger = Logger.getLogger("SaveQueryDAO");
	@SuppressWarnings("unchecked")
	public List<SavedQueryModel> retrieveActiveQueries() {
		Session session = null;
		Criteria criteria;
		Criterion crit;
		try {
			session = SessionFactoryUtil.getSession();
			criteria = session.createCriteria(SavedQueryModel.class);

			crit = Restrictions.eq(SavedQueryTransfer.SavedQueryProperties.status.name(), SavedQueryTransfer.activeStatus);
			criteria.add(crit);
			
			criteria.addOrder(Order.asc(SavedQueryTransfer.SavedQueryProperties.queryName.name()).ignoreCase());
			
			List<SavedQueryModel> models = criteria.list();
			
			return models;
		} catch (Exception e) {			
			logger.error("Exception: " + e.getMessage());
		} finally {
			session.close();
		}

		return (new ArrayList<SavedQueryModel>());
	}

	@SuppressWarnings("unchecked")
	public SavedQueryModel retrieveQueryByID(Long queryID) {
		Session session = null;
		Criteria criteria;
		Criterion crit;
		try {
			session = SessionFactoryUtil.getSession();
			criteria = session.createCriteria(SavedQueryModel.class);
			crit = Restrictions.eq(SavedQueryTransfer.SavedQueryProperties.queryToolID.name(), queryID);
			criteria.add(crit);

			if (criteria.list().size() == 0)
			{
				criteria.list().add(new SavedQueryModel());
			}

			return (SavedQueryModel) criteria.list().get(0);
		} catch (Exception e) {			
			logger.error("Exception: " + e.getMessage());
		} finally {
			session.close();
		}

		return (new SavedQueryModel());
	}
	
	public SavedQueryModel retrieveActiveQuery(String queryName) {
		Session session = null;
		Criteria criteria;
		Criterion crit;
		try {
			session = SessionFactoryUtil.getSession();
			criteria = session.createCriteria(SavedQueryModel.class);

			crit = Restrictions.eq(SavedQueryTransfer.SavedQueryProperties.queryName.name(), queryName);
			criteria.add(crit);
			crit = Restrictions.eq(SavedQueryTransfer.SavedQueryProperties.status.name(), SavedQueryTransfer.activeStatus);
			criteria.add(crit);

			if (criteria.list().size() == 0)
			{
				return (null);
			}

			return (SavedQueryModel) criteria.list().get(0);
		} catch (Exception e) {			
			logger.error("Exception: " + e.getMessage());
		} finally {
			session.close();
		}

		return (null);
	}

	public SavedQueryModel retrieveOtherActiveQueries(String queryName, String queryID) {
		Session session = null;
		Criteria criteria;
		Criterion crit;
		try {
			session = SessionFactoryUtil.getSession();
			criteria = session.createCriteria(SavedQueryModel.class);

			crit = Restrictions.eq(SavedQueryTransfer.SavedQueryProperties.queryName.name(), queryName);
			criteria.add(crit);
			crit = Restrictions.eq(SavedQueryTransfer.SavedQueryProperties.status.name(), SavedQueryTransfer.activeStatus);
			criteria.add(crit);
			crit = Restrictions.ne(SavedQueryTransfer.SavedQueryProperties.queryToolID.name(), Long.parseLong(queryID));
			criteria.add(crit);
			
			if (criteria.list().size() == 0)
			{
				return (null);
			}

			return (SavedQueryModel) criteria.list().get(0);
		} catch (Exception e) {			
			logger.error("Exception: " + e.getMessage());
		} finally {
			session.close();
		}
		return (null);
	}
	
	public void deactivateQueryID(Long queryID) {
		Session session = null;
		try {
			session = SessionFactoryUtil.getSession();
			session.getNamedQuery(SavedQueryModel.deactivateQueryID)
				.setLong(SavedQueryModel.queryIDField, queryID)
				.executeUpdate();
			
			logger.info("Deactivated query ID: " + queryID);

		} catch (Exception e) {			
			logger.error("Exception: " + e.getMessage());
		} finally {
			session.close();
		}
	}	

	public void saveQuery(SavedQueryModel query) {
		Session session = null;
		try {
			session = SessionFactoryUtil.getSession();
            session.beginTransaction();
            
			session.save(SavedQueryModel.class.getName(), query);

			logger.info("Saved query: " + query.getQueryName());

		} catch (Exception e) {			
			logger.error("Exception: " + e.getMessage());
            session.getTransaction().rollback();
		} finally {
            session.getTransaction().commit();
			session.close();
		}
	}	
	
}