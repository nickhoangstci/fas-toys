package crt.com.ntelx.query.model;

public interface Sort {

public enum SortDirection{asc, desc};
	
SortDirection getSortType();
Object getColumnName();
}