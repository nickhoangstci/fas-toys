package crt.com.ntelx.query.model;

import org.apache.log4j.Logger;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import com.freightdesk.fdfolio.common.SessionFactoryUtil;

public class QuerySearchDAO implements SearchDAO {

	protected final Logger logger = Logger.getLogger("QuerySearchDAO");
	
	@Override
	// search results are based on the search filter critering and sorting
	public List<QueryModel> retrieveSearchResults(
			List<SearchFilter> searchCriteria, Sort sorting, Boolean showSubset) {
		Session session = null;
		Criteria criteria;
		Criterion crit;
		Order sortOrder;
		try {
			session = SessionFactoryUtil.getSession();
			criteria = session.createCriteria(QueryModel.class);

			// each criteria is evaluated first based on disjunction (OR/AND)
			for (SearchFilter filter : searchCriteria) {
				// for disjunctions of "OR" statements, multiple fields 
				// may be evaluated against criteria. (x == a or y == b)
				if (SearchFilter.Disjunction.OR == filter.getDisjunction()) {
					crit = makeOrDisjunctionCriteria(filter);
				} else {
				// the disjunction by default is "AND" (and x == a)
					crit = makeCriterion(filter);
				}
				
				// if the criteria is not null due to some error in translation, then it is added
				if (crit != null) 
					criteria.add(crit);
			}

			// for previewing, a subset may be shown
			if (showSubset)
				criteria.setMaxResults(50);
			
			// if the sorting column is not null, then sorting criteria is made
			if ((String) sorting.getColumnName() != null)
			{
				sortOrder = makeSortingCriteria(sorting);
				
				if (sortOrder != null)
				{
					criteria.addOrder(sortOrder);
				}
			}

			@SuppressWarnings("unchecked")
			List<QueryModel> results = formatDates(criteria.list());
			
			return results;
		} catch (Exception e) {
			
			logger.error("Exception: " + e.getMessage());
		} finally {
			session.close();
		}

		return (new ArrayList<QueryModel>());
	}

	private List<QueryModel> formatDates(List<QueryModel> list) {
		
		List<QueryModel> results = list;
		
		for (QueryModel row : results)
		{
			// update all the date formats to something presentable.
			try {			
				if (!"".equals(row.getCreatedDate()))
				row.setCreatedDate(QueryModelTransfer.outputDateFormat.format(QueryModelTransfer.inputDateFormat.parse(row.getCreatedDate())));
			} catch (ParseException e) {
			    logger.error("Exception: " + e.getMessage());
				
			}				

			try {
				if (!"".equals(row.getReportingStartDate()))
				row.setReportingStartDate(QueryModelTransfer.outputDateFormat.format(QueryModelTransfer.inputDateFormat.parse(row.getReportingStartDate())));
			} catch (ParseException e) {
			    logger.error("Exception: " + e.getMessage());
				
			}	

			try {
				if (!"".equals(row.getReportingEndDate()))
				row.setReportingEndDate(QueryModelTransfer.outputDateFormat.format(QueryModelTransfer.inputDateFormat.parse(row.getReportingEndDate())));
			} catch (ParseException e) {
			     logger.error("Exception: " + e.getMessage());
				
			}	

			try {
				if (!"".equals(row.getUpdatedDate()))
				row.setUpdatedDate(QueryModelTransfer.outputDateFormat.format(QueryModelTransfer.inputDateFormat.parse(row.getUpdatedDate())));
			} catch (ParseException e) {
			    logger.error("Exception: " + e.getMessage());
				
			}	
		}

		return results;
	}

	// the sorting criteria order is discerned to be either ascending or descending
	private Order makeSortingCriteria(Sort sorting) {
		Order sort = null;
		if (Sort.SortDirection.asc == sorting.getSortType())
		{
			sort = Order.asc((String) sorting.getColumnName());
		}else if (Sort.SortDirection.desc == sorting.getSortType())
		{
			sort = Order.desc((String) sorting.getColumnName());			
		}
		return sort;
	}

	// for OR disjunctions, the columns are String [], and they values are all the same. 
	private Criterion makeOrDisjunctionCriteria(SearchFilter filter) {
		Criterion crit = null;
		Criterion nestedCrit = null;
		for (String column : (String[]) filter.getPropertyName()) {
			nestedCrit = nestedCrit == null ? Restrictions.like(column,
					(String) filter.getFilterValue(), MatchMode.ANYWHERE)
					: Restrictions.or(nestedCrit, Restrictions.ilike(column,
							(String) filter.getFilterValue(),
							MatchMode.ANYWHERE));
		}
		crit = Restrictions.and(nestedCrit);
		return crit;
	}

	// a standard AND criteria clause is created based on the predicates
	private Criterion makeCriterion(SearchFilter filter) {

		Criterion crit = null;

		java.util.Date dateTime = null;
		SimpleDateFormat inputFormat = QueryModelTransfer.formFormat;
		SimpleDateFormat outputFormat = new SimpleDateFormat("dd-MMM-yy");
		
		// dates are formatted into the string that sql will recognize
		if (SearchFilter.ValueDataType.DATE == filter.getDataType()) {
			try {

				dateTime = inputFormat.parse((String) filter.getFilterValue());
			} catch (ParseException e) {				
				logger.error("Exception: " + e.getMessage());
				return null;
			}
		}

		// each predicate is switched against and added
		switch (filter.getPredicate()) {
		case EQ:
			crit = Restrictions.eq((String) filter.getPropertyName(),
					filter.getFilterValue());
			break;
		case LIKE:
			crit = Restrictions.ilike((String) filter.getPropertyName(),
					(String) filter.getFilterValue(), MatchMode.ANYWHERE);
			break;
		case IN:
			// with the IN predicate, it is assumed that the values are in a String [].
			crit = Restrictions.in((String) filter.getPropertyName(),
					(Object[]) filter.getFilterValue());
			break;
		case GTE:
			crit = dateTime == null ? Restrictions.ge(
					(String) filter.getPropertyName(), filter.getFilterValue())
					: Restrictions
							.ge((String) filter.getPropertyName(), outputFormat.format(dateTime));
			break;
		case LTE:
			crit = dateTime == null ? Restrictions.le(
					(String) filter.getPropertyName(), filter.getFilterValue())
					: Restrictions
							.le((String) filter.getPropertyName(), outputFormat.format(dateTime));
			break;
		default:
			break;
		}

		return crit;
	}
}