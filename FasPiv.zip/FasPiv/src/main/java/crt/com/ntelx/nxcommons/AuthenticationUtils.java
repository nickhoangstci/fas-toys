package crt.com.ntelx.nxcommons;

import com.freightdesk.fdcommons.ApplicationProperties;
import com.freightdesk.fdcommons.ApplicationTabs;
import com.freightdesk.fdcommons.ConnectionUtil;
import com.freightdesk.fdcommons.Credentials;
import com.freightdesk.fdcommons.InvalidUserException;
import com.freightdesk.fdcommons.PasswordExpiredException;
import com.freightdesk.fdcommons.PasswordHasher;
import com.freightdesk.fdcommons.SessionKey;
import com.freightdesk.fdcommons.SessionStore;
import com.freightdesk.fdcommons.UserNotActiveException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.security.auth.login.AccountExpiredException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.directwebremoting.WebContext;
import org.directwebremoting.WebContextFactory;

import com.freightdesk.fdcommons.asyncprocess.AsyncProcessManager;
import com.freightdesk.fdcommons.asyncprocess.AsyncProcessingLogModel;
import com.freightdesk.fdfolio.useraccess.model.SystemUserModel;

public class AuthenticationUtils {
	/** A logger */
	protected static Logger logger = Logger.getLogger("AuthenticationUtils");

	public static Credentials getCredentials(String userId, String password, String domain, String ipAddress) throws InvalidUserException, UserNotActiveException, PasswordExpiredException,
			AccountExpiredException, SQLException {
		String passphraseHash = PasswordUtils.hashPassword(password);
		userId = userId.toUpperCase();
		StringBuffer query = new StringBuffer(
				"SELECT U.SYSTEMUSERID,U.UOMCODE,U.CURRENCYCODE,U.DATEFORMAT,U.TIMEZONEID, U.ORGID, U.PASSWORDEXPIRATIONDATE, U.ISPASSWORDAUTOEXPIRE, U.AUTOEXPIREDAYS, U.ISACTIVE, U.LASTLOGINTIMESTAMP, U.LASTUPDATETIMESTAMP+U.AUTOEXPIREDAYS add_date, U.DOMAINNAME, ");
		query.append("U.SYSTEMROLECODE,U.NUMFAILEDLOGIN,SR.SYSTEMROLENAME FROM SYSTEMUSER U,SYSTEMROLE SR ");
		query.append("WHERE U.SYSTEMROLECODE=SR.SYSTEMROLECODE AND UPPER(U.USERID)=? AND U.DOMAINNAME=? AND U.PASSPHRASEHASH=? ");
		Connection connection = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Credentials credentials = null;
		try {
			logger.debug("getCredentials(userId,password,domain) begin. \n [DQL] " + query);
			connection = ConnectionUtil.getConnection();
			pstmt = connection.prepareStatement(query.toString());
			pstmt.setString(1, userId.toUpperCase());
			pstmt.setString(2, domain);
			pstmt.setString(3, passphraseHash);
			rs = pstmt.executeQuery();
			if (AuthenticationUtils.validateUser(rs, userId, domain)) {
				long systemUserId = rs.getLong("SYSTEMUSERID");
				int previousFailedLogin = rs.getInt("NUMFAILEDLOGIN");
				// Since user is valid, reset the NUMFAILEDLOGIN to 0
				AuthenticationUtils.setNumFailedLogin(systemUserId, 0);
				String uomCode = rs.getString("UOMCODE");
				String currencyCode = rs.getString("CURRENCYCODE");
				String dateFormat = rs.getString("DATEFORMAT");
				String timeZoneId = rs.getString("TIMEZONEID");
				Timestamp lastLoginTimestamp = rs.getTimestamp("LASTLOGINTIMESTAMP");
				long orgId = rs.getLong("ORGID");
				String isActive = rs.getString("ISACTIVE");
				String role = rs.getString("SYSTEMROLECODE");

				// BEGIN: autoexpiration set and check
				int isPasswordAutoExpire = rs.getInt("ISPASSWORDAUTOEXPIRE");
				Timestamp expDate = null;

				if (isPasswordAutoExpire > 0) {
					expDate = rs.getTimestamp("add_date");
				}
				// END:

				// Get the parent orgs for this user
				Map<String, Long> typeOrgMap = UserUtils.getParentTypeById(orgId);

				// Get all contacts that share your parent org
				List<Long> relatedContacts = UserUtils.getRelatedContacts(orgId);
				List<String> relatedUserIds = UserUtils.getUserIds(relatedContacts);

				credentials = new Credentials();
				credentials.setSystemUserId(systemUserId);
				credentials.setUserId(userId);
				credentials.setDomainName(domain);
				credentials.setUomCode(uomCode);
				credentials.setCurrencyCode(currencyCode);
				credentials.setDateFormat(dateFormat);
				credentials.setTimeZoneId(timeZoneId);
				credentials.setRole(role);
				credentials.setOrgId(orgId);
				credentials.setIsActive(isActive);
				credentials.setLastLoginTime(lastLoginTimestamp);
				credentials.setNumFailedLogin(previousFailedLogin);
				credentials.setExpirationDate(expDate);
				credentials.setRelatedUserIds(relatedUserIds);
				// retrieved from user request. user for logging
				credentials.setIpAddress(ipAddress);
				credentials.setSystemRoleName(rs.getString("SYSTEMROLENAME"));

				// could have one or two parent org ids. Either loc and/or
				// org/car
				if (typeOrgMap.containsKey("ORG")) {
					credentials.setParentOrgType("ORG");
					credentials.setParentOrgId(typeOrgMap.get("ORG"));
				}

				if (typeOrgMap.containsKey("LOC"))
					credentials.setParentLocId(typeOrgMap.get("LOC"));

				logger.debug("ParentOrgId = " + credentials.getParentOrgId() + ", ParentLocId = " + credentials.getParentLocId());

			}
		} catch (SQLException sqEx) {
			logger.error("Exception in getCredentials(" + userId + ",password, " + domain + ")", sqEx);
			throw new RuntimeException(sqEx);
		} finally {
			ConnectionUtil.closeResources(connection, pstmt, rs);
		}
		return credentials;
	}


	public static Credentials getPivCredentials(String userId, String domain, String ipAddress) throws InvalidUserException, UserNotActiveException, PasswordExpiredException,
			AccountExpiredException, SQLException {

		userId = userId.toUpperCase();
		
		StringBuffer query = new StringBuffer(
				"SELECT U.SYSTEMUSERID,U.UOMCODE,U.CURRENCYCODE,U.DATEFORMAT,U.TIMEZONEID, U.ORGID, U.PASSWORDEXPIRATIONDATE, U.ISPASSWORDAUTOEXPIRE, U.AUTOEXPIREDAYS, U.ISACTIVE, U.LASTLOGINTIMESTAMP, U.LASTUPDATETIMESTAMP+U.AUTOEXPIREDAYS add_date, U.DOMAINNAME, ");
		query.append("U.SYSTEMROLECODE,SR.SYSTEMROLENAME FROM SYSTEMUSER U,SYSTEMROLE SR ");
		query.append("WHERE U.SYSTEMROLECODE=SR.SYSTEMROLECODE AND UPPER(U.USERID)=? AND U.DOMAINNAME=? AND ROWNUM=1");
		
		Connection connection = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Credentials credentials = null;
		try {
			logger.info("getCredentials(userId,domain) begin. \n [DQL] " + query);
			connection = ConnectionUtil.getConnection();
			
			pstmt = connection.prepareStatement(query.toString());
			pstmt.setString(1, userId.toUpperCase());
			pstmt.setString(2, domain);
			
			rs = pstmt.executeQuery();

			//if (AuthenticationUtils.validateUser(rs, userId, domain)) {
			
//			try {
				if (rs.next()) {
					
				long systemUserId = rs.getLong("SYSTEMUSERID");
				//int previousFailedLogin = rs.getInt("NUMFAILEDLOGIN");
				// Since user is valid, reset the NUMFAILEDLOGIN to 0
				AuthenticationUtils.setNumFailedLogin(systemUserId, 0);
				String uomCode = rs.getString("UOMCODE");
				String currencyCode = rs.getString("CURRENCYCODE");
				String dateFormat = rs.getString("DATEFORMAT");
				String timeZoneId = rs.getString("TIMEZONEID");
				Timestamp lastLoginTimestamp = rs.getTimestamp("LASTLOGINTIMESTAMP");
				long orgId = rs.getLong("ORGID");
				String isActive = rs.getString("ISACTIVE");
				String role = rs.getString("SYSTEMROLECODE");
				String roleName = rs.getString("SYSTEMROLENAME");


				logger.info(role + "----- Org ID:" + orgId);
				// Get the parent orgs for this user
				Map<String, Long> typeOrgMap = UserUtils.getParentTypeById(orgId);

				// Get all contacts that share your parent org
				List<Long> relatedContacts = UserUtils.getRelatedContacts(orgId);
				List<String> relatedUserIds = UserUtils.getUserIds(relatedContacts);

				credentials = new Credentials();
				credentials.setSystemUserId(systemUserId);
				credentials.setUserId(userId);
				credentials.setDomainName(domain);
				credentials.setUomCode(uomCode);
				credentials.setCurrencyCode(currencyCode);
				credentials.setDateFormat(dateFormat);
				credentials.setTimeZoneId(timeZoneId);
				credentials.setRole(role);
				credentials.setOrgId(orgId);
				credentials.setIsActive(isActive);
				credentials.setLastLoginTime(lastLoginTimestamp);
				credentials.setNumFailedLogin(0);
//				credentials.setExpirationDate(expDate);
				credentials.setRelatedUserIds(relatedUserIds);
				// retrieved from user request. user for logging
				credentials.setIpAddress(ipAddress);
				credentials.setSystemRoleName(roleName);

				// could have one or two parent org ids. Either loc and/or
				// org/car
				if (typeOrgMap.containsKey("ORG")) {
					credentials.setParentOrgType("ORG");
					credentials.setParentOrgId(typeOrgMap.get("ORG"));
				}

				if (typeOrgMap.containsKey("LOC"))
					credentials.setParentLocId(typeOrgMap.get("LOC"));

				logger.info("ParentOrgId = " + credentials.getParentOrgId() + ", ParentLocId = " + credentials.getParentLocId());
				
				logger.info("Credentials: " + credentials.toString());
				
				
			}
		} catch (SQLException sqEx) {
			logger.error("Exception in getCredentials(" + userId + "  " + domain + ")", sqEx);
			throw new RuntimeException(sqEx);
		} finally {
			ConnectionUtil.closeResources(connection, pstmt, rs);
		}
		return credentials;
	}

	public static boolean validateUser(ResultSet rs, String userId, String domain) throws InvalidUserException, UserNotActiveException, PasswordExpiredException, AccountExpiredException {
		logger.debug("validateUser(ResultSet): begin");
		// User is blocked if they have more failed login attempts than the
		// limit
                int failedLoginLimit = 10;
                try {
                    failedLoginLimit = Integer.parseInt(ApplicationProperties.getProperty("password.allowedFailedLogins"));
                }
                catch (Exception e) {
        		logger.debug("validateUser(allowedFailedLogins:"+ ApplicationProperties.getProperty("password.allowedFailedLogins"));
        		logger.debug("Exception:"+ e.getMessage());
                       failedLoginLimit = 10;
                }
		try {
			if (rs.next()) {
				Timestamp passwordExpirationDate = rs.getTimestamp("PASSWORDEXPIRATIONDATE");
				int isPasswordAutoExpire = rs.getInt("ISPASSWORDAUTOEXPIRE");
				int numFailedLogin = rs.getInt("NUMFAILEDLOGIN");
				String isActive = rs.getString("ISACTIVE");
				Timestamp currentDate = new Timestamp(System.currentTimeMillis());
				Timestamp addDate = rs.getTimestamp("add_date");
				logger.debug("IsActive: " + isActive);

				if (isActive.equalsIgnoreCase("Y") || isActive.equalsIgnoreCase("C") || isActive.equalsIgnoreCase("S")) {
					if (passwordExpirationDate != null) {
						logger.debug("currentDate " + currentDate + " passwordExpirationDate " + passwordExpirationDate);
						if (!currentDate.before(passwordExpirationDate)) {
							throw new PasswordExpiredException();
						}
					}
					if (isPasswordAutoExpire > 0) {
						logger.debug("currentDate " + currentDate + " addDate " + addDate);
						if (addDate != null && !currentDate.before(addDate)) {
							throw new PasswordExpiredException();
						}
					}
					if (numFailedLogin > failedLoginLimit) {
						throw new AccountExpiredException("user " + userId + " in domain " + domain + " has " + numFailedLogin + " failed login attempts.  Limit is " + failedLoginLimit);
					}
				} else {
					throw new UserNotActiveException();
				}
			} else {
				if (incrementNumFailedLogin(userId, domain) == true) {
					throw new InvalidUserException("Invalid Password");
				} else {
					throw new InvalidUserException("User not found");
				}
			}
		} catch (SQLException sqex) {
			logger.error("SQLException in validateUser (ResultSet)", sqex);
			throw new RuntimeException(sqex);
		}
		return true;
	}

        
	public static Map getParents(long orgId) throws SQLException {
		String type = null;
		logger.debug("getParents(): begin");
		Map map = new HashMap();
		Connection connection = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			connection = ConnectionUtil.getConnection();
			String typeQuery1 = "SELECT ORGHIERARCHYTYPECODE  FROM ORGHIERARCHY WHERE ORGID=?";
			stmt = connection.prepareStatement(typeQuery1);
			stmt.setLong(1, orgId);
			rs = stmt.executeQuery();
			if (rs.next())
				type = rs.getString(1);

			ConnectionUtil.closeResources(null, stmt, rs);
			logger.debug("Type: " + type);
			
			if ((type != null) && (type.equals("LOC"))) {
				String query = "SELECT PARENTORGID FROM ORGHIERARCHY WHERE ORGID=?";
				stmt = connection.prepareStatement(query);
				stmt.setLong(1, orgId);

				for (rs = stmt.executeQuery(); rs.next();) {
					long id = rs.getLong(1);
					map.put("ORG", new Long(id));
				}
				ConnectionUtil.closeResources(null, stmt, rs);			
			} else if ((type != null) && (type.equals("CON"))) {
				String query = "SELECT PARENTORGID FROM ORGHIERARCHY WHERE ORGID=?";
				stmt = connection.prepareStatement(query);
				stmt.setLong(1, orgId);

				long id = 0L;
				for (rs = stmt.executeQuery(); rs.next();) {
					id = rs.getLong(1);
					map.put("CON", new Long(id));
				}	
				ConnectionUtil.closeResources(null, stmt, rs);
				String typeQuery = "SELECT ORGHIERARCHYTYPECODE FROM ORGHIERARCHY WHERE ORGID=?";				
				
				stmt = connection.prepareStatement(typeQuery);
				stmt.setLong(1, id);
				rs = stmt.executeQuery();

				ConnectionUtil.closeResources(null, stmt, rs);
				String typeId;

				for (typeId = ""; rs.next(); typeId = rs.getString(1)) {
				}

				if (typeId.equals("LOC")) {
					map.put("LOC", new Long(id));

					String orgQuery = "SELECT PARENTORGID FROM ORGHIERARCHY WHERE ORGID=?";
					stmt = connection.prepareStatement(orgQuery);
					stmt.setLong(1, id);

					long grandParentOrgid = 0L; // assuming parent of location
												// is of type ORG
					for (rs = stmt.executeQuery(); rs.next();)
						grandParentOrgid = rs.getLong(1);

					map.put("ORG", new Long(grandParentOrgid));
					ConnectionUtil.closeResources(null, stmt, rs);
				} else if (typeId.equals("ORG")) {
					map.put("ORG", new Long(id));
				}
			}
		} catch (Exception sqEx) {
			logger.error("Exception in getParents (" + orgId + ",type) ", sqEx);
			throw new SQLException();
		} finally {
			ConnectionUtil.closeResources(connection, stmt, rs);
		}
		return map;
	}

	/*
	 * retrieves basic information on a user.
	 */
	public static SystemUserModel retrieveUserInfo(String domainName, String userId) throws Exception {
		logger.debug("Attempting to retrieve details of user " + domainName + "." + userId);
		SystemUserModel systemUser = new SystemUserModel();
		Connection connection = null;
		ResultSet rs = null;
		PreparedStatement pStmt = null;

		String query = "select s.systemuserid, s.orgid, s.domainname,s.userid,s.systemrolecode,s.ispasswordautoexpire,s.autoexpiredays,s.isactive,s.lastupdatetimestamp,s.createtimestamp,s.numfailedlogin,o.email,o.contactfirstname "
				+ "from systemuser s, orghierarchy o " + "where s.orgid = o.orgid and " +
				// 1 2
				"s.domainname=? and s.userid=?";
		try {
			connection = ConnectionUtil.getConnection();
			pStmt = connection.prepareStatement(query);

			// bind the two variables
			pStmt.setString(1, domainName);
			pStmt.setString(2, userId);

			rs = pStmt.executeQuery();
			if (rs.next()) {
				systemUser.setSystemUserId(rs.getLong("SYSTEMUSERID"));
				logger.debug("Found user with ID of " + systemUser.getSystemUserId());
				systemUser.setOrgId(rs.getLong("ORGID"));
				systemUser.setDomainName(rs.getString("DOMAINNAME"));
				systemUser.setUserId(rs.getString("USERID"));
				systemUser.setSystemRoleCode(rs.getString("SYSTEMROLECODE"));
				systemUser.setIsPasswordAutoExpire(rs.getInt("ISPASSWORDAUTOEXPIRE"));
				systemUser.setAutoExpireDays(rs.getInt("AUTOEXPIREDAYS"));
				systemUser.setIsActive(rs.getString("ISACTIVE"));
				systemUser.setEmail(rs.getString("EMAIL"));
				systemUser.setContactFirstName(rs.getString("CONTACTFIRSTNAME"));
				systemUser.setLastUpdateTimestamp(rs.getTimestamp("LASTUPDATETIMESTAMP"));
				systemUser.setCreateTimestamp(rs.getTimestamp("CREATETIMESTAMP"));
				systemUser.setNumFailedLogin(rs.getInt("NUMFAILEDLOGIN"));
			} 
		} catch (Exception ex) {
			logger.error("Exception attempting query: " + query, ex);
			throw ex;
		} finally {
			ConnectionUtil.closeResources(connection, pStmt, rs);
		}
                
                return systemUser;
	}

	public static boolean updateSystemUser(SystemUserModel systemUserModel, Credentials credentials) {
		logger.debug("updating systemuser ");
		boolean updated = false;
		boolean resetPassword = false;

		String updateClause = "UPDATE SYSTEMUSER SET PASSWORDEXPIRATIONDATE =? , ISPASSWORDAUTOEXPIRE =?,  AUTOEXPIREDAYS =? ,  DOMAINNAME =?, ISACTIVE=? , SYSTEMROLECODE=?, USERID=?, ORGID=?, LASTUPDATEUSERID=?, LASTUPDATETIMESTAMP=?";
		String whereClause = " WHERE SYSTEMUSERID=?";
		String updateQuery = "";
		AsyncProcessingLogModel asyncLogModel = new AsyncProcessingLogModel();
		AsyncProcessManager asyncManager = new AsyncProcessManager();
		String domainUser = systemUserModel.getDomainName() + "." + systemUserModel.getUserId();
		String logMsg = "";

		// Check to see whether the user password is being reset
		if (systemUserModel.getPassword() == null || systemUserModel.getPassword().equals("")) {
			updateQuery = updateClause + whereClause;
		} else {
			resetPassword = true;
			updateQuery = updateClause + ", PASSPHRASEHASH =?, LASTLOGINTIMESTAMP =?, NUMFAILEDLOGIN =?" + whereClause;
		}
		logger.debug("Password reset for user " + domainUser + " is " + resetPassword);

		Connection connection = null;
		PreparedStatement pStmt = null;

		try {
			// Log user edits in the ASYNCPROCESSINGLOG table
			asyncLogModel.init(credentials.getUserId(), credentials.getDomainName(), "USER UPDATE", "ADMIN", "In process update of user " + domainUser, credentials.getIpAddress());
			asyncLogModel = asyncManager.createAsyncProcessLog(asyncLogModel);

			connection = ConnectionUtil.getConnection();
			pStmt = connection.prepareStatement(updateQuery);

			pStmt.setTimestamp(1, systemUserModel.getPasswordExpirationDate());
			pStmt.setLong(2, systemUserModel.getIsPasswordAutoExpire());
			pStmt.setLong(3, systemUserModel.getAutoExpireDays());
			pStmt.setString(4, systemUserModel.getDomainName());
			pStmt.setString(5, systemUserModel.getIsActive());
			pStmt.setString(6, systemUserModel.getSystemRoleCode());
			pStmt.setString(7, systemUserModel.getUserId());
			pStmt.setLong(8, systemUserModel.getOrgId());
			pStmt.setString(9, credentials.getUserId());
			pStmt.setTimestamp(10, new Timestamp(System.currentTimeMillis()));
			if (resetPassword) {
				String hashedPassword = (new PasswordHasher()).hashPassword(systemUserModel.getPassword());
				pStmt.setString(11, hashedPassword);
				pStmt.setTimestamp(12, null);
				pStmt.setInt(13, 0);
				pStmt.setLong(14, systemUserModel.getSystemUserId());
				logMsg = "Successful password reset and update of user " + domainUser;
			} else {
				pStmt.setLong(11, systemUserModel.getSystemUserId());
				logMsg = "Successful update of user " + domainUser;
			}
			pStmt.executeUpdate();

			updated = true;

			asyncManager.logResult(asyncLogModel, true, logMsg, "updateSystemUser");

		} catch (Exception ex) {
			logger.error("Error while updating user", ex);
			asyncManager.logResult(asyncLogModel, false, "Failed to update user " + domainUser + " due to system exception.", "Exception");
		} finally {
			ConnectionUtil.closeResources(connection, pStmt, null);
		}

		return updated;
	}

	public static HashMap<String,String> getNxRolePermissionList(String role) {
		Connection connection = null;
		ResultSet rs = null;
		PreparedStatement pstmt = null;
		HashMap<String,String> codeNameList = new HashMap<String,String>();
		
		// ctrl+F7 in sqldeveloper to format
		String query = "SELECT F.SYSTEMFUNCTIONCODE, F.SYSTEMFUNCTIONNAME FROM SYSTEMFUNCTION F, SYSTEMROLEFUNCTION R WHERE R.DOMAINNAME = 'PUBLIC' AND R.SYSTEMFUNCTIONCODE=F.SYSTEMFUNCTIONCODE AND R.DOMAINNAME = F.DOMAINNAME AND R.SYSTEMROLECODE  = ?";

		try {
			logger.debug("Returning map of System function codes and function names for role " + role);
			connection = ConnectionUtil.getConnection();
			pstmt = connection.prepareStatement(query);
			pstmt.setString(1, role);
			
			String functionCode;
			String functionName;
			
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				functionCode = rs.getString("SYSTEMFUNCTIONCODE");
				functionName = rs.getString("SYSTEMFUNCTIONNAME");
				
				codeNameList.put(functionCode, functionName);
			}

		} catch (Exception ex) {
			logger.error("Exception - Error querying SYSTEMFUNCTION and SYSTEMROLEFUNCTION tables.\n" + query);
			
		} finally {
			ConnectionUtil.closeResources(connection, pstmt, rs);
		}
		logger.debug("Role "+role+" has "+codeNameList.size()+ " function codes");
		
		return codeNameList;
	}

	/**
	 * Updates the LastLoginTimestamp for the specified user.
	 * 
	 * @param systemUserId
	 * @throws SQLException
	 */
	public static void updateLastLoginTimestamp(long systemUserId) throws SQLException {
		logger.info("updateLastLoginTimestamp(): begin, systemUserId: " + systemUserId);

		String query = "UPDATE SYSTEMUSER SET LASTLOGINTIMESTAMP = ? WHERE SYSTEMUSERID=?";
		Connection connection = null;
		PreparedStatement pStmt = null;
		try {
			connection = ConnectionUtil.getConnection();
			pStmt = connection.prepareStatement(query);
			pStmt.setTimestamp(1, new Timestamp(System.currentTimeMillis()));
			pStmt.setLong(2, systemUserId);
			pStmt.executeUpdate();
			logger.debug("Finished updateLastLoginTimestamp()");
		} catch (SQLException sqEx) {
			logger.error("Exception in updateLastLoginTimestamp()", sqEx);
			throw sqEx;
		} finally {
			ConnectionUtil.closeResources(connection, pStmt, null);
		}
	}

	public static void setNumFailedLogin(long systemUserId, int numFailedLogin) throws SQLException {

		String query = "UPDATE SYSTEMUSER SET NUMFAILEDLOGIN = ? WHERE SYSTEMUSERID=?";
		Connection connection = null;
		PreparedStatement pStmt = null;
		try {
			connection = ConnectionUtil.getConnection();
			pStmt = connection.prepareStatement(query);
			pStmt.setInt(1, numFailedLogin);
			pStmt.setLong(2, systemUserId);
			pStmt.executeUpdate();
		} catch (SQLException sqEx) {
			logger.error("Could not set NUMFAILEDLOGIN to " + numFailedLogin, sqEx);
			throw sqEx;
		} finally {
			ConnectionUtil.closeResources(connection, pStmt, null);
		}
	}

	private static boolean incrementNumFailedLogin(String userId, String domain) throws SQLException {
		int numFailedLogin = 0;
		long systemUserId = 0;
		// Get the number of failed logins from the database.
		String query = "SELECT SYSTEMUSERID, NUMFAILEDLOGIN FROM SYSTEMUSER U WHERE U.USERID=? AND U.DOMAINNAME=?";
		Connection connection = null;
		PreparedStatement pStmt = null;
		ResultSet result = null;
		try {
			connection = ConnectionUtil.getConnection();
			pStmt = connection.prepareStatement(query);
			pStmt.setString(1, userId);
			pStmt.setString(2, domain);
			result = pStmt.executeQuery();

			if (result.next() == true) {
				systemUserId = result.getLong(1);
				numFailedLogin = result.getInt(2);
				// Increment the number of failed logins and set in the
				// database.
				numFailedLogin++;
				setNumFailedLogin(systemUserId, numFailedLogin);
				return true;
			} else {
				// UserId was not found.
				return false;
			}
		} catch (SQLException sqEx) {
			logger.error("Error while selecting NUMFAILEDLOGIN for userId=" + userId + ", domain" + domain);
			return false;
		} finally {
			ConnectionUtil.closeResources(connection, pStmt, result);
		}
	}
        
	// checks to see if a user currently has an active session
	public static boolean isUserLoggedIn(String userId, String domain) {

		Collection sessions = SessionStore.getAllSessions();
		logger.debug("Total Active Sessions :" + sessions.size());
		Map userIdPropertyMap = new HashMap();

		for (Iterator i = sessions.iterator(); i.hasNext();) {
			SessionStore sessionStore = (SessionStore) i.next();
			Credentials eachCredentials = (Credentials) sessionStore.get(SessionKey.CREDENTIALS);
			String currentModule = ApplicationTabs.getTabKey((Integer) sessionStore.get(SessionKey.CURRENT_TAB));
			String systemRoleName = "";
			if (eachCredentials != null) {
				logger.debug("user online:" + eachCredentials.getDomainName() + ":" + eachCredentials.getUserId());
				if (eachCredentials.getDomainName().equalsIgnoreCase(domain) && eachCredentials.getUserId().equalsIgnoreCase(userId)) {
					return true;
				}
			}
		}

		return false;
	}
	
	/*
	 * If using an ajax call via DWR (direct web remoting). This will return the current user's credentials. This means the user's session is active and is logged in
	 */
	public static Credentials getCredentialsForDWR() {
		Credentials credentials;
		try {
			logger.debug("checking sessionStore for credentials");
			WebContext ctx = WebContextFactory.get();
			HttpServletRequest req = ctx.getHttpServletRequest();
			HttpSession session = req.getSession(false);
			SessionStore store = SessionStore.getInstance(session);
			credentials = (Credentials) store.get(SessionKey.CREDENTIALS);
			logger.debug("User  is " + credentials.getDomainName() + "." + credentials.getUserId());
		} catch (Exception ex) {			
			logger.error("Exception - Failed to read to user credentials from session store.  Returning null session: " + ex.getMessage());
			credentials = null;
		}

		return credentials;
	}

}