/** 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/FDSuiteProperties.java,v 1.1.4.3 2010/12/01 21:57:18 mechevarria Exp $ 
 * 
 *  Modification History:
 *  $Log: FDSuiteProperties.java,v $
 *  Revision 1.1.4.3  2010/12/01 21:57:18  mechevarria
 *  use runtime only
 *
 *  Revision 1.1.4.2  2010/12/01 19:06:50  mechevarria
 *  simplified
 *
 *  Revision 1.1.4.1  2010/07/21 18:54:14  mechevarria
 *  add reset methods
 *
 *  Revision 1.1  2006/10/09 12:23:03  dkumar
 *  class for loading FDSuite.properties
 *
 */
/**
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 */
package com.freightdesk.fdcommons;

import org.apache.log4j.Logger;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

/**
 * @author Mike Echevarria
 * 
 */
public class FDSuiteProperties {
	private static Logger logger = Logger.getLogger("FDSuiteProperties");
	
	private static final String propsPath = System.getProperty("RUNTIME_HOME") + File.separator + "FDSuite.properties";

	protected static FDSuiteProperties _instance = null;

	private static Properties props = new Properties();

	private FDSuiteProperties() {
		load();
	}

	public static String getProperty(String key) {
		getInstance();
		return FDSuiteProperties.props.getProperty(key);
	}

	private synchronized static void load() {
		try {
			InputStream inputStream = new FileInputStream(propsPath);
			props.load(inputStream);
		} catch (Exception ex) {			
			logger.error("Exception Failed to load: " + ex.getMessage());
		}
	}

	public static void reset() {
		if (props != null)
		  props.clear();
		load();
	}

	private static FDSuiteProperties getInstance() {
		if (_instance == null) {
			_instance = new FDSuiteProperties();
		}
		return _instance;
	}

}
