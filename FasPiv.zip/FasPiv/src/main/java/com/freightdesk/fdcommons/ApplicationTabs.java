/** 
 * Copyright (c) 2000-2002 NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/ApplicationTabs.java,v 1.3.4.4 2009/10/14 19:25:26 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: ApplicationTabs.java,v $
 *  Revision 1.3.4.4  2009/10/14 19:25:26  mechevarria
 *  rename tabs
 *
 *  Revision 1.3.4.3  2009/07/09 19:34:18  mechevarria
 *  additional tab for search page
 *
 *  Revision 1.3.4.2  2009/06/24 17:58:40  mechevarria
 *  update tab values for FDfolio
 *
 *  Revision 1.3.4.1  2008/06/18 19:40:49  mechevarria
 *  merge updates from head
 *
 *  Revision 1.4  2007/07/31 09:42:14  atripathi
 *  entries added for Assets Tab.
 *
 *  Revision 1.3  2006/10/25 12:37:09  dkumar
 *  added edi tab
 *
 *  Revision 1.2  2006/08/25 14:35:22  ranand
 *  Added new Tab Conveyance
 *
 *  Revision 1.1  2006/03/29 22:05:35  ranand
 *  moved files from folio
 *
 *  Revision 1.1  2006/03/28 21:20:06  aarora
 *  Creating an fdcommons folder
 *
 *  Revision 1.3  2005/01/18 22:06:05  amrinder
 *  Minor formatting changes and one javadoc correction
 *
 *  Revision 1.2  2004/10/11 06:18:16  asingh
 *  Added CARD_TAB Constants
 *
 *  Revision 1.1  2004/09/15 13:05:24  ranand
 *  2.6 Baseline
 */

package com.freightdesk.fdcommons;

/**
 * A utility class to manage the tabs for the LCP Appliation.
 *
 * <P>
 * It encapsulates the position for each tab.  The purpose of
 * this class is that any rearrangement, addition, deletion of
 * tabs to the view should be a minimal change process.
 *
 * <P>
 * The tab constants are declared Integer instead of int, so that they
 * can be used in <code>Map</code>s, session attributes, etc.
 *
 * @author Amrinder Arora
 *
 * @see com.ntelx.nxcommons.SessionKey#CURRENT_TAB
 */

public final class ApplicationTabs
{
    /** Constants for each tab */

    /** Home tab */
    public static final Integer USERHOME = new Integer (0);
    public static final Integer COMPLIANCE = new Integer (1);
    public static final Integer SHIPMENT = new Integer (2);
    public static final Integer ANALYSIS = new Integer (3);
    public static final Integer DOCUMENT = new Integer (4);
    public static final Integer SETTLEMENT = new Integer (5);
    public static final Integer ADDRESS = new Integer (6);
    public static final Integer REPORTS = new Integer (7);
    public static final Integer TARIFF = new Integer (8);
    public static final Integer VESSELVEHICLE = new Integer (9);
    public static final Integer PLANNING = new Integer (10);
    public static final Integer ITEM = new Integer (11);
    public static final Integer EDI = new Integer (12);
    public static final Integer SETUP = new Integer (13);
    public static final Integer ASSETS = new Integer (14);
    public static final Integer SEARCH = new Integer (15);
    public static final Integer QUERY = new Integer (16);
    public static final Integer DASHBOARD = new Integer (17);
    public static final Integer REQUESTTRACKER = new Integer (18);
    public static final Integer EXPANDEDSEARCH = new Integer (19);

    /**Card Tab**/
    public static final Integer CARD_CONTROLAGENT = new Integer (0);
    public static final Integer CARD_RECURRENCE   = new Integer (1);
    public static final Integer CARD_RULE         = new Integer (2);
    public static final Integer CARD_ACTION       = new Integer (3);
    
    /**
     * Gets the application tab key
     * that is used in application resources.
     */
    public static final String getTabKey (int i)
    {
        String tabKeyRoot = "lcp.vocab.";
        if (i == 0)
            return tabKeyRoot + "home";
        if (i == 1)
            return tabKeyRoot + "cargo";
        if (i == 2)
            return tabKeyRoot + "shipment";
        if (i == 3)
            return tabKeyRoot + "analysis";
        if (i == 4)
            return tabKeyRoot + "document";
        if (i == 5)
            return tabKeyRoot + "settlement";
        if (i == 6)
            return tabKeyRoot + "address";
        if (i == 7)
            return tabKeyRoot + "reports";
        if (i == 8)
            return tabKeyRoot + "planning";
        if (i == 9)
            return tabKeyRoot + "tariff";
        if (i == 10)
            return tabKeyRoot + "setup";
        if (i == 11)
            return tabKeyRoot + "reports";
        if (i == 12)
            return tabKeyRoot + "conveyance";
        if (i == 13)
            return tabKeyRoot + "setup";
        if (i == 14)
            return tabKeyRoot + "assets";
        if (i == 15)
            return tabKeyRoot + "search";
        if (i == 16)
            return tabKeyRoot + "query";
        if (i == 17)
            return tabKeyRoot + "dashboard";
        if (i == 18)
            return tabKeyRoot + "requesttracker";
        if (i == 19)
            return tabKeyRoot + "expandedsearch";
        throw new IllegalArgumentException ("Unrecognized argument to getTabKey()");
    }

    /**
     * An overloaded utility method to get the application tab key
     * that is used in ApplicationResources.properties.
     * It delegates the message to getTabKey (int).
     *
     * @see #getTabKey(int) getTabKey
     */
    public static final String getTabKey (Integer i) {
		int tabIndex=0;
		//temporary solution added by BIJU, needed to discuss with Amrinder
		if (i!=null) {
			tabIndex = i.intValue();
		}
        return getTabKey (tabIndex);
    }
}
