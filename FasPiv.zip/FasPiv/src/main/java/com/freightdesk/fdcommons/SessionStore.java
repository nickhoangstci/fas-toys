/** 
 * Copyright (c) 2000-2002 NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/SessionStore.java,v 1.7.2.1.2.3 2009/03/10 19:41:14 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: SessionStore.java,v $
 *  Revision 1.7.2.1.2.3  2009/03/10 19:41:14  mechevarria
 *  update validation to backup reading from request if reading from cookies fails
 *
 *  Revision 1.7.2.1.2.2  2009/02/26 20:53:22  mechevarria
 *  moved to info level
 *
 *  Revision 1.7.2.1.2.1  2008/07/16 18:45:04  mechevarria
 *  merge with head to support monitor 3.8.2
 *
 *  Revision 1.15  2008/07/08 14:13:11  narora
 *  DASHBOARD_TAB_LIST key added to generalKeys collection.
 *
 *  Revision 1.14  2008/07/08 14:10:31  narora
 *  DASHBOARD_TAB_LIST key moved from FDMonitor SessionKey class.
 *
 *  Revision 1.13  2008/06/18 14:39:58  atripathi
 *  session key REQUEST_STRING added to general keys.
 *
 *  Revision 1.12  2007/11/30 08:27:12  atripathi
 *  PRODUCT_NAME session key added to general keys.
 *
 *  Revision 1.11  2007/11/23 11:29:15  atripathi
 *  MODULE_NAME general key added.
 *
 *  Revision 1.10  2007/11/21 13:39:39  atripathi
 *  VIEW_MODE considered as general key so as to avid clearing it when clearState is called.
 *
 *  Revision 1.9  2007/08/09 17:00:12  ranand
 *  added SEARCH_QUERY_MAP  to gkeys list
 *
 *  Revision 1.8  2007/04/12 16:37:02  dkumar
 *  minor change
 *
 *  Revision 1.7  2006/09/07 16:35:33  dkumar
 *  changes DISABLE_AUTOLOGOUT to KEEP_ME_LOGGED_IN
 *
 *  Revision 1.6  2006/09/07 12:03:18  dkumar
 *  added DISABLE_AUTOLOGOUT key in General Key Set
 *
 *  Revision 1.5  2006/08/17 10:22:48  dkumar
 *  removed synchronization on allSessionStores
 *
 *  Revision 1.4  2006/08/11 20:38:29  dkumar
 *  changes for common login functionality in FDSuite[ stored sessionList instead of session, synchronized all sessionStore]
 *
 *  Revision 1.3  2006/03/29 23:57:54  aarora
 *  new files into fdcommons
 *
 *  Revision 1.2  2006/03/29 22:33:46  aarora
 *  organized imports
 *
 *  Revision 1.1  2006/03/29 22:05:35  ranand
 *  moved files from folio
 *
 *  Revision 1.1  2006/03/28 21:20:06  aarora
 *  Creating an fdcommons folder
 *
 *  Revision 1.4  2005/08/25 23:28:21  amrinder
 *  Added a condition to check if the user's session expired due to user logging in from another location
 *  Added a reference back to HttpSession
 *  Added a static list of all session stores
 *  Added mechanisms to manage the session stores list
 *
 *  Revision 1.3  2004/09/15 13:03:45  ranand
 *  2.6 Baseline
 */


package com.freightdesk.fdcommons;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionBindingEvent;
import javax.servlet.http.HttpSessionBindingListener;

import org.apache.log4j.Logger;


/**
 * SessionStore is used to guard the session as a valued commodity.
 * SessionStore encapsulates a Map (but does not extend it), so you
 * can only put keys of type SessionKey in the SessionStore.
 *
 * All the objects to be stored in the Session are forced to be defined at
 * application design time, and can all be listed in the SessionKey class.
 *
 * @see com.freightdesk.common.SessionKey
 * @author Amrinder Arora
 * @author Amit Tripathi
 * @author Nipun Arora
 */
public class SessionStore implements HttpSessionBindingListener
{
    /** Collection of all active credentials.  Defined HashMap (instead of Map) 
     * for efficiency reason.  */
    protected static HashMap allSessionStores = new HashMap();

    /** A Logger */
    protected static Logger logger = Logger.getLogger("com.freightdesk.fdcommons.SessionStore");

    /** Reference to the related HttpSession */
    protected List sessionList = new ArrayList();

    /**
     * The data structure that actually holds the key value pairs
     *
     * We use a Hashtable and not a HashMap, since it is synchronized.
     */
    private Map inner = new Hashtable();

    /** A collection of general keys. */
    protected static Collection generalKeys = null;

    static {
        List gKeys = new ArrayList();
        gKeys.add(SessionKey.ACCESS_CONTROL_LIST);
        gKeys.add(SessionKey.CREDENTIALS);
        gKeys.add(SessionKey.CURRENT_TAB);
        gKeys.add(SessionKey.SESSION_STORE);
        gKeys.add(SessionKey.OBJECT_LOCK);
        generalKeys = Collections.unmodifiableList(gKeys);
    }

    /**
     * Gets an instance of the SessionStore for the given HttpSession object.
     *
     * SessionStore implements the Singleton pattern in a weaker sense.
     * Many instances of SessionStore can exist at any moment, but only one
     * instance per HttpSession.  For the first call for an HttpSession, an instance
     * of SessionStore is created.  For all further calls for the same HttpSession,
     * the same instance of SessionStore is returned.
     */
    public static SessionStore getInstance(HttpSession session)
    {
        //SessionStore sessionStore = (SessionStore) session.getAttribute(SessionKey.SESSION_STORE.getKey());
        SessionStore sessionStore = null;
        if (session != null) {
            sessionStore = (SessionStore) session.getAttribute(SessionKey.SESSION_STORE.getKey());
        }
        if (sessionStore == null) {
        	logger.debug("Session store is null, creating a new instance");
            sessionStore = new SessionStore();
            //session.setAttribute(SessionKey.SESSION_STORE.getKey(), sessionStore);
            if (session != null) {
            session.setAttribute(SessionKey.SESSION_STORE.getKey(), sessionStore);
        }
        }
        return sessionStore;
    }

    /** Sets a reference to the related HttpSession. */
    public void addSession(HttpSession sessionArg)
    {
        sessionList.add(sessionArg);
    }

    /**
     * Gets the Object mapped to the SessionKey
     */
    public Object get(SessionKey key)
    {
        return inner.get(key);
    }

    /**
     * Puts an Object mapping it to the given SessionKey
     */
    public Object put(SessionKey key, Object value)
    {
        Object removedObj = inner.put(key, value);
        if (key.equals(SessionKey.CREDENTIALS)) {
            SessionStore.addToSessionStores(this);
            if (removedObj != null) {
                logger.info("Putting a credentials and previous was not null, this is not a handled use case");
            }
        }
        return removedObj;
    }

    /**
     * Removes an Object mapped to the given SessionKey
     */
    public Object remove(SessionKey key)
    {
        return inner.remove(key);
    }

    /**
     * A convenience method to retain only the general keys.
     * General keys include CREDENTIALS, ACCESS_CONTROL_LIST,
     * CURRENT_TAB, OBJECT_LOCK and SESSION_STORE.  This method can be used
     * to trim down the session to bare minimum.
     *
     * @link com.freightdesk.common.BaseHomeAction#clearState
     */
    public void retainOnlyGeneralKeys()
    {
        logger.debug("SessionStore: retainOnlyGeneralKeys: begin");
        logger.debug("SessionStore has " + inner.keySet().size() + " keys");
        if (inner.keySet().retainAll(generalKeys)) {
            logger.debug("Now the SessionStore has only " + inner.keySet().size() + " keys");
        }

        // this loop lets us log each individual key removed.
        /*
         Iterator keys = inner.keySet().iterator();
         while (keys.hasNext()) {
         SessionKey key = (SessionKey) keys.next();
         if (!generalKeys.contains (key)) {
         logger.debug ("Removing key from the session: [" +
         key.getKey() + ", " + inner.get(key) + "]");
         keys.remove ();
         }
         }
         */
    }

    /**
     * A utility method to view the SessionStore.
     * @return A java.lang.String representation, best viewable in an HTML page.
     */
    public String toString()
    {
        StringBuffer sb = new StringBuffer("{<BR>");
        Iterator keys = inner.keySet().iterator();
        while (keys.hasNext()) {
            SessionKey key = (SessionKey) keys.next();
            sb.append(" " + key.getKey() + ": " + inner.get(key) + "<BR><BR>");
        }
        return sb.toString() + "}<BR>";
    }

    /**
     * Implementing valueBound() as defined in HttpSessionBindingListener
     */
    public void valueBound(HttpSessionBindingEvent event)
    {
        addSession(event.getSession());
        logger.debug("value bound: " + event);
    }

    /**
     * Handles the event when the corresponding HttpSession is unbound.
     * Releases all the locks held by the web user.
     *
     * Implementing valueUnbound() as defined in HttpSessionBindingListener
     */
    public void valueUnbound(HttpSessionBindingEvent event)
    {
        logger.debug("value unbound: " + event);
        HttpSession expiringSession = event.getSession();
        sessionList.remove(expiringSession);
        if (sessionList.size() == 0) {
            Credentials credentials = (Credentials) get(SessionKey.CREDENTIALS);
            if (credentials != null) {
                ObjectLock objectLock = (ObjectLock) get(SessionKey.OBJECT_LOCK);
                if (objectLock != null) {
                    objectLock.releaseAllLocksForUser(credentials.getSystemUserId());
                }
                if (allSessionStores.containsValue(this)) {
                    allSessionStores.remove(new Long(credentials.getSystemUserId()));
                }
                logger.info("Number of active sessions: " + allSessionStores.size());
            }
        }
    }

    /** Adds the specified sessionStore to all session stores.  Also checks
     * that no other session store is open for the same system user, and
     * if so, invalidates that. */
    protected static void addToSessionStores(SessionStore sessionStore)
    {
        Credentials credentials = (Credentials) (sessionStore.get(SessionKey.CREDENTIALS));
        Object o = allSessionStores.put(new Long(credentials.getSystemUserId()), sessionStore);
        logger.info("Number of active sessions: " + allSessionStores.size());
        if (o != null) {
            logger.info("A user's session expired because same user logged in from another location");
            SessionStore expiredSessionStore = (SessionStore) o;
            List expiringSessionList = expiredSessionStore.sessionList;
            for (int i = 0; i < expiringSessionList.size(); i++) {
                HttpSession tempSession = (HttpSession) expiringSessionList.get(i);
                tempSession.setAttribute("logout.reason.loggedInFromAnotherLoc", "true");
            }
        }
    }

    /** Gets the collection of all sessions that are open. */
    public static Collection getAllSessions()
    {
        return allSessionStores.values();
    }

    public static SessionStore getInstance(HttpSession session, long systemUserId)
    {
        SessionStore store = (SessionStore) allSessionStores.get(new Long(systemUserId));
        if (store == null) {
        	logger.debug("Could not find session store for user " + systemUserId);
            store = new SessionStore();
        } else {
        	logger.debug("Found session store for user " + systemUserId);
        }
        session.setAttribute(SessionKey.SESSION_STORE.getKey(), store);
        return store;
    }

    public void invalidateSessions(HttpServletRequest request)
    {
        logger.debug("invalidateSessions");
        int size = sessionList.size();
        for (int i = 0; i < size; i++) {
            while (sessionList.size() > 0) {
                ((HttpSession) sessionList.get(0)).invalidate();
                break;
            }
        }
    }


}
