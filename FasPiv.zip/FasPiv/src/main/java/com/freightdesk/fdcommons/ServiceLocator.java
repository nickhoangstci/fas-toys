/** 
 * Copyright (c) 2000-2002 NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/ServiceLocator.java,v 1.1.4.2 2010/09/22 21:04:27 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: ServiceLocator.java,v $
 *  Revision 1.1.4.2  2010/09/22 21:04:27  mechevarria
 *  merged with head
 *
 *  Revision 1.3  2010/04/26 08:39:50  Anjesh_Kumar
 *  Added a new method getRemoteObject() for ejb 3
 *
 *  Revision 1.2  2009/01/22 21:45:45  mechevarria
 *  add method to reset singleton and proper instantiation of a singleton constructor
 *
 *  Revision 1.1  2006/03/29 22:05:35  ranand
 *  moved files from folio
 *
 *  Revision 1.1  2006/03/28 21:20:06  aarora
 *  Creating an fdcommons folder
 *
 *  Revision 1.4  2005/03/16 22:46:20  amrinder
 *  Minor javadoc and formatting changes
 *
 *  Revision 1.3  2004/09/15 13:03:45  ranand
 *  2.6 Baseline
 */

package com.freightdesk.fdcommons;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import javax.ejb.EJBHome;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.rmi.PortableRemoteObject;

import org.apache.log4j.Logger;

/**
 * Serves as a central access point for all JNDI resources. Also caches the
 * resources so if the resource has been looked up once, it potentially saves a
 * call to the JNDI service.
 * 
 * @author Biju Joseph
 * @author Amrinder Arora
 */
public class ServiceLocator {

	protected InitialContext context;

	private Map cache; // used to hold references to EJBHomes/JMS Resources for
	// re-use

	private static Logger logger = Logger.getLogger("com.freightdesk.common.ServiceLocator");

	private static ServiceLocator instance;

    private ServiceLocator() throws ServiceLocatorException {
	try {
		context = new InitialContext();
		cache = Collections.synchronizedMap(new HashMap());
	} catch (NamingException ne) {
		throw new ServiceLocatorException(ne);
	} catch (Exception e) {
		throw new ServiceLocatorException(e);
	}
    }

    public static synchronized ServiceLocator getInstance() {
	if (instance == null) {
		try {
			instance = new ServiceLocator();
		} catch (ServiceLocatorException se) {
			logger.error("Exception initializing singleton.", se);
			//se.printStackTrace();
		}
	}
	return instance;
    }

    /*
     * Re-initialize singleton class.  To be called by the bootstrap
     */
    public static void reset() {
	try {
		instance = new ServiceLocator();
	} catch (ServiceLocatorException se) {
		logger.error("Exception initializing singleton.", se);
		//se.printStackTrace();
	}
    }

    /**
     * Gets the ejb Remote home factory. It caches the retrieved homes, so 
     * potentially saves a call to the JNDI service if ejb home factory has already been
     * retrieved. 
     * Clients need to cast to the type of EJBHome they desire.
     *
     * @exception ServiceLocatorException If there is a problem looking up
     * the home or if there is a naming exception (remote home not bound). 
     */
    public EJBHome getRemoteHome(String jndiHomeName, Class className) 
        throws ServiceLocatorException 
    {
        EJBHome home = null;
        try {
            if (cache.containsKey(jndiHomeName)) {
                home = (EJBHome) cache.get(jndiHomeName);
            } else {
                Object objref = context.lookup(jndiHomeName);
                Object obj = PortableRemoteObject.narrow(objref, className);
                home = (EJBHome)obj;
                cache.put(jndiHomeName, home);
            }
        } catch (NamingException ne) {
            logger.error ("Naming Exception getting home: " + jndiHomeName, ne);
            throw new ServiceLocatorException(ne);
        } catch (Exception e) {
            logger.error ("Exception getting home: " + jndiHomeName, e);
            throw new ServiceLocatorException(e);
        }
        return home;
    }
    /**
     * Create remote Object using the jndi name.
     * @param jndiName
     * @return
     */
    public Object getRemoteObject(String jndiName) throws Exception
    {
        Object remote = null;
        try {
            if(cache.containsKey(jndiName)){
                remote = cache.get(jndiName);
            }else{
                remote = context.lookup(jndiName);
                cache.put(jndiName, remote);
            }
        } catch (Exception e) {
            logger.error("Exception in getting Remote: "+jndiName,e);
            throw new ServiceLocatorException(e);
        }
        return remote;
    }
}
