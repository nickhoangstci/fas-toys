/** 
 * 
 * Copyright (c) 2000-2002 NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 *  Modification History:
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/ProjectMetaData.java,v 1.1 2006/03/29 22:05:35 ranand Exp $

 *  $Log: ProjectMetaData.java,v $
 *  Revision 1.1  2006/03/29 22:05:35  ranand
 *  moved files from folio
 *
 *  Revision 1.1  2006/03/28 21:20:06  aarora
 *  Creating an fdcommons folder
 *
 *  Revision 1.1  2005/04/15 09:06:45  ranand
 *  changed for retrieve optimization
 *
 *
 * 
 */


package com.freightdesk.fdcommons;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;


/**
 * Encapsulates all the properties of ProjectMetaData that can be set
 * differently for each deployment.
 *
 *
 * Implemented as a singleton.
 *
 * @author  Rajender Anand
 */
public class ProjectMetaData {


    /**
     * The (only) instance of this Singleton
     */
    protected static ProjectMetaData _instance;

    /**
     * The interal data structure used to store the properties
     */
    private Properties inner;


    /**
     * Gets the property using the given key
     * @param key The key for the mapping
     * @return The value corresponding to the key
     */
    public boolean isXPathIncluded (String key) {
        Boolean isInclude = new Boolean(getInstance().inner.getProperty(key));
        return isInclude.booleanValue();
    }
    
    /**
     * load the properties from the properties file.
     */
    public synchronized static void initFromProperties (InputStream inputStream) 
        throws IOException 
    {
        getInstance().inner.load(inputStream);
    }    

    /**
     * load the properties from the properties file.
     */
    public synchronized static void initFromXML () 
        throws IOException 
    {
        
    }    

    /**
     * Only constructor is declared private.
     */
    private ProjectMetaData() {
        inner = new Properties();
    }
    
    /**
     * The getInstance() method for this Singleton.
     * Creates an instance if necessary.
     */
    public static ProjectMetaData getInstance() {
        if (_instance == null) {
            _instance = new ProjectMetaData();
        }
        return _instance;
    }
}
