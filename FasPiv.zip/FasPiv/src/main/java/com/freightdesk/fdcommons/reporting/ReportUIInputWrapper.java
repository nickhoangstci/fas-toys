/** 
 * 
 * Copyright (c) 2000-2002 NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/reporting/ReportUIInputWrapper.java,v 1.1 2006/06/21 11:20:25 dkumar Exp $
 * 
 *  Modification History:
 *  $Log: ReportUIInputWrapper.java,v $
 *  Revision 1.1  2006/06/21 11:20:25  dkumar
 *  repackaging of ReportUtility to FDCommons
 *
 *  Revision 1.1  2004/09/15 13:36:28  asingh
 *  2.6 Baseline
 *
 * 
 */

package com.freightdesk.fdcommons.reporting;

/**
 * @author rajender.anand
 *
 */
public class ReportUIInputWrapper {

    private String inputType;
    private String label;


	/**
	 * Returns the inputType.
	 * @return String
	 */
	public String getInputType() {
		return inputType;
	}

	/**
	 * Returns the label.
	 * @return String
	 */
	public String getLabel() {
		return label;
	}

	/**
	 * Sets the inputType.
	 * @param inputType The inputType to set
	 */
	public void setInputType(String inputType) {
		this.inputType = inputType;
	}

	/**
	 * Sets the label.
	 * @param label The label to set
	 */
	public void setLabel(String label) {
		this.label = label;
	}

}
