/** 
 * 
 * Copyright (c) 2000-2002 NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/taglib/IfTag.java,v 1.1.2.1 2007/05/18 18:51:42 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: IfTag.java,v $
 *  Revision 1.1.2.1  2007/05/18 18:51:42  mechevarria
 *  merge with main branch
 *
 *  Revision 1.2  2007/04/12 16:34:52  dkumar
 *  licensing corrections
 *
 *  Revision 1.1  2006/07/04 15:46:57  dkumar
 *  repackaged to fdcommons
 *
 *  Revision 1.9  2006/05/27 03:19:56  aarora
 *  Removed unnecessary code, organized imports and formatted
 *
 *  Revision 1.8  2006/05/23 22:15:41  aarora
 *  Removed unused system navigation type
 *
 *  Revision 1.7  2006/05/11 22:18:46  aarora
 *  Small change as the SessionKey class has been added to com.freightdesk.fdfolio.commons
 *
 *  Revision 1.6  2006/03/28 21:23:02  aarora
 *  Repackaging of fdcommons
 *
 *  Revision 1.5  2005/07/27 09:31:30  ranand
 *  Class name changed from LcpProperties to ApplicationProperties
 *
 *  Revision 1.4  2004/09/28 10:55:19  biju
 *  removed debug statement that is printed a lot because of the heavy use of the associated tag
 *
 *  Revision 1.3  2004/09/15 13:03:45  ranand
 *  2.6 Baseline
 *
 * 
 */


package com.freightdesk.fdcommons.taglib;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.Tag;
import javax.servlet.jsp.tagext.TagSupport;

import org.apache.log4j.Logger;

import com.freightdesk.fdcommons.ApplicationProperties;
import com.freightdesk.fdcommons.LicenseProperties;

/**
 * IfTag implements a custom JSP tag that can be used to hide/show
 * JSP code based on a user's access previleges.  Multiple conditions
 * can be specified in the <code>if</code> tag for AND functionality.
 *
 * This tag should be used as follows.
 *
 * <P>
 * <B>The following scriplet code can be replaced by alternative custom tag usage.</B>
 * <FONT face="lucida console, arial" color=#660066>
 * <PRE>
 * &lt;%@ page import="com.freightdesk.common.ApplicationProperties" %&gt;
 * &lt;%
 *     String systemNavigationType = credentials.getSystemNavigationType();
 *     String product = ApplicationProperties.getProperty (LcpProperties.PRODUCT);
 *     if (systemNavigationType.equals ("Y")) {
 * %&gt;
 *         Body of HTML that should be shown if the user is of system navigation type Y
 * &lt;%
 *     }
 *
 *     if (product.equalsIgnoreCase ("LCP")) {
 * %&gt;
 *         Body of HTML that should be shown for the LCP product
 * &lt;%
 *     }
 *
 *     if ((product.equalsIgnoreCase ("AMS")) &amp;&amp; (systemNavigationType.equals ("X"))) {
 * %&gt;
 *         Body of HTML that should be shown for the AMS product and if
 *         the user is of system navigation type X
 * &lt;%
 *     }
 *
 * %&gt;
 * </PRE>
 * </FONT>
 *
 * <P>
 * <B>Equivalent custom tag usage:</B>
 * <FONT face="lucida console, arial" color=#006666>
 * <PRE>
 * &lt;app:if systemNavigation="Y"&gt;
 *         Body of HTML that should be shown if the user is of system navigation type Y
 * &lt;/app:if&gt;
 * &lt;app:if product="LCP"&gt;
 *         Body of HTML that should be shown for the LCP product
 * &lt;/app:if&gt;
 * &lt;app:if product="AMS" systemNavigation="X"&gt;
 *         Body of HTML that should be shown for the AMS product and if
 *         the user is of system navigation type X
 * &lt;/app:if&gt;
 * </PRE>
 * </FONT>
 *
 * <P>
 * Runtime Expression for the value of product tag is allowed.<BR>
 * Runtime Expression for the value of systemNavigation tag is allowed.
 *
 * @author Amrinder Arora
 */
public class IfTag extends TagSupport implements Tag
{
    /**
     * a log4j Logger
     */
    protected Logger logger = Logger.getLogger (getClass());

    /**
     * The condition on product
     */
    protected String product = null;

    /**
     * The condition on system navigation
     */
    protected String systemNavigation = null;

 	/**
	 * The condition on licensed
	 */
    protected String licensed = null;

    /**
	 * The condition on not licensed
	 */
    protected String notLicensed = null;

    /**
	 * The labelKey, needed for getting the label from the ApplicationResources file
	 * This label will be shown as the label of hyperlink associated license.html
	 */
    protected String labelKey = null;

    /**
     * Sets the permission attribute from the JSP
     */
    public void setProduct (String product) {
        this.product = product;
    }

    /**
     * Sets the systemNavigation attribute from the JSP
     */
    public void setSystemNavigation (String systemNavigation) {
        this.systemNavigation = systemNavigation;
    }

    /**
	 * Sets the licensed attribute from the JSP
	 */
	public void setLicensed (String licensed) {
		this.licensed = licensed;
	}

	/**
	 * Sets the licensed attribute from the JSP
	 */
	public void setNotLicensed (String notLicensed) {
		this.notLicensed = notLicensed;
	}


    /**
     * Processes the start of the tag.
     */
    public int doStartTag() throws JspException {
        try {

            // if a condition on product was specified
            if (product != null) {
                // if it is not the right product, skip the body
                if (!product.equalsIgnoreCase (ApplicationProperties.getProperty (ApplicationProperties.PRODUCT))) {
                    return SKIP_BODY;
                }
            }

            // if a condition on licensed was specified
			if (licensed != null) {
				// if it is not having license, skip the body
				if (! LicenseProperties.isProductLicensed(licensed)) {
					return SKIP_BODY;
				}
            }

            // if a condition on notLicensed was specified
			if (notLicensed != null) {
				// if it is having license, skip the body
				if (LicenseProperties.isProductLicensed(notLicensed)) {
					return SKIP_BODY;
				}
            }

            // Be default, we include the body.  It is possible that one of the
            // if blocks earlier has already returned skip body.
            return EVAL_BODY_INCLUDE;

        } catch (Exception ioe) {
            logger.error ("Exception while writing to client", ioe);
            throw new JspException("IOException while writing to client" + ioe.getMessage());
        }
    }
}
