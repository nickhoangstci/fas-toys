/** 
 * 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolio/util/Attic/DomainObjects.java,v 1.2.4.1 2010/08/22 23:08:34 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: DomainObjects.java,v $
 *  Revision 1.2.4.1  2010/08/22 23:08:34  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.2  2006/03/28 21:23:01  aarora
 *  Repackaging of fdcommons
 *
 *  Revision 1.1  2004/09/15 13:05:24  ranand
 *  2.6 Baseline
 *
 * 
 */

package com.freightdesk.fdcommons;

/**
 * This class describes constants for all DomainObjects
 * in the LCP application.  The Domain objects are also
 * stored in the DomainObjects table.  Each domain object represents
 * a physical entity in the Shipping Industry.
 *
 * @author Amrinder Arora
 * @author Ravi Gupta
 * @author Ajeet Sachan
 */
public class DomainObjects
{
    /**
     * A private constructor for DomainObjects, so that a public constructor 
     * is not created
     */
    private DomainObjects()
    {
        super();
    }

    /**
     * A utility method to see if the given domainobject code is recognized
     */
    public static boolean isValid (String domainObjectCode) {
        if (LcpConstants.DomainObjects.SHIPMENT.equals (domainObjectCode))
            return true;
        if (LcpConstants.DomainObjects.SHIPMENTLEG.equals (domainObjectCode))
            return true;
        if (LcpConstants.DomainObjects.PACKAGE.equals (domainObjectCode))
            return true;
        if (LcpConstants.DomainObjects.EQUIPMENT.equals (domainObjectCode))
            return true;
        if (LcpConstants.DomainObjects.ORGHIERARCHY.equals (domainObjectCode))
            return true;
        if (LcpConstants.DomainObjects.DOCUMENT.equals (domainObjectCode))
            return true;
        if (LcpConstants.DomainObjects.DOCUMENTSUBMISSION.equals (domainObjectCode))
            return true;
        if (LcpConstants.DomainObjects.ORDER.equals (domainObjectCode))
            return true;
        return false;
    }

    /**
     * A conevenience method to get the name of the domain object.
     * It is preferred to get the key using the 
     * {@link DomainObjects#getDomainObjectNameKey(String)} method
     * since the key can be used with an appropriate resource bundle.
     *
     * @return The name of the object
     */
    public static String getDomainObjectName(String argDomianObjectCode)
    {
        return getDomainObjectNameKey(argDomianObjectCode).substring(10);
    }

    /**
     * Gets the message key for the domain object.
     * This message key can be used with the resouce bundle to get
     * appropriate text for each language.
     *
     * @param int domainObjectCode
     * @return The message key for the domainObjectCode.
     */

    public static String getDomainObjectNameKey(String domainObjectCode)
    {
        if (LcpConstants.DomainObjects.SHIPMENT.equals (domainObjectCode))
            return "lcp.vocab.shipment";
        if (LcpConstants.DomainObjects.SHIPMENTLEG.equals (domainObjectCode))
            return "lcp.vocab.shipmentleg";
        if (LcpConstants.DomainObjects.PACKAGE.equals (domainObjectCode))
            return "lcp.vocab.package";
        if (LcpConstants.DomainObjects.EQUIPMENT.equals (domainObjectCode))
            return "lcp.vocab.equipment";
        if (LcpConstants.DomainObjects.ORGHIERARCHY.equals (domainObjectCode))
            return "lcp.vocab.orghierarchy";
        if (LcpConstants.DomainObjects.DOCUMENT.equals (domainObjectCode))
            return "lcp.vocab.document";
        if (LcpConstants.DomainObjects.DOCUMENTSUBMISSION.equals (domainObjectCode))
            return "lcp.vocab.documentsubmission";
        if (LcpConstants.DomainObjects.ORDER.equals (domainObjectCode))
            return "lcp.vocab.order";
        throw new RuntimeException(
            "Unknown value of document domainObjectID: " + domainObjectCode);
    }

}
