/** 
 * Copyright (c) 2000-2002 NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/InvalidUserException.java,v 1.1 2006/08/11 20:56:27 dkumar Exp $
 * 
 *  Modification History:
 *  $Log: InvalidUserException.java,v $
 *  Revision 1.1  2006/08/11 20:56:27  dkumar
 *  chages for making fdsuite struts based application
 *
 *  Revision 1.5  2006/03/28 21:23:02  aarora
 *  Repackaging of fdcommons
 *
 *  Revision 1.4  2004/12/17 00:17:14  amrinder
 *  Removed the no args constructor
 *
 *  Revision 1.3  2004/12/01 07:08:28  asaxena
 *  Changed the toString() method to return getMessage()
 *
 *  Revision 1.2  2004/10/20 04:03:47  amrinder
 *  Added some logs
 *
 *  Revision 1.1  2004/09/15 13:07:11  ranand
 *  2.6 Baseline
 */


package com.freightdesk.fdcommons;


/**
 * Thrown when the user logging into the system is not a recognized user.
 *
 * @author Nitin Gupta
 * @author Amrinder Arora 
 */
public class InvalidUserException 
    extends LcpApplicationException
{
    /**
     * Creates an instance.
     * @param exp The exception details that is passed to super 
     */
    public InvalidUserException(String exp)
    {
        super(exp);
    }

    /** Returns a String representation of the exception.
     * <B>Note: </B>This code should be changed to use the paramString pattern. */
    public String toString()
    {
        return getMessage();
    }
}

