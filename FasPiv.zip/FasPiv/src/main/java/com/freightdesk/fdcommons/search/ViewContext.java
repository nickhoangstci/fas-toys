/** 
 * Copyright (c) 2000-2002 NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/search/ViewContext.java,v 1.18 2008/05/16 10:16:58 atripathi Exp $
 * 
 *  Modification History:
 *  $Log: ViewContext.java,v $
 *  Revision 1.18  2008/05/16 10:16:58  atripathi
 *  comments added before forwardedFrom field.
 *
 *  Revision 1.17  2008/05/15 13:05:14  narora
 *  Minor comments added.
 *
 *  Revision 1.16  2008/05/14 15:14:30  narora
 *  Methods getQueryWhereClauseForSqlOr and prepareCriteriaWithSqlOr implemented.
 *
 *  Revision 1.15  2008/05/14 06:27:04  atripathi
 *  field forwardedFrom added to see how the messages are to be displayed.
 *
 *  Revision 1.14  2008/04/24 14:36:58  atripathi
 *  java docs added.
 *
 *  Revision 1.13  2008/04/23 09:14:32  atripathi
 *  fields actionName and ActionMessages instance actionMessages added.
 *
 *  Revision 1.12  2008/02/06 09:53:47  ranand
 *  changed message format
 *
 *  Revision 1.11  2008/01/22 14:57:49  atripathi
 *  some methods overloaded to work with hibernate 3.
 *
 *  Revision 1.10  2007/08/10 18:55:04  ranand
 *  removed debug statements
 *
 *  Revision 1.9  2007/08/09 17:00:40  ranand
 *  added comments
 *
 *  Revision 1.8  2007/08/07 19:51:15  ranand
 *  added new property queryContext
 *
 *  Revision 1.7  2007/07/13 19:54:27  ranand
 *  debug messages added
 *
 *  Revision 1.6  2007/06/25 15:03:23  ranand
 *  removed clear message method
 *
 *  Revision 1.5  2007/06/21 02:37:07  ranand
 *  changed for messaging
 *
 *  Revision 1.4  2007/06/18 19:44:20  ranand
 *  canged for messaging
 *
 *  Revision 1.3  2007/06/13 20:55:56  ranand
 *  major changeds
 *
 *  Revision 1.2  2007/06/11 21:29:49  ranand
 *  Added new properties
 *
 *  Revision 1.1  2007/06/06 20:52:01  ranand
 *  new files for serach Framework
 *
 *  
 */
package com.freightdesk.fdcommons.search;

import java.io.Serializable;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
//import org.apache.struts.action.ActionMessages;
import com.freightdesk.fdcommons.ActionMessages;
import org.hibernate.Criteria;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;

/**
 * class for holding user view preferences information
 * @author Rajender Anand
 * @author Amit Tripathi
 * @author Nipun Arora
 *
 */
public class ViewContext implements Serializable
{
    /**  A Logger */
    protected static Logger logger = Logger.getLogger("com.freightdesk.fdcommons.search.ViewContext");

    /* The entity type that this view context applies on.  For example, order, invoice, shipment, rule, entry, etc. */
    protected Class classType;

    private String actionName;

    /** For storing the location from where this viewContext object is forwarded   */
    private String forwardedFrom;

    /** instance for keeping all messages related to this view context instance     */
    private ActionMessages actionMessages = new ActionMessages();

    private QueryContext queryContext;

    private FilterContext filterContext;

    private SearchContext searchContext;

    private SortContext sortContext = new SortContext();

    private RangeContext rangeContext = new RangeContext();

    /** True if request is from main Tab not from Drop down or search */
    private boolean isDefault;

    /** Total Count of Records */
    private int totalCount;


    private String message;

    public ViewContext()
    {
    }


    public boolean isDefault()
    {
        return isDefault;
    }

    public void setDefault(boolean isDefault)
    {
        this.isDefault = isDefault;
    }

    public FilterContext getFilterContext()
    {
        return filterContext;
    }

    public void setFilterContext(FilterContext filterContext)
    {
        this.filterContext = filterContext;
    }

    public Class getClassType()
    {
        return classType;
    }

    public void setClassType(Class classTypeArg)
    {
        this.classType = classTypeArg;
    }

    public String getAttribute1()
    {
        return sortContext.attribute1;
    }

    public void setAttribute1(String attribute1)
    {
        sortContext.attribute1 = attribute1;
    }

    public String getAttribute2()
    {
        return sortContext.attribute2;
    }

    public void setAttribute2(String attribute2)
    {
        sortContext.attribute2 = attribute2;
    }

    public String getOrder1()
    {
        return sortContext.order1;
    }

    public void setOrder1(String order1)
    {
        sortContext.order1 = order1;
    }

    public String getOrder2()
    {
        return sortContext.order2;
    }

    public void setOrder2(String order2)
    {
        sortContext.order2 = order2;
    }

    public int getDbStartIndex()
    {
        return rangeContext.dbStartIndex;
    }

    public void setDbStartIndex(int dbStartIndex)
    {
        rangeContext.dbStartIndex = dbStartIndex;
    }

    public int getMaxResult()
    {
        return rangeContext.maxResult;
    }

    public void setMaxResult(int maxResult)
    {
        rangeContext.maxResult = maxResult;
    }

    public int getViewOffsetIndex()
    {
        return rangeContext.viewOffsetIndex;
    }

    public void setViewOffsetIndex(int viewOffsetIndex)
    {
        rangeContext.viewOffsetIndex = viewOffsetIndex;
    }


    public int getTotalCount()
    {
        return this.totalCount;
    }

    public void setTotalCount(int totalCount)
    {
        this.totalCount = totalCount;
    }


    public SearchContext getSearchContext()
    {
        return searchContext;
    }


    public void setSearchContext(SearchContext searchContext)
    {
        this.searchContext = searchContext;
    }

    /**
     * 
     * Adds Criterion using SQL Or clause to the given criteria from FilterContext.
     * 
     * @param criteria
     */
    public void prepareCriteriaWithSqlOr(Criteria criteria, List propertyMatchList)
    {
        if (propertyMatchList != null) {
            Iterator iterator = propertyMatchList.iterator();
            PropertyMatch prop1 = (PropertyMatch) iterator.next();
            Criterion cr = prop1.getCriterion();
            while (iterator.hasNext()) {
                PropertyMatch prop = (PropertyMatch) iterator.next();
                cr = Restrictions.or(cr, prop.getCriterion());
            }
            criteria.add(cr);
        }
    }

    /**
     * Overloaded method to work with Hibernate 3
     * Adds Criterion to the given criteria from FilterContext.
     * 
     * @param criteria
     */
    public void prepareCriteria(org.hibernate.Criteria criteria)
    {
        List propertyMatchList = getPropertyMatchList();
        if (propertyMatchList != null) {
            Iterator iterator = propertyMatchList.iterator();
            while (iterator.hasNext()) {
                PropertyMatch propertyMatch = (PropertyMatch) iterator.next();
                criteria.add(propertyMatch.getCriterion3());

                if (getAttribute1() != null) {
                    if (SearchConstants.ASC.equalsIgnoreCase(getOrder1()))
                        criteria.addOrder(org.hibernate.criterion.Order.asc(getAttribute1()));
                    else
                        criteria.addOrder(org.hibernate.criterion.Order.desc(getAttribute1()));
                }
            }
        }
        if (getMaxResult() != 0) {
            criteria.setFirstResult(getDbStartIndex());
            criteria.setMaxResults(getMaxResult());
        }
    }

    public List getPropertyMatchList()
    {
        if (filterContext == null) {
            return searchContext.getPropertyMatchList();
        } else {
            return filterContext.getPropertyMatchList();
        }
    }


    /**
     * 
     * creates a whereClause for the SQL query using FilterContext. 
     * 
     * @return String
     */
    public String getQueryWhereClause()
    {
        String whereClause = "";

        List propMatchList = getPropertyMatchList();
        if (propMatchList != null) {

            for (int i = 0; i < propMatchList.size(); i++) {
                PropertyMatch propertyMatch = (PropertyMatch) propMatchList.get(i);
                whereClause += propertyMatch.toString();

                if (i < (propMatchList.size() - 1)) {
                    whereClause += " AND ";
                }
            }
            logger.debug("whereClause: " + whereClause);
        }
        return whereClause;
    }

    /**
     * creates a whereClause for the SQL query using FilterContext using SQL Or clause. 
     * 
     * @return String
     */
    public String getQueryWhereClauseForSqlOr(List propMatchList)
    {
        String whereClause = "";

        if (propMatchList != null) {

            for (int i = 0; i < propMatchList.size(); i++) {
                PropertyMatch propertyMatch = (PropertyMatch) propMatchList.get(i);
                whereClause += propertyMatch.toString();

                if (i < (propMatchList.size() - 1)) {
                    whereClause += " OR ";
                }
            }
            logger.debug("getQueryWhereClauseForSqlOr(): end, whereClause: " + whereClause);
        }
        return whereClause;
    }

    /**
     * 
     * returns message string for View Context
     * 
     * @return String
     */
    public String getMessage()
    {
        logger.debug("getMessage(): begin");
        if (message == null) {
            initMessage();
        }
        logger.debug("getMessage(): end");
        return this.message;
    }


    /** Initializes the message for this view context. */
    private void initMessage()
    {
        logger.debug("initMessage(): begin");
        if (filterContext == null) {
            message = "Currently showing: " + searchContext.getMessage();
        } else {
            message = "Currently showing: \"" + filterContext.getMessage() + "\"";
        }
        logger.debug("initMessage(): end");
    }


    /**
     * 
     * Encapsulates SortContext Properties
     * 
     * @author Rajender Anand
     *
     */
    class SortContext implements Serializable
    {
        public String attribute1;

        public String order1;

        public String attribute2;

        public String order2;
    }


    /**
     * 
     * Encapsulates RangeContext Properties
     * 
     * @author Rajender Anand
     *
     */
    class RangeContext implements Serializable
    {
        public int dbStartIndex;

        public int maxResult;

        public int viewOffsetIndex;

        public String toString()
        {
            return "dbstart: " + dbStartIndex + " maxResult:  " + maxResult + " viewOffsetIndex: " + viewOffsetIndex;
        }
    }


    /**
     * @return the queryContext
     */
    public QueryContext getQueryContext()
    {
        return queryContext;
    }


    /**
     * @param queryContext the queryContext to set
     */
    public void setQueryContext(QueryContext queryContext)
    {
        this.queryContext = queryContext;
    }


    public String getActionName()
    {
        return actionName;
    }


    public void setActionName(String actionName)
    {
        this.actionName = actionName;
    }

    /**
     * gets action messages instance for this instance
     * can be used in storing more than one action message instance.
     * @return
     */
    public ActionMessages getActionMessages()
    {
        return actionMessages;
    }


    public String getForwardedFrom()
    {
        return forwardedFrom;
    }


    public void setForwardedFrom(String forwardedFrom)
    {
        this.forwardedFrom = forwardedFrom;
    }
}
