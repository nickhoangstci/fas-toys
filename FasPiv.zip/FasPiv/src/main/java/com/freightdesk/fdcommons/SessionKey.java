/** 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/SessionKey.java,v 1.11.4.2 2008/07/16 18:45:04 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: SessionKey.java,v $
 *  Revision 1.11.4.2  2008/07/16 18:45:04  mechevarria
 *  merge with head to support monitor 3.8.2
 *
 *  Revision 1.21  2008/07/08 14:11:05  narora
 *  DASHBOARD_TAB_LIST key moved from FDMonitor SessionKey class.
 *
 *  Revision 1.20  2008/06/18 14:40:51  atripathi
 *  REQUEST_STRING added For logging execution time of requests.
 *
 *  Revision 1.19  2007/11/30 08:26:36  atripathi
 *  PRODUCT_NAME session key added.
 *
 *  Revision 1.18  2007/11/23 11:29:15  atripathi
 *  MODULE_NAME general key added.
 *
 *  Revision 1.17  2007/11/21 13:38:53  atripathi
 *  new key VIEW_MODE added.
 *
 *  Revision 1.16  2007/07/30 23:24:06  ranand
 *  added new sessionkey for search query
 *
 *  Revision 1.15  2007/07/03 11:31:32  atripathi
 *  new session key HINT_QUESTION_LIST added.
 *
 *  Revision 1.14  2007/06/30 06:09:07  atripathi
 *  new session key USER_ID for password task.
 *
 *  Revision 1.13  2007/06/06 20:53:52  ranand
 *  Added new key for View Context
 *
 *  Revision 1.12  2007/06/06 11:51:14  atripathi
 *  NAVIGATION_SEARCH_QUERY added
 *
 *  Revision 1.11  2007/02/21 11:27:46  nsehra
 *  new key added for 'EDIHOME'
 *
 *  Revision 1.10  2006/09/07 16:35:09  dkumar
 *  changes DISABLE_AUTOLOGOUT to KEEP_ME_LOGGED_IN
 *
 *  Revision 1.9  2006/09/07 12:01:48  dkumar
 *  added DISABLE_AUTOLOGOUT key for disabling auto log out feature when
 *  using FDSUITE_COOKIE ( using keep me logged in check box)
 *
 *  Revision 1.8  2006/08/21 10:55:51  dkumar
 *  rooled back to version 1.6 ( removed  AUDIT_HOME_ADVANCESEARCH_CLAUSE key)
 *
 *  Revision 1.7  2006/08/21 09:55:13  dkumar
 *  added AUDIT_HOME_ADVANCESEARCH_CLAUSE
 *
 *  Revision 1.6  2006/05/27 03:17:50  aarora
 *  Removed all FDfolio session keys from commons
 *
 *  Revision 1.5  2006/05/25 08:00:51  nsehra
 *  oved FDMonitor key to SessionKey class in FDMonitor
 *
 *  Revision 1.4  2006/05/08 15:01:52  ranand
 *  added sessionkey DUPLICATE_ORDER_LINE_ITEM
 *
 *  Revision 1.3  2006/05/03 03:43:36  aarora
 *  Changed the class so it is no longer final, and changed constructor from private to protected
 *
 *  Revision 1.2  2006/04/26 06:53:58  dkumar
 *  Added Key DOCUMENTHOME_INVOKED_FROM
 *
 *  Revision 1.1  2006/03/29 22:05:35  ranand
 *  moved files from folio
 *
 *  Revision 1.1  2006/03/28 21:20:06  aarora
 *  Creating an fdcommons folder
 *
 *  Revision 1.27  2006/03/10 20:40:08  ranand
 *  no message
 *
 *  Revision 1.26  2006/03/10 20:28:09  ranand
 *  adde new key for auditor
 *
 *  Revision 1.25  2006/03/10 11:12:55  nsehra
 *  key added
 *
 *  Revision 1.24  2006/03/09 23:48:23  ranand
 *  new keys added
 *
 *  Revision 1.23  2005/10/20 10:44:01  nsehra
 *  key added for user shipment
 *
 *  Revision 1.22  2005/10/05 12:02:25  nsehra
 *  dashboard tile configuration
 *
 *  Revision 1.21  2005/09/28 08:35:54  ranand
 *  Code clean up of Address Module
 *
 *  Revision 1.20  2005/08/30 02:15:10  amrinder
 *  Added a Session key for ORG_ROLE
 *
 *  Revision 1.19  2005/08/29 07:38:22  ranand
 *  added session keys for routing
 *
 *  Revision 1.18  2005/08/24 08:48:55  ranand
 *  changed to select routing template without rate calculation for Shipment
 *
 *  Revision 1.17  2005/08/23 05:50:20  ranand
 *  attach an existing shipment to order  using lookup
 *
 *  Revision 1.16  2005/07/12 14:51:58  nsehra
 *  order id added
 *
 *  Revision 1.15  2005/07/12 12:23:43  ranand
 *  added a key for Item Stateful Bean
 *
 *  Revision 1.14  2005/04/21 09:47:32  nsehra
 *  invoice item count for settelment home page
 *
 *  Revision 1.13  2005/04/14 09:09:58  nsehra
 *  no message
 *
 *  Revision 1.12  2005/04/11 20:41:18  nsehra
 *  no message
 *
 *  Revision 1.11  2005/04/01 09:58:10  ranand
 *  Intelliagent enhancements
 *
 *  Revision 1.10  2005/03/29 11:43:55  ranand
 *  intelliagent enhancements
 *
 *  Revision 1.9  2005/02/28 06:43:36  ranand
 *  changes for adding Lookup in Card WorkFlow page
 *
 *  Revision 1.8  2005/01/14 14:48:19  ajena
 *  Added new Key SHIPMENT_TOTAL_COUNT   AND SHIPMENT_START_INDEX
 *
 *  Revision 1.7  2004/12/07 12:50:12  ranand
 *  Changed for standard Paging
 *
 *  Revision 1.6  2004/10/11 06:17:21  asingh
 *  Added CURRENT_CARD_TAB Session Key
 *
 *  Revision 1.5  2004/10/07 07:00:12  ranand
 *  adde a new key  ARCHIVED_INVOICES
 *
 *  Revision 1.4  2004/09/22 10:29:23  asaxena
 *  added key ADVANCED_SEARCH_FILTER
 *
 *  Revision 1.3  2004/09/15 13:03:45  ranand
 *  2.6 Baseline
 */

package com.freightdesk.fdcommons;

/**
 * SessionKey class encapsulates a key that can be stored in a SessionStore.
 * It declares a private constructor, so only declared static attributes can be
 * used to get instances of SessionKey objects.
 *
 * @author Mike Echevarria
 */
public class SessionKey
{
    
    // Keys for shipment home
    public static final SessionKey SHIPMENT_LIST = new SessionKey("SHIPMENT_LIST");
    public static final SessionKey SHIPMENT_TYPE = new SessionKey("SHIPMENT_TYPE");
    public static final SessionKey TEMP_SHIPMENT_TYPE = new SessionKey("TEMP_SHIPMENT_TYPE");
    public static final SessionKey SHIPMENT_STATUS = new SessionKey("SHIPMENT_STATUS");
    public static final SessionKey SHIPMENTHOME_INVOKED_FROM = new SessionKey("SHIPMENTHOME_INVOKED_FROM");
    public static final SessionKey INVOICE_SHIPMENTID = new SessionKey("INVOICE_SHIPMENTID");
    public static final SessionKey SHIPMENT_TOTAL_COUNT = new SessionKey("SHIPMENT_TOTAL_COUNT");
    public static final SessionKey SHIPMENT_START_INDEX = new SessionKey("SHIPMENT_START_INDEX"); // used for paging
    public static final SessionKey USER_SHIPMENT = new SessionKey("USER_SHIPMENT"); // used for paging
	public static final SessionKey SEARCH_PROCESS = new SessionKey("SEARCH_PROCESS");
	
    // These keys will be retained as long as the user is in session
    public static final SessionKey ACCESS_CONTROL_LIST = new SessionKey("ACCESS_CONTROL_LIST");


    public static final SessionKey CREDENTIALS = new SessionKey("CREDENTIALS");

    public static final SessionKey PASSWORD_UPDATED = new SessionKey("PASSWORD_UPDATED");
    
    public static final SessionKey CURRENT_TAB = new SessionKey("CURRENT_TAB");

    public static final SessionKey SESSION_STORE = new SessionKey("SESSION_STORE");

    public static final SessionKey OBJECT_LOCK = new SessionKey("OBJECT_LOCK");
    
    // These keys may or may not be retained when user moves between different modules
    public static final SessionKey CHECK_DELETE_ITEM = new SessionKey("CHECK_DELETE_ITEM");

    public static final SessionKey INDEX = new SessionKey("INDEX");

    public static final SessionKey START_INDEX = new SessionKey("START_INDEX"); // used for paging
    public static final SessionKey DE_START_INDEX = new SessionKey("DE_START_INDEX");
    public static final SessionKey TOTAL_COUNT = new SessionKey("TOTAL_COUNT"); // Total records in rate for paging
    public static final SessionKey DE_TOTAL_COUNT = new SessionKey("DE_TOTAL_COUNT");
    public static final SessionKey CCSF_DIR_EMP_START_INDEX = new SessionKey("CCSF_DIR_EMP_START_INDEX");
	public static final SessionKey CCSF_AG_EMP_START_INDEX = new SessionKey("CCSF_AG_EMP_START_INDEX");
    public static final SessionKey ADVANCE_SEARCH_QUERY = new SessionKey("ADVANCE_SEARCH_QUERY");

    public static final SessionKey SEARCH_STR = new SessionKey("SEARCH_STR");

    public static final SessionKey SEARCH_FILTER = new SessionKey("SEARCH_FILTER");

    public static final SessionKey CURRENT_CARD_TAB = new SessionKey("CURRENT_CARD_TAB");

    public static final SessionKey HOME_PAGING_OFFSET = new SessionKey("HOME_PAGING_OFFSET");

    // Keys added for Home Page of each tabs
    public static final SessionKey STACK = new SessionKey("STACK");

    public static final SessionKey IS_FORWARDED = new SessionKey("IS_FORWARDED");

    public static final SessionKey TYPE_OF_SORT = new SessionKey("TYPE_OF_SORT");

    public static final SessionKey PAGE_INDEX = new SessionKey("PAGE_INDEX");

    public static final SessionKey CANCEL_SEARCH = new SessionKey("CANCEL_SEARCH");

    public static final SessionKey OFFSET = new SessionKey("OFFSET");

    public static final SessionKey DETAIL_OFFSET = new SessionKey("DETAIL_OFFSET");

    // Keys added for shipment details
    public static final SessionKey HASH_ASSIGNED_LIST = new SessionKey("HASH_ASSIGNED_LIST");

    public static final SessionKey SHIPMENT_DETAILS = new SessionKey("SHIPMENT_DETAILS");

    // Keys added for Users List
    public static final SessionKey USER_LIST = new SessionKey("USER_LIST");

    public static final SessionKey USER_MODEL = new SessionKey("USER_MODEL");

    public static final SessionKey USER_CONTACT_MODEL = new SessionKey("USER_CONTACT_MODEL");

    public static final SessionKey USER_ADDRESS = new SessionKey("USER_ADDRESS");
    
    // Keys added for Password Reset
    public static final SessionKey USER_ID = new SessionKey("USER_ID");

    // Keys added for Reports
    public static final SessionKey REPORT_MAP = new SessionKey("REPORT_MAP");

    // Keys added for Address
    public static final SessionKey ADDRESS_TYPE = new SessionKey("ADDRESS_TYPE");

    public static final SessionKey ADVANCE_SEARCH = new SessionKey("ADVANCE_SEARCH");

    public static final SessionKey ORG_ROLE = new SessionKey("ORG_ROLE");


    /** Required for Dahsborad for returning control to callee page*/
    public static final SessionKey INVOKED_FROM = new SessionKey("INVOKED_FROM");
    
    // Event home
    public static final SessionKey START_DATE = new SessionKey("START_DATE");
    public static final SessionKey END_DATE = new SessionKey("END_DATE");
    public static final SessionKey SEARCH_TXT = new SessionKey("SEARCH_TXT");
    public static final SessionKey SEARCH_CERT = new SessionKey("SEARCH_CERT");
    
    // Event
    public static final SessionKey EVENT_LIST = new SessionKey("EVENT_LIST");
    public static final SessionKey EVENT_TYPE = new SessionKey("EVENT_TYPE");
    public static final SessionKey EVENT_INDEX = new SessionKey("EVENT_INDEX");//indexEventView
    public static final SessionKey EVENT_MODEL = new SessionKey("EVENT_MODEL");
    public static final SessionKey EVENT_LOCATION = new SessionKey("EVENT_LOCATION");
    public static final SessionKey EVENT_VIEW_FROM = new SessionKey("EVENT_VIEW_FROM");
    public static final SessionKey INVOLVEDPARTY_INVOKED_FROM = new SessionKey("INVOLVEDPARTY_INVOKED_FROM");
    public static final SessionKey EVENT_INVOKED_FROM = new SessionKey("EVENT_INVOKED_FROM");
    public static final SessionKey EVENT_ID = new SessionKey("EVENT_ID");
    public static final SessionKey EVENT_ACTION = new SessionKey("EVENT_ACTION");
    
    // Session key for Org
    public static final SessionKey PARENT_ORGID = new SessionKey("PARENT_ORGID");
    public static final SessionKey ORGHIERARCHY_TYPES = new SessionKey("ORGHIERARCHY_TYPES");
    public static final SessionKey LOCATION_MODEL = new SessionKey("LOCATION_MODEL");
    public static final SessionKey CONTACT_MODEL = new SessionKey("CONTACT_MODEL");
    public static final SessionKey LOOKUP_FROM = new SessionKey("LOOKUP_FROM");
    public static final SessionKey LOOKUP_FOR_SHIP = new SessionKey("LOOKUP_FOR_SHIP");
    public static final SessionKey CONTACT_INDEX = new SessionKey("CONTACT_INDEX");
    public static final SessionKey LOCATION_INDEX = new SessionKey("LOCATION_INDEX");
    public static final SessionKey ORGHIERARCHY_MODEL = new SessionKey("ORGHIERARCHY_MODEL");
    public static final SessionKey ORGID = new SessionKey("ORGID");
    
    public static final SessionKey ORGANIZATION_LIST = new SessionKey("ORGANIZATION_LIST");
    public static final SessionKey CCSF_LIST = new SessionKey("CCSF_LIST");
    public static final SessionKey CCSF_LIST_JSON_STR = new SessionKey("CCSF_LIST_JSON_STR");
    public static final SessionKey CCSF_LIST_DETAIL_REC = new SessionKey("CCSF_LIST_DETAIL_REC");
    public static final SessionKey IAC_LIST = new SessionKey("IAC_LIST");
    public static final SessionKey IAC_LIST_JSON_STR = new SessionKey("IAC_LIST_JSON_STR");
    public static final SessionKey CCSF_DIR_EMP_MAP = new SessionKey("CCSF_DIR_EMP_MAP");
    public static final SessionKey CCSF_AG_EMP_MAP = new SessionKey("CCSF_AG_EMP_MAP");
    public static final SessionKey CCSF_FAC_CONT_MAP = new SessionKey("CCSF_FAC_CONT_MAP");
    public static final SessionKey CCSF_FAC_CERT_MAP = new SessionKey("CCSF_FAC_CERT_MAP");
    public static final SessionKey CCSF_APP_DET_MAP = new SessionKey("CCSF_APP_DET_MAP");
    public static final SessionKey CCSF_AMM_DET_MAP = new SessionKey("CCSF_AMM_DET_MAP");
    public static final SessionKey SHIPPER_NOTES_MAP = new SessionKey("SHIPPER_NOTES_MAP");
    public static final SessionKey SHIPPER_DET_MAP = new SessionKey("SHIPPER_DET_MAP");
    public static final SessionKey SHIPPER_ORG_MAP = new SessionKey("SHIPPER_ORG_MAP");
    public static final SessionKey DETAIL_PAGE_IAC_LIST = new SessionKey("DETAIL_PAGE_IAC_LIST");
	
    public static final SessionKey DETAIL_PAGE_SUB_COMP_LIST = 
        new SessionKey("DETAIL_PAGE_SUB_COMP_LIST");
    public static final SessionKey DETAIL_PAGE_SUB_COMP_STATION_LIST = 
        new SessionKey("DETAIL_PAGE_SUB_COMP_STATION_LIST");
    public static final SessionKey DETAIL_PAGE_SUB_COMP_AC_SECCONTACT_LIST = 
        new SessionKey("DETAIL_PAGE_SUB_COMP_AC_SECCONTACT_LIST");
    public static final SessionKey DETAIL_PAGE_SUB_COMP_AC_STA_LIST = 
	    new SessionKey("DETAIL_PAGE_SUB_COMP_AC_STA_LIST");
    public static final SessionKey DETAIL_PAGE_SUB_COMP_AG_DETAIL_LIST = 
        new SessionKey("DETAIL_PAGE_SUB_COMP_AG_DETAIL_LIST");		
    public static final SessionKey DETAIL_PAGE_SUB_COMP_AG_CONT_LIST = 
        new SessionKey("DETAIL_PAGE_SUB_COMP_AG_CONT_LIST");
    public static final SessionKey DETAIL_PAGE_SUB_COMP_AG_ASSO_IAC_LIST = 
	new SessionKey("DETAIL_PAGE_SUB_COMP_AG_ASSO_IAC_LIST");
    public static final SessionKey DETAIL_PAGE_SUB_COMP_AG_STA_LIST = 
	new SessionKey("DETAIL_PAGE_SUB_COMP_AG_STA_LIST");		
    		
	public static final SessionKey DETAIL_PAGE_SEC_CORD_MAP = 
		new SessionKey("DETAIL_PAGE_SEC_CORD_MAP");
	public static final SessionKey DETAIL_PAGE_PRINCIPLE_CORD_MAP = 
		new SessionKey("DETAIL_PAGE_PRINCIPLE_CORD_MAP");
	public static final SessionKey DETAIL_PAGE_STATION_MAP = 
		new SessionKey("DETAIL_DETAIL_PAGE_STATION_MAP");
	public static final SessionKey DETAIL_PAGE_AGENT_MAP = 
		new SessionKey("DETAIL_PAGE_AGENT_MAP");
	public static final SessionKey DETAIL_PAGE_SUB_IND_AGENT_MAP = 
		new SessionKey("DETAIL_PAGE_SUB_IND_AGENT_MAP");	
	public static final SessionKey DETAIL_PAGE_AGENT_EMP_MAP = 
		new SessionKey("DETAIL_PAGE_AGENT_EMP_MAP");
	public static final SessionKey DETAIL_PAGE_DIR_EMP_MAP = 
		new SessionKey("DETAIL_PAGE_DIR_EMP_MAP");
	public static final SessionKey DETAIL_PAGE_CCSF_DIR_EMP_MAP = 
		new SessionKey("DETAIL_PAGE_CCSF_DIR_EMP_MAP");		
	public static final SessionKey DETAIL_PAGE_SUBJECTINDIVIDUAL_LIST = 
	    new SessionKey("DETAIL_PAGE_SUBJECTINDIVIDUAL_LIST");
	public static final SessionKey DETAIL_PAGE_RESIDENT_PHYSICAL_MAP = 
		new SessionKey("DETAIL_PAGE_RESIDENT_PHYSICAL_MAP");
	public static final SessionKey DETAIL_PAGE_IAC_NUMBER_MAP = 
		new SessionKey("DETAIL_PAGE_IAC_NUMBER_MAP");
	public static final SessionKey DETAIL_PAGE_PHYSICAL_AGENT_MAP = 
		new SessionKey("DETAIL_PAGE_PHYSICAL_AGENT_MAP");
	public static final SessionKey DETAIL_PAGE_AC_NUMBER_MAP = 
		new SessionKey("DETAIL_PAGE_AC_NUMBER_MAP");
	public static final SessionKey DETAIL_PAGE_PERSONAL_MAP = 
		new SessionKey("DETAIL_PAGE_PERSONAL_MAP");
	public static final SessionKey DETAIL_PAGE_CITIZENSHIP_MAP = 
		new SessionKey("DETAIL_PAGE_CITIZENSHIP_MAP");
	
    public static final SessionKey Shipper_LIST = new SessionKey("Shipper_LIST");
	public static final SessionKey SubjectCompany_LIST = new SessionKey("SubjectCompany_LIST");
	public static final SessionKey SubjectIndividual_LIST = new SessionKey("SubjectIndividual_LIST");
    public static final SessionKey DIRECT_EMP_LIST = new SessionKey("DIRECT_EMP_LIST");
    public static final SessionKey RESULT_PER_PAGE = new SessionKey("RESULT_PER_PAGE");
	public static final SessionKey RESULT_PER_PAGE_SUB_IND_AGENT_MAP = new SessionKey("RESULT_PER_PAGE_SUB_IND_AGENT_MAP");
	public static final SessionKey RESULT_PER_PAGE_IAC = new SessionKey("RESULT_PER_PAGE_IAC");
	public static final SessionKey RESULT_PER_PAGE_SUB_IND = new SessionKey("RESULT_PER_PAGE_SUB_IND");
	public static final SessionKey RESULT_PER_PAGE_CCSF = new SessionKey("RESULT_PER_PAGE_CCSF");
	public static final SessionKey RESULT_PER_PAGE_SHIPPER = new SessionKey("RESULT_PER_PAGE_SHIPPER");
	public static final SessionKey RESULT_PER_PAGE_SUB_COMP = new SessionKey("RESULT_PER_PAGE_SUB_COMP");
	public static final SessionKey RESULT_PER_PAGE_IAC_DET_AGENT = new SessionKey("RESULT_PER_PAGE_IAC_DET_AGENT");
	public static final SessionKey RESULT_PER_PAGE_CCSF_DET_DIR_EMP = new SessionKey("RESULT_PER_PAGE_CCSF_DET_DIR_EMP");
	public static final SessionKey RESULT_PER_PAGE_CCSF_DET_AG_EMP = new SessionKey("RESULT_PER_PAGE_CCSF_DET_AG_EMP");
    
    // Keys added for involved party
    public static final SessionKey INVOLVEDPARTY_ADDRESS_DETAILS = new SessionKey("INVOLVEDPARTY_ADDRESS_DETAILS");
    public static final SessionKey INVOLVEDPARTY_INDEX = new SessionKey("INVOLVEDPARTY_INDEX");
    public static final SessionKey INVOLVEDPARTY_LIST = new SessionKey("INVOLVEDPARTY_LIST");
    public static final SessionKey INVOLVEDPARTY_MODEL = new SessionKey("INVOLVEDPARTY_MODEL");
    public static final SessionKey CARRIER_LIST        = new SessionKey("CARRIER_LIST");
    
    // Keys added for query tool
    public static final SessionKey QUERY_MODEL = new SessionKey("QUERY_MODEL");

    /**
     * The only constructor is declared private.  No instances can be created other than
     * the ones created from static attributes.
     */
    protected SessionKey(String key)
    {
        _key = key;
    }

    /**
     * Gets the hashcode so that the SessionKey can be used with HashMaps.
     *
     * @return The hashcode of this SessionKey object.
     */
    public int hashCode()
    {
        return _key.hashCode();
    }

    /**
     * Gets the key of the SessionKey
     */
    public String getKey()
    {
        return _key;
    }

    private String _key = null;
}
