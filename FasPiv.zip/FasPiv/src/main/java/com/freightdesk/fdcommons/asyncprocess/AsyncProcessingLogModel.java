/** 
* Copyright (c) 2000-2002 NTELX 
*  All rights reserved. 
* 
* This software is the confidential and proprietary information of NTELX 
* ("Confidential Information").  You shall not disclose such Confidential Information 
* and shall use it only in accordance with the terms of the license agreement you entered 
* into with NTELX. 
* 
* 
*  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/asyncprocess/AsyncProcessingLogModel.java,v 1.1.4.3 2010/03/15 13:47:09 mechevarria Exp $ 
* 
*  Modification History:
*  $Log: AsyncProcessingLogModel.java,v $
*  Revision 1.1.4.3  2010/03/15 13:47:09  mechevarria
*  add ipAddress
*
*  Revision 1.1.4.2  2008/12/11 13:50:44  mechevarria
*  brought over from head
*
*  Revision 1.2  2008/05/16 11:16:06  ranand
*  added new property in AsyncProcessLogModel
*
*  Revision 1.1  2007/03/02 10:11:40  dkumar
*  Classes For Time Consuming Asynchronous Requests
*
*  Revision 1.1  2007/02/27 16:31:46  dkumar
*  Asynchronous processing for time consuming task functionality
*
*/
/**
 * Copyright (c) 2000-2002 NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 */
package com.freightdesk.fdcommons.asyncprocess;

import java.sql.Timestamp;
import com.freightdesk.fdcommons.BaseModel;



/**
 * @author Deepak Kumar
 *
 */
public class AsyncProcessingLogModel extends BaseModel
{
    public static final String STATUS_SUCCESS = "COMPLETED";
    public static final String STATUS_FAILED = "FAILED";
    public static final String STATUS_INPROCESS = "IN PROCESS";
    
    private long asyncProcessingLogId ;
    
    private String description;
    
    private String moduleName;
    
    private String feedBack;
    
    private String GUID;
    
    private String ipAddress;
    
    // non-persistence properties.
    private int totalCount;
    
    private int execRecordCount;
    
    private String browser;
    
    private double browserVersion;
    
    public void init(String user, String dom, String desc, String mod, String feed, String ip) {
    	Timestamp initTimestamp = new Timestamp(System.currentTimeMillis());
    	createTimestamp = initTimestamp;
    	lastUpdateTimestamp = initTimestamp;
    	lastUpdateUserId = user;
    	createUserId = user;
    	domainName = dom;
    	description = desc;
    	moduleName = mod;
    	feedBack = feed;
    	ipAddress = ip;
    	status = STATUS_INPROCESS;
    }
    
    public void complete(String newFeedBack, boolean newStatus) {
    	feedBack = newFeedBack;
    	if (newStatus == true) {
    		status = STATUS_SUCCESS;
    	}
    	else {
    		status = STATUS_FAILED;
    	}
    	lastUpdateTimestamp = new Timestamp(System.currentTimeMillis());
    }
    

    public String getBrowser() {
    	if(browser == null)
    		return "";
		return browser;
	}

	public void setBrowser(String browser) {
		this.browser = browser;
	}

	public double getBrowserVersion() {
		return browserVersion;
	}

	public void setBrowserVersion(double browserVersion) {
		this.browserVersion = browserVersion;
	}

	public String getIpAddress() {
		return ipAddress;
	}

	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	public long getPrimaryKey()
    {
        return asyncProcessingLogId;
    }



    public long getAsyncProcessingLogId()
    {
        return asyncProcessingLogId;
    }



    public void setAsyncProcessingLogId(long asyncProcessingLogId)
    {
        this.asyncProcessingLogId = asyncProcessingLogId;
    }



    public String getDescription()
    {
        return description;
    }



    public void setDescription(String description)
    {
        this.description = description;
    }



    public String getFeedBack()
    {
        return feedBack;
    }



    public void setFeedBack(String feedBack)
    {
        this.feedBack = feedBack;
    }



    public String getModuleName()
    {
        return moduleName;
    }



    public void setModuleName(String moduleName)
    {
        this.moduleName = moduleName;
    }

    /**
     * @return Returns the execRecordCount.
     */
    public int getExecRecordCount()
    {
        return execRecordCount;
    }
    /**
     * @param execRecordCount The execRecordCount to set.
     */
    public void setExecRecordCount(int execRecordCount)
    {
        this.execRecordCount = execRecordCount;
    }
    /**
     * @return Returns the gUID.
     */
    public String getGUID()
    {
        return GUID;
    }
    /**
     * @param guid The gUID to set.
     */
    public void setGUID(String guid)
    {
        GUID = guid;
    }
    /**
     * @return Returns the totalCount.
     */
    public int getTotalCount()
    {
        return totalCount;
    }
    /**
     * @param totalCount The totalCount to set.
     */
    public void setTotalCount(int totalCount)
    {
        this.totalCount = totalCount;
    }
}
