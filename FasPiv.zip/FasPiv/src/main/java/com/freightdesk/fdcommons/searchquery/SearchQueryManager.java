/**
 * Copyright (c) 2000-2002 NTELX
 *  All rights reserved. 
 *
 * This software is the confidential and proprietary information of NTELX
 * ("Confidential Information").  You shall not disclose such Confidential Information
 * and shall use it only in accordance with the terms of the license agreement you entered
 * into with NTELX. 
 *
 *
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/searchquery/SearchQueryManager.java,v 1.5 2008/01/07 12:52:56 ranand Exp $
 *
 *  Modification History:
 *  $Log: SearchQueryManager.java,v $
 *  Revision 1.5  2008/01/07 12:52:56  ranand
 *  changed  getParamvalue method to static
 *
 *  Revision 1.4  2007/08/10 18:52:56  ranand
 *  Used Transaction to save query and moved methods from RulesAdvancesearch
 *
 *  Revision 1.3  2007/08/09 16:59:50  ranand
 *  added new method
 *
 *  Revision 1.2  2007/08/07 19:53:11  ranand
 *  SearchQueryModel
 *
 *  Revision 1.1  2007/07/30 23:25:11  ranand
 *  Added for save Search Query framework
 *
 */


package com.freightdesk.fdcommons.searchquery;

import java.util.ArrayList;
import java.util.List;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.transaction.UserTransaction;

import org.apache.log4j.Logger;

import com.freightdesk.fdcommons.Credentials;


public class SearchQueryManager
{
    /** An Instance of SearchQueryDao */
    private SearchQueryDao searchQueryDao = new SearchQueryDao();
    
    /** Initial Context */
    private InitialContext ic = null;
    
    /** A Logger */
    private Logger logger = Logger.getLogger("com.freightdesk.fdcommons.searchquery.SearchQueryManager"); 
    
    
    public SearchQueryManager()
    {
        try {
            ic = new InitialContext();
        } catch(NamingException nex) {
            
            throw new RuntimeException("Naming exception in SearchQueryManager() while creating InitialContext ", nex);
        }
    } 
    /**
     * 
     * saves query.
     * 
     * @param name
     * @param query
     * @param objectType
     * @param credentials
     */
    public SearchQueryModel saveQuery(String name, String query, String countQuery, String objectType, List params, Credentials credentials)
        throws Exception
    {
        logger.debug("saveQuery(): begin");
        SearchQueryModel searchQueryModel = getSearchQueryModel(name, query, countQuery, objectType, params, credentials);
        UserTransaction transaction = null;
        try {
            transaction = (UserTransaction)ic.lookup("java:comp/UserTransaction");
            transaction.begin();
            searchQueryDao.createSearchQuery(searchQueryModel);
            transaction.commit();
            logger.debug("saveQuery(): end");
            
        } catch(Exception e ) {
            transaction.rollback();
            logger.error("Exception in saveQuery(): ", e);
            throw e;
        }        
        return searchQueryModel;

    }

    /**
     * 
     * creaete SearchQueryModel
     * 
     * @param name
     * @param query
     * @param countQuery
     * @param objectType
     * @param credentials
     * @return
     */
    private SearchQueryModel getSearchQueryModel(String name, String query, String countQuery, String objectType, List params, Credentials credentials)
    {
        logger.debug("getSearchQueryModel(): begin");
        SearchQueryModel searchQueryModel = new SearchQueryModel();
        searchQueryModel.setName(name);
        searchQueryModel.setObjectType(objectType);
        searchQueryModel.setQuery(query);
        searchQueryModel.setCountQuery(countQuery);
        searchQueryModel.setBaseProperties(credentials);
        
        searchQueryModel.setQueryParam(params);
        logger.debug("getSearchQueryModel(): end");
        
        return searchQueryModel;
    }
    
    /**
     * 
     * Creates List of SearchQueryParam  from the given List of paramValues
     * 
     * @param strparamValues
     * @return
     */
    public List getQueryParamList(List strparamValues, Credentials credentials)
    {
        logger.debug("getQueryParamList(): begin");
        List queryParamList = new ArrayList();
        
        int index = 0;
        for(int i = 0; i < strparamValues.size(); i++) {
            index = i+1;  // incrementing the index for sequence used in Prepared Statement. 
            String value = (String) strparamValues.get(i);
            SearchQueryParam queryParam = new SearchQueryParam();
            queryParam.setBaseProperties(credentials);
            queryParam.setParamValue(value);
            queryParam.setSequence(index);
            queryParamList.add(queryParam);
        }
        logger.debug("getQueryParamList(): end");
        return queryParamList;
    }
    
    /**
     * 
     * Returns a String Array of query Param values from the given List of SearchQueryParam objects.
     * Maintains the sequence of param values.
     * 
     * 
     * @param queryParam
     * @return String[]
     */
    public static String[] getParamValues(List queryParam) {
        
        String[] paramValues = new String[queryParam.size()];
        
        for(int i = 0; i < queryParam.size(); i++) {
            SearchQueryParam searchQueryParam = (SearchQueryParam) queryParam.get(i);
            int sequence = searchQueryParam.getSequence() - 1;
            paramValues[sequence] = searchQueryParam.getParamValue(); 
        }
        
        return paramValues;
    }
    
    
    /**
     * Delegates the call to SearchQueryDao
     * 
     * @param searchQueryId
     * @return
     * @throws Exception
     */
    public List getSearchQueryParam(long searchQueryId) throws Exception{
        return searchQueryDao.retrieveQueryParam(searchQueryId);
    }
   
}