package com.freightdesk.fdcommons;

/**
 * An exception that can be thrown by subsystem once it realizes that system is
 * either shutting down or a dependency has already become unavailable due 
 * to a pending system shutdown.
 *
 * @author Amrinder Arora
 */
public class SystemUnavailableException extends RuntimeException
{
    /** Creates an instance of system unavailable exception, using the given message */
    public SystemUnavailableException(String message)
    {
        super(message);
    }
}
