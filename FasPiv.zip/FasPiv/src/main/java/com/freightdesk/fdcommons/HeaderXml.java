/**
 * into with NTELX.
 *
 *
 * Module Description: Model is corresponding to the  header xml.
 *  $ID:$
 *
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/HeaderXml.java,v 1.1 2006/06/14 15:03:37 nsehra Exp $
 *
 *  Modification History:
 *  $Log: HeaderXml.java,v $
 *  Revision 1.1  2006/06/14 15:03:37  nsehra
 *  first version
 *
 *  Revision 1.2  2004/09/21 01:17:09  agarg
 *  Merging package names and the new error handling
 *
 *  Revision 1.4  2003/10/06 10:35:17  agarg
 *  for DEE
 *
 *  Revision 1.3  2003/08/21 21:35:56  agarg
 *  Making the XML Models to serializable models
 *
 *  Revision 1.2  2002/12/20 14:27:30  agarg
 *  Code clean up activity for xmlintmanager
 *
 *  Revision 1.1  2002/12/10 08:49:55  agarg
 *  for insert Inv party and ShipmentREL2.0
 *
 *
 *
 */

package com.freightdesk.fdcommons;
import com.freightdesk.fdcommons.AcknowledgementMethod;

import java.io.Serializable;

public class HeaderXml   implements Serializable {
	private String senderReferenceQualifer;
    private String userName;
    private String password;
    private String senderReferenceIdentifer;
    private String messageType;
	private AcknowledgementMethod acknowledgementMethod;
    public HeaderXml(String         messageType,
                     String         senderReferenceIdentifer,
                     String         senderReferenceQualifer,
                     String         userName,
                     String         password,
					 AcknowledgementMethod acknowledgementMethod)
    {
        this.messageType = messageType;
        this.senderReferenceIdentifer = senderReferenceIdentifer;
        this.senderReferenceQualifer = senderReferenceQualifer;
        this.userName = userName;
        this.password = password;
        this.acknowledgementMethod = acknowledgementMethod;
  }
    public void setMessageType(String         messageType)
    {
		this.messageType = messageType;
    }
    public String getMessageType()
    {
        return messageType;
    }
    public void setSenderReferenceIdentifer(String         senderReferenceIdentifer)
    {
		this.senderReferenceIdentifer = senderReferenceIdentifer;
    }
    public String getPassword()
    {

        return password;
    }
    public HeaderXml()
    {

    }
    public void setSenderReferenceQualifer(String         senderReferenceQualifer)
    {
        this.senderReferenceQualifer = senderReferenceQualifer;
    }
    public void setPassword(String         password)
    {
		this.password = password;
    }
    public String getUserName()
    {
        return userName;
    }
    public String getSenderReferenceIdentifer()
    {
        return senderReferenceIdentifer;
    }
    public String getSenderReferenceQualifer()
    {
        return senderReferenceQualifer;
    }
    public void setUserName(String         userName)
    {
        this.userName = userName;
    }
	public AcknowledgementMethod getAcknowledgementMethod()
	{
		return acknowledgementMethod;
	}
	public void setAcknowledgementMethod(AcknowledgementMethod acknowledgementMethod)
	{
		this.acknowledgementMethod = acknowledgementMethod;
	}
}