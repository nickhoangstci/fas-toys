/** 
 * 
 * Copyright (c) 2000-2002 NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/reporting/ReportXML.java,v 1.1.4.1 2009/08/06 16:07:33 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: ReportXML.java,v $
 *  Revision 1.1.4.1  2009/08/06 16:07:33  mechevarria
 *  using the head version for the ability to use role based reports
 *
 *  Revision 1.2  2007/10/26 09:43:34  dkumar
 *  Added Roles to Report
 *
 *  Revision 1.1  2006/06/21 11:20:25  dkumar
 *  repackaging of ReportUtility to FDCommons
 *
 *  Revision 1.2  2004/12/16 16:07:44  asaxena
 *  fixed  bug 1166
 *
 *  Revision 1.1  2004/09/15 13:36:28  asingh
 *  2.6 Baseline
 *
 * 
 */

package com.freightdesk.fdcommons.reporting;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

@XmlAccessorType(XmlAccessType.NONE)
public class ReportXML {

	@XmlElement(name="NAMEKEY")
	private String name;

	@XmlElement(name="FILENAME")
	private String fileName;

	@XmlElement(name="CONFIGFILE")
	private String configFile;

	@XmlElement(name="CATEGORY")
	private String category;
	
	@XmlElement(name="FORMAT")
	private List<String> formats = new ArrayList<String>();
	
	private String selectedFormat;

	@XmlElement(name="ROLE")
	private List<String> roles = new ArrayList<String>();

	@XmlElement(name="PARAM")
	private List<ParamXML> params = new ArrayList<ParamXML>();

	public List<String> getFormats() {
		return formats;
	}

	public void setFormats(List<String> formats) {
		this.formats = formats;
	}

	public String getSelectedFormat() {
		return selectedFormat;
	}

	public void setSelectedFormat(String exportFormat) {
		this.selectedFormat = exportFormat;
	}

	/**
	 * Returns the configFile.
	 * 
	 * @return String
	 */
	public String getConfigFile() {
		return configFile;
	}

	/**
	 * Returns the name.
	 * 
	 * @return String
	 */
	public String getName() {
		return name;
	}

	/**
	 * Returns the params.
	 * 
	 * @return List
	 */
	public List<ParamXML> getParams() {
		return params;
	}

	/**
	 * Returns the fileName.
	 * 
	 * @return String
	 */
	public String getFileName() {
		return fileName;
	}

	/**
	 * Sets the configFile.
	 * 
	 * @param configFile
	 *            The configFile to set
	 */
	public void setConfigFile(String configFile) {
		this.configFile = configFile;
	}

	/**
	 * Sets the name.
	 * 
	 * @param name
	 *            The name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Sets the params.
	 * 
	 * @param params
	 *            The params to set
	 */
	public void setParams(List<ParamXML> params) {
		this.params = params;
	}

	/**
	 * Sets the fileName.
	 * 
	 * @param fileName
	 *            The fileName to set
	 */

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	/**
	 * Returns the category.
	 * 
	 * @return String
	 */
	public String getCategory() {
		return category;
	}

	/**
	 * Sets the category.
	 * 
	 * @param category
	 *            The category to set
	 */
	public void setCategory(String category) {
		this.category = category;
	}

	public List<String> getRoles() {
		return roles;
	}

	public void setRoles(List<String> roles) {
		this.roles = roles;
	}

}
