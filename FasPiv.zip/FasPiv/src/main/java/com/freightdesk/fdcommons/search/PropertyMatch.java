/** 
 * Copyright (c) 2000-2002 NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/search/PropertyMatch.java,v 1.6 2008/03/27 07:07:48 ranand Exp $
 * 
 *  Modification History:
 *  $Log: PropertyMatch.java,v $
 *  Revision 1.6  2008/03/27 07:07:48  ranand
 *  fixed apostrophy bug
 *
 *  Revision 1.5  2008/03/24 12:39:22  ranand
 *  fixed apostrophy bug
 *
 *  Revision 1.4  2008/01/22 14:57:49  atripathi
 *  some methods overloaded to work with hibernate 3.
 *
 *  Revision 1.3  2007/06/18 19:43:08  ranand
 *  removed default constructor
 *
 *  Revision 1.2  2007/06/13 20:55:42  ranand
 *  added new methods
 *
 *  Revision 1.1  2007/06/12 16:55:59  ranand
 *  corrected Naming convention
 *
 *  Revision 1.2  2007/06/11 21:30:00  ranand
 *  added constructor
 *
 *  Revision 1.1  2007/06/06 20:52:01  ranand
 *  new files for serach Framework
 *
 *  
 */
package com.freightdesk.fdcommons.search;

import java.util.Collection;
import java.util.Iterator;

import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Restrictions;

import crt.com.ntelx.nxcommons.NxUtils;


public class PropertyMatch
{

    private String property;

    private Object value;

    private int operator;

    private String matchMode;
    
    /**
     * 
     * PropertyMatch Constructor
     * 
     * @param property
     * @param value
     * @param operator
     * @param matchMode
     */
    public PropertyMatch(String property, Object value, int operator, String matchMode)
    {
        this.property=property;
        this.value=value;
        this.operator=operator;
        this.matchMode=matchMode;
    }

    /**
     * 
     * @return
     */
    public String getMatchMode()
    {
        return matchMode;
    }
    
    /**
     * 
     * @param matchMode
     */
    public void setMatchMode(String matchMode)
    {
        this.matchMode = matchMode;
    }

    /**
     * 
     * @return
     */
    public int getOperator()
    {
        return operator;
    }

    /**
     * 
     * @param operator
     */
    public void setOperator(int operator)
    {
        this.operator = operator;
    }
    
    /**
     * 
     * @return
     */
    public String getProperty()
    {
        return property;
    }
    
    /**
     * 
     * 
     * @param property
     */
    public void setProperty(String property)
    {
        this.property = property;
    }

    /**
     * 
     * 
     * @return
     */
    public Object getValue()
    {
        return value;
    }

    /**
     * 
     * @param value
     */
    public void setValue(Object value)
    {
        this.value = value;
    }

    /**
     * 
     *  gets Criterion for the given propertyMatch object
     * @param property
     * @param value
     * @param operatorType
     * @return
     */
    public Criterion getCriterion()
    {
        if(SearchConstants.LIKE == operator)
        {
            if(SearchConstants.BEGINSWITH.equals(matchMode)){
                return Restrictions.ilike(property, value.toString(), getMatchMode(matchMode));
            }
            if(SearchConstants.ENDSWITH.equals(matchMode)){
                return Restrictions.ilike(property, value.toString(), getMatchMode(matchMode));
            }
            if(SearchConstants.EXACT.equals(matchMode)){
                return Restrictions.ilike(property, value.toString(), getMatchMode(matchMode));
            }else{
                return Restrictions.ilike(property, value.toString(), getMatchMode(matchMode));
            }
        }else if(SearchConstants.EQUALS == operator)
        {
            return Restrictions.eq(property, value);
        }else if(SearchConstants.GT_THAN == operator)
        {
            return Restrictions.gt(property, value);
        }else if(SearchConstants.GT_THAN_EQUALS == operator)
        {
            return Restrictions.ge(property, value);
        }else if(SearchConstants.IN == operator)
        {
            if(value instanceof Collection)
            {
                Collection collection = (Collection)value;
                return Restrictions.in(property, collection);
            }else
            {
                Object[] objArray = {value};
                return Restrictions.in(property, objArray);
            }
        }else if(SearchConstants.IS_NOT_NULL == operator)
        {
            return Restrictions.isNotNull(property);
        }else if(SearchConstants.IS_NULL == operator)
        {
            return Restrictions.isNull(property);
        }else if(SearchConstants.LESS_THAN == operator)
        {
            return Restrictions.lt(property, value);
        }else if(SearchConstants.LESS_THAN_EQUALS == operator)
        {
            return Restrictions.le(property, value);
        }else if(SearchConstants.NOT_EQUALS == operator)
        {
            return Restrictions.not(Restrictions.eq(property, value));
        }
        throw new RuntimeException(" Unknown SQL Operator:  "+operator+ ", for property: "+property);
    }
    /**
     * Overloaded method to work with hibernate 3
     *  gets Criterion for the given propertyMatch object
     * @param property
     * @param value
     * @param operatorType
     * @return
     */
    public org.hibernate.criterion.Criterion getCriterion3()
    {
    	if(SearchConstants.LIKE == operator)
        {
            if(SearchConstants.BEGINSWITH.equals(matchMode)){
                return org.hibernate.criterion.Restrictions.ilike(property, value.toString(), getMatchMode3(matchMode));
            }
            if(SearchConstants.ENDSWITH.equals(matchMode)){
                return org.hibernate.criterion.Restrictions.ilike(property, value.toString(), getMatchMode3(matchMode));
            }
            if(SearchConstants.EXACT.equals(matchMode)){
                return org.hibernate.criterion.Restrictions.ilike(property, value.toString(), getMatchMode3(matchMode));
            }else{
                return org.hibernate.criterion.Restrictions.ilike(property, value.toString(), getMatchMode3(matchMode));
            }
        }else if(SearchConstants.EQUALS == operator)
        {
            return org.hibernate.criterion.Restrictions.eq(property, value);
        }else if(SearchConstants.GT_THAN == operator)
        {
            return org.hibernate.criterion.Restrictions.gt(property, value);
        }else if(SearchConstants.GT_THAN_EQUALS == operator)
        {
            return org.hibernate.criterion.Restrictions.ge(property, value);
        }else if(SearchConstants.IN == operator)
        {
            if(value instanceof Collection)
            {
                Collection collection = (Collection)value;
                return org.hibernate.criterion.Restrictions.in(property, collection);
            }else
            {
                Object[] objArray = {value};
                return org.hibernate.criterion.Restrictions.in(property, objArray);
            }
        }else if(SearchConstants.IS_NOT_NULL == operator)
        {
            return org.hibernate.criterion.Restrictions.isNotNull(property);
        }else if(SearchConstants.IS_NULL == operator)
        {
            return org.hibernate.criterion.Restrictions.isNull(property);
        }else if(SearchConstants.LESS_THAN == operator)
        {
            return org.hibernate.criterion.Restrictions.lt(property, value);
        }else if(SearchConstants.LESS_THAN_EQUALS == operator)
        {
            return org.hibernate.criterion.Restrictions.le(property, value);
        }else if(SearchConstants.NOT_EQUALS == operator)
        {
            return org.hibernate.criterion.Restrictions.not(org.hibernate.criterion.Restrictions.eq(property, value));
        }
        throw new RuntimeException(" Unknown SQL Operator:  "+operator+ ", for property: "+property);
    }
    
    /**
     * 
     * return SQL representation for this Object.
     * 
     * @return String
     */
    public String toString(){
        
        String str = "";
        
        if(SearchConstants.LIKE == operator)
        {
            if(value != null)
            {
                String val = value.toString();
                int index = val.indexOf("'");
                if(index != -1 ) {
                    val = NxUtils.findAndReplace(val, "'", "''" );
                }
                if(SearchConstants.BEGINSWITH.equals(matchMode)){
                    str += " upper("+property+") LIKE '"+val.toUpperCase()+"%' ";
                }
                if(SearchConstants.CONTAINS.equals(matchMode)){
                    str += " upper("+property+") LIKE '%"+val.toUpperCase()+"%' ";
                }
                if(SearchConstants.ENDSWITH.equals(matchMode)){
                    str += " upper("+property+") LIKE '%"+val.toUpperCase()+"' ";
                }
                if(SearchConstants.EXACT.equals(matchMode)){
                    str += " upper("+property+") = '"+val.toUpperCase()+"' ";
                }
                
            }
            return str;
            
        }else if(SearchConstants.EQUALS == operator){
            if(value != null)
            {
                str += property + " = '"+value+"' ";
            }
            return str;
            
        }else if(SearchConstants.GT_THAN == operator){
            if(value != null)
            {
                str += property+" > "+value;
            }
            return str;
            
        }else if(SearchConstants.GT_THAN_EQUALS == operator){
            if(value != null)
            {
                str += property + " >= " + value;
            }
            return str;
            
        }else if(SearchConstants.IN == operator){
            if(value != null)
            {
                if(value instanceof Collection){
                    str += property + " IN ( ";
                    Collection collection = (Collection)value;
                    Iterator iterator = collection.iterator();
                    while(iterator.hasNext()){
                        str += " '"+iterator.next()+"' ";
                    }
                    str += " )";
                }else{
                    str += property + " IN ('"+value+"')";
                }
            }
            return str;
            
        }else if(SearchConstants.IS_NOT_NULL == operator){
                str += property + " IS NOT NULL ";
                return str;
                
        }else if(SearchConstants.IS_NULL == operator)
        {
            str += property + " IS NULL ";
            return str;
            
        }else if(SearchConstants.LESS_THAN == operator){
            if(value != null)
            {
                str += property + " < " + value;
            }
            return str;
            
        }else if(SearchConstants.LESS_THAN_EQUALS == operator){
            if(value != null)
            {
                str += property + " <= " + value;
            }
            return str;
            
        }else if(SearchConstants.NOT_EQUALS == operator){
            if(value != null)
            {
                str += property + " != '" + value+ "' ";
            }
            return str;
            
        }
        throw new RuntimeException(" Unknown SQL Operator:  "+operator);
    }
    
    /**
     * Returns hibernate expression matchmode, depending on filter string 
     * 
     * @param filter String
     * @return MatchMode
     */
    public MatchMode getMatchMode(String filter)
    {
        if (filter.equalsIgnoreCase(SearchConstants.BEGINSWITH))
            return MatchMode.START;
        else if (filter.equalsIgnoreCase(SearchConstants.CONTAINS))
            return MatchMode.ANYWHERE;
        else if (filter.equalsIgnoreCase(SearchConstants.ENDSWITH))
            return MatchMode.END;
        else
            return MatchMode.EXACT;
    }
    /**
     * overloaded method to work with hibernate 3
     * Returns hibernate expression matchmode, depending on filter string 
     * @param filter String
     * @return MatchMode
     */
    public org.hibernate.criterion.MatchMode getMatchMode3(String filter)
    {
        if (filter.equalsIgnoreCase(SearchConstants.BEGINSWITH))
            return org.hibernate.criterion.MatchMode.START;
        else if (filter.equalsIgnoreCase(SearchConstants.CONTAINS))
            return org.hibernate.criterion.MatchMode.ANYWHERE;
        else if (filter.equalsIgnoreCase(SearchConstants.ENDSWITH))
            return org.hibernate.criterion.MatchMode.END;
        else
            return org.hibernate.criterion.MatchMode.EXACT;
    }
}
