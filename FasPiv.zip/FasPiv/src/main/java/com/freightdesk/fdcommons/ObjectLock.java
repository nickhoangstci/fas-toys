/** 
 * 
 * Copyright (c) 2000-2002 NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/ObjectLock.java,v 1.2 2006/03/29 22:34:19 aarora Exp $
 * 
 *  Modification History:
 *  $Log: ObjectLock.java,v $
 *  Revision 1.2  2006/03/29 22:34:19  aarora
 *  minor optimizatio
 *
 *  Revision 1.1  2006/03/29 22:05:35  ranand
 *  moved files from folio
 *
 *  Revision 1.1  2006/03/28 21:20:06  aarora
 *  Creating an fdcommons folder
 *
 *  Revision 1.3  2004/09/15 13:03:45  ranand
 *  2.6 Baseline
 *
 * 
 */


package com.freightdesk.fdcommons;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;


public class ObjectLock {

	// temp object used for synchronization purpose only
    private static Object lock = new Object();
    
    private Map objectLockMap; 
	protected Logger logger = Logger.getLogger (getClass());
    private static ObjectLock _instance;
    private static long nextLockId;
         

	/**
	 * Private constructor for this class.
	 */

    private ObjectLock()
    {
    	nextLockId = 0;
    	objectLockMap = new HashMap();
    	
    }
	/**
	 * Static method used for returning the same instance to the user.
	 * @return instance of the ObjectLock class.
	 */

    public static  ObjectLock getInstance()
    {
		synchronized (lock)
		{
		  	if (_instance == null)
    	    {
			//	System.out.println("Creating a new instance");
			   _instance = new ObjectLock();
    	    }
		}
     	return _instance;
    }

	/**
	 * The method is used to obtain the lock for an object against specific user.
	 * @param objectKey - Combination of domainObject Type and Object id
	 * @param userId    - systen User id
	 * @return lockid to the user, if the lock is obtained 
	 * @exception  ObjectLockException   - thrown if object is already locked by another user.
    */
    public void obtainLock(ObjectKey objectKey,long userId) throws ObjectLockedException
    {
    	logger.info("obtainLock::begin");
    	long currLockId = 0;
		
    	synchronized (lock)
    	{
			ObjectValue objectValue = null;
				if (!objectLockMap.containsKey(objectKey))
				{
				   currLockId = nextLockId++;
				   objectValue = new ObjectValue(userId,currLockId);
				   objectLockMap.put(objectKey,objectValue);
    		       logger.debug("obtained the lock for Object Id::"+objectKey.getDomainObjectId()+"::UserId="+userId);
		 	 
				}  
                else // Object already locked
                {
                      objectValue = (ObjectValue)objectLockMap.get(objectKey);
                    if (((ObjectValue)objectLockMap.get(objectKey)).getUserId() != userId)
                    {
                       	  throw new ObjectLockedException("Object Already locked by another user");
                    }                    
                }
        }

      }

	/**
	 * The method is used to release the lock against the specific object. 
	 * @param objectKey - Combination of domainObject Type and Object id
	*/
      
	public void releaseLock(ObjectKey objectKey,long userId)
	{
		logger.info("releaseLock::begin");
		logger.debug("before releasing the lock::ObjectLock Map = "+objectLockMap);
		synchronized (lock)
		{
            if (objectLockMap.containsKey(objectKey))
            {
 			   ObjectValue objectValue = (ObjectValue)objectLockMap.get(objectKey);
               if (objectValue.getUserId() == userId)
			   {
			      logger.debug("trying to release the lock..");
                  objectLockMap.remove(objectKey);
			   }
        	}
		}	
       logger.debug("after releasing the lock::ObjectLock Map = "+objectLockMap);
     }
		
	/**
	 * The method is used release all the locks obtained by the user.
	 * @param userId - SystemUserId of the user.
	 */

	public void releaseAllLocksForUser(long userId)
	{
        logger.info("releaseAllLocksForUser::begin");
        synchronized(lock)
        {
             Set keys = objectLockMap.keySet();
		     Iterator i = keys.iterator();
  		     while (i.hasNext())
		     {
			    ObjectKey objectKey =(ObjectKey)i.next();
			    if (((ObjectValue)objectLockMap.get(objectKey)).getUserId() == userId)
			     {
			    	  i.remove();
			     }
		    }
	       	logger.debug("After releasing all locks for the user:ObjectLockMap="+objectLockMap);
        }
	}
}


