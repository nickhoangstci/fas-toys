package com.freightdesk.fdcommons;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.apache.log4j.Logger;

public class ErrorLogDAO extends BaseDao{
	 /** A logger */
    protected Logger logger = Logger.getLogger (getClass());
    /**
     * creates errorlog for an error code.
     * @param errorLogModel
     */
	public void createErrorLog(ErrorLogModel errorLogModel) throws Exception{
		logger.debug("createErrorLog(): begins for ErrorLogModel"+errorLogModel);
		String query="insert into errorLog(ERRORLOGID, ERRORCODE, ERRORMESSAGE, USERID, IPADDRESS, USERAGENT, PRIORITY, STATUS, CREATETIMESTAMP, LASTUPDATEUSERID, LASTUPDATETIMESTAMP, DOMAINNAME) values (?,?,?,?,?,?,?,?,?,?,?,?)";
		Connection connection = null;
	    PreparedStatement pStmt = null;
	    try{
	    	connection=ConnectionUtil.getConnection();
	    	if(errorLogModel.getErrorLogID()==0L){
	    		errorLogModel.setErrorLogID(getNextID("ERRORLOGID"));
	    	}
	    	pStmt=connection.prepareStatement(query);
	    	pStmt.setLong(1,errorLogModel.getErrorLogID());
	    	pStmt.setLong(2,errorLogModel.getErrorCode());
	    	pStmt.setString(3,errorLogModel.getErrorMessage());
	    	pStmt.setString(4,errorLogModel.getUserId());
	    	pStmt.setString(5,errorLogModel.getIpAddress());
	    	pStmt.setString(6,errorLogModel.getUserAgent());
	    	pStmt.setString(7,errorLogModel.getPriority());
	    	pStmt.setString(8,errorLogModel.getStatus());
	    	pStmt.setTimestamp(9,errorLogModel.getCreateTimeStamp());
	    	pStmt.setString(10,errorLogModel.getLastUpdateUserId());
	    	pStmt.setTimestamp(11,errorLogModel.getLastUpdateTimeStamp());
	    	pStmt.setString(12,errorLogModel.getDomainName());
	    	pStmt.executeUpdate();
            logger.debug ("Finished createErrorLog()");
	    }catch(SQLException sqEx){
	    	logger.error("Exception in createErrorLog():" , sqEx);  
	    	throw sqEx;
	    }catch(Exception e){
	    	logger.error("Exception in createErrorLog():" , e);  
	    	throw e;
	    } finally{
	    	ConnectionUtil.closeResources(connection, pStmt, null);
	    }
	}
}
