/** 
 * Copyright (c) 2000-2002 NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/search/FilterContext.java,v 1.4 2007/06/21 02:37:07 ranand Exp $
 * 
 *  Modification History:
 *  $Log: FilterContext.java,v $
 *  Revision 1.4  2007/06/21 02:37:07  ranand
 *  changed for messaging
 *
 *  Revision 1.3  2007/06/19 16:43:49  ranand
 *  fixed Exception
 *
 *  Revision 1.2  2007/06/18 19:43:22  ranand
 *  added getMessage
 *
 *  Revision 1.1  2007/06/06 20:52:01  ranand
 *  new files for serach Framework
 *
 *  
 */
package com.freightdesk.fdcommons.search;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class FilterContext
{
    private List propertyMatchList;
    private String description;
    
    private static List ignoredPropertiesForUI = new ArrayList();
    static {
        ignoredPropertiesForUI.add ("DOMAINNAME");
        ignoredPropertiesForUI.add ("STATUS");
    }
    
    /**
     * Constructor for FilterContext
     * 
     * @param propertyMatchList
     */
    public FilterContext (List propertyMatchList){
        this.propertyMatchList = propertyMatchList;
    }
    
    
    /**
     * 
     * @return  List
     */
    public List getPropertyMatchList()
    {
        return propertyMatchList;
    }

    /**
     * 
     * @param propertyMatch
     */
    public void setPropertyMatchList(List propertyMatchList)
    {
        this.propertyMatchList = propertyMatchList;
    }

    
    public String getDescription()
    {
        return description;
    }


    public void setDescription(String description)
    {
        this.description = description;
    }


    public String getMessage()
    {
        if(description != null)
            return description;
        
        if (propertyMatchList == null || propertyMatchList.size() == 0) {
            return "";
        }
        StringBuffer msgBuffer = new StringBuffer();
        Iterator propMatchIter = propertyMatchList.iterator();
        while (propMatchIter.hasNext()) {
            PropertyMatch current = (PropertyMatch) propMatchIter.next();
            if (ignoredPropertiesForUI.contains(current.getProperty().toUpperCase())) {
                continue;
            }
            msgBuffer.append(current.getProperty()+" "+SearchConstants.getOperatorString(current.getOperator()) + " " + current.getValue() + " , ");
        }
        if(msgBuffer.length() > 1){
           return msgBuffer.substring(0, msgBuffer.lastIndexOf(","));
        }
        
        return msgBuffer.toString();
    }
    
    
}
