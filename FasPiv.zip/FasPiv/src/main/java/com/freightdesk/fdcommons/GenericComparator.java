/** 
 * 
 * Copyright (c) 2000-2002 NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/GenericComparator.java,v 1.1.2.2.2.1 2009/01/30 20:35:37 mbegley Exp $
 * 
 *  Modification History:
 *  $Log: GenericComparator.java,v $
 *  Revision 1.1.2.2.2.1  2009/01/30 20:35:37  mbegley
 *  removed worthless debug
 *
 *  Revision 1.1.2.2  2007/05/18 18:52:00  mechevarria
 *  merge with main branch
 *
 *  Revision 1.21  2007/03/19 13:38:26  mechevarria
 *  Casting of null object to exact.  Ensures compatibility with JDK 1.5 and 1.6
 *
 *  Revision 1.1  2006/03/29 22:05:35  ranand
 *  moved files from folio
 *
 *  Revision 1.1  2006/03/28 21:20:06  aarora
 *  Creating an fdcommons folder
 *
 *  Revision 1.1  2004/09/15 13:05:24  ranand
 *  2.6 Baseline
 *
 * 
 */

package com.freightdesk.fdcommons;

import java.io.Serializable;
import java.lang.reflect.Method;
import java.util.Comparator;

import org.apache.log4j.Logger;

/**
 * A generic comparator to compare two objects. The field name on which the two
 * objects should be compared is provided as a parameter to the constructor. The
 * direction of the compare (ascending/descending) is also provided as a
 * parameter to the constructor.
 * 
 * <P>
 * Note: The GenericComparator imposes orderings that are NOT consistent with
 * equals. In fact, GenericComparator never claims that two objects are equal.
 * 
 * <P>
 * When a GenericComparator is initialized, it first generates the getter method
 * for the given attribute name.
 * 
 * @author Amrinder Arora
 */
public class GenericComparator implements Comparator, Serializable {
	private String attributeName;
	private Method attributeGetter;
	private boolean ascending;

	/**
	 * A log4j Logger
	 */
	protected Logger logger = Logger.getLogger(getClass());

	/**
	 * A public constructor.
	 * 
	 * <P>
	 * It calculates the getter method, by appending get to the attributename,
	 * and capitalizing the first letter. For example, if attribute name is
	 * given as xy67yu, the getter method getXy67yu() is used.
	 * 
	 * @param theClass
	 *            The Class for which this GenericComparator will be used
	 * @param attributeName
	 *            The attribute of the DocumentModel object that the object
	 *            should be sorted by
	 * @param ascending
	 *            Whether the sorting should be in ascending order or descending
	 */
	public GenericComparator(Class theClass, String attributeName, boolean ascending) {
		logger.debug("GenericComparator(" + theClass + ", " + attributeName + ", " + ascending + ")");
		attributeName = attributeName.trim();
		this.attributeName = attributeName;
		this.ascending = ascending;
		StringBuffer attributeGetterName = new StringBuffer("get");
		if (attributeName.length() > 0)
			attributeGetterName.append(attributeName.substring(0, 1).toUpperCase());
		if (attributeName.length() > 1)
			attributeGetterName.append(attributeName.substring(1));
		try {
			attributeGetter = theClass.getMethod(attributeGetterName.toString(), new Class[] {});
		} catch (Exception e) {
			logger.error("Getter method for the attribute could not be located");
			throw new RuntimeException(e);
		}
		logger.debug("Getter method is:" + attributeGetter);
	}

	/**
	 * A method defined in the Comparator interface to compare two objects.
	 * 
	 * @throws ClassCastException
	 *             if either argument is not of the given class
	 * 
	 * @return -1 if the first objects is "lesser than" the second object. 1 if
	 *         the first objects is "greater than" the second object. -1 if the
	 *         two objects are equal on the field (since the field may not be
	 *         unique, it does not mean the two objects are "equal");
	 */
	public int compare(Object obj1, Object obj2) {

		// logger.debug ("compare() begin, attribute: " + attributeName);

		try {
			Object attributeValue1 = attributeGetter.invoke(obj1, (Object[]) null);
			Object attributeValue2 = attributeGetter.invoke(obj2, (Object[]) null);

			int result;

			// Null is lesser than anything else.
			if ((attributeValue1 == null) && (attributeValue2 == null)) {
				result = 0;
			} else if ((attributeValue1 == null) && (attributeValue2 != null)) {
				result = -1;
			} else if ((attributeValue1 != null) && (attributeValue2 == null)) {
				result = 1;
			} else if (attributeValue1 instanceof Comparable) {
				// logger.debug ("attribute " + attributeName +
				// " is Comparable ");
				// the attribute values are Comparable, we have hit
				// the JackPot. We have absolutely nothing intelligent to do
				// logger.debug("attributeValue1 " + attributeValue1 +
				// " attributeValue2 "+attributeValue2);
				Comparable comp1 = (Comparable) attributeValue1;
				Comparable comp2 = (Comparable) attributeValue2;
				result = comp1.compareTo(comp2);
			} else {
				// if the attribute values are not Comparable
				// we must write custom cases (Java != Magic)
				throw new RuntimeException("Dont know how to sort by " + attributeName);
			}

			if (result == 0) {
				result = -1; // to help in stable sort
			}

			if (!ascending) {
				result = 0 - result;
			}

			return result;

		} catch (Exception e) {
			logger.error("Exception in compareTo", e);
			throw new RuntimeException(e);
		}
	}

	/**
	 * Checks if any other comparator behaves like this one. JDK API says that
	 * it is <I>always</I> safe <I>not</I> to override Object.equals(Object).
	 */
	public boolean equals(Object otherComparator) {
		return this.equals(otherComparator);
	}
}
