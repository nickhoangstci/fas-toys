package com.freightdesk.fdcommons;

import java.io.Serializable;
import java.sql.Timestamp;
/**
 * 
 * @author amit tripathi
 *
 */
public class WorkTimeModel extends BaseModel implements Serializable
{
    private long workTimeID;
    private long systemUserID;
    private Timestamp startTime;
    private Timestamp endTime;
    private long duration;
    private String projCode;
    private String taskCode;
    private String description;
    public WorkTimeModel()
    {
        
    }
    public WorkTimeModel(Timestamp startTime, Timestamp endTime, long duration, String projCode, String taskCode, String description)
    {
        this.startTime=startTime;
        this.endTime=endTime;
        this.duration=duration;
        this.projCode=projCode;
        this.taskCode=taskCode;
        this.description=description;
    }
    /**
     * Implements the abstract method defined by BaseModel.
     *
     * @return The primaryKey for this model object
     */
    public long getPrimaryKey(){
        return this.workTimeID;
    }
    public long getWorkTimeID()
    {
        return workTimeID;
    }
    public void setWorkTimeID(long workTimeID)
    {
        this.workTimeID = workTimeID;
    }
    public long getSystemUserID()
    {
        return systemUserID;
    }
    public void setSystemUserID(long systemUserID)
    {
        this.systemUserID = systemUserID;
    }
    public Timestamp getStartTime()
    {
        return startTime;
    }
    public void setStartTime(Timestamp startTime)
    {
        this.startTime = startTime;
    }
    public Timestamp getEndTime()
    {
        return endTime;
    }
    public void setEndTime(Timestamp endTime)
    {
        this.endTime = endTime;
    }   
    public String getProjCode()
    {
        return projCode;
    }
    public void setProjCode(String projCode)
    {
        this.projCode = projCode;
    }
    public String getTaskCode()
    {
        return taskCode;
    }
    public void setTaskCode(String taskCode)
    {
        this.taskCode = taskCode;
    }    
    public long getDuration()
    {
        return duration;
    }
    public void setDuration(long duration)
    {
        this.duration = duration;
    }
    public String getDescription()
    {
        return description;
    }
    public void setDescription(String description)
    {
        this.description = description;
    }  
}
