/** 
 * 
 * Copyright (c) 2000-2002 NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/ObjectLockedException.java,v 1.1 2006/03/29 22:05:35 ranand Exp $
 * 
 *  Modification History:
 *  $Log: ObjectLockedException.java,v $
 *  Revision 1.1  2006/03/29 22:05:35  ranand
 *  moved files from folio
 *
 *  Revision 1.1  2006/03/28 21:20:06  aarora
 *  Creating an fdcommons folder
 *
 *  Revision 1.3  2004/09/15 13:03:45  ranand
 *  2.6 Baseline
 *
 * 
 */

package com.freightdesk.fdcommons;



/**
 * This class implements the exception thrown if the Object is already locked by another user.
 *
 */
public class ObjectLockedException extends Exception {
  private Exception exception;

  /**
   * Creates a new ObjectLockedException wrapping another exception, and with a detail message.
   * @param message the detail message.
   * @param exception the wrapped exception.
   */
  public ObjectLockedException(String message, Exception exception) {
    super(message);
    this.exception = exception;
    return;
  }

  /**
   * Creates a ObjectLockedException with the specified detail message.
   * @param message the detail message.
   */
  public ObjectLockedException(String message) {
    this(message, null);
    return;
  }

  /**
   * Creates a new ObjectLockedException wrapping another exception, and with no detail message.
   * @param exception the wrapped exception.
   */
  public ObjectLockedException(Exception exception) {
    this(null, exception);
    return;
  }

  /**
   * Gets the wrapped exception.
   * @return the wrapped exception.
   */
  public Exception getException() {
    return exception;
  }

  
  public String toString() {
    if (exception instanceof ObjectLockedException) {
      return ((ServiceLocatorException) exception).toString();
    }
    return exception == null ? super.toString() : exception.toString();
  }
}

