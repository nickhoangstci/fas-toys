/*
 * Created on Oct 7, 2004
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package com.freightdesk.fdcommons;

/**
 * Encpsulates DomainObject info
 *
 * @author biju.joseph
 */
public class DomainObjectModel extends BaseModel {
	private long domainObjectId;
	private String domainObjectCode;
	/**
	 * @return domainObjectCode
	 */
	public String getDomainObjectCode() {
		return domainObjectCode;
	}

	/**
	 * @return domainObjectId
	 */
	public long getDomainObjectId() {
		return domainObjectId;
	}

	/**
	 * @param domainObjectCode
	 */
	public void setDomainObjectCode(String domainObjectCode) {
		this.domainObjectCode = domainObjectCode;
	}

	/**
	 * @param domainObjectId
	 */
	public void setDomainObjectId(long domainObjectId) {
		this.domainObjectId = domainObjectId;
	}
	
	/**
	 * Implements the abstract method defined by BaseModel. 
	 */
	public long getPrimaryKey(){
		return domainObjectId;
	}  
}
