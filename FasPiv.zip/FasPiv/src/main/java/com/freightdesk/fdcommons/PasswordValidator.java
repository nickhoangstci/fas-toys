package com.freightdesk.fdcommons;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

/**
 * validates password according to the password policy in property file.
 * @author ak.tripathi
 *
 */
public class PasswordValidator {
	private String passwordPolicy;
	private boolean mixedCase;
	private boolean specialCase;
	private boolean numeric;	
	private int length=0;
	private static Map _instances = new HashMap();
	
//	 a logger
    private static Logger logger =
        Logger.getLogger("com.freightdesk.common.PasswordValidator");
	/**
	 * constructs requirements to be fullfilled by password.
	 *
	 */
	private PasswordValidator(){
		passwordPolicy = FDSuiteProperties.getProperty("password.strength.policy");
		if(passwordPolicy.indexOf('m')>=0){
			mixedCase = true;
		}
		if(passwordPolicy.indexOf('s')>=0){
			specialCase = true;
		}
		if(passwordPolicy.indexOf('n')>=0){
			numeric = true;
		}
		String numberString = getNumbers(passwordPolicy);
		if(numberString != null && !"".equalsIgnoreCase(numberString)){
			length = Integer.parseInt(numberString);
		}		
	}
	/**
	 * Gets the instance for this domainName.
	 * The first time this method is called for that domain,
	 * it creates an instance, and puts it in the _instances map.
	 *  Next time, it returns the already created instance for that domain.
	 * @param domainName
	 * @return
	 */
	public static PasswordValidator getInstance(){
		PasswordValidator passwordValidator = (PasswordValidator)(_instances.get("PUBLIC"));
		if(passwordValidator == null){
			passwordValidator = new PasswordValidator();
			_instances.put("PUBLIC", passwordValidator);
		}
		return passwordValidator;
	}
	/**
	 * clears the map.
	 * removes the already existing instance of this class.
	 * @param domainName
	 */
	public static void clear(){
		_instances.clear();
	}

	/**
	 * validates password according to password policy set in properties file
	 * 
	 * @param password
	 * @return
	 */
	public String validatePassword(String password) {
        logger.debug("validatePassword(): begin");
		String msg = "";
		if(password.length()<length){
			msg = "at least"+length+ " characters,";
		}
		if(mixedCase){
			boolean smallCase = false;
			boolean capCase = false;
			for (int i = 0; i < password.length(); i++) {
				char c = password.charAt(i);
				if ((c >= 'a') && (c <= 'z')) {
					smallCase = true;
				}
				if ((c >= 'A') && (c <= 'Z')) {
					capCase = true;
				}
				if (smallCase == true && capCase == true){
					break;
				}
		   }
			if (smallCase == false || capCase == false) {
				msg = msg + "mixed case characters,";
			}
		}
		if(specialCase){
			boolean special = false;
			for (int i = 0; i < password.length(); i++) {
				char c = password.charAt(i);
				if ((c > 'z') || ((c < 'a') && (c > 'Z'))
						|| ((c > '9') && (c < 'A')) || ((c > ' ') && (c < '0'))) {
					special = true;
					break;
				}				
			}
			if (special == false) {
				msg = msg + "at least one special character,";
			}
		}
		if(numeric){
			boolean numeric = false;
			for (int i = 0; i < password.length(); i++) {
				char c = password.charAt(i);
				if ((c >= '0') && (c <= '9')) {
					numeric = true;
					break;
				}
			}
			if (numeric == false) {
				msg = msg + "at least one numeric character,";
			}			
		}
		if (msg.length() > 0)
			msg = msg.substring(0,msg.length()-1)+".";
		return msg;
	}

	public String getPasswordPolicy() {
		return passwordPolicy;
	}

	public void setPasswordPolicy(String passwordPolicy) {
		this.passwordPolicy = passwordPolicy;
	}
/**
 * property file input must be of any type containing an integer
 * @param s
 * @return
 */
	private static String getNumbers(String s) {
        int startIndex=0;
        int endIndex=-1;
        for(int i=0; i<s.length();i++){
            if(!Character.isDigit(s.charAt(i))){                
                continue;
            }else{
                startIndex=i;
                break;
            }
        }
        for (int i=startIndex; i<(s.length());i++){
            if (Character.isDigit(s.charAt(i))) {
                  endIndex = i;
                  continue;            
              } else{
                  break;
              }
        }          
         return s.substring(startIndex, endIndex+1);
      }

	public int getLength() {
		return length;
	}
	
	public void setLength(int length) {
		this.length = length;
	}
	
	public boolean isMixedCase() {
		return mixedCase;
	}
	
	public void setMixedCase(boolean mixedCase) {
		this.mixedCase = mixedCase;
	}
	
	public boolean isNumeric() {
		return numeric;
	}
	
	public void setNumeric(boolean numeric) {
		this.numeric = numeric;
	}
	
	public boolean isSpecialCase() {
		return specialCase;
	}

	public void setSpecialCase(boolean specialCase) {
		this.specialCase = specialCase;
	}
}
