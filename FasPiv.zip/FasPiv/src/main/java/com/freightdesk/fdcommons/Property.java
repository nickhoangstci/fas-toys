/** 
* Copyright (c) 2000-2002 NTELX 
*  All rights reserved. 
* 
* This software is the confidential and proprietary information of NTELX 
* ("Confidential Information").  You shall not disclose such Confidential Information 
* and shall use it only in accordance with the terms of the license agreement you entered 
* into with NTELX. 
* 
* 
*  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/Property.java,v 1.1 2006/10/27 10:05:15 ranand Exp $ 
* 
*  Modification History:
*  $Log: Property.java,v $
*  Revision 1.1  2006/10/27 10:05:15  ranand
*  Added to read XML properties file
*
*/

package com.freightdesk.fdcommons;

/**
 * Tis class contains the information related to property.
 * @author Rajender Anand
 *
 */
public class Property
{
    /** Sequence of property */
    private long sequence;
    
    /** Name of property */
    private String name;
    
    /**  Value of property */
    private String value;
    
    /** description of property */
    private String description;

    /**
     * @return Returns the description.
     */
    public String getDescription()
    {
        return description;
    }

    /**
     * @param description The description to set.
     */
    public void setDescription(String description)
    {
        this.description = description;
    }

    /**
     * @return Returns the name.
     */
    public String getName()
    {
        return name;
    }

    /**
     * @param name The name to set.
     */
    public void setName(String name)
    {
        this.name = name;
    }

    /**
     * @return Returns the sequence.
     */
    public long getSequence()
    {
        return sequence;
    }

    /**
     * @param sequence The sequence to set.
     */
    public void setSequence(long sequence)
    {
        this.sequence = sequence;
    }

    /**
     * @return Returns the value.
     */
    public String getValue()
    {
        return value;
    }

    /**
     * @param value The value to set.
     */
    public void setValue(String value)
    {
        this.value = value;
    }
    
    
    
    
    
}
