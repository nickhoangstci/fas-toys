/** 
 * Copyright (c) 2000-2002 NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/LcpConstants.java,v 1.5.2.1.2.5 2010/06/22 22:45:27 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: LcpConstants.java,v $
 *  Revision 1.5.2.1.2.5  2010/06/22 22:45:27  mechevarria
 *  default uom to engl
 *
 *  Revision 1.5.2.1.2.4  2009/09/18 18:11:16  mechevarria
 *  additional FAS constants
 *
 *  Revision 1.5.2.1.2.3  2009/07/31 15:06:20  cdoan
 *  Synched with HEAD
 *
 *  Revision 1.21  2009/07/10 12:03:28  Vishal_Suri
 *  relationShipTypeCode inner class added.
 *
 *  Revision 1.20  2009/03/10 09:19:56  narora
 *  JNDI_NAME member added in WatchPointSubSourceType class.
 *
 *  Revision 1.19  2009/03/03 10:06:42  ranand
 *  added new constants in DomainObjects
 *
 *  Revision 1.18  2009/02/10 09:53:22  atripathi
 *  inner class StartPageCodes removed.
 *
 *  Revision 1.17  2009/02/06 11:42:16  atripathi
 *  new class StartPageCodes added.
 *
 *  Revision 1.16  2008/11/06 16:41:53  fdoughty
 *  Added LcpConstants.DomainObjects.WIKI constant
 *
 *  Revision 1.15  2008/07/16 08:32:05  narora
 *  WatchPointSubSourceType constant added
 *
 *  Revision 1.14  2008/04/23 09:10:19  atripathi
 *  inner class ViewContextMessage added
 *
 *  Revision 1.13  2008/04/11 11:28:48  atripathi
 *  static inner class in LCPConstants LoggerPriorityType added for logger messages priority.
 *
 *  Revision 1.12  2008/02/05 08:46:27  ranand
 *  Added  new LCPConstants for INBOX
 *
 *  Revision 1.11  2007/09/19 11:21:31  nsehra
 *  shipment status updated
 *
 *  Revision 1.10  2007/07/30 23:24:25  ranand
 *  added new constant for domain object type
 *
 *  Revision 1.9  2007/07/02 15:21:38  ranand
 *  moved serverMode property to FusionProperties
 *
 *  Revision 1.8  2007/06/29 00:02:00  ranand
 *  Added new constant for Fusion
 *
 *  Revision 1.7  2007/04/12 16:35:27  dkumar
 *  constants for cookie names
 *
 *  Revision 1.6  2007/03/21 13:51:52  nsehra
 *  systemrole inner class added
 *
 *  Revision 1.5  2006/09/30 13:58:19  dkumar
 *  removed Product inner class
 *
 *  Revision 1.4  2006/07/20 09:38:54  dkumar
 *  rolled back to 1.2
 *
 *  Revision 1.3  2006/07/19 14:17:13  dkumar
 *  removed related_product_label and related_product_value
 *
 *  Revision 1.2  2006/04/07 16:17:06  ranand
 *  change the Constants Name used in dashBoard
 *
 *  Revision 1.1  2006/03/29 22:05:35  ranand
 *  moved files from folio
 *
 *  Revision 1.1  2006/03/28 21:20:06  aarora
 *  Creating an fdcommons folder
 *
 *  Revision 1.28  2006/03/28 18:08:56  ranand
 *  constants adeded  for mapping file name of EventRetrieve
 *
 *  Revision 1.27  2005/10/05 12:01:30  nsehra
 *  dashboard tile configuration
 *
 *  Revision 1.26  2005/09/30 13:46:24  nsehra
 *  changed tiles constants values
 *
 *  Revision 1.25  2005/09/09 00:30:12  amrinder
 *  Removed an unused class
 *
 *  Revision 1.24  2005/09/02 13:53:11  pjain
 *  added eventtype
 *
 *  Revision 1.23  2005/08/31 13:37:41  nsehra
 *  added a constant
 *
 *  Revision 1.22  2005/08/31 11:05:14  ranand
 *  changes for customization of Dashboard
 *
 *  Revision 1.21  2005/08/30 23:23:57  amrinder
 *  Changed a constant
 *
 *  Revision 1.20  2005/08/30 12:56:22  pjain
 *  added constant
 *
 *  Revision 1.19  2005/08/30 02:13:31  amrinder
 *  Split OrgHierarchyTypes class into Types and Roles
 *
 *  Revision 1.18  2005/08/29 14:03:57  pjain
 *  added constants
 *
 *  Revision 1.17  2005/08/25 08:13:47  pjain
 *  added constants
 *
 *  Revision 1.16  2005/08/24 02:56:13  amrinder
 *  Trying to decrease dependance on shipment references
 *
 *  Revision 1.15  2005/07/01 07:35:01  pjain
 *  removed redundant classes
 *
 *  Revision 1.14  2005/06/16 13:39:18  nsehra
 *  Removed InvovledPartyTypeCode class
 *
 *  Revision 1.13  2005/06/14 11:59:51  nsehra
 *  InvovledPartyTypeCode added
 *
 *  Revision 1.12  2005/04/26 20:20:18  amrinder
 *  Removed UserPreferences class
 *
 *  Revision 1.11  2005/01/21 13:53:43  pjain
 *  Added SMS handling
 *
 *  Revision 1.10  2005/01/21 12:53:09  biju
 *  added INTERMODAL constant under shipmenttransportmode
 *
 *  Revision 1.9  2005/01/18 22:05:34  amrinder
 *  Minor formatting changes
 *
 *  Revision 1.8  2004/12/01 12:21:58  asingh
 *  Added content type text/xml as well as file extention type .xml
 *
 *  Revision 1.7  2004/10/21 09:31:46  ranand
 *  changes for Shipment Leg Sequencing
 *
 *  Revision 1.6  2004/09/21 12:49:21  agarg
 *  added a constant for data base escape character
 *
 *  Revision 1.5  2004/09/21 08:53:59  ranand
 *  rollback the changes done in previous version
 *
 *  Revision 1.4  2004/09/21 08:47:42  ranand
 *  package of Manager classes  changed from folioweb to folio
 *
 *  Revision 1.3  2004/09/15 13:03:45  ranand
 *  2.6 Baseline
 */


package com.freightdesk.fdcommons;

/**
 * LcpConstants is a collection of constant values that must
 * be the same in DB and application for the system to work correctly.
 * For example, Application needs to know which Document Status code
 * is approved and which is created.
 *
 * @author Amrinder Arora
 * @author Amit Tripathi
 * @author Nipun Arora
 */
public class LcpConstants {

    public static class DomainObjects
    {
        public final static String SHIPMENT = "SHIP";
        public final static String SHIPMENTLEG = "LEG";
        public final static String LEGSTOP = "LSTOP";
        public final static String EVENT = "EVENT";
        public final static String PACKAGE = "PCKGE";
        public final static String EQUIPMENT = "EQPMT";
        public final static String ORGHIERARCHY = "ORGNZ";
        public final static String DOCUMENT = "DOC";
        public final static String DOCUMENTSUBMISSION = "DOCSB";
        public final static String ORDER = "ORDER";
        public final static String RULES = "RULES";  // Constant used for FDAnalyzer Rules 
        public final static String INBOX = "INBOX";  // Constant used for FDAnalyzer Inbox  
        public final static String WIKI = "WIKI";  // Constant used for FDAnalyzer Wiki
    }

    public static class CommunicationMethodTypes {
        public static final String PHONE = "PHONE";
        public static final String EMAIL = "EMAIL";
        public static final String SMS = "SMS";
        public static final String FAX = "FAX";
        public static final String US_CUSTOMS_QUEUE = "USCUSTQ";
        public static final String EFWD = "EFWD";
    }

    public static class DocumentStatus {
        public static final String CREATED = "CREAT";
        public static final String APPROVED = "APRV";
        public static final String SUBMITTED = "SBMT";
        public static final String ON_HOLD = "HOLD";
        public final static String ARCHIVED = "ARCHV";
        public final static String NEW = "NEW";
    }

    public static class DocumentFormat {
        public static final String PDF = "PDF";
        public static final String CAMIR = "CAMIR";
        public static final String EDI = "EDI";
        public static final String WORD = "WORD";
        public static final String TEXT = "TEXT";
    }

    public static class ContentType {
        public static final String TEXT_XML = "text/xml";
        public static final String TEXT_HTML = "text/html";
        public static final String APP_PDF   = "application/pdf";
        public static final String APP_DOC   = "application/msword";
        public static final String APP_ZIP   = "application/x-zip";
        public static final String IMG_GIF   = "image/gif";
        public static final String IMG_JPG   = "image/jpeg";
    }

    public static class DocumentFolder {
        public static final String TEXT   = "Texts";
        public static final String IMG    = "Images";
        public static final String PDF    = "Pdfs";
        public static final String DOC    = "Docs";
        public static final String ZIP    = "Zips";
        public static final String OTHER  = "Others";
    }

    public static class FileExtentionType {
        public static final String TEXT  = "txt";
        public static final String PDF   = "pdf";
        public static final String DOC   = "doc";
        public static final String ZIP   = "zip";
        public static final String GIF   = "gif";
        public static final String JPG   = "jpg";
        public static final String BMP   = "bmp";
        public static final String XML   = "xml";
    }

    public static class DocumentTemplate {
        public static final long CommercialInvoice = 1;
        public static final long ShippersLetterOfInstructions = 2;
        public static final long BILL_OF_LADING = 6;
        public static final long INSPECTION_REPORT = 7;
        public static final long AMS_MANIFEST_CREATE_CAMIR = 100;
        public static final long AMS_MANIFEST_DELETE_CAMIR = 10l;
        public static final long AMS_MANIFEST_REPLACE_CAMIR = 102;
        public static final long AMS_VESSEL_ARRIVE_CAMIR = 103;
        public static final long AMS_MANIFEST_EDIT = 104;
        public static final long AMS_MANIFEST_CONSIST = 105;

        public static final String AUTOAPPROVE_TRUE = "1";
        public static final String AUTOSUBMIT_TRUE = "1";
    }

    public static class DocumentSubmissionStatus {
        public static final String AWAITING_SUBMISSION = "AWAIT";
        public static final String SUBMITTED = "SUBMT";
        public final static String REJECTED = "REJCT";
        public static final String APPROVED = "APPRV";
        public static final String RECEIVED = "RECV";
    }

    public static class OrgHierarchyTypes {
        public static final String ORG = "ORG";
        public static final String LOCATION = "LOC";
        public static final String CONTACT = "CON";
    }

    public static class OrgHierarchyRoles {
		public static final String CARRIER = "CAR";
		public static final String PORT = "PORT";
        public static final String AIRPORT = "AIRPT";
        public static final String RAIL_TERMINAL= "RAILT";
        public static final String ROAD_TERMINAL = "ROADT";
		public static final String DRIVER = "DRVR";
    }

    public static class UnitCategory {
        public static final String Weight = "WGT";
        public static final String Volume = "VOL";
        public static final String Length = "LEN";
    }

    public static class PackageTypeCode {
        public static final String BLK = "BLK";
    }

    public static class ItemTradeClassification {
        public static final String SCHEDULE_B = "SCHB";
    }

    public static class ItemClassification {
        public static final String CATALOG_NUMBER = "CATNO";
        public static final String ITEM_NUMBER = "ITNO";
        public static final String MODEL_NUMBER = "MNO";
        public static final String PART_NUMBER = "PNO";
        public static final String SKU_NUMBER = "SKUNO";
        public static final String UPC_NUMBER = "UPCNO";
    }

    public static class InvolvedPartyTypeCode {
        public static final String DRIVER = "DRV";
        public static final String AMS_FILER = "AMSF";
        public static final String NOTIFYPARTY = "NT";
        public static final String CONSIGNEE = "CONS";
        public static final String SHIPPER = "SHIP";
        public static final String SHIPMENT_CREATOR = "SHCRT";
        public static final String FORWARDER = "FW";
        public static final String INTERMEDIATE_CONSIGNEE = "IC";
        public static final String INSPECTION_AGENCY = "INSAG";
        public static final String EXPORTER = "EX";
        public static final String ORDER_CREATOR = "POCR";
		public static final String CUSTOMS_BROKER = "CB";
    }

    public static class PaymentTermsTypeCode {
        public static final String PREPAID = "PRPD";
        public static final String COLLECT = "CLCT";
        public static final String COD = "COD";
    }

    public static class ShipmentChargeType {
        public static final String FOB = "FOB";
        public static final String Cartage = "CTG";
        public static final String AnyFees = "OTHER";
        public static final String Insurance = "INC";
        public static final String TotalCIF = "TCIF";
        public static final String TRANSPORTATION_CHARGE = "TRANS";
        public static final String ACCESSORIAL_CHARGE = "ACC";
    }

    public static class ShipmentReferenceType {
        public static final String OCEAN_BILL_OF_LADING = "OB";
        public static final String BILL_OF_LADING_NUMBER = "BM";
        public static final String SHIPPER_REFERENCE_NUMBER = "SR";
        public static final String GOV_BILL_OF_LADING = "BL";
        public static final String HO = "HO";
        public static final String AW = "AW";
        public static final String MAWB = "MAWB";
        public static final String CUSTOMER_REFERENCE_NUMBER = "CR";
        public static final String MASTER_BILL_OF_LADING = "MB";
        public static final String HOUSE_BILL_OF_LADING = "B";
        public static final String HA = "HA";
		public static final String INVOICE_NUMBER = "INV";
		public static final String INVOICE_DETAIL_NUMBER = "INDET";
        public static final String PERMIT_NUMBER = "PN";
    }

    public final class ShipmentStatus {
        public final static String BOOKING_ACCEPTED = "BKACC";
        public final static String DELAYED = "DELAY";
        public final static String PLANNED = "PLN";
        public final static String ENROUTE = "EN";
        public final static String DELIVERED = "DELV";
        public final static String INVOICED = "INV";
        public final static String CUSTOMERHOLD = "CH";
        public final static String BOOKING_SUBMITTED = "BKSUB";
        public final static String OPEN = "OPEN";
        public final static String CLOSED = "CLOSE";
        public final static String INFORMATION_REQUESTED = "INFRQ";
        public final static String ACCEPTED = "ACCPT";
        public final static String ACTIVE_RELEASE = "ACTRL";
        public final static String ACTIVE_WAITING = "ACTWT";
        public final static String CLEARED_PENDING_RELEASE = "CLRPR";
        public final static String REJECTED = "RJCTD";
        public final static String SUBMITTED = "SUBIT";
    }

    public final class ShipmentObjectType {
        public final static String SHIPMENT = "SHIP";
        public final static String MAWB = "MAWB";
        public final static String HAWB = "HAWB";
        public final static String TEMPLATE = "TMPLT";
        public final static String DISCREPANCY_REPORT = "DR";
        public final static String INSPECTION_REPORT = "IR";
        public final static String BILL_OF_LADING = "BL";
        public final static String BOOKING_REQUEST = "BR";
        public final static String BOOKING_CONFIRMATION = "BC";
        public final static String LOADING_DOCUMENT = "LDOC";
        public final static String PACKING_LIST = "PL";
    }

    public static class ShipmentTransportMode {
        public static final String OCEAN = "11";
        public static final String AIR = "40";
        public static final String RAIL = "20";
        public static final String TRUCK = "30";
        public static final String PARCEL = "60";
		public static final String INTERMODAL = "21";
    }

    public static class XmlIntManager
    {
        public static final String PROPERTIES_FILE = "xmlintmanager.properties";
        public static final String MAPPINGFILE_INSERT_SHIPMENT = "insertShipmentMapping.xml";
        public static final String RETRIEVE_SHIPMENT_RESULT_MAPPING_FILE = "retrieveShipmentResultMapping.xml";
        public static final String RETRIEVE_SHIPMENT_INPUT_MAPPING_FILE = "retrieveShipmentInputMapping.xml";
        public static final String DELETE_SHIPMENT_INPUT_MAPPING_FILE = "deleteShipmentInputMapping.xml";
        public static final String MAPPINGFILE_HEADER = "headerMapping.xml";
        public static final String MAPPING_FILE_ORG = "orghierarchyMapping.xml";
        public static final String MAPPINGFILE_ACKNOWLEDGEMENT = "acknowledgementMapping.xml";
        public static final String MAPPINGFILE_ERROR = "errorMapping.xml";
        public static final String MAPPINGFILE_SHIPMENTMODEL = "shipmentmodelmapping.xml";
        public static final String MAPPINGFILE_ADD_INVOLVEDPARTY = "addInvolvedPartyMapping.xml";
        public static final String ADD_CHARGES_MAPPING_FILE = "addChargesMapping.xml";
        public static final String ADD_EVENTS_MAPPING_FILE = "addEventMapping.xml";
        public static final String RETRIEVE_EVENT_INPUT_MAPPING_FILE = "retrieveEventInputMapping.xml";
        public static final String RETRIEVE_EVENT_RESULT_MAPPING_FILE = "retrieveEventResultMapping.xml";
        public static final String MAPPINGFILE_INSERT_ORDER = "insertOrderMapping.xml";
        public static final String ADD_LEG_CONTAINER_MAPPING_FILE = "addLegContainerMapping.xml";
        public static final String ADD_UPDATE_LEG_STOP_MAPPING_FILE ="addUpdateLegStopMapping.xml";
        public static final String UPDATE = "update";
        public static final String INSERT = "insert";
        public static final String DELETE = "DELETE";
        public static final String DATABASEESCAPECHAR = "'";

        public static final String MAPPINGFILE_INSERT_INVOICE = "insertInvoiceMapping.xml";

        public static final String MAPPINGFILE_ERROR_INVOICE = "errorInvoiceMapping.xml";
    }

    public static class DataExtractionEngine
    {
    	public static final String PROPERTIES_FILE = "lcp-dee.properties";
    }


    public static class DeterminantAttributes
    {
        public static final String TOTAL_CHARGEABLE_WEIGHT = "TCHGW";
        public static final String TOTAL_WEIGHT = "TOTWT";
        public static final String GROSS_VOLUME = "GRVOL";
        public static final String GROSS_WEIGHT = "GRWGT";
        public static final String NUMBER_20_CONTAINERS = "NUM2C";
        public static final String NUMBER_40_CONTAINERS = "NUM4C";
        public static final String NUMBER_PACKAGES = "NUMP";
        public static final String ALWAYS_1 = "ALWS1";
        public static final String IS_MASTERBILL = "ISMBL";
        public static final String IS_HOUSEBILL = "ISHBL";
		public static final String IS_HAZARDOUS = "ISHZS";
        public static final String TRANSPORTATION_COST = "TPCST";
        public static final String LDIST = "LDIST";
    }
    public static class UOM
    {
        public final static String METRIC_WEIGHT_LABEL = "KILOGRAM";
        public final static String METRIC_WEIGHT_VALUE = "KG";
        public final static String ENGLISH_WEIGHT_LABEL = "POUND";
        public final static String ENGLISH_WEIGHT_VALUE = "POUND";
        public final static String METRIC_VOLUME_LABEL = "CUBIC METER";
        public final static String METRIC_VOLUME_VALUE = "CBM";
        public final static String ENGLISH_VOLUME_LABEL = "CUBIC FEET";
        public final static String ENGLISH_VOLUME_VALUE = "CFT";
        public final static String SECOND = "SEC";
        public final static String POUND = "POUND";
        public final static String CUBIC_FEET = "CCFT";
        public final static String CUBIC_METER = "CMTR";
    }

    public static class Paging
    {
        public final static long START = 1;
        public final static long END = 200;
    }
    public static class UserPreferenceCodes
    {
        public final static String FAVORITE_LABEL = "Favorite";
        public final static String FAVORITE_VALUE = "FAV";
    }
            
    // User Prefeence Values for Code Favorite.
    public static class UserPreferenceValues
    {
        public final static String CREATE_ORDER_LABEL = "Create an Order";
        public final static String CREATE_ORDER_VALUE = "CREATEORDER";
        public final static String CREATE_SHIPMENT_LABEL = "Create a Shipment";
        public final static String CREATE_SHIPMENT_VALUE = "CREATESHIP";
        public final static String CREATE_ORG_LABEL = "Create an Organization";
        public final static String CREATE_ORG_VALUE = "CREATEORG";
        public final static String CREATE_ROUTING_LABEL = "Create a Routing Plan";
        public final static String CREATE_ROUTING_VALUE = "CREATEROUTE";
        public final static String GET_QUICKQUOTE_VALUE = "GETQUICKQUOTE";
        public final static String GET_QUICKQUOTE_LABEL = "Get a QuickQuote";
        public final static String VIEW_SHIPMENT_ROUTING_VALUE = "VIEWSHIPMENTROUTING";
        public final static String CREATE_EVENT_VALUE = "CREATEEVENT";
        public final static String CREATE_EVENT_LABEL = "Create an Event";
		public final static String SEARCH_SHIPMENT = "SEARCHSHIPMENT";
		public final static String SEARCH_SHIPMENT_LABEL = "Search Shipment";
    }       
    
    public static class PreferenceDefaultValues
     {
        public final static String CURRENCYCODE= "USD";
        public final static String DATEFORMAT  = "MM/dd/yyyy";
        public final static String TIMEZONEID  = "EST";
        public final static String UOMCODE     = "ENGL";
     }   
    
    public static class EventCategory
    {
        public final static String SYS_EVENT      = "SYS";
        public final static String BUISINESS      = "BUS";
        public final static String TRANSPORTATION = "TRNS";    
        public final static String INSPECTION     = "INS";
    }
    
    public static class EventType
    {
        public final static String CONTAINER_SEALED         = "CS";
        public final static String INSPECTION_REQUESTED     = "INR";            
        public final static String INSPECTION               = "INS";            
        public final static String IMAGE_INSPECTION         = "IMGIN";            
        public final static String NOTIFY_SHIPMENT_CREATION = "NOTF";
        public final static String GATE_IN                  = "GIN";
        public final static String GATE_OUT                  = "GOUT";
    }

    public static class LegType
    {
        public final static String DOMESTIC         = "DOMST";
        public final static String INTERNATIONAL     = "INTER";            
     }
    public static class EventReferenceType
    {
        public final static String INSPECTION_ID         = "INSID";
    }

    public static class InspectionReport
    {
        public final static String SHIPMENTORIGINADDRESSID = "SHIPMENTORIGINADDRESSID";
        public final static String SHIPMENTDESTINATIONADDRESSID = "SHIPMENTDESTINATIONADDRESSID";

        public final static String LEGNUMBER = "LEGNUMBER";
        public final static String MODECODE = "MODECODE";

        public final static String PACKAGEQUANTITY = "PACKAGEQUANTITY";
        public final static String LINEITEMQUANTITY = "LINEITEMQUANTITY";

        public final static String LEGORIGINSTOPFUNCTIONCODE = "LEGORIGINSTOPFUNCTIONCODE";
        public final static String LEGDESTINATIONSTOPFUNCTIONCODE = "LEGDESTINATIONSTOPFUNCTIONCODE";
    }
    
    public static class InspectionOrCheckType
    {
        public final static String MATERIAL_BROACH_EVIDENCE = "MBE";
        public final static String WALLS_BROKEN = "WB";
        public final static String WALLS_REPAIRED = "WR";
        public final static String WALLS_VULNERABLE = "WV";
        public final static String HINGES_VULNERABLE = "HV";
        public final static String HINGES_BROKEN = "HB";
        public final static String EXTERIOR_ROOF_BROKEN = "ERB";
        public final static String EXTERIOR_ROOF_VULNERABLE = "ERV";
        public final static String FLOOR_NEW_LUMBER_ADHERED = "FNLA";
        public final static String FLOOR_NEW_LUMBER_INSERTED = "FNLI";
        public final static String EXTERIOR_BOTTOM_VULNERABLE = "EBV";
        public final static String EXTERIOR_BOTTOM_SUSPICIOUS_OBJECT = "EBSOV";
        public final static String OTHER_COMMENTS = "OCM";
        public final static String DIGITAL_PHOTOS_COUNT = "DGC";
        public final static String CAUSE_FOR_ALERT = "CFA";
        public final static String ALERT_OVERAGES = "ALO";
        public final static String ALERT_SHORTAGES = "ALS";
        public final static String ALERT_CONCEALED_GOODS = "ACG";
        public final static String ALERT_SUSPICIOUS_GOODS = "ASG";
        public final static String ALERT_CURRENCY = "ALCR";
        public final static String ALERT_CONTRABAND = "ALCB";
    }

    public static class LegContainer
    {
        public final static String IMAGE_REPORT_MAPPING_FILE = "ImagingReport.xml";
    }

    public static class OverduePeriod
    {
        public final static String ONE_HOUR = "1 Hour";
        public final static String TWELVE_HOUR = "12 Hours";
        public final static String ONE_DAY = "1 Day";
        public final static String THREE_DAY = "3 Days"; 
        public final static String ONE_WEEK = "1 Week"; 
    }

    public class InvoiceStatusCode
    {
        public final static String INPROCESS = "INPRO";
        public final static String ADJUSTED = "ADJUS";
        public final static String CLOSE = "CLOSE";
        public final static String APPROVED = "APPR";
        public final static String REJECTED = "REJ";
        public final static String PROCESSED = "PROC";
        public final static String OPEN = "OPEN";
    }

    public static class LoggerPriorityType
    {
    	public final static String DEBUG = "DEBUG";
        public final static String WARN = "WARN";
        public final static String INFO = "INFO";
        public final static String ERROR = "ERROR";
        public final static String FATAL = "FATAL";       
    }
    
    public static class SystemRole
    {
        public final static String SYSTEM_ADMINISTRATOR = "SYS";
        public final static String DOMAIN_ADMINISTRATOR = "DOMAD";
        
    }

    /**
     * 
     * @author Amit Tripathi
     *
     */
    public static class ViewContextMessage
    {
        public final static String VIEW_CONTEXT_MESSAGE1 = "HOME_MSG";
        public final static String VIEW_CONTEXT_MESSAGE2 = "DETAILS_MSG";
        
    }
    
    public static class WatchPointSubSourceType
    {
        public static final String ORACLE = "ORC";
        public static final String SQLSERVER = "SQL";
        public static final String MYSQL = "MYSQL";
        public static final String JNDI_NAME = "JNDI";
    }
}

