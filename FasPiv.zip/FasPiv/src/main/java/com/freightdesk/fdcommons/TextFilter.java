/** 
 * 
 * Copyright (c) 2000-2002 NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/TextFilter.java,v 1.1.4.1 2008/12/11 13:50:44 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: TextFilter.java,v $
 *  Revision 1.1.4.1  2008/12/11 13:50:44  mechevarria
 *  brought over from head
 *
 *  Revision 1.3  2008/06/20 12:35:00  narora
 *  getSQLString method modified. Replaced single quotes in searchText parameter by double single quotes.
 *
 *  Revision 1.2  2007/08/07 19:52:57  ranand
 *  added new methods
 *
 *  Revision 1.1  2006/04/05 21:09:52  ranand
 *  moved from fdfolio.util
 *
 *  Revision 1.1  2004/09/15 13:05:24  ranand
 *  2.6 Baseline
 *
 * 
 */


package com.freightdesk.fdcommons;

/**
 * A utility class to help with searches on text fields.
 * Mostly, it is used with advanced search functionality.
 *
 * @author Amrinder Arora
 * @author Nipun Arora
 */
public class TextFilter
{
    public static final String BEGINS_WITH = "beginsWith";
    public static final String CONTAINS = "contains";
    public static final String ENDS_WITH = "endsWith";
    public static final String EXACT_MATCH = "exactMatch";

    /**
     * Gets an SQL string that can be used directly with a search text
     * and included as part of the query.
     */
    public static String getSQLString (String textFilter, String searchText) 
    {
    	searchText = searchText.replaceAll("'", "''") ;
        if (BEGINS_WITH.equalsIgnoreCase (textFilter))
            return " LIKE '" + searchText + "%'";
        if (CONTAINS.equalsIgnoreCase (textFilter))
            return " LIKE '%" + searchText + "%'";
        if (ENDS_WITH.equalsIgnoreCase (textFilter))
            return " LIKE '%" + searchText + "'";
        if (EXACT_MATCH.equalsIgnoreCase (textFilter))
            return " = '" + searchText + "'";
        throw new RuntimeException ("textFilter: " + textFilter + " not recognized!");
    }
    
    /**
     * 
     * Gets the searchText used as param value depending upon the TextFilter.
     * 
     */
    public static String getParamValue (String textFilter, String searchText) 
    {      
    	if (TextFilter.BEGINS_WITH.equalsIgnoreCase (textFilter))
            return searchText + "%";
        if (TextFilter.CONTAINS.equalsIgnoreCase (textFilter))
            return "%" + searchText + "%";
        if (TextFilter.ENDS_WITH.equalsIgnoreCase (textFilter))
            return "%" + searchText ;
        if (TextFilter.EXACT_MATCH.equalsIgnoreCase (textFilter))
            return  searchText ;
        
        throw new RuntimeException ("textFilter: " + textFilter + " not recognized!");
    }
    
    public static String getOperator(String textFilter) {

        if (TextFilter.EXACT_MATCH.equalsIgnoreCase (textFilter))
            return  " = " ;
        else 
            return " LIKE ";
                
    }
}
