/** 
 * 
 * Copyright (c) 2000-2002 NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/UserPreferences.java,v 1.1.4.1 2009/03/20 17:04:41 cdoan Exp $
 * 
 *  Modification History:
 *  $Log: UserPreferences.java,v $
 *  Revision 1.1.4.1  2009/03/20 17:04:41  cdoan
 *  Merged Head and GS branch
 *
 *  Revision 1.2  2009/02/06 11:44:51  atripathi
 *  converted into a wrapper class containing user preferences map, and method to get single value and the whole list from this map added.
 *
 *  Revision 1.1  2006/03/29 22:05:35  ranand
 *  moved files from folio
 *
 *  Revision 1.1  2006/03/28 21:20:06  aarora
 *  Creating an fdcommons folder
 *
 *  Revision 1.1  2004/09/15 13:05:24  ranand
 *  2.6 Baseline
 *
 * 
 */



package com.freightdesk.fdcommons;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Wrapper class for User Preferences
 * @author Amit Tripathi
 *
 */
public class UserPreferences
{
    public boolean alertUsrForShipmtChgsGoingToExtLink = true;
    
    private Map userPreferenceMap = new HashMap();

    public Map getUserPreferenceMap()
    {
        return userPreferenceMap;
    }

    public void setUserPreferenceMap(Map userPreferenceMap)
    {
        this.userPreferenceMap = userPreferenceMap;
    }
    /**
     * returns preference value for passed preference code
     * @param prefCode
     * @return
     */
    public String getPreference(String prefCode)
    {
        if (userPreferenceMap.size()>0 ) {
            List prefValue = (List)userPreferenceMap.get(prefCode);
            if (prefValue != null && prefValue.size()>0){
                return String.valueOf(prefValue.get(0));
            }
        }
        return null;
    }
    /**
     * return preference values list for passed preference code
     * @param prefCode
     * @return
     */
    public List getPreferences (String prefCode)
    {
        if (userPreferenceMap.size()>0 ) {
            List prefValueList = (List)userPreferenceMap.get(prefCode);
            return prefValueList;
        }
        return null;
    }
}
