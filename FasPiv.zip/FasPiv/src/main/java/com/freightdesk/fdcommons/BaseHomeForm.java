/** 
 * Copyright (c) 2000-2002 NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/BaseHomeForm.java,v 1.1 2007/07/16 17:56:06 ranand Exp $ 
 *
 *  Modification History:
 *  $Log: BaseHomeForm.java,v $
 *  Revision 1.1  2007/07/16 17:56:06  ranand
 *  Added new BaseForm Class
 *
 *
 */
package com.freightdesk.fdcommons;

public class BaseHomeForm extends BaseForm {
    
    private String sortOrder;
    
    private String sortColumn;

    public String getSortColumn()
    {
        return sortColumn;
    }

    public void setSortColumn(String sortColumn)
    {
        this.sortColumn = sortColumn;
    }

    public String getSortOrder()
    {
        return sortOrder;
    }

    public void setSortOrder(String sortOrder)
    {
        this.sortOrder = sortOrder;
    }

}
