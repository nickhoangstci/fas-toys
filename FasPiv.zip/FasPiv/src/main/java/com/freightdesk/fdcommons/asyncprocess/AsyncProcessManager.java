/** 
* Copyright (c) 2000-2002 NTELX 
*  All rights reserved. 
* 
* This software is the confidential and proprietary information of NTELX 
* ("Confidential Information").  You shall not disclose such Confidential Information 
* and shall use it only in accordance with the terms of the license agreement you entered 
* into with NTELX. 
* 
* 
*  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/asyncprocess/AsyncProcessManager.java,v 1.2.4.2 2008/12/11 13:50:44 mechevarria Exp $ 
* 
*  Modification History:
*  $Log: AsyncProcessManager.java,v $
*  Revision 1.2.4.2  2008/12/11 13:50:44  mechevarria
*  brought over from head
*
*  Revision 1.5  2008/05/19 10:38:41  ranand
*  minor changes
*
*  Revision 1.4  2008/05/17 06:26:33  ranand
*  added debug statements
*
*  Revision 1.3  2008/05/16 11:16:06  ranand
*  added new property in AsyncProcessLogModel
*
*  Revision 1.2  2007/03/12 15:47:59  dkumar
*  method for deleting all logs for a user
*
*  Revision 1.1  2007/03/02 10:11:40  dkumar
*  Classes For Time Consuming Asynchronous Requests
*
*/

package com.freightdesk.fdcommons.asyncprocess;

import java.util.List;

import org.apache.log4j.Logger;

import com.freightdesk.fdcommons.Credentials;
import com.freightdesk.fdcommons.GenericComparator;

/**
 * Manager for AJAX Asynchronous processing for time consumming framework
 * 
 * @author Deepak Kumar
 * @author Rajender Anand
 *  
 */
public class AsyncProcessManager
{
      protected AsyncProcessingLogDao asyncProcessingLogDao = new AsyncProcessingLogDao();
      protected static Logger logger = Logger.getLogger(AsyncProcessManager.class);
      public static final String PENDING_REQUEST_CACHE = "PENDING_REQUEST_CACHE";
      public static final int CACHE_ELEMENT_TIME_TO_LIVE = 3600;
            
      public AsyncProcessManager()
      {

      }
      
      public List retrieveHomeViewList(Credentials credentials, String serachStr) throws Exception
      {
          try
          {
              return asyncProcessingLogDao.retrieveHomeList(credentials.getUserId(), credentials.getDomainName(), serachStr);
          }
          catch (Exception e)
          {
              logger.debug("Exception in retrieveHomeViewList " + e);
              throw e;
          }
      }
      
      public void logResult(AsyncProcessingLogModel model, boolean success, String message, String method) {
      	model.complete(message, success);
        	try {
         	   this.updateAsyncProcessLogModel(model);
            } catch (Exception ex) {
         	   logger.error("Failed to update ASYNCPROCESSINGLOG during " + method);
            }
        }
      
      public void updateAsyncProcessLogModel(AsyncProcessingLogModel asyncProcessLogModel) throws Exception
      {
          try
          {
              asyncProcessingLogDao.update(asyncProcessLogModel);
          }
          catch (Exception e)
          {
              logger.debug("Exception in updateAsyncProcessLogModel " + e);
              throw e;
          }
      }

      public AsyncProcessingLogModel createAsyncProcessLog(AsyncProcessingLogModel asyncProcessLogModel) throws Exception
      {
          try
          {
              return asyncProcessingLogDao.create(asyncProcessLogModel);
          }
          catch (Exception e)
          {
              logger.debug("Exception in createAsyncProcessLog " + e);
              throw e;
          }
      }

      public void deleteAsyncProcessLog(long asyncProcessLogId) throws Exception
      {
          asyncProcessingLogDao.delete(asyncProcessLogId);
      }
      
      public void deleteAllAsyncProcessLog(Credentials credentials) throws Exception
      {
          asyncProcessingLogDao.deleteAll(credentials.getUserId(),credentials.getDomainName());
      }

      /**
       * Sorts Asynchronous Message by a given column.
       * 
       * @param ediMessageList
       *            Contains order models.
       * @param isAscending
       *            True/false.
       * @param fieldAttribute
       *            The attribute of the OrderModel on which the sort is done.
       */
      public void doSortByColumn(List ediMessageList, String fieldAttribute, boolean isAscending)
      {
          java.util.Collections.sort(ediMessageList, new GenericComparator(AsyncProcessingLogModel.class, fieldAttribute, isAscending));
      }


}
