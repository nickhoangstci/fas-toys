/** 
 * Copyright (c) 2000-2002 NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/BaseDao.java,v 1.7.4.8 2010/11/15 21:12:01 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: BaseDao.java,v $
 *  Revision 1.7.4.8  2010/11/15 21:12:01  mechevarria
 *  remove lobhandler
 *
 *  Revision 1.7.4.7  2010/04/30 22:33:39  mechevarria
 *  fix open jdbc
 *
 *  Revision 1.7.4.6  2010/03/01 14:21:23  mechevarria
 *  safer delete method
 *
 *  Revision 1.7.4.5  2009/02/27 16:19:56  mechevarria
 *  fix error in deleteRecord method from head
 *
 *  Revision 1.7.4.4  2009/02/25 13:39:52  mechevarria
 *  merge with head for new jdbc delete method
 *
 *  Revision 1.11  2009/02/24 22:36:58  aarora
 *  Added a delete method that also takes a long param
 *
 *  Revision 1.10  2008/12/11 13:49:36  mechevarria
 *  additional methods merged over from the gov_solutions branch
 *
 *  Revision 1.9  2007/10/01 19:37:04  ranand
 *  Added constants
 *
 *  Revision 1.8  2007/07/06 07:10:37  atripathi
 *  imports organized.
 *
 *  Revision 1.7  2007/02/13 11:59:49  atripathi
 *  null pointer check added
 *
 *  Revision 1.6  2006/10/31 14:02:40  dkumar
 *  no change (Test Cruise Control)
 *
 *  Revision 1.5  2006/10/31 08:35:24  dkumar
 *  no change
 *
 *  Revision 1.4  2006/10/30 16:47:53  dkumar
 *  no change
 *
 *  Revision 1.3  2006/04/10 20:10:39  ranand
 *  deprecated method using statement for exceute query
 *
 *  Revision 1.2  2006/04/10 20:08:26  ranand
 *  added new overloaded method executeQuery_long and executeQuery_String
 *
 *  Revision 1.1  2006/03/29 22:05:35  ranand
 *  moved files from folio
 *
 *  Revision 1.1  2006/03/28 21:20:06  aarora
 *  Creating an fdcommons folder
 *
 *  Revision 1.3  2005/10/15 00:06:31  pjain
 *  changed exception
 *
 *  Revision 1.2  2005/09/30 13:45:37  nsehra
 *  retrieve method added
 *
 *  Revision 1.1  2005/08/20 12:30:16  pjain
 *  centralized DAO package
 *
 *  Revision 1.12  2005/08/09 21:58:56  amrinder
 *  Some formatting changes
 *
 *  Revision 1.11  2005/06/27 22:35:25  amrinder
 *  Added another method to easily retrieve Strings in simple queries
 *
 *  Revision 1.10  2005/06/13 18:37:36  amrinder
 *  Added a method to conveniently execute queries that return a single NUMBER value
 *
 *  Revision 1.9  2005/04/21 21:57:45  amrinder
 *  Added a deleteRecord method
 *
 *  Revision 1.8  2005/04/15 09:06:45  ranand
 *  changed for retrieve optimization
 *
 *  Revision 1.7  2004/12/01 23:02:18  amrinder
 *  Added a method executeUpdate and improved the Javadoc
 *
 *  Revision 1.6  2004/11/23 17:53:23  asaxena
 *  removed extraneous import statements
 *
 *  Revision 1.5  2004/09/23 10:59:06  biju
 *  exception handling improvement
 *
 *  Revision 1.4  2004/09/23 09:51:25  biju
 *  moved the LOB handling to LOBHandler classs
 *
 *  Revision 1.3  2004/09/15 13:03:45  ranand
 *  2.6 Baseline
 */

package com.freightdesk.fdcommons;


import java.math.BigInteger;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;


/**
 * BaseDao is the superclass of all DAOs (Data Access Objects) used in Folio.
 *
 * <P>Extending BaseDAO primarily gives the following features to a DAO:
 * <OL>
 * <LI> A ready method to get a connection, using getConnection()
 * <LI> A logger based on concrete class (logger is not defined as static)
 * <LI> Ability to get the next ID of any sequency by invoking getNextID ("SHIPMENTID")
 * <LI> Ability to easily run DB commands by calling executeUpdate ()
 * <LI> Ability to easily handle binary data
 * </OL>
 *
 * @author Ravi Kant Gupta
 * @author Biju Joseph
 * @author Amrinder Arora
 */
public class BaseDao 
{
    /** A logger */
    protected final Logger logger = Logger.getLogger(BaseDao.class);


    /** 
     * Used in SQLQuery  set in the QueryContext object. 
     * It is replaced by the Table Column Name before executing SQL 
     */
    public static final String ORDER_BY_COLUMN = "$COLUMN_NAME$";

    /**
     *  Used in SQLQuery  set in the QueryContext object. 
     *  It is replaced by the Sorting Order before executing SQL.
     */
    public static final String ORDER = "$ORDER$";

    
    /** Gets a connection to the DB */
    public Connection getConnection() 
        throws SQLException 
    {
        return ConnectionUtil.getConnection();
    }


    /**
     * Deletes a record by using the specified passed DML.
     * This utility method can be called from concrete subclasses
     * to write concise methods for deletions.  For example,
     * delete (entityId) can be written as:
     * deleteRecord ("DELETE FROM ENTITY WHERE ENTITYID = ?", ENTITYID); 
     * 
     * <P>It ensures that a single record is deleted, and rolls back the transaction
     * if multiple records get deleted.
     *
     * <P>If multiple records need to be deleted, the callee 
     * should use the "executeUpdate" method instead.
     *
     * @param deleteQuery The query string (DML) that should be used for deleting 
     * @param idValue The ID of the record that will be set as the first argument in the prepared statement
     * @throws IllegalArgumentException If the query causes multiple records to be deleted 
     */
    public void deleteRecord (String deleteQuery, long idValue) 
        throws SQLException 
    {
        PreparedStatement pStmt = null;
        Connection connection = null;
        try {
            connection = getConnection();
            pStmt = connection.prepareStatement(deleteQuery);
            pStmt.setLong(1, idValue);
            int rVal = pStmt.executeUpdate();
            if (rVal > 1) {
                logger.warn ("deleteRecord() deleted multiple records, attempting rollback");
                try {
                    connection.rollback();
                } catch (SQLException sqEx) {
                    logger.error("deleteRecord() deleted multiple records, and unable to rollback TX", sqEx);
                }
                throw new IllegalArgumentException ("Statement " + deleteQuery + 
                        " caused " + rVal + " records to be deleted.  Attempted rollback.");
            }
        } catch (SQLException ex) {
            logger.error("Exception in deleteRecord: " + deleteQuery, ex);
            throw ex;
        } finally {
            ConnectionUtil.closeResources(connection, pStmt, null);
        }
    }
    
    /*
     * Convenience method for updating records
     */
    
    public int executeUpdate(String query, HashMap<Integer, Object> params) {
    	PreparedStatement pStmt = null;
		Connection connection = null;
    	
    	int numRowUpdate = 0;
    	
    	try {
    		connection = getConnection();
    		pStmt = connection.prepareStatement(query);
    		pStmt = bindParams(pStmt,params);
    		numRowUpdate = pStmt.executeUpdate();
    		
    		pStmt.close();
			connection.close();
    	} catch (Exception ex) {
    		//logger.error("Failed to execute update, returning -1");
    		//ex.printStackTrace();
			logger.error("Exception - Failed to execute update, returning -1: " + ex.getMessage());
    		numRowUpdate = -1;
    	} finally {
			ConnectionUtil.closeResources(connection, pStmt, null);
		}
    	
    	return numRowUpdate;
    }

    /**
     * Gets the next ID from the specified sequence.
     *
     * @throws SQLException If there is any problem accessing the database
     */
    public long getNextID(String argSequenceName) 
        throws SQLException 
    {
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        long id = -1;
        try {
            conn = getConnection();
            String query = "SELECT " + argSequenceName + ".NEXTVAL FROM DUAL";
            logger.debug(argSequenceName + " sequnece Query: " + query);
            stmt = conn.createStatement();
            rs = stmt.executeQuery(query);
            if (rs.next()) {
                id = rs.getLong(1);
                logger.debug("Next " + argSequenceName + " is = " + id);
            }
        }
        catch (SQLException e) {
            logger.error("getNextID(): " + e.getMessage(), e);
            throw e;
        }
        finally {
            ConnectionUtil.closeResources(conn, stmt, rs);
        }
        return id;
    }

    /**
     * Checks if the specified XPath is to be considered for this project.
     *
     * @param xPath The XPath to check
     * @return true if the xpath is used in this project (that is, the entity at the xpath
     * should be persisted and retrieved).
     * @return false if the xpath is not used in this project (that is, the entity
     * at the xpath should NOT be persisted or retrieved).
     */
    public boolean isXPathIncluded (String xpath)
    {
        ProjectMetaData projectMetaData = ProjectMetaData.getInstance(); 
        return projectMetaData.isXPathIncluded(xpath);
    }

	/** 
	 * Gets a List of @DataBaseRowModel.  
	 * The query must be completely ready to execute,
	 * If the result set is empty ,empty List will be returned
	 * All database columns retrieved as String.
	 */    
	public List<DataBaseRowModel> retrieve(String query)
		throws SQLException
	{
		PreparedStatement pStmt = null;
		ResultSet rs = null;
		Connection connection = null;
		List<DataBaseRowModel> dataBaseTable = new ArrayList<DataBaseRowModel>();
		try
		{
			connection = getConnection();
			pStmt = connection.prepareStatement(query);
			rs = pStmt.executeQuery();
			ResultSetMetaData rsmd = rs.getMetaData();
			int numberOfColumns = rsmd.getColumnCount();
			while (rs.next())
			{
				DataBaseRowModel dataBaseRowModel = new DataBaseRowModel() ;
				String[] dataBaseRow = new String[numberOfColumns];
				for(int i=1;i<=numberOfColumns;i++)
				{
					dataBaseRow[i-1] = ((rs.getString(i)!=null)?rs.getString(i):"");
				}
				dataBaseRowModel.setDataBaseRow(dataBaseRow);
				dataBaseTable.add(dataBaseRowModel);
			}
		}
		catch (SQLException sqEx)
		{
			logger.error ("Error in query: " + query);
			throw sqEx;
		}
		catch (Exception e) {
			   logger.error ("Error in query: " + query);
			   throw new RuntimeException(e);
		}
		finally
		{
			ConnectionUtil.closeResources(connection, pStmt, rs);
		}
		return dataBaseTable;
	}

    /**
     * executes a query using prepared statement and return a long result  
     * @param query
     * @param arg1
     * @return
     */
    public long executeQuery_long(String query, HashMap<Integer, Object> params) {
        long retVal = 0;
        
        Connection connection = null;
        PreparedStatement  pStmt  = null;
        ResultSet rs = null;
        
        try {
            connection = ConnectionUtil.getConnection();
            pStmt = connection.prepareStatement(query);
            pStmt = bindParams(pStmt,params);
            rs = pStmt.executeQuery();
            
            if(rs.next())
            	retVal = rs.getLong(1);
        }
        catch (Exception ex) {
            //logger.error("Failed to run query, returning -1");
            //ex.printStackTrace();
			logger.error("Exception - Failed to run query, returning -1: " + ex.getMessage());
            retVal = -1;
        }
        finally {
              ConnectionUtil.closeResources(connection,pStmt,rs);
        }
        return retVal;
    }
    
    
    /**
     * executes a query using prepared statement and return a String result  
     * @param query
     * @param arg1
     * @return
     */
    public String executeQuery_String(String query, long arg1[])
        throws SQLException
    {
        String retVal = null;
        
        Connection connection = null;
        PreparedStatement  stmt  = null;
        ResultSet  rs    = null;
        try {
            connection = ConnectionUtil.getConnection();
            stmt = connection.prepareStatement(query);
            for (int i = 1; i<=arg1.length; i++)
                stmt.setLong(i, arg1[i-1]);
            rs   = stmt.executeQuery();
            if (!rs.next()) {
                throw new NoRecordFoundException ("Query returned no record: " + query);
            }
            
            retVal = rs.getString(1);
            
            if (rs.next()) {
                throw new IllegalArgumentException("Query returned more than one record: " + query);
            }
        }
        catch (SQLException e)
        {
            logger.error("Error in executing query: "+query,e);
            throw e;
        }
        finally {
              ConnectionUtil.closeResources(connection,stmt,rs);
        }
        return retVal;
    }
    
    /*
     * Convenience method to prepared a dynamically created statement and still use bind variables
     */
    public PreparedStatement bindParams(PreparedStatement pStmt, HashMap<Integer, Object> paramMap) {
    	try {
    		for (Map.Entry<Integer, Object> entry : paramMap.entrySet()) {
    			String className = entry.getValue().getClass().getName();
    			
    			// bind based on object type
    			if(className.equalsIgnoreCase("java.lang.String")) {
    				logger.debug("Binding String "+(String) entry.getValue()+" to param "+ entry.getKey());
    				pStmt.setString(entry.getKey(), (String) entry.getValue());
    				
    			} else if(className.equalsIgnoreCase("java.lang.Integer")) {
    				logger.debug("Binding Integer "+(Integer) entry.getValue()+" to param "+ entry.getKey());
    				pStmt.setInt(entry.getKey(), (Integer) entry.getValue());
    				
    			} else if(className.equalsIgnoreCase("java.lang.Long")) {
    				logger.debug("Binding Long "+(Long) entry.getValue()+" to param "+ entry.getKey());
    				pStmt.setLong(entry.getKey(), (Long) entry.getValue());
    				
    			} else if(className.equalsIgnoreCase("java.math.BigInteger")) {
    				logger.debug("Binding BigInteger "+((BigInteger) entry.getValue()).longValue()+" to param "+ entry.getKey());
    				pStmt.setLong(entry.getKey(), ((BigInteger) entry.getValue()).longValue());
    				
    			} else if(className.equalsIgnoreCase("java.sql.Timestamp")) {
    				logger.debug("Binding Timestamp "+(Timestamp) entry.getValue()+" to param "+ entry.getKey());
    				pStmt.setTimestamp(entry.getKey(), (Timestamp) entry.getValue());
    				
    			} else {
    				logger.warn("Did not bind " + className + " to param " + entry.getKey());
    			}
    		}
    	} catch (Exception ex) {
    		//ex.printStackTrace();
			logger.error("Exception: " + ex.getMessage());
    	}
    	return pStmt;
    }
    
    /**
     * executes a query using prepared statement and return a String result  
     * @param String query
     * @param String arg1
     * @return
     */
    public String executeQuery_String(String query, String arg1[])
        throws SQLException
    {
        String retVal = null;
        logger.debug("executeQuery_String(String,String[]): begin");
        Connection connection = null;
        PreparedStatement  stmt  = null;
        ResultSet  rs    = null;
        try {
            connection = ConnectionUtil.getConnection();
            stmt = connection.prepareStatement(query);
            for (int i = 1; i<=arg1.length; i++)
                stmt.setString(i, arg1[i-1]);
            rs   = stmt.executeQuery();
            if (!rs.next()) {
                throw new NoRecordFoundException ("Query returned no record: " + query);
            }
            
            retVal = rs.getString(1);
            
            if (rs.next()) {
                throw new IllegalArgumentException("Query returned more than one record: " + query);
            }
        }
        catch (SQLException e)
        {
            logger.error("Error in executing query: "+query,e);
            throw e;
        }
        finally {
              ConnectionUtil.closeResources(connection,stmt,rs);
        }
        return retVal;
    }
    /**
     * executes a query using prepared statement and return a long result  
     * @param String query
     * @param String arg1
     * @return
     */
    public long executeQuery_long(String query, String arg1[])
        throws SQLException
    {
        long retVal = -1;
        
        Connection connection = null;
        PreparedStatement  stmt  = null;
        ResultSet  rs    = null;
        try {
            connection = ConnectionUtil.getConnection();
            stmt = connection.prepareStatement(query);
            for (int i = 1; i<=arg1.length; i++)
                stmt.setString(i, arg1[i-1]);
            
                
            rs   = stmt.executeQuery();
            if (!rs.next()) {
                throw new NoRecordFoundException ("Query returned no record: " + query);
            }
            retVal = rs.getLong(1);
            if (rs.next()) {
                throw new IllegalArgumentException("Query returned more than one record: " + query);
            }
        }
        catch (SQLException e)
        {
            logger.error("Error in executing query: "+query,e);
            throw e;
        }
        finally {
              ConnectionUtil.closeResources(connection,stmt,rs);
        }
        return retVal;
    }

    // MBEGLEY: for partition
    public Timestamp getCurrentTimestamp()
	        throws SQLException
	    {
	        Connection conn = null;
	        PreparedStatement  stmt  = null;
	        ResultSet rs = null;
	        Timestamp ts = null;
	        try
	        {
	            conn = getConnection();
	            String query = "SELECT SYSDATE FROM DUAL";
	            logger.debug("SYSDATE query:" + query);
	            stmt = conn.prepareStatement(query);
	            rs = stmt.executeQuery();
	            if (rs.next())
	            {
	                ts = rs.getTimestamp(1);

	            }
	            //long millis = ts.getTime();
	            //long oneYearInMillis = (60000 * 3600000) * 365;
	            //ts.setTime(millis + oneYearInMillis);
	        }
	        catch (SQLException e)
	        {
	            logger.error("getCurrentTimestamp(): " + e.getMessage(), e);
	            throw e;
	        }
	        finally
	        {
	            ConnectionUtil.closeResources(conn, stmt, rs);
	        }
	        return ts;
    }
    
    
	@SuppressWarnings("unchecked")
	public static <T> Set<T> filterActiveList(Set<T> set, Session s) {
		Query filterQuery = s.createFilter(set, "where this.status = 'ACTIVE'");
		return new HashSet<T>(filterQuery.list());
	}
    
}
