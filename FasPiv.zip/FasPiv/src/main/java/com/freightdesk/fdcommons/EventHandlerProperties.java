/** 
 * 
 * Copyright (c) 2000-2002 NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/EventHandlerProperties.java,v 1.1 2006/03/29 23:57:54 aarora Exp $
 * 
 *  Modification History:
 *  $Log: EventHandlerProperties.java,v $
 *  Revision 1.1  2006/03/29 23:57:54  aarora
 *  new files into fdcommons
 *
 *  Revision 1.4  2006/03/29 22:53:13  aarora
 *  Due to repackaging of FormatDate
 *
 *  Revision 1.3  2006/03/28 21:23:01  aarora
 *  Repackaging of fdcommons
 *
 *  Revision 1.2  2005/01/21 13:53:43  pjain
 *  Added SMS handling
 *
 *  Revision 1.1  2004/09/15 13:05:24  ranand
 *  2.6 Baseline
 *
 * 
 */

package com.freightdesk.fdcommons;

public class EventHandlerProperties {
	private String subject; 
	private String message;
	private String senderName;
	private Object content;
	private String contentType;
    private String attachedFileName;
    private String priority;

	private String tempSubject = "Change Status in ";
    private String tempMessage = "The status of object changed from this to that";

    /**
     * Constructor for EventHandlerProperties
     */
    public EventHandlerProperties(String communicationMethodTypeCode) {
        super();
        if(communicationMethodTypeCode.equals(LcpConstants.CommunicationMethodTypes.EMAIL)) {
        	this.subject = tempSubject;
        	this.message = tempMessage;
        	this.contentType = "text/plain";
        }
    	if(communicationMethodTypeCode.equals(LcpConstants.CommunicationMethodTypes.FAX)) {
    		this.subject = tempSubject;
    		this.message = tempMessage;
    		this.senderName = "FreightDesk Technologies";
    		this.contentType = "text/plain";
    	}
    	if(communicationMethodTypeCode.equals(LcpConstants.CommunicationMethodTypes.SMS)) {
    		this.message = tempMessage;
    		this.senderName = "FDfolio";
    		this.contentType = "text";
    	}
    }
    
	/**
		* Constructor for EventHandlerProperties
		*/
   public EventHandlerProperties(Object content ,String attachedFileName) {
		this.content = content;
		this.attachedFileName = attachedFileName;
      }
	public String getSubject() {
    	return subject;
    }
    
    public void setSubject(String argSubject) {
    	subject = argSubject;
    }
    
    public String getMessage() {
    	return message;
    }
    
    public void setMessage(String argMessage) {
    	message = argMessage;
    }
    
    public String getSenderName() {
    	return senderName;
    }
    
    public void setSenderName(String argSenderName) {
    	senderName = argSenderName;
    }
    /**
     * @return content object
     */
    public Object getContent() {
        return content;
    }

    /**
     * @return content type
     */
    public String getContentType() {
        return contentType;
    }

    /**
     * @param contentObject
     */
    public void setContent(Object contentObject) {
        content = contentObject;
    }

    /**
     * @param argContentType
     */
    public void setContentType(String argContentType) {
        contentType = argContentType;
    }

    /**
     * @return attachedFileName
     */
    public String getAttachedFileName() {
        return attachedFileName;
    }

    /**
     * @param argAttachedFileName
     */
    public void setAttachedFileName(String argAttachedFileName) {
        attachedFileName = argAttachedFileName;
    }

    /**
     * @return priority
     */
    public String getPriority()
    {
        return priority;
    }

    /**
     * @param argPriority
     */
    public void setPriority(String argPriority)
    {
        priority = argPriority;
    }

}

