package com.freightdesk.fdcommons.taglib;

import java.util.Collection;
import java.util.Iterator;
import java.util.Locale;
import com.opensymphony.xwork2.ActionSupport;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.Tag;
import javax.servlet.jsp.tagext.TagSupport;

import org.apache.log4j.Logger;

import com.freightdesk.fdcommons.OptionBean;

public class i18nCollection extends TagSupport implements Tag {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;


	/**
	 * a log4j Logger
	 */
	protected Logger logger = Logger.getLogger(getClass());


	protected Collection collection;

	protected String propertyValue;
	
	//public static org.apache.struts.util.MessageResources messages = org.apache.struts.util.MessageResources.getMessageResources("WEB-INF/resources/ApplicationResources");
        
	/**
	 * Processes the start of the tag.
	 */
	public int doStartTag() throws JspException {
		try {

			JspWriter out = pageContext.getOut();
			out.println("<START TAG>");
			// Iterate the collection of Option Beans :0
			//<option value="JESSD">DIRECT JESS</option>
			// todo:internationalize label????????
			 for (Iterator it = collection.iterator (); it.hasNext();) {
				 OptionBean ob = (OptionBean) it.next();
				
				 if(propertyValue != null){

					 if(propertyValue.equalsIgnoreCase(ob.getValue())){
						 out.println("<option value=\"" + ob.getValue() + "\" selected=\"true\">" + ob.getLabel() + "</option>");
					 } else {
						 out.println("<option value=\"" + ob.getValue() + "\">" + ob.getLabel() + "</option>");
					 }
				 } else {
					 out.println("<option value=\"" + ob.getValue() + "\">" + ob.getLabel() + "</option>");
				 }
				 
				}
			

		} catch (Exception ioe) {
			logger.error("Exception while writing to client", ioe);
			throw new JspException("IOException while writing to client"
					+ ioe.getMessage());
		}
		return SKIP_BODY;
	}

	/* ***
	public String internationalizeLabel(HttpServletRequest request, String key, String[] params)
	{	
		String localLabel = null;
		try{
			System.out.println("Begin: internationalizeLabel");
			Locale locale = request.getLocale();
			localLabel = messages.getMessage(locale, key, params);
			if(localLabel == null || "".equals(localLabel))
				localLabel = key;
		}
		catch(Exception e)
		{
			System.out.println("Error:"+ e.getMessage());
			return key;
		}
		return localLabel;
	}
        *** */
        
	public void setCollection(Collection collection) {
		this.collection = collection;
	}

	public void setPropertyValue(String propertyValue) {
		this.propertyValue = propertyValue;
	}


}
