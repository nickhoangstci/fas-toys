/** 
 * Copyright (c) 2000-2002 NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/BasicValidateAction.java,v 1.1.4.1.2.5 2010/10/04 15:53:05 mechevarria Exp $ 
 * 
 *  Modification History:
 *  $Log: BasicValidateAction.java,v $
 *  Revision 1.1.4.1.2.5  2010/10/04 15:53:05  mechevarria
 *  use url decoding on cookie descrypting
 *
 *  Revision 1.1.4.1.2.4  2009/03/11 14:37:06  mechevarria
 *  removed encryption of userid parameter
 *
 *  Revision 1.1.4.1.2.3  2009/03/10 19:41:14  mechevarria
 *  update validation to backup reading from request if reading from cookies fails
 *
 *  Revision 1.1.4.1.2.2  2009/01/21 16:22:10  mechevarria
 *  updates for new version of struts
 *
 *  Revision 1.1.4.1.2.1  2008/12/11 13:50:44  mechevarria
 *  brought over from head
 *
 *  Revision 1.6  2008/07/29 06:55:04  atripathi
 *  now we use BasicValidateAction to always fetch session from cookie.
 *
 *  Revision 1.5  2008/04/11 11:30:04  atripathi
 *  handleApplicationError in ApplicationErrorHandler changed to accept additional credentials object and used here.
 *
 *  Revision 1.4  2007/12/18 11:05:55  dkumar
 *  Expire page consolidaion for Suite
 *
 *  Revision 1.3  2007/09/12 16:30:34  dkumar
 *  Setting Locale for i18n
 *
 *  Revision 1.2  2007/05/24 15:15:58  dkumar
 *  minor change
 *
 *  Revision 1.1  2007/04/12 16:30:46  dkumar
 *  base version
 *
 */
/**
 * Copyright (c) 2000-2002 NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 */
package com.freightdesk.fdcommons;

import java.io.IOException;
import java.net.URLDecoder;
import java.util.Enumeration;
import java.util.Locale;
import java.util.StringTokenizer;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
//import org.apache.struts.action.Action;
//import org.apache.struts.action.ActionErrors;
//import org.apache.struts.action.ActionForm;
//import org.apache.struts.action.ActionForward;
//import org.apache.struts.action.ActionMapping;
//import org.apache.struts.action.ActionMessage;
//import org.apache.struts.action.ActionMessages;

/**
 * @author Deepak Kumar
 * 
 */
//public abstract class BasicValidateAction extends Action {
//	protected Logger logger = Logger.getLogger(getClass());
//
//	/** A encryption manager to aid in setting and using cookies */
//	protected EncryptionManager encryptionManager = new EncryptionManager();
//
//	/** The execute method which every concrete sub class should implement */
//	public abstract ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response, Credentials credentials) throws java.lang.Exception;
//
//	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
//		logger.debug("execute :");
//		HttpSession session = request.getSession();
//		// Sets the preferred LOCALE
//		setPreferredLocale(request);
//
//		SessionStore store = null;
//
//		if (!hasValidLicense()) {
//			logger.debug("License for product is not valid or expired, redirecting to login page");
//			ActionErrors errors = new ActionErrors();
//			errors.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("error.licenseExpired"));
//			this.saveErrors(request, errors);
//			store.invalidateSessions(request);
//			return mapping.findForward("licenseExpired");
//		}
//
//		Credentials credentials = (Credentials) store.get(SessionKey.CREDENTIALS);
//		if (credentials == null) {
//			logger.debug("User is not logged in, redirecting to login page");
//			ActionErrors errors = new ActionErrors();
//			errors.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("error.sessionExpired"));
//			this.saveErrors(request, errors);
//			store.invalidateSessions(request);
//			try {
//				response.sendRedirect("/expire.jsp?");
//				return null;
//			} catch (IOException e) {
//				logger.debug("Exception in Redirecting to Expire page  " + e);
//			}
//		}
//
//		// checks that user is already login then forward to login page
//		if (session.getAttribute("logout.reason.loggedInFromAnotherLoc") != null) {
//			logger.debug("User has logged in from another page, logging out from here, and redirecting to login page");
//			ActionErrors errors = new ActionErrors();
//			errors.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("error.sessionExpired.loggedInFromAnotherLoc"));
//			this.saveErrors(request, errors);
//			store.invalidateSessions(request);
//			try {
//				response.sendRedirect("/expire.jsp?");
//				return null;
//			} catch (IOException e) {
//				logger.debug("Exception in Redirecting to Expire page  " + e);
//			}
//		}
//
//		try {
//			return this.execute(mapping, form, request, response, credentials);
//
//		} catch (Throwable e) {
//			logger.error("Exception raised in execute, redirecting to home page", e);
//
//			// Lets the application error handler handle the top level exception
//			ApplicationErrorHandler.handleApplicationError(e, credentials);
//			session.setAttribute("LAST_UNEXPECTED_EXCEPTION", e);
//
//			// Added to avoid self looping
//			logger.debug("Exception was invoked from :" + store.get(SessionKey.CURRENT_TAB));
//			return mapping.findForward("error");
//		}
//	}
//
//	private String getValueFromEncrypted(String encrypted) {
//		String result = null;
//		if (encrypted != null) {
//			try {
//			  encrypted = URLDecoder.decode(encrypted,"UTF-8");
//			  result = new String(encryptionManager.decryptWithSC(Base64.decode(encrypted)));
//			} catch (Exception ex) {
//				ex.printStackTrace();
//			}
//		}
//		return result;
//	}
//
//	/**
//	 * Checks License for the current product
//	 * 
//	 * @return
//	 */
//	public abstract boolean hasValidLicense();
//
//	/**
//	 * Sets the locale and HTML orientation. Uses the #getPreferredLocale to get
//	 * the user preferred locale. Sets the locale on the request/session. Uses
//	 * java.awt.ComponentOrientation to get the HTML direction. Sets the HTML
//	 * direction as a session attribute if the user is in session. Sets the HTML
//	 * direction as a request attribute if the user is not in session.
//	 */
//	protected void setPreferredLocale(HttpServletRequest request) {
//		logger.debug("setPreferredLocale: begin()");
//		String htmlOrientation = "LTR";
//		try {
//			Locale locale = getPreferredLocale(request);
//			setLocale(request, locale);
//			java.awt.ComponentOrientation co = java.awt.ComponentOrientation.getOrientation(locale);
//			if (!co.isLeftToRight()) {
//				htmlOrientation = "RTL";
//			}
//		} catch (Exception ignored) {
//			logger.debug("Exception setting HTML orientation, ignoring " + ignored);
//		}
//		logger.debug("HTML Orientation: " + htmlOrientation);
//		HttpSession session = request.getSession(false);
//		if (session != null) {
//			session.setAttribute("LANGUAGE_DIRECTION", htmlOrientation);
//		} else {
//			request.setAttribute("LANGUAGE_DIRECTION", htmlOrientation);
//		}
//	}
//
//	/**
//	 * Gets the user preferred locale from the user's browser.
//	 */
//	protected Locale getPreferredLocale(HttpServletRequest request) {
//		try {
//			Enumeration acceptedLanguagesEnum = request.getHeaders("Accept-Language");
//
//			if ((acceptedLanguagesEnum == null) || (!acceptedLanguagesEnum.hasMoreElements())) {
//				// cant do much here
//				logger.debug("No choices in accepted languages, returning default");
//				return Locale.getDefault();
//			}
//
//			// Although declared as an enumeration, at least in IE6.0, the
//			// entire
//			// information comes back in one String, which is the only element
//			// of Enumeration
//			String acceptedLanguagesString = (String) (acceptedLanguagesEnum.nextElement());
//
//			// the format of this string in IE6.0 is:
//			// lang1,lang2;q=w2,lang3;q=w3,lang4;q=w4,...
//
//			StringTokenizer locales = new StringTokenizer(acceptedLanguagesString, ",");
//			// keeps trying to set the locale until successful,
//			// if successful, method returns
//			// if unsuccessful, waits for next accepted language
//			while (locales.hasMoreElements()) {
//				String locale = locales.nextToken();
//				// ignore IE's q=0.x part
//				if (locale.indexOf(';') >= 0)
//					locale = locale.substring(0, locale.indexOf(';'));
//				logger.debug("locale accepted by client: " + locale);
//				try {
//					if (locale.length() >= 2) {
//						locale = locale.substring(0, 2);
//						logger.debug("Only considering language part of locale: " + locale);
//					}
//					Locale newLocale = new Locale(locale);
//					logger.debug("returning user's locale as: " + newLocale);
//					return newLocale;
//				} catch (Throwable t) {
//					logger.debug("unable to set locale to: " + locale);
//				}
//			}
//		} catch (Throwable t) {
//			logger.error("Exception in setting preferred locale", t);
//		}
//		return Locale.getDefault();
//	}
//
//}
