package com.freightdesk.fdcommons;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;
import java.util.Vector;

import javax.naming.InitialContext;
import javax.sql.DataSource;

import org.apache.log4j.Logger;


/**
* Implementation of a database connection pool.
*
* @author Amit Tripathi
*/
public class ConnectionPool
{
    // the map of the instances of this singleton
    // instances of ConnectionPool for each DB URI
    private static Map _instances = new HashMap();

    /** A logger */
    public static transient Logger logger = Logger.getLogger("com.freightdesk.fdmonitor.common.ConnectionPool");

    /**
    * The Vector allows us to store a number of connection objects and to retrieve them
    * safely. The Vector object is synchronized so that multiple threads requesting
    * connections will not get a reference to the same connection object.
    */
    private Vector availableConnections;

    private Timer timer = new Timer();


    /**
    * Number of connections to establish in the connection pool.
    */
    private int mNumberOfConnections = 4;

    private Vector inuseConnections;
    
    /** Creates an instance. */
    private ConnectionPool()
    {
    }

    /**
    * For a Singleton pattern the constructor is private so that the instance of
    * this class is managed by the static getInstance method.
    *
    * @see #getInstance()
    */
    private ConnectionPool(String dbURI, String sourceSubType, String dbUserName, String dbPassword, long maxConnections, long maxIdleTime)
    {
        prepareConnectionPool(dbURI, sourceSubType, dbUserName, dbPassword, maxConnections, maxIdleTime);
        TimerTask timerTask = new TimerTask() {
            public void run()
            {
                checkIdleConnection();
            }
        };
        if (maxIdleTime > 0)
            timer.schedule(timerTask, maxIdleTime * 1000 * 60 / 2, maxIdleTime * 1000 * 60 / 2);
    }

    private void prepareConnectionPool(String dbURI, String sourceSubType, String dbUserName, String dbPassword, long maxConnections, long maxIdleTime)
    {
        Connection tempConnection;
        // First load the database driver by reading the driver from the properties file.
        try {
            String dbDriverName = null;
            if (LcpConstants.WatchPointSubSourceType.ORACLE.equalsIgnoreCase(sourceSubType) || LcpConstants.WatchPointSubSourceType.JNDI_NAME.equalsIgnoreCase(sourceSubType))
                dbDriverName = "oracle.jdbc.driver.OracleDriver";
            else if (LcpConstants.WatchPointSubSourceType.MYSQL.equalsIgnoreCase(sourceSubType))
                dbDriverName = "com.mysql.jdbc.Driver";
            else if (LcpConstants.WatchPointSubSourceType.SQLSERVER.equalsIgnoreCase(sourceSubType))
                dbDriverName = "com.microsoft.jdbc.sqlserver.SQLServerDriver";
            
            Class.forName(dbDriverName);
            mNumberOfConnections = new Long(maxConnections).intValue();
            inuseConnections = new Vector();
            availableConnections = new Vector(mNumberOfConnections);
            InitialContext ic = null;
            DataSource dataSource = null;
            for (int i = 0; i < mNumberOfConnections; i++) {
                
                if(LcpConstants.WatchPointSubSourceType.JNDI_NAME.equalsIgnoreCase(sourceSubType)){
                    String lookupName = "java:" + dbURI;
                    logger.debug ("checkOut(): begin, lookupName: " + lookupName);
                    ic = new InitialContext();
                    dataSource = (DataSource) ic.lookup(lookupName);
                    tempConnection = dataSource.getConnection();
                } else {
                    tempConnection = DriverManager.getConnection(dbURI, dbUserName, dbPassword);
                }
                ConnectionProperties connectionProperties = new ConnectionProperties();
                connectionProperties.setConnection(tempConnection);
                connectionProperties.setIdleTime(maxIdleTime);
                connectionProperties.setLastAccessTime(System.currentTimeMillis());
                availableConnections.addElement(connectionProperties);
            }
        } catch (Exception setupException) {
            logger.error("Unable to setup JDBC connection pool. " + setupException);
        }
    }

    /**
     * checks for idle connections and closes them
     */
    private void checkIdleConnection()
    {
        logger.debug("In checkIdleConnection() at time:" + System.currentTimeMillis());
        Iterator iterator = this.availableConnections.iterator();
        while (iterator.hasNext()) {
            ConnectionProperties connectionProperties = (ConnectionProperties) iterator.next();
            long currentTime = System.currentTimeMillis();
            long lastAccessTime = connectionProperties.getLastAccessTime();
            long connectionIdleTime = currentTime - lastAccessTime;
            if (connectionIdleTime > (connectionProperties.getIdleTime() * 60 * 1000)) {
                try {
                    Connection connection = connectionProperties.getConnection();
                    if (!connection.isClosed()) {
                        connectionProperties.getConnection().close();
                    }
                } catch (Exception e) {
                    logger.warn("Exception in closing idle connection" + e);
                }
            }
        }
    }

    /**
     * Gets the instance for this DBURI.
     * The first time this method is called for that DBURI,
     * it creates an instance, and puts it in the internal map.
     * Next time, it returns the already created instance for that DBURI.    
     */
    public static ConnectionPool getInstance(String dbURI, String sourceSubType, String dbUserName, String dbPassword, long maxConnections, long maxIdleTime, boolean isReset)
    {
        logger.debug("ConnectionPool.getInstance: " + dbURI);
        ConnectionPool lrd = (ConnectionPool) (_instances.get(dbURI + dbUserName));
        if (isReset == true){
            return lrd;
        }
        if (lrd != null){            
            if (lrd.availableConnections.size()+lrd.inuseConnections.size() <= maxConnections ) {
                _instances.remove(dbURI + dbUserName);
                lrd = new ConnectionPool(dbURI, sourceSubType, dbUserName, dbPassword, maxConnections, maxIdleTime);
                _instances.put(dbURI + dbUserName, lrd);
            }
            return lrd;
        }            
        // synchronizing on the lock.  There is nothing magical about lock,
        // just need some object to synchronize on, and lock is a static attribute
        // and hence available in this method.
        synchronized (ConnectionPool.class) {
            logger.debug("In the synchronized block");
            // previous call to get was outside of synchronized block, must call it again
            lrd = (ConnectionPool) (_instances.get(dbURI + dbUserName));
            if (lrd == null) {
                logger.debug("Creating new instance of ConnectionPool for " + dbURI);
                lrd = new ConnectionPool(dbURI, sourceSubType, dbUserName, dbPassword, maxConnections, maxIdleTime);
                _instances.put(dbURI + dbUserName, lrd);
            }
            logger.debug("leaving the synchronized block");
        }
        return lrd;
    }

    /**
    * Returns a database connection from the pool or new Connection from passed parameters if none is available.
    *
    * @return           Database connection or null if none available.
    */
    public Connection checkOut(String dbURI, String dbUserName, String dbPassword, String sourceSubType)
        throws SQLException
    {
        logger.debug("checkOut() begins...");
        logger.debug("available Connections = " + availableConnections.size());
        logger.debug("max connections = " + mNumberOfConnections);
        logger.debug("In use connections = " + inuseConnections.size());
        Connection dbConnection = null;
        ConnectionProperties connectionProperties = null;
        if (this.availableConnections.size() > 0) {
            connectionProperties = (ConnectionProperties) this.availableConnections.firstElement();
            dbConnection = connectionProperties.getConnection();            
            try {
                if (dbConnection.isClosed()) {
                    dbConnection = checkOut(dbURI, dbUserName, dbPassword, sourceSubType);
                } else {
                    this.availableConnections.remove(connectionProperties);
                    this.inuseConnections.add(connectionProperties);
                    // dbConnection.getMetaData().getTableTypes();
                }
            } catch (SQLException sqlE) {
                dbConnection = checkOut(dbURI, dbUserName, dbPassword, sourceSubType);
            }
        }
        if (dbConnection == null) {
            try {
                String dbDriverName = null;
                if (LcpConstants.WatchPointSubSourceType.ORACLE.equalsIgnoreCase(sourceSubType) || LcpConstants.WatchPointSubSourceType.JNDI_NAME.equalsIgnoreCase(sourceSubType))
                    dbDriverName = "oracle.jdbc.driver.OracleDriver";
                else if (LcpConstants.WatchPointSubSourceType.MYSQL.equalsIgnoreCase(sourceSubType))
                    dbDriverName = "com.mysql.jdbc.Driver";
                else if (LcpConstants.WatchPointSubSourceType.SQLSERVER.equalsIgnoreCase(sourceSubType))
                    dbDriverName = "com.microsoft.jdbc.sqlserver.SQLServerDriver";
                Class.forName(dbDriverName);
                InitialContext ic = null;
                DataSource dataSource = null;
                if(LcpConstants.WatchPointSubSourceType.JNDI_NAME.equalsIgnoreCase(sourceSubType)){
                    String lookupName = "java:" + dbURI;
                    logger.debug ("checkOut(): begin, lookupName: " + lookupName);
                    ic = new InitialContext();
                    dataSource = (DataSource) ic.lookup(lookupName);
                    dbConnection = dataSource.getConnection();
                } else { 
                    dbConnection = DriverManager.getConnection(dbURI, dbUserName, dbPassword);
                }
            } catch (Exception e) {
                logger.error("Exception in getting connection to DB URI: " + dbURI, e);
                throw new SQLException (e.getMessage());
            }
        }
        logger.debug("max connections = " + mNumberOfConnections);
        logger.debug("available Connections = " + availableConnections.size());
        logger.debug("In use connections = " + inuseConnections.size());
        logger.debug("checkOut() ends...");
        return dbConnection;
    }

    /**
    * Check a connection back into the pool or directly close it if maxSixe is reached.
    *
    * @param            pConnection          Database connection to return to the pool.
    */
    public void checkIn(Connection pConnection, long maxIdleTime, long maxConnections)
    {
        logger.debug("checkIn() begins...");
        logger.debug("available Connections = " + availableConnections.size());
        logger.debug("max connections = " + mNumberOfConnections);
        logger.debug("In use connections = " + inuseConnections.size());
        if (pConnection != null) {
            try {
                if (!pConnection.isClosed()) {
                    ConnectionProperties connectionProperties = new ConnectionProperties();
                    connectionProperties.setConnection(pConnection);
                    connectionProperties.setIdleTime(maxIdleTime);
                    connectionProperties.setLastAccessTime(System.currentTimeMillis());
                    if ((this.availableConnections.size() + this.inuseConnections.size()) == new Long(maxConnections).intValue()) {
                        pConnection.close();
                    } else {
                        this.availableConnections.addElement(connectionProperties);
                        if (this.inuseConnections.size() > 0) {
                            Iterator iterator = this.inuseConnections.iterator();
                            ConnectionProperties connectionProperties3 = null;
                            while (iterator.hasNext()) {
                                ConnectionProperties connectionProperties2 = (ConnectionProperties) iterator.next();
                                if (connectionProperties2.getConnection().equals(pConnection)) {
                                    connectionProperties3 = connectionProperties2;
                                    break;
                                }
                            }
                            if (connectionProperties3 != null) {
                                this.inuseConnections.remove(connectionProperties3);
                            } else {
                                pConnection.close();
                            }
                        }
                    }
                }
            } catch (SQLException sqlE) {
                logger.error("Error in checking connection back in Connection Pool:"+sqlE); // Do nothing. Bad connection checked in. If counting checkouts reduce
                // the count here.
            }
        }
        logger.debug("available Connections = " + availableConnections.size());
        logger.debug("max connections = " + mNumberOfConnections);
        logger.debug("In use connections = " + inuseConnections.size());
        logger.debug("checkIn() ends...");
    }

    /**
      * Shutdown the connection pool by closing all connections and de-registering
      * the JDBC driver.
     */
    public static synchronized void clearAll()
    {
        Iterator iterator = _instances.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry entry = (Map.Entry) iterator.next();
            clear((ConnectionPool) entry.getValue());
        }
    }

    /**
    * Shutdown the connection pool by closing all connections and de-registering
    * the JDBC driver.
    */
    public static void clear(ConnectionPool connectionPool)
    {
        ConnectionProperties tempConnection = null;
        ListIterator ConnectionIterator = connectionPool.availableConnections.listIterator();

        try {
            while (ConnectionIterator.hasNext()) {
                tempConnection = (ConnectionProperties) ConnectionIterator.next();
                if(tempConnection.getConnection()!= null)
                {
                    tempConnection.getConnection().close();
                }                
            }
            ConnectionIterator = connectionPool.inuseConnections.listIterator();
            while (ConnectionIterator.hasNext()) {
                tempConnection = (ConnectionProperties) ConnectionIterator.next();
                if(tempConnection.getConnection()!= null)
                {
                    tempConnection.getConnection().close();
                }   
            }
            ConnectionIterator = null;
            connectionPool.availableConnections.removeAllElements();
            connectionPool.inuseConnections.removeAllElements();
            connectionPool.timer.cancel();
        } catch (SQLException sqlE) {
            logger.error("Unable to close the connection:" + sqlE);
        }

    }

}
