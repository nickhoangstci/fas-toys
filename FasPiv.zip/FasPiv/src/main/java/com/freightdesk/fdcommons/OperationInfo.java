/** 
 * 
 * Copyright (c) 2000-2002 NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/OperationInfo.java,v 1.1 2006/03/29 22:05:35 ranand Exp $
 * 
 *  Modification History:
 *  $Log: OperationInfo.java,v $
 *  Revision 1.1  2006/03/29 22:05:35  ranand
 *  moved files from folio
 *
 *  Revision 1.1  2006/03/28 21:20:06  aarora
 *  Creating an fdcommons folder
 *
 *  Revision 1.2  2004/10/19 10:26:56  ranand
 *  enhancement for Sub Packages
 *
 *  Revision 1.1  2004/09/15 13:05:24  ranand
 *  2.6 Baseline
 *
 * 
 */



package com.freightdesk.fdcommons;

import java.io.Serializable;


public class OperationInfo implements Serializable
{

    private String managerName;
    private String operationType;
    private String action;
    private String subAction;
    private String id;
    private String value;
    private String type;
    
    // properties added for managing the Hierarchical relation.
    private String level;
    private String index;
    private Object currentObj;

    public OperationInfo(String newManagerName, String anAction, String anId)
    {
        managerName = newManagerName;
        action = anAction;
        id = anId;
        value = "";
    }

    public OperationInfo(String newManagerName, String anAction, String anId, String aValue)
    {
        managerName = newManagerName;
        action = anAction;
        id = anId;
        value = aValue;
    }

    public OperationInfo(String newManagerName, String newOperationType, String anAction, String anSubAction, String anId, String aValue)
    {
        managerName = newManagerName;
        operationType = newOperationType;
        action = anAction;
        subAction = anSubAction;
        id = anId;
        value = aValue;
    }

    public OperationInfo(String newManagerName, String newOperationType, String anAction, String anSubAction, String anId, String aValue, String atype)
    {
        managerName = newManagerName;
        operationType = newOperationType;
        action = anAction;
        subAction = anSubAction;
        id = anId;
        value = aValue;
        type = atype;
    }

    public OperationInfo(String newManagerName, String newOperationType, String anAction, String anSubAction, String anId, String aValue, String atype, String level, Object currentObj)
    {
        managerName = newManagerName;
        operationType = newOperationType;
        action = anAction;
        subAction = anSubAction;
        id = anId;
        value = aValue;
        type = atype;
        this.level = level;
        this.currentObj = currentObj;
    }

    public String getAction()
    {
        return action;
    }

    public String getId()
    {
        return id;
    }

    public String getManagerName()
    {
        return managerName;
    }

    public String getOperationType()
    {
        return operationType;
    }

    public String getSubAction()
    {
        return subAction;
    }

    public String getType()
    {
        return type;
    }

    public String getValue()
    {
        return value;
    }
    /**
     * Returns the level.
     * @return String
     */
    public String getLevel() {
        return level;
    }


    public void setAction(String aAction)
    {
        action = aAction;
    }

    public void setId(String aId)
    {
        id = aId;
    }

    public void setManagerName(String aManagerName)
    {
        managerName = aManagerName;
    }

    public void setOperationType(String operationType)
    {
        this.operationType = operationType;
    }

    public void setSubAction(String aSubAction)
    {
        subAction = aSubAction;
    }

    public void setType(String type)
    {
        this.type = type;
    }

    public void setValue(String aValue)
    {
        value = aValue;
    }

    /**
     * Sets the level.
     * @param level The level to set
     */
    public void setLevel(String level) {
        this.level = level;
    }

    public String toString()
    {
        return managerName + "-" + operationType + "-" + action + "-" + "-" + subAction + "-" + id + "-" + value;
    }
    
    /**
     * Header key is being used to show the navigation level on the Jsp page
     * using application resource file as mapping for keys.   
     * 
     * @return navigationHeaderKey
     */
    public String getNavigationHeaderKey()
    {
    	return "navigation.header."+managerName.trim().toLowerCase(); 
    }
    
    public boolean equals(Object thatObject) {
    	OperationInfo thatOperationInfo = (OperationInfo)thatObject;
    	String thatManagerName = thatOperationInfo.getManagerName();
    	if(this.managerName != null && thatManagerName != null && !this.managerName.equalsIgnoreCase(thatManagerName)) {
    		return false;
    	}
    	
    	String thatSubAction = thatOperationInfo.getSubAction();
    	if(this.subAction != null && thatSubAction != null && !this.subAction.equalsIgnoreCase(thatSubAction)) {
    		return false;
    	}
    	
    	String thatAction = thatOperationInfo.getAction();
    	if(this.action != null && thatAction != null && !this.action.equalsIgnoreCase(thatAction)) {
    		return false;
    	}
    	
    	String thatOperationType = thatOperationInfo.getOperationType();
    	if(this.operationType != null && thatOperationType != null && !this.operationType.equalsIgnoreCase(thatOperationType)) {
    		return false;
    	}
    	
        String thatlevel = thatOperationInfo.getLevel();
        if(this.level != null && thatlevel != null && !this.level.equalsIgnoreCase(thatlevel)) {
            return false;
        }
    	return true;   	
    	
    }

	/**
	 * Returns the currentObj.
	 * @return Object
	 */
	public Object getCurrentObj() {
		return currentObj;
	}

	/**
	 * Sets the currentObj.
	 * @param currentObj The currentObj to set
	 */
	public void setCurrentObj(Object currentObj) {
		this.currentObj = currentObj;
	}

	/**
	 * Returns the index.
	 * @return String
	 */
	public String getIndex() {
		return index;
	}

	/**
	 * Sets the index.
	 * @param index The index to set
	 */
	public void setIndex(String index) {
		this.index = index;
	}

}

