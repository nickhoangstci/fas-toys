/** 
* Copyright (c) 2000-2002 NTELX 
*  All rights reserved. 
* 
* This software is the confidential and proprietary information of NTELX 
* ("Confidential Information").  You shall not disclose such Confidential Information 
* and shall use it only in accordance with the terms of the license agreement you entered 
* into with NTELX. 
* 
* 
*  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/licensing/LicenseValidator.java,v 1.1.4.1 2007/05/18 18:51:04 mechevarria Exp $ 
* 
*  Modification History:
*  $Log: LicenseValidator.java,v $
*  Revision 1.1.4.1  2007/05/18 18:51:04  mechevarria
*  add new licensing
*
*  Revision 1.1  2007/04/12 16:31:14  dkumar
*  base version
*
*/
package com.freightdesk.fdcommons.licensing;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.sql.Timestamp;

import com.freightdesk.fdcommons.Base64;
import com.freightdesk.fdcommons.FormatDate;
import com.freightdesk.fdcommons.SymmetricCipher;

public class LicenseValidator
{
    
    /**
     * Generates License Key Object from encrypted License Text
     * @param licenseData
     * @return LicenseKey Object
     * @throws GeneralSecurityException
     * @throws IOException 
     * @throws ClassNotFoundException 
     * @throws InvalidLicenseException 
     */
    public LicenseKey createLicenseKey(String licenseData) throws GeneralSecurityException, IOException, ClassNotFoundException
    {
        byte[] decodedBytes = Base64.decode(licenseData);
        byte[] decryptedBytes = SymmetricCipher.getInstance().decrypt(decodedBytes);
        ByteArrayInputStream byteInStream = new ByteArrayInputStream(decryptedBytes);
        DataInputStream input = new DataInputStream(byteInStream);
        LicenseKey licenseKey = new LicenseKey();
        licenseKey.readFromStream(input);
        return licenseKey;
    }
    
    
    /**
     * validates the license key
     * @param key
     * @param product
     * @return boolean
     * @throws InvalidLicenseException
     */
    public boolean validateLicense(LicenseKey key, String product) throws InvalidLicenseException
    {
        byte keyVersionMajor =key.getMajorKeyVersion();
        byte keyVersionMinor =key.getMinorKeyVersion();
        byte configCode = key.getConfigurationCode();
        byte licenseType = key.getLicenseType();
        Timestamp expDate = key.getExpirationDate();
        
        StringBuffer errors = new StringBuffer();

        boolean valid = true;
        
        if(!((keyVersionMajor >= LicenseConstants.KEY_MAJOR_MIN.byteValue()) && (keyVersionMajor <= LicenseConstants.KEY_MAJOR_MAX.byteValue())))
        {
            valid=false;
            errors.append("Invalid key major version :"+keyVersionMajor+" \n");
        }
        
        if(!((keyVersionMinor >= LicenseConstants.KEY_MINOR_MIN.byteValue()) && (keyVersionMinor <= LicenseConstants.KEY_MINOR_MAX.byteValue())))
        {
            valid=false;
            errors.append("Invalid key minor version :"+keyVersionMinor+" \n");
        }
        
        if(product == null || configCode != LicenseConstants.ProductCode.getConfigCode(product))
        {
            valid=false;
            errors.append("Invalid configuration code :"+configCode+" \n");
        }

        if(!((licenseType == LicenseConstants.LicenseType.Demo.byteValue()) || (licenseType == LicenseConstants.LicenseType.Full.byteValue())))
        {
            valid=false;
            errors.append("Invalid license type:"+licenseType+" \n");
        }

        if(expDate==null ||expDate.before(new Timestamp(System.currentTimeMillis())))
        {
            valid=false;
            errors.append("Invalid expirationDate:"+FormatDate.format(expDate, LicenseConstants.DATE_FORMAT)+" \n");
        }

        if(valid == false)
            throw new InvalidLicenseException(errors.toString());
        
        return valid;
    }

}
