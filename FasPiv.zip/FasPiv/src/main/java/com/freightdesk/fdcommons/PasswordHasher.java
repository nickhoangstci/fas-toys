/** 
 * 
 * Copyright (c) 2000-2002 NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/PasswordHasher.java,v 1.1 2007/06/29 14:13:55 atripathi Exp $
 * 
 *  Modification History:
 *  $Log: PasswordHasher.java,v $
 *  Revision 1.1  2007/06/29 14:13:55  atripathi
 *  moved from folio to commons.
 *
 *  Revision 1.3  2006/05/23 22:21:55  aarora
 *  Formatted the code
 *  Organized imports
 *  Removed unused variables
 *  [Trying to get to no Eclipse warnings]
 *
 *  Revision 1.2  2004/12/02 20:37:16  bdealey
 *  Changed logger.info to logger.debug
 *
 *  Revision 1.1  2004/09/15 13:07:11  ranand
 *  2.6 Baseline
 *
 * 
 */

package com.freightdesk.fdcommons;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.apache.log4j.Logger;


public class PasswordHasher {
	final static String hashingAlgo = "SHA-1";
	protected Logger logger = Logger.getLogger(getClass());
	
    public String hashPassword(String password) {
		logger.debug("hashPassword() method - begin ");
        byte[] buf = new byte[password.length()];
         
        buf = password.getBytes();

        MessageDigest algo = null;

        try {
            algo = MessageDigest.getInstance(hashingAlgo);
        } catch (NoSuchAlgorithmException e) {
			logger.error("Exception in  hashPassword() method::", e);	
            throw new RuntimeException(e); 
        }
        algo.reset();
        algo.update(buf);

        return new sun.misc.BASE64Encoder().encode(algo.digest());
    }
    public boolean  hashPasswordAndCompare(String passwordToBeHashed,
        String passwordHash) {
        return (hashPassword(passwordToBeHashed).equals(passwordHash));
    }
}
