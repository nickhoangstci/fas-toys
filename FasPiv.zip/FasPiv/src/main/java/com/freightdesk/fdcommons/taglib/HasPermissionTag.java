/** 
 * 
 * Copyright (c) 2000-2002 NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/taglib/HasPermissionTag.java,v 1.1 2006/07/04 15:46:57 dkumar Exp $
 * 
 *  Modification History:
 *  $Log: HasPermissionTag.java,v $
 *  Revision 1.1  2006/07/04 15:46:57  dkumar
 *  repackaged to fdcommons
 *
 *  Revision 1.4  2004/09/28 10:55:19  biju
 *  removed debug statement that is printed a lot because of the heavy use of the associated tag
 *
 *  Revision 1.3  2004/09/15 13:03:45  ranand
 *  2.6 Baseline
 *
 * 
 */


package com.freightdesk.fdcommons.taglib;

import javax.servlet.jsp.tagext.Tag;
import javax.servlet.jsp.tagext.TagSupport;

import org.apache.log4j.Logger;


/**
 * HasPermissionTag implements a custom JSP tag that can be used to hide/show
 * buttons based on a user's access previleges.
 *
 * This tag should be used as:
 * <app:security permission="PERMISSION_NAME">
 *      <app:hasPermission>
 *          Body of HTML to be shown when the user has the specified permission
 *      </app:hasPermission>
 *      <app:noPermission>
 *          Body of HTML to be shown when the user does not have the specified permission
 *      </app:noPermission>
 * </app:security>
 *
 * <P>
 * This tag must be embedded inside a SecurityTag.
 *
 * @see com.ntelx.nxcommons.taglib.SecurityTag
 * @see com.ntelx.nxcommons.taglib.NoPermissionTag
 *
 * @author Amrinder Arora
 */
public class HasPermissionTag extends TagSupport implements Tag
{
    /**
     * a log4j Logger
     */
    protected Logger logger = Logger.getLogger (getClass());

    /**
     * Processes the start of the tag.
     */
    public int doStartTag() {
        SecurityTag parent = (SecurityTag) (getParent());
        if (parent.hasPermission())
            return EVAL_BODY_INCLUDE;
        else return SKIP_BODY;
    }
}
