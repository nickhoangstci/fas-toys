/** 
 * Copyright (c) 2000-2002 NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/BaseSLSBean.java,v 1.1 2006/03/29 22:05:35 ranand Exp $
 * 
 *  Modification History:
 *  $Log: BaseSLSBean.java,v $
 *  Revision 1.1  2006/03/29 22:05:35  ranand
 *  moved files from folio
 *
 *  Revision 1.1  2006/03/28 21:20:06  aarora
 *  Creating an fdcommons folder
 *
 *  Revision 1.5  2005/09/13 00:46:03  amrinder
 *  Added a comment
 *
 *  Revision 1.4  2005/08/09 21:57:56  amrinder
 *  Added two methods, maybe will remove the body and delegate to BaseDao
 *
 *  Revision 1.3  2004/09/15 13:03:45  ranand
 *  2.6 Baseline
 */

package com.freightdesk.fdcommons;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;

import org.apache.log4j.Logger;



/**
 * A base class for stateless session beans in the application.
 * It provides a few basic services to all extending classes:
 * <OL>
 *   <LI> Getting a database connection
 *   <LI> A logger
 *   <LI> Implementing basic EJB methods, for activating,
 *   passivating , creating and removing EJBs.
 * </OL>
 *
 * @author Amrinder Arora
 */
public abstract class BaseSLSBean
    implements SessionBean
{
    protected Logger logger = Logger.getLogger(getClass());
    protected SessionContext sessionContext;    

    public void ejbActivate()
        throws EJBException
    {
    }

    /** Creates an instances of this EJB. */
    public void ejbCreate()
        throws CreateException
    {
    }

    public void ejbPassivate()
        throws EJBException
    {
    }

    public void ejbRemove()
        throws EJBException
    {
    }

    /**
     * Sets the session context
     */
    public void setSessionContext (SessionContext sessionCtx)
    {
        this.sessionContext = sessionCtx;
    }

    /**
     * Gets a connection to the database.
     *
     * If the dataSource is null, it looks up the dataSource 
     * again, otherwise it gets a connection from the dataSource.
     *
     * @return Connection
     */
    protected Connection getConnection()
        throws SQLException
    {        
		return ConnectionUtil.getConnection();		
    }

    /**
     * Executes the query specified in the passed DQL.
     * This method can be used to write concise code that 
     * needs to run query that returns a single record with a single
     * column of Number type.  This value is then returned
     * as a Java long primitive value.
     *  
     * It can be used conveniently to run a count query
     * or one that returns a single column
     * that is defined as a Number type in the DB. 
     * @throws IllegalArgumentException If the query does not return any result, or
     * if the query returns multiple records (rows)
     * <B>Note:</B> 
     * No exception is thrown if query returns more than one columns, extra columns are simply ignored 
     */
    public long executeQuery_long (String query) 
        throws SQLException 
    {
        Connection connection = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            connection = getConnection();
            stmt = connection.createStatement();
            rs = stmt.executeQuery (query);
            if (!rs.next()) {
                throw new IllegalArgumentException ("Query returned no record: " + query);
            }
            long longValue = rs.getLong (1);
            if (rs.next()) {
                throw new IllegalArgumentException ("Query returned more than one record: " + query);
            }
            return longValue;
        } catch (SQLException ex) {
            logger.error("Exception in executeQuery_long", ex);
            throw ex;
        } finally {
            ConnectionUtil.closeResources(connection, stmt, rs);
        }
    }

    /**
     * Executes the query specified in the passed DQL.
     * This method can be used to write concise code that 
     * needs to run query that returns a single record with a single
     * column of Number type.  This value is then returned
     * as a Java long primitive value.
     *  
     * It can be used conveniently to run a count query
     * or one that returns a single column
     * that is defined as a Number type in the DB. 
     * @throws IllegalArgumentException If the query does not return any result, or
     * if the query returns multiple records (rows)
     * <B>Note:</B> 
     * No exception is thrown if query returns more than one columns, extra columns are simply ignored 
     */
    public String executeQuery_String (String query) 
        throws SQLException 
    {
        Connection connection = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            connection = getConnection();
            stmt = connection.createStatement();
            rs = stmt.executeQuery (query);
            if (!rs.next()) {
                throw new IllegalArgumentException ("Query returned no record: " + query);
            }
            String strValue = rs.getString (1);
            if (rs.next()) {
                throw new IllegalArgumentException ("Query returned more than one record: " + query);
            }
            return strValue;
        } catch (SQLException ex) {
            logger.error("Exception in executeQuery_String", ex);
            throw ex;
        } finally {
            ConnectionUtil.closeResources(connection, stmt, rs);
        }
    }
}

