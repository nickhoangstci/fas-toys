/** 
 * 
 * Copyright (c) 2000-2002 NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/OptionBean.java,v 1.1.4.1 2010/11/24 16:42:52 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: OptionBean.java,v $
 *  Revision 1.1.4.1  2010/11/24 16:42:52  mechevarria
 *  html and special character safe class
 *
 *  Revision 1.1  2006/03/29 22:05:35  ranand
 *  moved files from folio
 *
 *  Revision 1.1  2006/03/28 21:20:06  aarora
 *  Creating an fdcommons folder
 *
 *  Revision 1.3  2004/09/15 13:03:45  ranand
 *  2.6 Baseline
 *
 * 
 */

package com.freightdesk.fdcommons;

import java.io.Serializable;

import org.apache.commons.lang.StringEscapeUtils;

public class OptionBean implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 7394391621934562454L;
	private String label;
	private String value;

	// constructors
	public OptionBean() {
	}

	/**
	 * label is what is displayed to the user value is what the property is set
	 * to
	 */
	public OptionBean(String label, String value) {
		this.label = label;
		this.value = value;
	}

	// since collection will most likely be shown in web page, escape html and trim white space
	public String getLabel() {
		if (label == null)
			return "";
		else
			return StringEscapeUtils.escapeHtml(label.trim());
	}

	public void setLabel(String newLabel) {
		label = newLabel;
	}

	public String getValue() {
		if (value == null)
			return "";
		else
			return StringEscapeUtils.escapeHtml(value.trim());
	}

	public void setValue(String newValue) {
		value = newValue;
	}
}
