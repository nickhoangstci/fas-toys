/** 
 * Copyright (c) 2000-2002 NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/DataBaseRowModel.java,v 1.2 2006/05/03 03:45:02 aarora Exp $ 
 * 
 *  Modification History:
 *  $Log: DataBaseRowModel.java,v $
 *  Revision 1.2  2006/05/03 03:45:02  aarora
 *  Improved an internal variable name
 *
 *  Revision 1.1  2006/03/29 22:05:35  ranand
 *  moved files from folio
 *
 *  Revision 1.1  2006/03/28 21:20:06  aarora
 *  Creating an fdcommons folder
 *
 *  Revision 1.1  2005/09/30 13:51:36  nsehra
 *  first version
 *
 */
package com.freightdesk.fdcommons;

/**
 * @author Nitin Sehra
 */
public class DataBaseRowModel
{
	protected String[] dataValues;

    /**
     * @return
     */
    public String[] getDataBaseRow()
    {
        return dataValues;
    }

    /**
     * @param strings
     */
    public void setDataBaseRow(String[] strings)
    {
        dataValues = strings;
    }
}
