package com.freightdesk.fdcommons;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

/**
 * 
 * @author Amit Tripathi
 *
 */
public class FDSuiteReferenceData
{
    //	 the map of the instances of this singleton
    // instances of DocumentManagerReferenceData for each domain
    private static Map _instances = new HashMap();

    // a logger
    private static Logger logger = Logger.getLogger("com.freightdesk.common.FDSuiteReferenceData");

    /**
     * The following data is independent of domain
     */
    private List hintQuestionList;    

    /**
     * Creates an instance of SetupReferenceData for a particular domain name.
     * This constructor is declared private, and it is only called from
     * the getInstance() method.  
     */
    private FDSuiteReferenceData(String domainName)
    {
        try {
            hintQuestionList = setHintQuestionsList(domainName);            
        } catch (SQLException e) {
            logger.error("Exception in instantiating FDSuiteReferenceData for domain " + domainName, e);
        }
    }

    /**
     * Gets the instance for this domainName.
     * The first time this method is called for that domain,
     * it creates an instance, and puts it in the _instances map.
     * Next time, it returns the already created instance for that domain.
     */
    public static FDSuiteReferenceData getInstance(String domainName)
    {
        FDSuiteReferenceData userSetupReferenceData = (FDSuiteReferenceData) (_instances.get(domainName));
        if (userSetupReferenceData == null) {
            userSetupReferenceData = new FDSuiteReferenceData(domainName);
            _instances.put(domainName, userSetupReferenceData);
        }
        return userSetupReferenceData;
    }

    private List setHintQuestionsList(String domainName)
        throws SQLException
    {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        List hintQuestionOptionBeanList = null;
        try {
            String query = "SELECT SECURITYQUESTIONCODE, SECURITYQUESTIONNAME from SECURITYQUESTION where DOMAINNAME in ('PUBLIC',?)";
            connection = ConnectionUtil.getConnection();
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, domainName);
            resultSet = preparedStatement.executeQuery();
            hintQuestionOptionBeanList = new ArrayList();
            while (resultSet.next()) {
                String hintQuestionCode = resultSet.getString("SECURITYQUESTIONCODE");
                String hintQuestionName = resultSet.getString("SECURITYQUESTIONNAME");
                OptionBean optionBean = new OptionBean(hintQuestionCode, hintQuestionName);
                hintQuestionOptionBeanList.add(optionBean);
            }
        } catch (SQLException e) {
            logger.error("Exception in getHintQuestionsList(String domainName):" + e);
            throw e;
        } finally {
            ConnectionUtil.closeResources(connection, preparedStatement, resultSet);
        }
        return hintQuestionOptionBeanList;
    }

    /**
     * gets SystemFunctionMap
     * @return Map containing system function name as key and code as value
     * @throws SQLException
     */
    public Map retrieveSystemFunctionMap()
        throws SQLException
    {
        Connection connection = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            String query = "select SYSTEMFUNCTIONCODE, SYSTEMFUNCTIONNAME from SYSTEMFUNCTION";
            connection = ConnectionUtil.getConnection();
            stmt = connection.prepareStatement(query);
            rs = stmt.executeQuery();
            Map systemFunctionMap = new HashMap();
            while (rs.next()) {
                String systemFunctionCode = rs.getString("SYSTEMFUNCTIONCODE");
                String systemFunctionName = rs.getString("SYSTEMFUNCTIONNAME");
                systemFunctionMap.put(systemFunctionName, systemFunctionCode);
            }
            return systemFunctionMap;
        } catch (SQLException sqEx) {
            logger.error("SQL Error occurred during getAllSystemFunction()", sqEx);
            throw sqEx;
        } finally {
            ConnectionUtil.closeResources(connection, stmt, rs);
        }

    }

    public List getHintQuestionsList()
    {
        return this.hintQuestionList;
    }


    /**
     * Clears all retrieved reference data.
     * This ensures that next time an instance is requested, it will
     * be refreshed from the DB.
     */
    public static void clearReferenceData()
    {
        logger.info("clearReferenceData (): begin");
        _instances.clear();
    }    
}
