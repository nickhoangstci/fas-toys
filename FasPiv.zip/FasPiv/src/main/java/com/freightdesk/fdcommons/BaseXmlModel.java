/** 
 * Copyright (c) 2000-2002 NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/BaseXmlModel.java,v 1.1 2006/03/29 22:05:35 ranand Exp $
 * 
 *  Modification History:
 *  $Log: BaseXmlModel.java,v $
 *  Revision 1.1  2006/03/29 22:05:35  ranand
 *  moved files from folio
 *
 *  Revision 1.1  2006/03/28 21:20:06  aarora
 *  Creating an fdcommons folder
 *
 *  Revision 1.1  2006/02/13 08:22:52  pjain
 *  Refactored UserModel to BaseXmlModel
 *
 *  Revision 1.5  2005/08/18 23:47:48  amrinder
 *  Corrected some comments
 *
 *  Revision 1.4  2004/11/19 09:45:16  ranand
 *  added a property primaryKey
 *
 *  Revision 1.3  2004/09/15 13:03:45  ranand
 *  2.6 Baseline
 */

package com.freightdesk.fdcommons;

import java.io.Serializable;

/**
 * Encapsulates a base XML model element.
 *
 * @author Amit Garg
 */
public class BaseXmlModel 
    implements Serializable
{
    long primaryKey;
    
    public BaseXmlModel()
    {
    }
  
	/**
	 * Returns the primaryKey.
	 * @return long
	 */
	public long getPrimaryKey() {
		return primaryKey;
	}

	/**
	 * Sets the primaryKey.
	 * @param primaryKey The primaryKey to set
	 */
	public void setPrimaryKey(long primaryKey) {
		this.primaryKey = primaryKey;
	}
}

