/** 
 * 
 * Copyright (c) 2000-2002 NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/taglib/SecurityTag.java,v 1.1 2006/07/04 15:46:57 dkumar Exp $
 * 
 *  Modification History:
 *  $Log: SecurityTag.java,v $
 *  Revision 1.1  2006/07/04 15:46:57  dkumar
 *  repackaged to fdcommons
 *
 *  Revision 1.6  2006/05/11 22:18:55  aarora
 *  Small change as the SessionKey class has been added to com.freightdesk.fdfolio.commons
 *
 *  Revision 1.5  2006/03/28 21:23:02  aarora
 *  Repackaging of fdcommons
 *
 *  Revision 1.4  2004/09/28 10:55:19  biju
 *  removed debug statement that is printed a lot because of the heavy use of the associated tag
 *
 *  Revision 1.3  2004/09/15 13:03:45  ranand
 *  2.6 Baseline
 *
 * 
 */


package com.freightdesk.fdcommons.taglib;

import java.util.Map;

import javax.servlet.http.HttpSession;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.Tag;
import javax.servlet.jsp.tagext.TagSupport;

import org.apache.log4j.Logger;

import com.freightdesk.fdcommons.SessionKey;
import com.freightdesk.fdcommons.SessionStore;

/**
 * SecurityTag implements a custom JSP tag that can be used to hide/show
 * JSP code based on a user's access previleges.
 *
 * This tag should be used as follows.
 *
 * <P>
 * <B>The following scriplet code can be replaced by alternative custom tag usage.</B>
 * <FONT face="lucida console, arial" color=#660066>
 * <PRE>
 * &lt;%
 *     Map accessList = (Map) (sessionStore.get (SessionKey.ACCESS_CONTROL_LIST));
 *     if (accessList.containsKey("S18")) {
 * %&gt;
 *              Body of HTML to be shown when the user has the specified permission (S18)
 * &lt;%
 *     } else {
 * %&gt;
 *              Body of HTML to be shown when the user does not have the specified permission (S18)
 * &lt;%
 *     }
 * %&gt;
 * </PRE>
 * </FONT>
 *
 * <P>
 * <B>Equivalent custom tag usage:</B>
 * <FONT face="lucida console, arial" color=#006666>
 * <PRE>
 * &lt;app:security permission="S18"&gt;
 *     &lt;app:hasPermission&gt;
 *          Body of HTML to be shown when the user has the specified permission (S18)
 *     &lt;/app:hasPermission&gt;
 *     &lt;app:noPermission&gt;
 *          Body of HTML to be shown when the user does not have the specified permission (S18)
 *     &lt;/app:noPermission&gt;
 * &lt;/app:security&gt;
 * </PRE>
 * </FONT>
 *
 * <P>You can embed either or both child tags inside the security tag.
 *
 * @see com.freightdesk.fdfolio.common.taglib.HasPermissionTag
 * @see com.freightdesk.fdfolio.common.taglib.NoPermissionTag
 *
 * @author Amrinder Arora
 */
public class SecurityTag extends TagSupport implements Tag
{
    /**
     * a log4j Logger
     */
    protected Logger logger = Logger.getLogger (getClass());

    /**
     * The permission attribute of this tag
     */
    protected String permission;

    /**
     * Private variable to hold whether or not the user in session
     * has the specified permission.
     */
    private boolean _has_permission = false;

    /**
     * Does the user in session have the specified permission?
     */
    public boolean hasPermission() {
        return _has_permission;
    }

    /**
     * Sets the permission attribute from the JSP
     */
    public void setPermission (String permission) {
        this.permission = permission;
    }

    /**
     * Processes the start of the tag.
     */
    public int doStartTag() throws JspException {
        try {
            HttpSession session = pageContext.getSession();
            SessionStore sessionStore = SessionStore.getInstance (session);
            Map accessMap = (Map) (sessionStore.get (SessionKey.ACCESS_CONTROL_LIST));
            if (accessMap.containsKey (permission))
                _has_permission = true;
            else
                _has_permission = false;

        } catch (Exception ioe) {
            logger.error ("Exception while writing to client", ioe);
            throw new JspException("IOException while writing to client" + ioe.getMessage());
        }
        return EVAL_BODY_INCLUDE;
    }
}
