package com.freightdesk.fdcommons;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.log4j.Logger;

/**
 * DAO for all required User Time Track database operations.
 * @author amit tripathi
 *
 */
public class UTTDao extends BaseDao
{
    protected Logger logger = Logger.getLogger(getClass());

    public static final String WORKSTATUS_AVAILABLE = "A";

    public static final String WORKSTATUS_WORKING = "W";

    public static final String WORKSTATUS_UNAVAILABLE = "U";

    /**
     * updates system user work status type code.
     * @param systemUserId
     * @param workStatusCode
     * @throws Exception
     */
    public void updateSystemUserWorkStatus(long systemUserId, String workStatusCode)
        throws Exception
    {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        try {
            String updateQuery = "update systemuser set WorkStatusCode=? where systemuserid=?";
            connection = getConnection();
            preparedStatement = connection.prepareStatement(updateQuery);
            preparedStatement.setString(1, workStatusCode);
            preparedStatement.setLong(2, systemUserId);
            preparedStatement.executeUpdate();
        } catch (Exception e) {
            logger.error("Exception in updateSystemUserWorkStatus:" + e);
            throw e;
        } finally {
            ConnectionUtil.closeResources(connection, preparedStatement, null);
        }
    }

    /**
     * creates work log.
     * @param workTimeModel
     * @throws Exception
     */
    public void createWorkLog(WorkTimeModel workTimeModel)
        throws Exception
    {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        try {
            String createQuery = "insert into utt_worktime(WorkTimeID,SystemUserID,StartTime,ProjCode,TaskCode,Description,CREATEUSERID, CREATETIMESTAMP, LASTUPDATEUSERID, LASTUPDATETIMESTAMP, DOMAINNAME) values (?,?,?,?,?,?,?,?,?,?,?)";
            long workTimeId = getNextID("workTimeId");
            connection = getConnection();
            preparedStatement = connection.prepareStatement(createQuery);
            preparedStatement.setLong(1, workTimeId);
            preparedStatement.setLong(2, workTimeModel.getSystemUserID());
            preparedStatement.setTimestamp(3, workTimeModel.getStartTime());
            preparedStatement.setString(4, workTimeModel.getProjCode());
            preparedStatement.setString(5, workTimeModel.getTaskCode());
            preparedStatement.setString(6, workTimeModel.getDescription());
            preparedStatement.setString(7, workTimeModel.getCreateUserId());
            preparedStatement.setTimestamp(8, workTimeModel.getCreateTimestamp());
            preparedStatement.setString(9, workTimeModel.getLastUpdateUserId());
            preparedStatement.setTimestamp(10, workTimeModel.getLastUpdateTimestamp());
            preparedStatement.setString(11, workTimeModel.getDomainName());
            preparedStatement.executeUpdate();
        } catch (Exception e) {
            logger.error("Exception in createWorkLog:" + e);
            throw e;
        } finally {
            ConnectionUtil.closeResources(connection, preparedStatement, null);
        }
    }

    /**
     * retrieves work time id for system user id whose end time needs to be specified.
     * @param systemuserId
     * @return
     * @throws Exception
     */
    public long retrieveWorkTimeIdForActiveUser(long systemuserId)
        throws Exception
    {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        long workTimeId = 0L;
        try {
            String retrieveQuery = "select worktimeid from utt_worktime where starttime is not null and endtime is null and systemuserid=? order by createtimestamp desc";
            connection = getConnection();
            preparedStatement = connection.prepareStatement(retrieveQuery);
            preparedStatement.setLong(1, systemuserId);
            resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                workTimeId = resultSet.getLong("worktimeid");
            }
        } catch (Exception e) {
            logger.error("Exception in retrieveWorkTimeIdForActiveUser:" + e);
            throw e;
        } finally {
            ConnectionUtil.closeResources(connection, preparedStatement, resultSet);
        }
        return workTimeId;
    }

    /**
     * updates end time for Active User
     * @param systemuserId
     * @param endTime
     * @throws Exception
     */
    public void updateEndTimeForActiveUser(long systemuserId, Timestamp endTime, Timestamp startTime)
        throws Exception
    {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        long workTimeId = 0L;
        try {
            workTimeId = retrieveWorkTimeIdForActiveUser(systemuserId);
        } catch (Exception e) {
            throw e;
        }
        try {
            String updateQuery = "update utt_worktime set endTime=?,  Duration=? where worktimeid=?";
            connection = getConnection();
            preparedStatement = connection.prepareStatement(updateQuery);
            preparedStatement.setTimestamp(1, endTime);
            long duration = endTime.getTime() - startTime.getTime();
            preparedStatement.setLong(2, duration);
            preparedStatement.setLong(3, workTimeId);
            preparedStatement.executeUpdate();
        } catch (Exception e) {
            logger.error("Exception in updateEndTimeForActiveUser:" + e);
            throw e;
        } finally {
            ConnectionUtil.closeResources(connection, preparedStatement, null);
        }
    }

    /**
     * gets workstatus code from system user id.
     * @param systemUserId
     * @return
     * @throws Exception
     */
    public String getWorkStatusCodeFromSystemUserId(long systemUserId)
        throws Exception
    {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        String workStatusCode = null;
        try {
            String selectQuery = "select WorkStatusCode from systemuser where systemuserid=?";
            connection = getConnection();
            preparedStatement = connection.prepareStatement(selectQuery);
            preparedStatement.setLong(1, systemUserId);
            resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                workStatusCode = resultSet.getString("WorkStatusCode");
            }
        } catch (Exception e) {
            logger.error("Exception in getWorkStatusCodeFromSystemUserId:" + e);
            throw e;
        } finally {
            ConnectionUtil.closeResources(connection, preparedStatement, resultSet);
        }
        return workStatusCode;
    }

    /**
     * retrieves start time for given system user id.
     * @param systemUserId
     * @return
     * @throws Exception
     */
    public Timestamp retrieveStartTimeFromSystemUserId(long systemUserId)
        throws Exception
    {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        Timestamp startTime = new Timestamp(0L);
        try {
            String retrieveQuery = "select starttime from utt_worktime where starttime is not null and endtime is null and systemuserid=? order by createtimestamp desc";
            connection = getConnection();
            preparedStatement = connection.prepareStatement(retrieveQuery);
            preparedStatement.setLong(1, systemUserId);
            resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                startTime = resultSet.getTimestamp("starttime");
            }
        } catch (Exception e) {
            logger.error("Exception in retrieveWorkTimeIdForActiveUser:" + e);
            throw e;
        } finally {
            ConnectionUtil.closeResources(connection, preparedStatement, resultSet);
        }
        return startTime;
    }

    /**
     * determins whether we require CheckIn for Role specified
     * @param roeList
     * @return
     */
    public boolean requireCheckInForRole(List roleList)
        throws Exception
    {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        String role = String.valueOf(roleList.get(0));
        boolean requireCheckin = false;
        try {
            String retrieveQuery = "select RequireCheckin from systemrole where SYSTEMROLECODE=?";
            connection = getConnection();
            preparedStatement = connection.prepareStatement(retrieveQuery);
            preparedStatement.setString(1, role);
            resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                if ("true".equalsIgnoreCase(resultSet.getString("RequireCheckin"))) {
                    requireCheckin = true;
                }
            }
        } catch (Exception e) {
            logger.error("Exception in requireCheckInForRole:" + e);
            throw e;
        } finally {
            ConnectionUtil.closeResources(connection, preparedStatement, resultSet);
        }
        return requireCheckin;
    }

    /**
     * retrieves All Users By passed WorkCode
     * @param workStatusCode
     * @param domainName
     * @return
     * @throws Exception
     */
    public List retrieveAllUsersByWorkCode(String workStatusCode, String domainName)
        throws Exception
    {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        List usersList = new ArrayList();
        try {
            String retrieveQuery = "select systemuserid, userid from systemuser where workstatuscode=? and domainName in ('PUBLIC',?)";
            connection = getConnection();
            preparedStatement = connection.prepareStatement(retrieveQuery);
            preparedStatement.setString(1, workStatusCode);
            preparedStatement.setString(2, domainName);
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                OptionBean optionBean = new OptionBean(resultSet.getString("userid"), String.valueOf(resultSet.getLong("systemuserid")));
                usersList.add(optionBean);
            }
        } catch (Exception e) {
            logger.error("Exception in retrieveAllUsersByWorkCode:" + e);
            throw e;
        } finally {
            ConnectionUtil.closeResources(connection, preparedStatement, resultSet);
        }
        return usersList;
    }

    /**
     * 
     * @param systemUserId
     * @return
     * @throws Exception
     */
    public String retrieveUserId(long systemUserId)
        throws Exception
    {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        String userId = "";
        try {
            String retrieveQuery = "select userid from systemuser where systemuserid=?";
            connection = getConnection();
            preparedStatement = connection.prepareStatement(retrieveQuery);
            preparedStatement.setLong(1, systemUserId);
            resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                userId = resultSet.getString("userid");
            }
        } catch (Exception e) {
            logger.error("Exception in retrieveUserId:" + e);
            throw e;
        } finally {
            ConnectionUtil.closeResources(connection, preparedStatement, resultSet);
        }
        return userId;
    }

    /**
     * retrieves all users by given query  
     * @param query     
     * @return Map containing key as systemuserid and value as another map containing columnnames in provided query
     * as key and there values as value
     * @throws Exception
     */
    public Map retrieveAllUsers(String query)
        throws Exception
    {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        Map resultsMap = new HashMap();
        try {
            connection = getConnection();
            preparedStatement = connection.prepareStatement(query);
            resultSet = preparedStatement.executeQuery();
            ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
            int columnCount = resultSetMetaData.getColumnCount();
            while (resultSet.next()) {
                Map resultSetRowMap = new HashMap();
                for (int i = 1; i <= columnCount; i++) {
                    String columnName = resultSetMetaData.getColumnName(i);
                    //systemuser id is not put in resultSetRowMap
                    if (!"systemuserid".equalsIgnoreCase(columnName)) {
                        resultSetRowMap.put(resultSetMetaData.getColumnLabel(i), resultSet.getObject(i));
                    }
                }
                long systemUserId = resultSet.getLong("systemuserid");
                //put whole resultSetRowMap in resultsMap corresponding to key as value to systemuserid column
                resultsMap.put(new Long(systemUserId), resultSetRowMap);
            }
        } catch (Exception e) {
            logger.error("Exception in retrieveAllUsersByWorkCode:" + e);
            throw e;
        } finally {
            ConnectionUtil.closeResources(connection, preparedStatement, resultSet);
        }
        return resultsMap;
    }

    /**
     * retrieves past 5 records from utt_worktime table for this system user id
     * @param systemUserId
     * @return
     * @throws Exception
     */
    public List retrievePastWorkHistory(long systemUserId)
        throws Exception
    {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        List pastWorkHistoryList = new ArrayList();
        try {
            String retrieveQuery = "select STARTTIME, ENDTIME, DURATION, PROJCODE, TASKCODE, DESCRIPTION from (select STARTTIME, ENDTIME, DURATION, PROJCODE, TASKCODE, DESCRIPTION from UTT_WORKTIME where SYSTEMUSERID=? ORDER BY STARTTIME DESC) where ROWNUM<6";
            connection = getConnection();
            preparedStatement = connection.prepareStatement(retrieveQuery);
            preparedStatement.setLong(1, systemUserId);
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                WorkTimeModel workTimeModel = new WorkTimeModel(resultSet.getTimestamp("STARTTIME"), resultSet.getTimestamp("ENDTIME"), resultSet.getLong("DURATION"), resultSet
                        .getString("PROJCODE"), resultSet.getString("TASKCODE"), resultSet.getString("DESCRIPTION"));
                pastWorkHistoryList.add(workTimeModel);
            }
        } catch (Exception e) {
            logger.error("Exception in retrievePastWorkHistory:" + e);
            throw e;
        } finally {
            ConnectionUtil.closeResources(connection, preparedStatement, resultSet);
        }
        return pastWorkHistoryList;
    }

    /**
     * checks in a given systemuserid to the system
     * @param systemUserId
     * @throws Exception
     */
    public void checkinUser(long systemUserId)
        throws Exception
    {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        try {
            String updateQuery = "update systemuser set workStatusCode=? where systemuserid=?";
            connection = getConnection();
            preparedStatement = connection.prepareStatement(updateQuery);
            preparedStatement.setString(1, WORKSTATUS_WORKING);
            preparedStatement.setLong(2, systemUserId);
            preparedStatement.executeUpdate();
        } catch (Exception e) {
            logger.error("Exception in checkinUser:" + e);
            throw e;
        } finally {
            ConnectionUtil.closeResources(connection, preparedStatement, null);
        }
    }

    /**
     * checks in all the provided comma seperated systemuserids to the system
     * @param systemUserId
     * @throws Exception
     */
    public void checkinUser(String systemUserIds)
        throws Exception
    {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        try {
            String updateQuery = "update systemuser set workStatusCode=? where systemuserid in (" + systemUserIds + ")";
            connection = getConnection();
            preparedStatement = connection.prepareStatement(updateQuery);
            preparedStatement.setString(1, WORKSTATUS_WORKING);
            preparedStatement.executeUpdate();
        } catch (Exception e) {
            logger.error("Exception in checkinUser:" + e);
            throw e;
        } finally {
            ConnectionUtil.closeResources(connection, preparedStatement, null);
        }
    }

    /**
     * checks out all the provided comma seperated systemuserids to the system
     * @param systemUserIds
     * @throws Exception
     */
    public void checkoutUser(String systemUserIds)
        throws Exception
    {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        try {
            String updateQuery = "update systemuser set workStatusCode=? where systemuserid in (" + systemUserIds + ")";
            connection = getConnection();
            preparedStatement = connection.prepareStatement(updateQuery);
            preparedStatement.setString(1, WORKSTATUS_UNAVAILABLE);
            preparedStatement.executeUpdate();
        } catch (Exception e) {
            logger.error("Exception in checkoutUser:" + e);
            throw e;
        } finally {
            ConnectionUtil.closeResources(connection, preparedStatement, null);
        }
    }
}
