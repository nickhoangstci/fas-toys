/** 
 * Copyright (c) 2000-2002 NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: 
 * 
 *  Modification History:
 *  $Log: 
 *
 */

package com.freightdesk.fdcommons.search;

import java.util.List;

/**
 * 
 * Encapsultes the SQL Query and SQL Count query 
 * used by View Context.
 * 
 * @author Rajender Anand
 *
 */
public class QueryContext
{
    private String sqlQuery;
    
    private List sqlParameters;
    
    private String countQuery;
    
    /**
     * Default Constructor
     *
     */
    public QueryContext()
    {
      
    }
    
    public QueryContext(String sqlQueryargs, List sqlParamArgs, String countQueryArgs) {
        sqlQuery = sqlQueryargs;
        sqlParameters = sqlParamArgs;
        countQuery = countQueryArgs;
    }
    
    

    /**
     * @return the countQuery
     */
    public String getCountQuery()
    {
        return countQuery;
    }

    /**
     * @param countQuery the countQuery to set
     */
    public void setCountQuery(String countQuery)
    {
        this.countQuery = countQuery;
    }

    /**
     * @return the sqlParameters
     */
    public List getSqlParameters()
    {
        return sqlParameters;
    }

    /**
     * @param sqlParameters the sqlParameters to set
     */
    public void setSqlParameters(List sqlParameters)
    {
        this.sqlParameters = sqlParameters;
    }

    /**
     * @return the sqlQuery
     */
    public String getSqlQuery()
    {
        return sqlQuery;
    }

    /**
     * @param sqlQuery the sqlQuery to set
     */
    public void setSqlQuery(String sqlQuery)
    {
        this.sqlQuery = sqlQuery;
    }
    
    
}
