/** 
 * Copyright (c) 2000-2002 NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/ApplicationErrorHandler.java,v 1.3.2.1.2.2 2010/04/21 20:28:13 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: ApplicationErrorHandler.java,v $
 *  Revision 1.3.2.1.2.2  2010/04/21 20:28:13  mechevarria
 *  updated package for email sender
 *
 *  Revision 1.3.2.1.2.1  2008/12/11 13:50:44  mechevarria
 *  brought over from head
 *
 *  Revision 1.18  2008/07/17 07:17:16  atripathi
 *  deprecated methods added for backward compatibility.
 *
 *  Revision 1.17  2008/05/20 21:32:14  aarora
 *  Major surgery, many overloads removed
 *
 *  Revision 1.16  2008/04/21 12:32:32  atripathi
 *  overloaded method to handle application error on the basis of userId and domainName added.
 *
 *  Revision 1.15  2008/04/21 12:09:52  atripathi
 *  EmailSender part moved to EmailSender class, comments refined andsome overloaded methods added for handling application error.
 *
 *  Revision 1.14  2008/04/16 22:08:40  aarora
 *  Minor changes in getExtract - starting with error message
 *
 *  Revision 1.13  2008/04/11 12:09:57  atripathi
 *  minor formatting changes.
 *
 *  Revision 1.12  2008/04/11 11:27:01  atripathi
 *  static inner class in LCPConstants renamed to LoggerPriorityType from ErrorPriorityType.
 *
 *  Revision 1.11  2008/04/11 11:22:35  atripathi
 *  method createErrorLog added.
 *
 *  Revision 1.10  2008/04/11 06:45:45  atripathi
 *  minor change to have only one loop variable throughout the method getExtract.
 *
 *  Revision 1.9  2008/04/11 06:32:43  atripathi
 *  only 10 stack trace elements in application domain processed to form trace string.
 *
 *  Revision 1.8  2008/04/10 05:52:26  atripathi
 *  two methods merged into one, PasswordHasher instance moved at class level, mailSubject string modified to contain errorCode.
 *
 *  Revision 1.7  2008/04/09 10:05:47  atripathi
 *  minor changes to include javadocs.
 *
 *  Revision 1.6  2008/04/09 08:26:08  atripathi
 *  in mail subject hashed error code included.
 *
 *  Revision 1.5  2008/02/22 12:19:14  nsehra
 *  email using event handler
 *
 *  Revision 1.4  2007/04/12 16:33:34  dkumar
 *  minor change
 *
 *  Revision 1.3  2006/10/09 12:12:07  dkumar
 *  created seperate FDSuite properties
 *
 *  Revision 1.2  2006/03/29 22:33:38  aarora
 *  organized imports
 *
 *  Revision 1.1  2006/03/29 22:05:35  ranand
 *  moved files from folio
 *
 *  Revision 1.2  2006/03/28 21:27:37  aarora
 *  Repackaging of fdcommons
 *
 *  Revision 1.1  2006/03/28 21:20:06  aarora
 *  Creating an fdcommons folder
 *
 *  Revision 1.11  2005/07/27 09:31:30  ranand
 *  Class name changed from LcpProperties to ApplicationProperties
 *
 *  Revision 1.10  2005/01/25 12:57:14  biju
 *  formatting changes
 *
 *  Revision 1.9  2005/01/25 12:48:57  biju
 *  issue with System exception mailing resolved
 *
 *  Revision 1.8  2005/01/24 21:13:58  amrinder
 *  Formatting changes
 *
 *  Revision 1.7  2004/12/02 20:37:16  bdealey
 *  Changed logger.info to logger.debug
 *
 *  Revision 1.6  2004/10/15 11:09:02  asaxena
 *  changed the signature of handleapplilcationError method to  incorporate the
 *  file name variable also
 *
 *  Revision 1.5  2004/10/11 11:15:45  asaxena
 *  Seperated the error message and attached xml file , now error message will
 *  be in mail body and xml file will go as attachment
 *
 *  Revision 1.4  2004/10/07 09:23:21  asaxena
 *  1. overloaded method handleApplicationError to also process the xml
 *      erromessages.
 *  2. used eventhandlerproperties object to send error message mail as
 *      attachment.
 *
 *  Revision 1.3  2004/09/15 13:03:45  ranand
 *  2.6 Baseline
 */

package com.freightdesk.fdcommons;

import java.sql.Timestamp;

import org.apache.log4j.Logger;



/**
 * Application Error Handler.  All highest level classes (MDB and Action)
 * should use the ApplicationErrorHandler to handle (top level)
 * application errors.
 *
 * @author Amrinder Arora
 * @author Amit Tripathi 
 */
public class ApplicationErrorHandler
{
    /** An instance of thread safe class password hasher */
    protected static PasswordHasher passwordHasher = new PasswordHasher();

    /** A logger */
    protected static Logger logger = Logger.getLogger("com.freightdesk.fdcommons.ApplicationErrorHandler");

    /** An instance of thread safe class ErrorLogDAO */
    protected static ErrorLogDAO errorLogDAO = new ErrorLogDAO();

    /**
     * Handles application errors.
     * 
     * @param appError
     * @param credentials
     */
    public static void handleApplicationError(Throwable appError, Credentials credentials)
    {
        logger.debug("handleApplicationError(Throwable, Credentials): begin ");
        handleApplicationError(appError, credentials.getUserId(), credentials.getDomainName());
    }

    /**
     * Overloaded method, logs information to DB using userId and domainName
     * @param Throwable appError
     * @param credentials
     * @param errorMessage
     * @param errorDetails
     * @param emailAddress
     * @param mailSubject
     */
    public static void handleApplicationError(Throwable appError, String userId, String domainName)
    {
        logger.info("handleApplicationError(): begin");
        try {
            String errorLogProperty = FDSuiteProperties.getProperty("application.errors.log");
            if (errorLogProperty == null || errorLogProperty.length() < 1) {
                logger.info("handleApplicationError():: property currently set to : " + errorLogProperty + ", set to EMAIL/DB to enable");
                return;
            }
            errorLogProperty = errorLogProperty.toUpperCase();
            String errorCodeStr = getExtract(appError);
            long errorCode = Long.parseLong(errorCodeStr);

            String errorMessage = appError.getMessage();

            try {
                if (errorLogProperty.indexOf("EMAIL") >= 0) {
                    String adminEmailAddress = FDSuiteProperties.getProperty("system.administrator.email");
                    if (adminEmailAddress == null || adminEmailAddress.equals("")) {
                        logger.info("Admin email address not provided, defaulting to: " + EmailSender.DEFAULT_SYS_AD_EMAIL);
                        adminEmailAddress = EmailSender.DEFAULT_SYS_AD_EMAIL;
                    }
                    StringBuffer errorDetails = getStackTraceBuffer(appError);
                    appendSystemProperties(errorDetails);
                    EmailSender.getInstance().sendMail(adminEmailAddress, "Error, error code: " + errorCodeStr, 
                            new StringBuffer(errorMessage + errorDetails));
                }
			} catch (Exception t) {
                logger.error("Error occurred during email handling of application error", t);
            }
            try {
                if (errorLogProperty.indexOf("DB") >= 0) {
                    saveErrorLogToDB(errorMessage, errorCode, userId, domainName);
                }
			} catch (Exception t) {
                logger.error("Error occurred during DB handling of application error", t);
            }
		} catch (Exception t) {
            logger.error("Error occurred during handling of application error", t);
        }
    }
    /**
     * only handles those application error, that are intended to be sent by email
     * @deprecated used for backward compatibility only.
     * @param Throwable appError
     * @param credentials
     * @param errorMessage
     * @param errorDetails
     * @param emailAddress
     * @param mailSubject
     * @param fileName
     * @param isAttachhmentRequired
     */
    public static void handleApplicationError (String errorMessage, String errorDetails,
            String emailAddress, String mailSubject, String fileName, boolean isAttachhmentRequired)
    {
        logger.info("handleApplicationError(): begin");
        try {
            String errorLogProperty = FDSuiteProperties.getProperty("application.errors.log");
            if (errorLogProperty == null || errorLogProperty.length() < 1) {
                logger.info("handleApplicationError():: property currently set to : " + errorLogProperty + ", set to EMAIL/DB to enable");
                return;
            }
            errorLogProperty = errorLogProperty.toUpperCase();
            String errorCodeStr = getExtract(new Throwable(errorMessage));
            long errorCode = Long.parseLong(errorCodeStr);    

            try {
                if (errorLogProperty.indexOf("EMAIL") >= 0) {
                    String adminEmailAddress = FDSuiteProperties.getProperty("system.administrator.email");
                    if (adminEmailAddress == null || adminEmailAddress.equals("")) {
                        logger.info("Admin email address not provided, defaulting to: " + EmailSender.DEFAULT_SYS_AD_EMAIL);
                        adminEmailAddress = EmailSender.DEFAULT_SYS_AD_EMAIL;
                    }                   
                    appendSystemProperties(new StringBuffer(errorDetails));
                    EmailSender.getInstance().sendMail(adminEmailAddress, "Error, error code: " + errorCodeStr, 
                            new StringBuffer(errorMessage + errorDetails));
                }
			} catch (Exception t) {
                logger.error("Error occurred during email handling of application error", t);
            }            
		} catch (Exception t) {
            logger.error("Error occurred during handling of application error", t);
        }
    }
    /**
     * Gets the string buffer from the stack trace elements of the given exception object.
     * 
     * @param appError
     * @return
     */
    private static StringBuffer getStackTraceBuffer(Throwable appError)
    {
        StringBuffer errorDetails = new StringBuffer(appError.getMessage());

        StackTraceElement[] stackTraceElements = appError.getStackTrace();
        StackTraceElement stackTraceElement = null;
        for (int i = 0; i < stackTraceElements.length; i++) {
            stackTraceElement = stackTraceElements[i];
            errorDetails.append("<br/> at " + stackTraceElement.toString());
        }
        return errorDetails;
    }

    /**
     * Appends system properties to the given string buffer.
     * 
     * @param strbuf
     */
    private static void appendSystemProperties(StringBuffer strbuf)
    {
        try {
            strbuf.append("Selected system properties:\n<UL>");
            String[] keys = { "user.name", "jboss.home.dir", "os.name", "java.io.tmpdir" };
            for (int i = 0; i < keys.length; i++) {
                strbuf.append("<LI><B>" + keys[i] + "</B>: " + System.getProperty(keys[i]));
            }
            strbuf.append("\n</UL>\n\n<P>");
		} catch (Exception ignored) {
        }
        try {
            strbuf.append("All properties:\n<UL>");
            java.util.Map systemProps = System.getProperties();
            java.util.Iterator keys = systemProps.keySet().iterator();
            while (keys.hasNext()) {
                Object key = keys.next();
                strbuf.append("<LI><B>" + key + "</B>: " + systemProps.get(key));
            }
            strbuf.append("\n</UL>\n\n<P>");
		} catch (Exception ignored) {
            logger.debug("Exception writing system properties to message, ignoring", ignored);
        }
    }

    /**
     * Saves error log to database.
     * 
     * @param ex
     * @param credentials
     */
    private static void saveErrorLogToDB(String errorMessage, long errorCode, String userId, String domainName)
    {
        if (errorCode > 0) {
            ErrorLogModel errorLogModel = new ErrorLogModel();
            errorLogModel.setErrorCode(errorCode);
            errorLogModel.setCreateTimeStamp(new Timestamp(System.currentTimeMillis()));
            errorLogModel.setDomainName(domainName);
            errorLogModel.setErrorMessage(errorMessage);
            errorLogModel.setIpAddress("ANON");
            errorLogModel.setLastUpdateTimeStamp(new Timestamp(System.currentTimeMillis()));
            errorLogModel.setLastUpdateUserId(userId);
            errorLogModel.setPriority(LcpConstants.LoggerPriorityType.ERROR);
            errorLogModel.setStatus("ACTIVE");
            errorLogModel.setUserAgent("UNKNOWN");
            errorLogModel.setUserId(userId);
            try {
                errorLogDAO.createErrorLog(errorLogModel);
            } catch (Exception e) {
                logger.error("Exception in creating error log:" + e);
            }
        }
    }

    /**
     * gets stack trace extract
     * @param ex
     * @return
     */
    private static String getExtract(Throwable ex)
    {
        String traceString = ex.getMessage();
        try {
            logger.debug("getStackTraceExtract(): begins for StackTrace:" + ex.getStackTrace());
            StackTraceElement[] stackTraceElements = ex.getStackTrace();
            String[] traceStringArr = new String[stackTraceElements.length];
            int lcv;
            for (lcv = 0; lcv < stackTraceElements.length; lcv++) {
                if (stackTraceElements[lcv].getClassName().indexOf("com.freightdesk") >= 0) {
                    traceStringArr[lcv] += "M:" + extractModuleName(stackTraceElements[lcv].getClassName()) + " F:" + stackTraceElements[lcv].getFileName() + " L:"
                            + stackTraceElements[lcv].getLineNumber() + "\n";
                }
            }
            if (traceStringArr.length < 10) {
                for (lcv = 0; lcv < traceStringArr.length; lcv++) {
                    traceString += traceStringArr[lcv];
                }
            } else if (traceStringArr.length >= 10) {
                for (lcv = 0; lcv < 5; lcv++) {
                    traceString += traceStringArr[lcv];
                }
                for (lcv = ((traceStringArr.length) - 5); lcv < traceStringArr.length; lcv++) {
                    traceString += traceStringArr[lcv];
                }
            }
        } catch (Exception e) {
            logger.info("Exception in getExtract(): ignoring" + e);
        }
        return String.valueOf(Math.abs((passwordHasher.hashPassword(traceString)).hashCode()));
    }

    /**
     * extracts module name from fullClassName
     * @param fullClassName
     * @return
     */
    private static String extractModuleName(String fullClassName)
    {
        if ((fullClassName == null) || ("".equalsIgnoreCase(fullClassName))) {
            return "";
        }
        String tmpClassName = fullClassName;
        int[] indexes = new int[fullClassName.length()];
        for (int i = 0; i < indexes.length; i++) {
            indexes[i] = fullClassName.lastIndexOf(".");
            if (indexes[i] < 0) {
                break;
            } else {
                fullClassName = fullClassName.substring(0, indexes[i]);
            }
        }
        return tmpClassName.substring(indexes[2], indexes[0]).replace('.', '-');
    }
}
