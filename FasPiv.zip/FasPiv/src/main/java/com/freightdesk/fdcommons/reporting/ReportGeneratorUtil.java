/** 
 * Copyright (c) 2000-2002 NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/reporting/ReportGeneratorUtil.java,v 1.5.4.2 2009/09/29 17:59:58 jhansford Exp $
 * 
 *  Modification History:
 *  $Log: ReportGeneratorUtil.java,v $
 *  Revision 1.5.4.2  2009/09/29 17:59:58  jhansford
 *  Added XLS exports
 *
 *  Revision 1.5.4.1  2009/08/06 16:07:34  mechevarria
 *  using the head version for the ability to use role based reports
 *
 *  Revision 1.6  2008/01/31 12:24:17  dkumar
 *  report scheduling changes
 *
 *  Revision 1.5  2006/12/14 11:04:00  atripathi
 *  minor changes in CSV report generator method
 *
 *  Revision 1.4  2006/12/14 09:53:25  atripathi
 *  minor changes in CSV report generator method
 *
 *  Revision 1.3  2006/12/13 09:30:39  atripathi
 *  methods generateCSVReport() and generateRTFReport() added to allow reports in csv and rtf formats
 *
 *  Revision 1.2  2006/06/22 22:37:54  aarora
 *  Organized imports
 *
 *  Revision 1.1  2006/06/21 11:20:25  dkumar
 *  repackaging of ReportUtility to FDCommons
 *
 *  Revision 1.4  2006/04/19 22:47:35  ranand
 *  change the LCP_RUNTIME_HOME to FD_RUNTIME_HOME
 *
 *  Revision 1.3  2006/03/28 21:23:06  aarora
 *  Repackaging of fdcommons
 *
 *  Revision 1.2  2006/02/24 21:32:16  ranand
 *  Report Generator class
 *
 *  Revision 1.1.2.3  2006/02/21 21:09:19  ranand
 *  fix Html Report image issue
 *
 *  Revision 1.1.2.2  2006/02/16 16:59:55  ranand
 *  chnges HTML report generation
 *
 *  Revision 1.1.2.1  2006/02/10 20:51:00  ranand
 *  Report Generator class to add different Report Formats
 *
 */

package com.freightdesk.fdcommons.reporting;

import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;

import net.sf.jasperreports.engine.JRExporterParameter;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.export.JExcelApiExporter;
import net.sf.jasperreports.engine.export.JRCsvExporter;
import net.sf.jasperreports.engine.export.JRCsvExporterParameter;
import net.sf.jasperreports.engine.export.JRXlsExporter;
import net.sf.jasperreports.engine.export.JRXlsExporterParameter;
import net.sf.jasperreports.engine.export.ooxml.JRDocxExporter;
import net.sf.jasperreports.engine.export.ooxml.JRDocxExporterParameter;
import net.sf.jasperreports.engine.export.ooxml.JRPptxExporter;

import org.apache.log4j.Logger;

/**
 * Report Generator class which generates the Report depending on type of
 * Format passes as Parameter.
 *
 * @author Michael Echevarria
 */

public class ReportGeneratorUtil
{

    private Logger logger = Logger.getLogger(getClass());
    /**
     *
     */
    public static final String TASK_PDF = "pdf";
    public static final String TASK_CSV = "csv";
    public static final String TASK_XLS = "xls";
    public static final String TASK_DOC = "docx";
    public static final String TASK_PPT = "pptx";
    
    /**
     * Generates report and write that to the given Output Stream
     * @param format
     * @param jasperPrint
     * @param outputStream
     * @throws IOException
     * @throws Exception
     */
	public void generateReport(String format, JasperPrint jasperPrint, OutputStream outputStream) throws IOException, Exception {
		if (TASK_PDF.equalsIgnoreCase(format)) {
			generatePDFReport(jasperPrint, outputStream);
		} else if (TASK_CSV.equalsIgnoreCase(format)) {
			generateCSVReport(jasperPrint, outputStream);
		} else if (TASK_XLS.equalsIgnoreCase(format)) {
			generateXLSReport(jasperPrint, outputStream);
		} else if (TASK_DOC.equalsIgnoreCase(format)) {
			generateDOCReport(jasperPrint, outputStream);
		} else if (TASK_PPT.equalsIgnoreCase(format)) {
			generatePptReport(jasperPrint, outputStream);
		}
	}
	
    /**
     * Generates report and write that to the given Output Stream
     * @param format
     * @param jasperPrint
     * @param outputStream
     * @throws IOException
     * @throws Exception
     */
	public void generateMultipleSheetsReport(String format, ArrayList<JasperPrint> jasperPrints, String[] sheetNames, OutputStream outputStream) throws IOException, Exception {
		if (TASK_XLS.equalsIgnoreCase(format)) {
			generateXLSMultipleSheetsReport(jasperPrints, sheetNames, outputStream);
		}
	}
	
	private void generateDOCReport(JasperPrint jasperPrint, OutputStream outputStream) throws Exception {
		logger.debug("Generating docx report");
		try {
			JRDocxExporter docExporter = new JRDocxExporter();
			
			docExporter.setParameter(JRDocxExporterParameter.JASPER_PRINT,jasperPrint);
			docExporter.setParameter(JRDocxExporterParameter.OUTPUT_STREAM,outputStream);		
			
			docExporter.exportReport();
			logger.debug("finished docx export");
        } 
        catch (Exception e)
        {
            logger.error("Exception in generating DOCX report");
            throw e;
        }
        finally
        {
            try {
                if (outputStream != null){
                    outputStream.flush();
                    outputStream.close();
                }
                
            } catch (Exception ignored) {
                logger.error ("Exception closing output stream, ignored", ignored);
            }
        }
	}

    
    private void generatePDFReport(JasperPrint jasperPrint, OutputStream outputStream) throws Exception
    {
        try {
            JasperExportManager.exportReportToPdfStream(jasperPrint, outputStream);
            
        } 
        catch (Exception e)
        {
            logger.error ("Exception in generating PDF report",e);
            throw e;
        }
        finally
        {
            try {
                if (outputStream != null){
                    outputStream.flush();
                    outputStream.close();
                }
                
            } catch (Exception ignored) {
                logger.error ("Exception closing output stream, ignored", ignored);
            }
        }
    }
    
    private void generateCSVReport(final JasperPrint jasperPrint,final OutputStream outputStream)
    {
        try{

            JRCsvExporter exporter=new JRCsvExporter();
            exporter.setParameter(JRExporterParameter.JASPER_PRINT, jasperPrint);
            exporter.setParameter(JRExporterParameter.OUTPUT_STREAM, outputStream);
            exporter.setParameter(JRCsvExporterParameter.FIELD_DELIMITER, ",");
            exporter.setParameter(JRCsvExporterParameter.RECORD_DELIMITER, "\n");
            
            // For csv output you do not need the title band or page footers.  Only the first pageHeader/columnHeader   	
    		jasperPrint.getPropertiesMap().setProperty("net.sf.jasperreports.export.csv.exclude.origin.band.pageFooter", "pageFooter");
    	  		
            exporter.exportReport();

        }
        catch(Exception e)
        {
            logger.error("Exception in generating report",e);
        }
    }   
    
    private void generateXLSReport(JasperPrint jasperPrint, OutputStream outputStream) throws Exception
    {
    	try
    	{
    		JExcelApiExporter exporterXLS = new JExcelApiExporter();
    		
    		exporterXLS.setParameter( JRXlsExporterParameter.JASPER_PRINT, jasperPrint );
    		exporterXLS.setParameter( JRXlsExporterParameter.IS_DETECT_CELL_TYPE, Boolean.TRUE );
    		exporterXLS.setParameter( JRXlsExporterParameter.IS_WHITE_PAGE_BACKGROUND, Boolean.FALSE );
    		exporterXLS.setParameter( JRXlsExporterParameter.IS_REMOVE_EMPTY_SPACE_BETWEEN_ROWS, Boolean.TRUE );
    		exporterXLS.setParameter( JRXlsExporterParameter.IS_REMOVE_EMPTY_SPACE_BETWEEN_COLUMNS, Boolean.TRUE );
    		exporterXLS.setParameter( JRXlsExporterParameter.IS_ONE_PAGE_PER_SHEET, Boolean.FALSE );
    		exporterXLS.setParameter( JRXlsExporterParameter.OUTPUT_STREAM, outputStream );
    		exporterXLS.setParameter( JRXlsExporterParameter.CREATE_CUSTOM_PALETTE, Boolean.TRUE );  
    		
    		// For excel output you do not need the title band or page footers.  Only the first pageHeader/columnHeader  
    		jasperPrint.getPropertiesMap().setProperty("net.sf.jasperreports.export.xls.exclude.origin.band.pageFooter", "pageFooter");    
    		
    		exporterXLS.exportReport();
    	}
    	catch ( Exception e )
    	{
    		logger.error( "Exception in generating XLS Report: " + e );
    	}
    }
    
    private void generateXLSMultipleSheetsReport(ArrayList<JasperPrint> jasperPrints, String[] sheetNames, OutputStream outputStream) throws Exception
    {
    	try
    	{
    		JRXlsExporter exporterXLS = new JRXlsExporter();
    		
    		logger.info("Size of jasperprints: " + jasperPrints.size());
    		logger.info("Size of sheetnames: " + sheetNames.length);
    		
    		exporterXLS.setParameter( JRXlsExporterParameter.JASPER_PRINT_LIST, jasperPrints );
    		exporterXLS.setParameter( JRXlsExporterParameter.SHEET_NAMES, sheetNames);
    		exporterXLS.setParameter( JRXlsExporterParameter.IS_DETECT_CELL_TYPE, Boolean.TRUE );
    		exporterXLS.setParameter( JRXlsExporterParameter.IS_WHITE_PAGE_BACKGROUND, Boolean.FALSE );
    		exporterXLS.setParameter( JRXlsExporterParameter.IS_REMOVE_EMPTY_SPACE_BETWEEN_ROWS, Boolean.TRUE );
    		exporterXLS.setParameter( JRXlsExporterParameter.IS_REMOVE_EMPTY_SPACE_BETWEEN_COLUMNS, Boolean.TRUE );
    		exporterXLS.setParameter( JRXlsExporterParameter.IS_ONE_PAGE_PER_SHEET, Boolean.FALSE );
    		exporterXLS.setParameter( JRXlsExporterParameter.OUTPUT_STREAM, outputStream );
    		exporterXLS.setParameter( JRXlsExporterParameter.CREATE_CUSTOM_PALETTE, Boolean.TRUE );  
   		
    		exporterXLS.exportReport();
    	}
    	catch ( Exception e )
    	{
    		logger.error( "Exception in generating XLS Report: " + e );
    	}
    }

    private void generatePptReport(JasperPrint jasperPrint, OutputStream outputStream) throws Exception {
    	try {
    		logger.debug("Exporting to PPT format");
    		
    		JRPptxExporter exporter = new JRPptxExporter ();
    		exporter.setParameter(JRExporterParameter.JASPER_PRINT,jasperPrint);
    		exporter.setParameter(JRExporterParameter.OUTPUT_STREAM,outputStream);
    		
    		exporter.exportReport();
    		
    	} catch (Exception ex) {
    		logger.error("Failed to export to PPT report");
    	}
    }
}
