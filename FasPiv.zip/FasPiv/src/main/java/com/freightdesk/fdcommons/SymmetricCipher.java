/** 
* Copyright (c) 2000-2002 NTELX 
*  All rights reserved. 
* 
* This software is the confidential and proprietary information of NTELX 
* ("Confidential Information").  You shall not disclose such Confidential Information 
* and shall use it only in accordance with the terms of the license agreement you entered 
* into with NTELX. 
* 
* 
*  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/SymmetricCipher.java,v 1.4.4.1.2.3 2010/12/01 21:57:17 mechevarria Exp $ 
* 
*  Modification History:
*  $Log: SymmetricCipher.java,v $
*  Revision 1.4.4.1.2.3  2010/12/01 21:57:17  mechevarria
*  use runtime only
*
*  Revision 1.4.4.1.2.2  2009/07/22 17:10:30  mechevarria
*  added new debug
*
*  Revision 1.4.4.1.2.1  2009/07/16 19:40:16  mechevarria
*  changed fdt_store.ks lookup path to be in FD-runtime by default
*
*  Revision 1.4.4.1  2007/05/18 18:52:37  mechevarria
*  merge with main branch
*
*  Revision 1.4  2007/04/19 11:04:37  dkumar
*  simple DES algo
*
*  Revision 1.3  2007/04/19 10:35:17  dkumar
*  removed BoncyCastle provder and used simple DES algo
*
*  Revision 1.2  2007/04/16 14:42:14  dkumar
*  using Bouncecastle crypto provider
*
*  Revision 1.1  2007/04/12 16:30:46  dkumar
*  base version
*
*/
package com.freightdesk.fdcommons;

import org.apache.log4j.Logger;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.security.GeneralSecurityException;
import java.security.Key;
import java.security.KeyStore;

public class SymmetricCipher {

     protected final Logger logger = Logger.getLogger("SymmetricCipher");
	 
	 private static final String algorithm = "DES";
     
     private static SymmetricCipher symmetricCipher ;

     
     private Key key = null;
     private Cipher cipher = null;

     private SymmetricCipher()
     {
         try {
             setUp();
         } catch (Exception e) {
             //System.err.println("Exception in SymmetricCipher :"+e.getMessage());
             //e.printStackTrace(System.err);
			 logger.error("Exception: " + e.getMessage());
         }
     }
     
     public static SymmetricCipher getInstance()
     {
         if(symmetricCipher == null)
         {
             symmetricCipher = new SymmetricCipher();
         }
         return symmetricCipher;
     }
     
     public static void resetCipher()
     {
         symmetricCipher = new SymmetricCipher();
     }
     
     private void setUp() throws Exception
     {
    	 String storeName = "";
    	 String FD_RUNTIME_HOME = "";
    	 
    	 // nx_store.ks is assumed to be in the same folder as FD_RUNTIME
    	 if(System.getProperty("RUNTIME_HOME") != null) {
    		 FD_RUNTIME_HOME = System.getProperty ("RUNTIME_HOME") +  File.separator;
    	 } else {
    		 System.out.println("FD_RUNTIME_HOME is null");
    	 }
         
         if((FDSuiteProperties.getProperty("FDSUITE_STORE")!=null))
             storeName=FD_RUNTIME_HOME + FDSuiteProperties.getProperty("FDSUITE_STORE");
         
         char[] storePasswd = "".toCharArray();
         if(FDSuiteProperties.getProperty("FDSUITE_STORE_PHRASE")!=null)
             storePasswd = FDSuiteProperties.getProperty("FDSUITE_STORE_PHRASE").toCharArray();
         
         char[] keyPasswd = "".toCharArray();
         if(FDSuiteProperties.getProperty("FDSUITE_SC_PHRASE")!=null)
         {
             keyPasswd = FDSuiteProperties.getProperty("FDSUITE_SC_PHRASE").toCharArray();
         }

         String keyAlias = "";
         if(FDSuiteProperties.getProperty("FDSUITE_SC_NAME")!=null)
         {
             keyAlias = FDSuiteProperties.getProperty("FDSUITE_SC_NAME");
         }
         
         KeyStore ks = KeyStore.getInstance("JCEKS");   
         FileInputStream fis = new FileInputStream(storeName);
         ks.load(new BufferedInputStream(fis), storePasswd);
         Key retrievedKey = ks.getKey(keyAlias, keyPasswd);
         if (retrievedKey instanceof SecretKey) {
             key = (SecretKey) retrievedKey;
         } else {
             System.out.println("Failed - Keys retrieved is of WRONG type!");
         }
         
         cipher = Cipher.getInstance(algorithm);
     }


     public byte[] encrypt(byte[] input) throws GeneralSecurityException 
     {
         cipher.init(Cipher.ENCRYPT_MODE, key);
         return cipher.doFinal(input);
     }

     public byte[] decrypt(byte[] encryptionBytes) throws GeneralSecurityException 
     {
         cipher.init(Cipher.DECRYPT_MODE, key);
         byte[] recoveredBytes = cipher.doFinal(encryptionBytes);
         return recoveredBytes;
       }
     
     
     public void main(String[] args) 
     throws Exception 
     {
         SymmetricCipher smCipher = getInstance();
         smCipher.setUp();
         if (args.length !=1) {
             System.out.println("USAGE: java LocalEncrypter " + "[String]");
             //System.exit(1);
         }
         byte[] encryptionBytes = null;
         String input = args[0];
         System.out.println("Entered: " + input);
         encryptionBytes = smCipher.encrypt(input.getBytes());
         System.out.println(encryptionBytes.length+" "+ new String(encryptionBytes,0,encryptionBytes.length,"UTF-8"));
         System.out.println("Recovered: " + new String(smCipher.decrypt(encryptionBytes)));
  }

}  
