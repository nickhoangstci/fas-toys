/** 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolioweb/addressbook/action/AddressHomeAction.java,v 1.23.2.7 2010/10/01 19:57:27 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: AddressHomeAction.java,v $
 *  Revision 1.23.2.7  2010/10/01 19:57:27  mechevarria
 *  jboss6 upgrade
 *
 *  Revision 1.23.2.6  2010/09/23 19:35:25  mechevarria
 *  remove ejb layer for instantiating objects.  direct calls to bean class now made
 *
 *  Revision 1.23.2.5  2010/09/15 15:18:21  mechevarria
 *  better log message
 *
 *  Revision 1.23.2.4  2010/08/22 23:08:27  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.23.2.3  2010/02/03 20:31:47  mechevarria
 *  update addresshome load query getorghierarchies to use bind variables
 *
 *  Revision 1.23.2.2  2009/02/23 20:49:01  mechevarria
 *  security updates
 *
 *  Revision 1.23.2.1  2007/12/13 15:15:32  mechevarria
 *  added function to remove possible bad characters from xss vulnerable fields
 *
 *  Revision 1.23  2007/01/29 11:02:31  atripathi
 *  user feedback messages added on successfull import of CSV
 *
 *  Revision 1.22  2006/11/01 12:02:49  dkumar
 *  added feedback message on Address deletion
 *
 *  Revision 1.21  2006/10/27 09:30:56  dkumar
 *  added address import/export functinality
 *
 *  Revision 1.20  2006/10/19 12:02:57  dkumar
 *  added code for org child navigation
 *
 *  Revision 1.19  2006/05/11 16:55:27  aarora
 *  Many changes as the SessionKey class has been added to com.freightdesk.fdfolio.commons
 *
 *  Revision 1.18  2006/04/10 22:42:23  aarora
 *  Removed redundant code
 *
 *  Revision 1.17  2006/03/28 21:22:59  aarora
 *  Repackaging of fdcommons
 *
 *  Revision 1.16  2005/09/28 08:35:54  ranand
 *  Code clean up of Address Module
 *
 *  Revision 1.15  2005/08/30 02:14:37  amrinder
 *  Trying to clean the code for handling links on address tab
 *
 *  Revision 1.14  2005/08/09 21:59:34  amrinder
 *  Some formatting changes
 *
 *  Revision 1.13  2005/08/03 12:06:56  ranand
 *  sorting applied on address home page
 *
 *  Revision 1.12  2005/07/27 09:31:30  ranand
 *  Class name changed from LcpProperties to ApplicationProperties
 *
 *  Revision 1.11  2005/07/05 12:50:46  nsehra
 *  removed isMyaddressbook there is already a session attribute ADDRESS_TYPE to provide the  functionality
 *
 *  Revision 1.10  2005/07/02 10:07:26  nsehra
 *  changed for myaddressbook
 *
 *  Revision 1.9  2005/06/23 14:20:14  nsehra
 *  Removed "No Data Found" message
 *
 *  Revision 1.8  2005/05/13 22:16:05  amrinder
 *  Some javadoc changes, and removed get from session and put into session store methods
 *
 *  Revision 1.7  2005/04/12 05:10:10  nsehra
 *  no message
 *
 *  Revision 1.6  2005/01/24 09:21:28  biju
 *  bug 1175 fixing
 *
 *  Revision 1.5  2004/12/16 06:43:46  amrinder
 *  General rework of organization module
 *
 *  Revision 1.4  2004/11/04 08:31:29  biju
 *  bug fixing - 1142
 *
 *  Revision 1.3  2004/10/11 10:01:42  biju
 *  bug 1130 fixed (added invokedFrom in queryString formation map)
 *
 *  Revision 1.2  2004/10/04 09:07:34  asaxena
 *  1. added constructor for AddressHomeAction class to initialize
 *     noOfAddressRecordsToLoad variable
 *  2.changed the hard coded value '200' by the varialbe noOfAddressRecordsToLoad
 *
 *  Revision 1.1  2004/09/15 13:36:27  asingh
 *  2.6 Baseline
 */

package com.freightdesk.fdfolioweb.addressbook.action;

import java.util.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.log4j.Logger;
import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionSupport;
import com.freightdesk.fdfolio.addressbook.AddressBookManager;

import crt.com.freightdesk.fdfolio.addressbook.util.OrgSearchResult;

import com.freightdesk.fdfolio.common.LcpReferenceData;
import com.freightdesk.fdfolio.dao.EventDAO;
import com.freightdesk.fdfolio.dao.OrghierarchyDAO;

import crt.com.freightdesk.fdfolio.orghierarchy.OrghierarchyBeanManager;

import com.freightdesk.fdfolio.orghierarchy.model.OrghierarchyModel;

import crt.com.freightdesk.fdfolioweb.orghierarchy.action.AddressHomeFilter;

import com.freightdesk.fdfolioweb.orghierarchy.action.OrghierarchyAction;
import com.freightdesk.fdcommons.ApplicationProperties;
import com.freightdesk.fdcommons.ApplicationTabs;
import com.freightdesk.fdcommons.Credentials;
import com.freightdesk.fdcommons.FDSuiteProperties;
import com.freightdesk.fdcommons.LcpConstants;
import com.freightdesk.fdcommons.ObjectLock;

import crt.com.ntelx.nxcommons.NxUtils;

import com.freightdesk.fdcommons.OperationInfo;
import com.freightdesk.fdcommons.OptionBean;
import com.freightdesk.fdcommons.SessionKey;
import com.freightdesk.fdcommons.SessionStore;
import com.freightdesk.fdcommons.StackManager;
import com.freightdesk.fdcommons.SystemUnavailableException;

import crt.com.ntelx.nxcommons.reporting.OptionCollectionManager;
import crt.com.freightdesk.fdfolio.common.IncludesUtil;

import com.freightdesk.fdfolioweb.orghierarchy.action.OrghierarchyAction.OrgFormFieldBean;

/**
 * The Struts Action class associated with AddressHome.jsp and the AddressHomeForm.
 *
 * @author Amrinder Arora 
 */
public class AddressHomeAction extends ActionSupport implements ServletRequestAware {
    class pager{
        public String offset;
		
    }
    private AddressHomeAction.pager pager = new AddressHomeAction.pager();
    protected Logger logger = Logger.getLogger(getClass());
    HttpServletRequest request = ServletActionContext.getRequest();
    private String loginTimeRoleMsg;
    
    /** An instance of AddressBookManager */
    protected AddressBookManager addrManager = new AddressBookManager();

    //variable used to pick no of records to load in a go.
    private int noOfAddressRecordsToLoad = 100;
    private String noOfAddressRecordsToLoadStr;
    private static final long serialVersionUID = 1L;
	
    // variables used to identify the user actions
    private String hdnProcess;
    private String action;
    private String imageClicked;
    private String invokedFrom;
    private String pagerOffset;
    
    // for addressHome searches
    private String orgHierarchyTypeCode;
    private String orgName;
    private String parentOrgName;
    private long addressId;
    private String city;
    private String stateProvinceCode;
    private String countryCode;
    private String countryName;
    private long orgId;
    
    //SearchBean string
    private String search;
    private String refSearch;
    private String selectRefType;
    private List<OptionBean> refTypeList = new ArrayList<OptionBean>();
    private List<String> refTypeStrList = new ArrayList<String>();
    private String start="";
    
    private List<OptionBean> orgTypeList = new ArrayList<OptionBean>();
    private List<String> orgTypeStrList = new ArrayList<String>();

    private String origin;
    private String lookup;
    private String link;
    private String parent;
    private String fromWhere;
    private String type;
    private String role;
    private String sortingOrder;
    private String sortingAttribute;
    private String forward;
    private String id;
    private String fromTab;
    private String process;
    private int index;
    private String selectedInvolvedPartyQualifier;
    private String Valid;
    
//    private FormFile file;
    private OrghierarchyModel orgModel;
    private List<OrghierarchyModel> orgList = new ArrayList();
    //private List<?> orgList;
    private List<Map> orgListMap;
    
    //map contains parameters to write in the query string of hyper refernces
    private HashMap linkSearchMap;
    private String home;

    String arrayAlphabet[] =  {"A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z" };

    /** Creates an instance of AddressHomeAction.
     * Attempts to load the addressbook maximum results property from configurable
     * properties.  If no such property is set, uses the default value of 100. */
    public AddressHomeAction () {
        try {
            noOfAddressRecordsToLoad =Integer.parseInt (ApplicationProperties.getProperty ("ADDRESSBOOK_MAXIMUM_RESULTS"));
            noOfAddressRecordsToLoadStr = Integer.toString(noOfAddressRecordsToLoad);            
        } catch (Exception ignored) {
            logger.debug ("ADDRESSBOOK_MAXIMUM_RESULTS property is not set, defaulting to 100 " + ignored);          
        }
    }
    
    private void cleanXss() {
    	logger.debug("Cleaning possible XSS characters from AddressHomeForm.");
    	String hdnProcess = getHdnProcess();
        String search = getSearch();
        String lookup = getLookup();
        String origin = getOrigin();
        String invokedFrom = getInvokedFrom();
        String link = getLink();
        String parent = getParent();
        String type = getType();
        String start = getStart();
        
        setHdnProcess(StringEscapeUtils.escapeHtml(hdnProcess));
        setOrigin(StringEscapeUtils.escapeHtml(origin));
        setInvokedFrom(StringEscapeUtils.escapeHtml(invokedFrom));
        setLookup(StringEscapeUtils.escapeHtml(lookup));
        setLink(StringEscapeUtils.escapeHtml(link));
        setParent(StringEscapeUtils.escapeHtml(parent));
        setType(StringEscapeUtils.escapeHtml(type));
        setStart(StringEscapeUtils.escapeHtml(start));
        return;
    }

    /**
     * Identifies the action and then delegates the
     * request to the appropriate method.
     */
    public String execute() throws Exception
    {
        logger.debug("beginning...");
        request = ServletActionContext.getRequest();
        HttpSession session = request.getSession(false);
        SessionStore store = SessionStore.getInstance(session);
        Credentials credentials = (Credentials) store.get(SessionKey.CREDENTIALS);
        
        loginTimeRoleMsg = IncludesUtil.getWelcomeMsg(credentials)+ "<br>" + IncludesUtil.getExpireMsg(credentials);
        
        // POAM HttpOnly Secure
        HttpServletResponse response = (HttpServletResponse)ServletActionContext.getResponse();
        String secure = "";
        if (request.isSecure())
        {
          secure = "; Secure";
        }
        response.setHeader("SET-COOKIE", "JSESSIONID=" + request.getSession().getId()
                         + "; Path=" + request.getContextPath() + "; HttpOnly" + secure);
        
        // Clean variables to fix XSS vulnerability
        cleanXss();

        setNoOfAddressRecordsToLoad(getNoOfAddressRecordsToLoad());
        SessionStore ss = SessionStore.getInstance(request.getSession());
        String advanceSearch = (String)ss.get(SessionKey.ADVANCE_SEARCH_QUERY);
        try {
        	String forward = getForward();               
                String tOrgId = request.getParameter("orgId");
                if (tOrgId != null) {
                    orgId = Long.parseLong(tOrgId);
                }
                
                setHdnProcess (request.getParameter("hdnProcess"));               
                               
				if (((hdnProcess != null) && (hdnProcess.equalsIgnoreCase("DELETE"))) 
				     || ((hdnProcess != null) && (hdnProcess.equalsIgnoreCase("sortByColumn")))){
                    setProcess(hdnProcess);
                } 
                
        	if(NxUtils.notEmptyOrBlank(forward))
        		return tokenThenForward(request,forward,id);
        	
            //For Paging          
            if (request.getParameter("pager.offset") != null) {               
                setPagerOffset(request.getParameter("pager.offset"));
                store.put (SessionKey.INDEX, pagerOffset);
                
                orgList = (List<OrghierarchyModel>)store.get(SessionKey.ORGANIZATION_LIST);
                orgListMap = convertToOrgListMap(orgList);
                
                return displayPage();
            }
            
            logger.debug("From Tab is: " + request.getParameter("fromTab"));
            
            if (getFromTab() != null ) {                
                type = getType();              
                return initPage();
                
            }
            

            // major action is identified from the process variable
            String process = getProcess();
            logger.debug("Process variable on form is: " + process);

            // considered that request is from Address Tab
            if (process == null || process.equals("")) {
                logger.debug("execute: process is null request is for organization");               
                return doAddressHomeLoadPage ();
            }

            // quick search from address home                    // request is from the alphabet link
            if ((process.equalsIgnoreCase("search")) || (process.equalsIgnoreCase("searchAddress"))) {
                respondBtnSearch(request, process);
                logger.debug("Searching from address home.");               
                return doAddressHomeSearch ();
            } else if (process.equalsIgnoreCase("delete")) {               
                logger.debug("execute: inside if (process.equalsIgnoreCase(delete))");
                return respondBtnDelete();
            }
            else if (process.equalsIgnoreCase("carrierlookup")) { //request from tarriff module
                logger.debug("execute: inside if (process.equalsIgnoreCase(carrierlookup))");
                return respondBtnCarrierLookup();
            } else if (process.equalsIgnoreCase("lookup"))    { // lookup for the address details from any other modules
                logger.debug("execute: inside if (process.equalsIgnoreCase(lookup))");
                return respondBtnLookup();
            } else if (process.equalsIgnoreCase("addressHome")) { //request is from oraganization or routing modules
                logger.debug("execute: inside if (process.equalsIgnoreCase(addressHome))");
                return respondBtnAddressHome ();
            } else if (process.equalsIgnoreCase("advancedSearch") || advanceSearch != null) { //request is from Advance Search Page
                logger.debug("execute: inside if (process.equalsIgnoreCase(advanceSearch))");
                respondBtnSearch(request, process);
                return respondBtnAdvancedSearch ();
            } else if (process.equalsIgnoreCase("cancelAdvanceSearch")) { 
                logger.debug("execute: inside if (process.equalsIgnoreCase(cancelAdvanceSearch))");
                ss.remove(SessionKey.ADVANCE_SEARCH_QUERY);
                StackManager sm = (StackManager)ss.get(SessionKey.STACK);
                sm.closeEvent();
                return doAddressHomeLoadPage();
            } else if ("sortByColumn".equalsIgnoreCase(process)) {
                return respondSortByColumn ();
            } else if ("navigateOrghierarchy".equalsIgnoreCase(process)) {
                return respondBtnNavigateOrghierarchy ();
            } else if ("import".equalsIgnoreCase(process)) {
                return process; 
            } else { // request is for oraganization list
                return doAddressHomeLoadPage();
            } // end of the if-else ladder

        } catch (Exception ex) {
            logger.error("Unexpected exception in execute(): ", ex);
            throw ex;
        }
    }

    private String respondBtnNavigateOrghierarchy() throws Exception {
        logger.info ("respondBtnNavigateOrghierarchy(): begin");
        request = ServletActionContext.getRequest();
        HttpSession session = request.getSession(false);
        SessionStore store = SessionStore.getInstance(session);
        Credentials credentials = (Credentials) store.get(SessionKey.CREDENTIALS);

        //List<?> orgList = null;
        List<OrghierarchyModel> orgList = null;
        long[] indexes = getPagingIndex(request,noOfAddressRecordsToLoad,false);

        try {
            SessionStore sessionStore = SessionStore.getInstance(request.getSession());
            long parentId = ((Long)sessionStore.get(SessionKey.PARENT_ORGID)).longValue();
            String orgHierarchyTypeCode = request.getParameter("orgHierarchyTypeCode");
            OrgSearchResult addressSearchResult = addrManager.getAddressHomeForOrgOrLoc(parentId,credentials,orgHierarchyTypeCode,indexes[0],indexes[1]);
            orgList = addressSearchResult.getOrgList();
            orgListMap = convertToOrgListMap(orgList);
            long count = addressSearchResult.getCount();
            sessionStore.put (SessionKey.TOTAL_COUNT, new Long(count));
            sessionStore.put (SessionKey.ORGANIZATION_LIST, orgList);
            return displayPage();
        } catch (Exception ex) {
            logger.error ("respondBtnNavigateOrghierarchy: unexpected expection", ex);
            throw ex;
        }
    }

    /**
     * The display method.  It is called when the request is forwarded from some other
     * page.
     */
    protected String displayPage () {
        request = ServletActionContext.getRequest();
        HttpSession session = request.getSession(false);
        SessionStore store = SessionStore.getInstance(session);
        Credentials credentials = (Credentials) store.get(SessionKey.CREDENTIALS);
		SessionStore sessionStore = SessionStore.getInstance (request.getSession());
        List<OrghierarchyModel> orgSessionList = (List<OrghierarchyModel>) (sessionStore.get(SessionKey.ORGANIZATION_LIST));
		
        setNoOfAddressRecordsToLoad(getNoOfAddressRecordsToLoad());	
		
		try {                       
            if ((getSortingAttribute()!= null) && (getSortingAttribute().trim().length()> 0)) {                
				addrManager.sortByColumn(orgSessionList,getSortingAttribute(),getSortingOrder().equals("up")?true:false);		
                orgListMap = convertToOrgListMap(orgSessionList);
		        request.setAttribute("OrgSessionList", orgSessionList);                
                request.setAttribute("SortingOrder", sortingOrder);
                request.setAttribute("SortingAttribute", sortingAttribute);
                	       
            }
        } catch (Exception e) {
            logger.error("caught exception");            
        }
		
        String strLink = getLink();
        String strParent  = getParent();
		
	logger.debug("displayPage strParent req.getPara...."+strParent);
        
        if (strParent == null || strParent.equals("")) {
            strParent = (String)request.getAttribute("hierarchytype");
        }

        String strLookup  = getLookup();
        logger.debug("strParent = "+strParent);
        

        //initalising the hashmap of the form bean  to keep the parameters on the hyper link
        HashMap<String, String> hmParam = new HashMap<String, String>();

        //check it again.........during integrated testing
        if (strLink == null )  {
            strLink = "null";
            request.setAttribute("Link",strLink);
        }
        if (strParent == null || strParent.equals(""))  {
            strParent = "null";
        }
        if (strLookup == null)  {
            strLookup = "null";
            request.setAttribute("Lookup",strLookup);
        }

        setLink(strLink);
        setParent(strParent);
        setLookup(strLookup);
        
        
        String process = getHdnProcess();
        
        hmParam.put("link",strLink);
        hmParam.put("parent",strParent);
        hmParam.put("lookup",strLookup);
        
        hmParam.put("hdnProcess",process);
        hmParam.put("origin","address");
        hmParam.put("invokedFrom",getInvokedFrom());
        if (strLookup.equalsIgnoreCase("involve")) {
            hmParam.put("selectedInvolvedPartyQualifier",request.getParameter("selectedInvolvedPartyQualifier"));
        }
        //setting the hashmap of form bean
        setLinkSearchMap(hmParam);
        
        //setting the message for the search result in to the request
        sessionStore.put (SessionKey.IS_FORWARDED,"No");
        sessionStore.put (SessionKey.CURRENT_TAB,ApplicationTabs.ADDRESS);
        
        
        LcpReferenceData lcpRefData = LcpReferenceData.getInstance(credentials.getDomainName());
        setRefTypeList(lcpRefData.getOrganizationReferenceTypeCodesList());
        
        refTypeStrList = convertRefTypeListToStringList (refTypeList);
        
        OptionCollectionManager optionManager = OptionCollectionManager.getInstance();
        setOrgTypeList(optionManager.getCollection("orgTypeList"));
        
        orgTypeStrList = convertOrgTypeListToStringList (getOrgTypeList());
        
        setType( convertOrgTypeValueToLabel(getType(), orgTypeList));
        
        if ((getSearch() != null) &&(getSearch().equalsIgnoreCase("NULL"))){
            setSearch("");
        }
        
        return "display";
    }

    /**
     * It is called when the execute method decides that action is for quick search(from the address home)
     **/
    protected String doAddressHomeSearch ()
        throws java.lang.Exception {
        request = ServletActionContext.getRequest();
        HttpSession session = request.getSession(false);
        SessionStore store = SessionStore.getInstance(session);
        Credentials credentials = (Credentials) store.get(SessionKey.CREDENTIALS);
                
        try {
            String link = getLink();
            String parent = getParent();
            List<String> typeList = new ArrayList<String>();
            typeList.add(parent);
            String fromWhere = getFromWhere();
            // gets an instance of session store
            SessionStore sessionStore = SessionStore.getInstance (request.getSession());

            List<OrghierarchyModel> orgList = null;
            long count = 0;
            long[] indexes = getPagingIndex(request,noOfAddressRecordsToLoad,false);
            
            sessionStore.put (SessionKey.SEARCH_STR, getSearch());
            
            // hdnParent variable does not have any proper value, so calling getQuickAddressHomeForTab
            if ((parent == null || parent.equalsIgnoreCase("null") || parent.trim().equals("")) || "ADDRESS".equalsIgnoreCase(fromWhere)) {
                logger.debug("parent value on form is empty or null");
                
				
                String addressType = getType();
				
				if(addressType != null) {
					// put AddressHome search filter
					
					AddressHomeFilter filter = new AddressHomeFilter();
					filter.setType(addressType.toUpperCase());
					filter.setSearch(getSearch().toUpperCase());
					filter.setReftype(getSelectRefType().toUpperCase());
					filter.setRefvalue(getRefSearch().toUpperCase());
					
					sessionStore.put(SessionKey.SEARCH_FILTER, filter);
				} else {
					addressType = (String)sessionStore.get(SessionKey.ADDRESS_TYPE);
				}
					
                OrgSearchResult addressSearchResult = addrManager.getQuickAddressHomeForTab(search, selectRefType, refSearch, credentials, 
                        addressType, null, indexes[0], indexes[1]);
                orgList = addressSearchResult.getOrgList();
                orgListMap = convertToOrgListMap(orgList);
                count = addressSearchResult.getCount();
            } else  { //hdnParent variable does have value ,so calling getAddressHome
                OrgSearchResult addressSearchResult = addrManager.getAddressHome(search,credentials,typeList, indexes[0], indexes[1]);
                orgList = addressSearchResult.getOrgList();
                orgListMap = convertToOrgListMap(orgList);
                count = addressSearchResult.getCount();
                request.setAttribute("Parent", parent);
            }


            // stores the organization list into the session (store)
            sessionStore.put (SessionKey.ORGANIZATION_LIST, orgList);
            sessionStore.put (SessionKey.TOTAL_COUNT, new Long(count));
            logger.debug("respondBtnQuickAddressSearch: after calling addrmgr: orgList.size() = " + orgList.size());
            

            // gets the stack manager from the session store
            StackManager sm = (StackManager) (sessionStore.get(SessionKey.STACK));
            OperationInfo operationInfo = (OperationInfo)sm.currentEvent();
            String oprType = operationInfo.getOperationType();
            logger.debug("respondBtnQuickAddressSearch: oprType is" + oprType+"  operationInfo "+operationInfo+ " link  "+link);
            
            if (oprType.equalsIgnoreCase("originloclookup") || oprType.equalsIgnoreCase("destloclookup") || (link != null && !link.equalsIgnoreCase("null") && !"".equals(link))) {
                sessionStore.put (SessionKey.SEARCH_PROCESS,"");
            } else {
                sessionStore.put (SessionKey.SEARCH_PROCESS,"addressDisplay");
            }

            return displayPage();
        } catch(Exception ex) {

            logger.debug("respondBtnQuickAddressSearch : unexpected expection ",ex);
            throw ex;
        }
    }
    // end of respondBtnQuickAddressSearch method

    //This method is used when the Tarriff module makes a request for the AddressHome.
    protected String respondBtnCarrierLookup()
        throws java.lang.Exception
    {
        request = ServletActionContext.getRequest();
        HttpSession session = request.getSession(false);
        SessionStore store = SessionStore.getInstance(session);
        Credentials credentials = (Credentials) store.get(SessionKey.CREDENTIALS);
        
        
        try    {
            logger.info ("respondBtnCarrierLookup : started ");
            long[] indexes = getPagingIndex(request,noOfAddressRecordsToLoad,false);
            //get the organization list from the manager
            OrgSearchResult addressSearchResult = addrManager.getAddressHomeForCarrier(search , credentials, indexes[0], indexes[1]);
            
            List<OrghierarchyModel> orgList = addressSearchResult.getOrgList();
            orgListMap = convertToOrgListMap(orgList);
            long count = addressSearchResult.getCount();
            SessionStore sessionStore = SessionStore.getInstance (request.getSession());
            sessionStore.put (SessionKey.TOTAL_COUNT, new Long(count));
            //storing the organization list into the session using SessionStore utility
            sessionStore.put (SessionKey.ORGANIZATION_LIST,orgList);

            return displayPage();
        }
        catch(Exception ex)    {
            logger.error ("respondBtnCarrierLookup : Exception is :  ", ex);
            throw ex;
        }
    } // end of respondBtnCarrierLookup method

    //ask to change the name of search to txtSearch .. actual requirement has to be find out
    protected String respondBtnLookup()
        throws java.lang.Exception {
        request = ServletActionContext.getRequest();
        HttpSession session = request.getSession(false);
        SessionStore store = SessionStore.getInstance(session);
        Credentials credentials = (Credentials) store.get(SessionKey.CREDENTIALS);
       
		try {
            logger.info ("respondBtnLookup : started ");
            
            //get the origin
            String origin = getOrigin();
            //origin of the request - can be any other modules of the LCP application
            
            OrgSearchResult addressSearchResult = null;
            if (origin != null)
            { 

                long[] indexes = getPagingIndex(request,noOfAddressRecordsToLoad,false);
                if (origin.equalsIgnoreCase("useraddress")) 
                {
                    //check the SearchBean string req, later
                    addressSearchResult = addrManager.getAddressHomeForUserAccess(search, credentials, indexes[0], indexes[1]);
                } else if (origin.equalsIgnoreCase("address")) {
                    String involvedPartyQualifier = request.getParameter("selectedInvolvedPartyQualifier");
                    //check the SearchBean string req, later
                    addressSearchResult = addrManager.getAddressHomeForLookUp(search, credentials,involvedPartyQualifier, indexes[0], indexes[1]);
                }

                if (addressSearchResult != null) {
					List<OrghierarchyModel> orgList = addressSearchResult.getOrgList();
					orgListMap = convertToOrgListMap(orgList);
					long count = addressSearchResult.getCount();
					SessionStore sessionStore = SessionStore.getInstance (request.getSession());
					sessionStore.put (SessionKey.TOTAL_COUNT, new Long(count));
					//storing the organization list into the session using SessionStore utility
					sessionStore.put (SessionKey.ORGANIZATION_LIST,orgList);
				}
                return displayPage();
            }

            logger.error ("respondBtnLookup : no matching condition ");
            throw new RuntimeException ("respondBtnLookup : no matching conditions");
        } catch(Exception ex) {
            logger.error ("respondBtnLookup : Exception is :  ", ex);
            throw ex;
        } 

    } //end of respondBtnLookup method

    /**
     * This method is used when request is for address home
     */
    protected String respondBtnAddressHome()
        throws java.lang.Exception {
        request = ServletActionContext.getRequest();
        HttpSession session = request.getSession(false);
        SessionStore store = SessionStore.getInstance(session);
        Credentials credentials = (Credentials) store.get(SessionKey.CREDENTIALS);
                
        try {
            logger.info ("respondBtnAddressHome : started ");
            /*
             *    hierarchy type can be ORG,LOC,CON
             *    ORG - Organization
             *    LOC - Location
             *    CON - Contact
             */
            long[] indexes = getPagingIndex(request,noOfAddressRecordsToLoad,false);
            SessionStore sessionStore = SessionStore.getInstance (request.getSession());

            String hiertypes = (String)request.getAttribute("hierarchytype");
            List<String> typeList = new ArrayList<String>();
            
            //List<?> orgList = null;
            List<OrghierarchyModel> orgList = null;
            if ((hiertypes != null) && (!hiertypes.equals(""))) {
            	// hiertypes is probably ORG,CAR
            	String[] typeTokenized = hiertypes.split(",");
            	Collections.addAll(typeList, typeTokenized); 
            	
                OrgSearchResult addressSearchResult = addrManager.getAddressHome(search, credentials, typeList, indexes[0], indexes[1]);
                orgList = addressSearchResult.getOrgList();
                orgListMap = convertToOrgListMap(orgList);
                long count = addressSearchResult.getCount();
                sessionStore.put (SessionKey.TOTAL_COUNT, new Long(count));
            } else { //if the hierarchy type is not available
                OrgSearchResult addressSearchResult = addrManager.getAddressHomeForLookUp(search, credentials,"", indexes[0], indexes[1]);
                orgList = addressSearchResult.getOrgList();
                orgListMap = convertToOrgListMap(orgList);
                long count = addressSearchResult.getCount();
                sessionStore.put (SessionKey.TOTAL_COUNT, new Long(count));
            }

            //storing the organization list into the session using SessionStore utility
            sessionStore.put (SessionKey.ORGANIZATION_LIST,orgList);

            logger.debug("respondBtnAddressHome: after calling addrmgr orgList.size is " + orgList.size());

            return displayPage();
        } catch(Exception ex)    {
            logger.error ("respondBtnAddressHome : Exception is :  ", ex);
            throw ex;
        }
    } //end of respondBtnAddressHome  method

    /**
     * Responds the clicking of a link on the drop down on the address tab.
     */
    protected String doAddressHomeLoadPage()
        throws Exception {
        request = ServletActionContext.getRequest();
        HttpSession session = request.getSession(false);
        SessionStore store = SessionStore.getInstance(session);
        Credentials credentials = (Credentials) store.get(SessionKey.CREDENTIALS);
        
        try {
            logger.debug ("begin");
            

            long[] indexes = getPagingIndex(request,noOfAddressRecordsToLoad,true);
            
            
            SessionStore sessionStore = SessionStore.getInstance (request.getSession());
            String orgType = "";
            AddressHomeFilter filter = (AddressHomeFilter)sessionStore.get(SessionKey.SEARCH_FILTER);
            if (sessionStore.get(SessionKey.SEARCH_FILTER) != null) {
            	logger.debug("!! " + filter);
                
                orgType = filter.getType();
                setType(filter.getType());
                setSelectRefType(filter.getReftype());
                setRefSearch(filter.getRefvalue());
                setSearch(filter.getSearch());
            }
            String orgRole = (String)sessionStore.get(SessionKey.ORG_ROLE);
            if (sessionStore.get(SessionKey.ORG_ROLE) == null) {
                orgRole = getRole();
                logger.debug("orgRole: " + orgRole);
                
                if (orgRole != null) {
                    sessionStore.put (SessionKey.ADDRESS_TYPE, orgRole);
                }
            }
            
            LcpReferenceData lcpRefData = LcpReferenceData.getInstance(credentials.getDomainName());
            setRefTypeList(lcpRefData.getOrganizationReferenceTypeCodesList());
            OptionCollectionManager optionManager = OptionCollectionManager.getInstance();
            setOrgTypeList(optionManager.getCollection("orgTypeList"));
            
            
            setSelectRefType( convertRefTypeLabelToValue(getSelectRefType(), refTypeList));
            
            setType( convertOrgTypeLabelToValue(getType(), orgTypeList));
            
            OrgSearchResult addressSearchResult = addrManager.getQuickAddressHomeForTab(getSearch(), getSelectRefType(), getRefSearch(), credentials, 
                    type, orgRole, indexes[0], indexes[1]);
            
            List<OrghierarchyModel> orgList = addressSearchResult.getOrgList();
            orgListMap = convertToOrgListMap(orgList);
            long count = addressSearchResult.getCount();
            

            sessionStore.put (SessionKey.TOTAL_COUNT, new Long(count));
            //storing the organization list into the session using SessionStore utility
            sessionStore.put (SessionKey.ORGANIZATION_LIST, orgList);
            sessionStore.remove(SessionKey.SEARCH_PROCESS);
            logger.debug("after calling addrmgr orgList.size() = " + orgList.size());
            
            return displayPage();
        }
        catch (Exception ex) {
            logger.error ("respondBtnQuickAddressHomeForTab: Exception is: ", ex);            
            throw ex;
        }
    }

    void printOrgList(List<OrghierarchyModel> theOrgList){
        Iterator<OrghierarchyModel>  itrList = theOrgList.iterator();
        OrghierarchyModel orghModel = new OrghierarchyModel();
        
        while (itrList.hasNext()) {
            orghModel = (OrghierarchyModel)itrList.next();           
        }
    }
    
    List<Map> convertToOrgListMap(List<OrghierarchyModel> theOrgList){
        int starting_idx=0;
        int counter=0;
        List<Map> theOrgListMap = new ArrayList();
        Map map = new HashMap();
        Iterator<OrghierarchyModel>  itrList = theOrgList.iterator();
        OrghierarchyModel orghModel = new OrghierarchyModel();
        if (request.getParameter("pager.offset") != null) {
            starting_idx = Integer.parseInt((String)request.getParameter("pager.offset"));
        }
        while (itrList.hasNext()) {
            orghModel = (OrghierarchyModel)itrList.next();
            
            if ((counter) >=  starting_idx){
                map = new HashMap();
                map.put("orgName", orghModel.getOrgName());
                map.put("parentOrgId", orghModel.getParentOrgId());
                map.put("parentOrgName", orghModel.getParentOrgName());
                map.put("orgHierarchyTypeCode", orghModel.getOrgHierarchyTypeCode().toLowerCase());
                map.put("city", orghModel.getCity());
                map.put("stateProvince", orghModel.getStateProvince());
                map.put("stateProvinceCode", orghModel.getStateProvinceCode());
                map.put("countryName", orghModel.getCountryName());
            
                theOrgListMap.add(map);
            }
            
            counter = counter + 1;
        }
        return theOrgListMap ;
    }

    /**
     * This method is called when the execute method decides that action is for advance search
     */
    protected String respondBtnAdvancedSearch ()
        throws Exception {
        logger.info ("respondBtnAdvancedSearch(): begin");
        request = ServletActionContext.getRequest();
        HttpSession session = request.getSession(false);
        SessionStore store = SessionStore.getInstance(session);
        Credentials credentials = (Credentials) store.get(SessionKey.CREDENTIALS);

        
        List<OrghierarchyModel> orgList = null;
        long[] indexes = getPagingIndex(request,noOfAddressRecordsToLoad,false);

        try {
            SessionStore sessionStore = SessionStore.getInstance(request.getSession());
            // Gets the advanced search result from the AddressBook Manager
            String query = (String)sessionStore.get(SessionKey.ADVANCE_SEARCH_QUERY);
            OrgSearchResult addressSearchResult = addrManager.getAdvancedSearchResults(query, credentials, indexes[0], indexes[1]);
            orgList = addressSearchResult.getOrgList();
            orgListMap = convertToOrgListMap(orgList);
            long count = addressSearchResult.getCount();
            sessionStore.put (SessionKey.TOTAL_COUNT, new Long(count));
            sessionStore.put (SessionKey.ORGANIZATION_LIST, orgList);
            return displayPage();
        } catch (Exception ex) {
            logger.error ("respondBtnAdvancedSearch: unexpected expection", ex);
            throw ex;
        }
    }

    protected String respondBtnDelete () {
        OrgFormFieldBean orgForm = new OrghierarchyAction().new OrgFormFieldBean();
        
        logger.info ("respondBtnDelete(): begin");
        
        request = ServletActionContext.getRequest();
        HttpSession session = request.getSession(false);
        SessionStore store = SessionStore.getInstance(session);
        Credentials credentials = (Credentials) store.get(SessionKey.CREDENTIALS);

        try {
            SessionStore sessionStore = SessionStore.getInstance(request.getSession());	
            
            long orgId = getOrgId();
            OrghierarchyDAO orgDao = new OrghierarchyDAO();
            EventDAO eventDAO = new EventDAO();
            boolean isDeleted = false;
            boolean isAirport = "AIRPT".equals(orgDao.getOrgType(orgId)); 
            
            String userRole = credentials.getRole();
            String userDomain = credentials.getDomainName();
            String orgDomain = orgDao.getOrgDomain(orgId);

            orgModel = orgDao.retrieve(orgId, null);
            
                       
            OrghierarchyBeanManager beanManager = new OrghierarchyBeanManager();
            beanManager.model2form(orgForm, orgModel);

            // For TSA Security, users can only delete organizations in their domain, or they must be a sys admin
            if(userDomain.equalsIgnoreCase(orgDomain) || userRole.equalsIgnoreCase("SYS") || userRole.equalsIgnoreCase("DOMAD")) {
            	if (!isAirport)
            	{
            		isDeleted = orgDao.delete(orgId);
            	} else {
            		if (!eventDAO.isAirportUsed(orgId))
            		{
                		isDeleted = orgDao.delete(orgId);

                        // update options drop down when airports are deleted
                        OptionCollectionManager.getInstance().reset();
                        logger.debug("Updating airport drop downs.");                       
            		} else {
            			logger.debug("Airport cannot be deleted because it is still in use.");                            
            		}
                }        

            } else {
            	logger.error("User "+userDomain+"."+credentials.getUserId()+" does not have permission to delete org " + orgId);                
            }
            // end security check
            if (isDeleted) {
                
                List<OrghierarchyModel> orgList = (List<OrghierarchyModel>)sessionStore.get(SessionKey.ORGANIZATION_LIST);
                
                int index = getIndex();
                
                orgList.remove(index);
                request.setAttribute("Valid", "True");
                
                addActionMessage(getText("addrbook.addressdel.success"));
                
                OrghierarchyAction.logAction(credentials, "DELETE ADDRESS", "deleted", orgForm);
                
            } else {
                request.setAttribute("Valid", "False");
                
				addActionError(getText("addrbook.addressdel.failed"));
            }
            logger.debug("respondBtnDelete : Org record deleted successfully");
            
            if ( sessionStore.get(SessionKey.ADVANCE_SEARCH_QUERY)!= null)
                setHdnProcess("advancedSearch");
            else if (sessionStore.get(SessionKey.SEARCH_STR) != null)
                setHdnProcess("search");
            else 
                setHdnProcess(null);
                        
            orgList.add(orgModel);
            sessionStore.put (SessionKey.TOTAL_COUNT, new Long(orgList.size()));
            sessionStore.put (SessionKey.ORGANIZATION_LIST, orgList);
            orgListMap = convertToOrgListMap(orgList);
            return displayPage();
        } catch (Exception ex) {            
			addActionError(getText("addrbook.addressdel.failed"));
            logger.error ("respondBtnDelete: unexpected expection", ex);
            throw new RuntimeException(ex);
        }
    }

    private String initPage()
        throws Exception {
        request = ServletActionContext.getRequest();
        //clearing the state
        clearState(request);
        StackManager sm = new StackManager();
        sm.createEvent(new OperationInfo("TaskManager", "login_home", "display", "", "", ""));
        sm.createEvent(new OperationInfo("OrganizationManager", "address_home", "display", "", "", ""));
        SessionStore sessionStore = SessionStore.getInstance (request.getSession());
        sessionStore.put (SessionKey.STACK,sm);
        return doAddressHomeLoadPage();
    }

    private String getProcess(HttpServletRequest request) {
        logger.info("getProcess(): begin");
        
        // gets an instance of session store
        SessionStore sessionStore = SessionStore.getInstance (request.getSession());


        String isForwarded = (String) (sessionStore.get (SessionKey.IS_FORWARDED));
        logger.debug ("execute : Forward Flag from Session " + isForwarded);
        
        // assumes request is forwarded from another Action
        if (isForwarded != null && isForwarded.equalsIgnoreCase("Yes")) {
            //getting the current operation info from the stack to identify the process(if the request is
            //forwarded from some other part of the application)
            StackManager sm = (StackManager) (sessionStore.get (SessionKey.STACK));
            OperationInfo operationInfo = (OperationInfo)sm.currentEvent();
            String action = operationInfo.getAction();
            logger.debug("getProcess: action value"+action);
            
            setHdnProcess(action);
            return action;
        }
        else {
            return getHdnProcess();
        }
    }

    /**
     * This method sorts the shipment listing based on a column.
     *
     * @param mapping            The ActionMapping used to select this instance
     * @param shipmentHomeForm   data related to shipment
     * @param request            The HTTP request we are processing
     * @param response           The HTTP response we are creating
     * @param credentials        user information
     *
     */
    protected String respondSortByColumn ()
        throws Exception {
        logger.info("respondSortByColumn: begin");
        

        // Gets an instance of sessionStore
        SessionStore sessionStore = SessionStore.getInstance (request.getSession());

        // gets the shipment session list from the session
        @SuppressWarnings("unchecked")
	List<OrghierarchyModel> orgSessionList = (List<OrghierarchyModel>) (sessionStore.get(SessionKey.ORGANIZATION_LIST));
        logger.debug ("Size of orgList in session: " + orgSessionList.size());
        

        String sortingOrder = getSortingOrder();
        String sortingAttribute = getSortingAttribute();

        /*boolean isAscending = false;
        if ("up".equalsIgnoreCase(sortingOrder)) {
            isAscending = true;
        }*/

        // Sorts the list of Address using AddressManager

        //addrManager.sortByColumn(orgSessionList,sortingAttribute,isAscending);				
        orgListMap = convertToOrgListMap(orgSessionList);

        logger.debug("Size of orgSessionList after sorting: " + orgSessionList.size());
        

        return displayPage ();
    }
    
	private String tokenThenForward(HttpServletRequest request, String name, String id) {
		logger.debug("Saving token then going to forward "+name);
		
		
		if(NxUtils.notEmptyOrBlank(id))
			setId(id);
		
		return name;
	}
        
    /**
     * Gets the starting and ending index for fetching the records between this range.
     * 
     * @param request HttpServletRequest
     * @return long[] array containg the staringIndex as first element and endingIndex as second element
     */
    protected long[] getPagingIndex(HttpServletRequest request, long noOfItemToLoad, boolean fromSession) {
        long startIndex = LcpConstants.Paging.START;
        long endIndex = 1;

        String requestStartIndexStr = request.getParameter("startIndex");
        logger.debug("request.startIndex: " + requestStartIndexStr);

        SessionStore ss = SessionStore.getInstance(request.getSession());

        if (requestStartIndexStr != null && !"".equals(requestStartIndexStr)) {
            try {
                startIndex = Long.parseLong(requestStartIndexStr);
            } catch (Exception _ignored) {}
        } else if (fromSession) {
            Object sessionStartIndexObj = ss.get(SessionKey.START_INDEX);
            logger.debug("session.startIndex: " + sessionStartIndexObj);
            if (sessionStartIndexObj != null)
                startIndex =  Long.parseLong(sessionStartIndexObj.toString());   
        }

        endIndex = startIndex + noOfItemToLoad - 1;
        logger.debug("start index: " + startIndex + ", endIndex: " + endIndex);
        ss.put(SessionKey.START_INDEX, new Long(startIndex));

        long index[] = {startIndex, endIndex};
        return index;
    }
    
    protected final void clearState(HttpServletRequest request) {
        // clear any state info from request and session
        logger.info ("clearState(): begin");
        HttpSession session = request.getSession();
        SessionStore sessionStore = SessionStore.getInstance (session);
        Credentials credentials = (Credentials)sessionStore.get(SessionKey.CREDENTIALS);
        if (credentials != null) {
           ObjectLock objectLock = (ObjectLock)sessionStore.get(SessionKey.OBJECT_LOCK);
            if (objectLock != null) {   logger.info("Object lock is not null");
                objectLock.releaseAllLocksForUser(credentials.getSystemUserId());
            }
        }
        sessionStore.retainOnlyGeneralKeys();
        if ("SE".equals(FDSuiteProperties.getProperty("system.availability.status"))) {
            throw new SystemUnavailableException("SE");
        }
    }

        public String getOrgHierarchyTypeCode() {
            if(orgHierarchyTypeCode == null)
                return "";
            else
		return orgHierarchyTypeCode;
	}

	public void setOrgHierarchyTypeCode(String orgHierarchyTypeCode) {
		this.orgHierarchyTypeCode = orgHierarchyTypeCode;
	}

	public String getOrgName() {
		return orgName;
	}

	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}

	public String getParentOrgName() {
		if(parentOrgName == null)
			return "";
		else
			return parentOrgName;
	}

	public void setParentOrgName(String parentOrgName) {
		this.parentOrgName = parentOrgName;
	}

	public long getAddressId() {
		return addressId;
	}

	public void setAddressId(long addressId) {
		this.addressId = addressId;
	}

	public String getCity() {
		if(city == null)
			return "";
		else
			return city;
	}

	public void setCity(String city) {
		this.city = city;
	}
        
        public String getValid() {
		if(Valid == null)
			return "";
		else
			return Valid;
	}

	public void setValid(String Valid) {
		this.Valid = Valid;
	}

	public String getStateProvinceCode() {
		if(stateProvinceCode == null)
			return "";
		else
			return stateProvinceCode;
	}

	public void setStateProvinceCode(String stateProvinceCode) {
		this.stateProvinceCode = stateProvinceCode;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public String getCountryName() {
		return countryName;
	}

	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}

	public long getOrgId() {
		return orgId;
	}

	public void setOrgId(long orgId) {
		this.orgId = orgId;
	}

	public List<OptionBean> getOrgTypeList() {
		return orgTypeList;
	}

	public void setOrgTypeList(List<OptionBean> orgTypeList) {
		this.orgTypeList = orgTypeList;
	}
        
        public List<String> getOrgTypeStrList() {
		return orgTypeStrList;
	}

	public void setOrgTypeStrList(List<String> orgTypeStrList) {
		this.orgTypeStrList = orgTypeStrList;
	}
	
	public String getSelectRefType() {
            if(selectRefType == null)
    		return "";
            return selectRefType;
	}

	public void setSelectRefType(String selectRefType) {
		this.selectRefType = selectRefType;
	}

	public String getRefSearch() {
            if(refSearch == null)
		return "";
            return refSearch;
	}

	public void setRefSearch(String refSearch) {
		this.refSearch = refSearch;
	}

	public List<OptionBean> getRefTypeList() {
		return refTypeList;
	}

	public void setRefTypeList(List<OptionBean> refTypeList) {
		this.refTypeList = refTypeList;
	}

	//getter and setter methods
    public void setHdnProcess(String hdnProcess) {
        this.hdnProcess = hdnProcess;
    }

    public String getHdnProcess() {
        if (hdnProcess != null) return hdnProcess.trim();
            return hdnProcess;
    }

    public void setLinkSearchMap(HashMap linkSearchMap) {
        this.linkSearchMap = linkSearchMap;
    }

    public HashMap getLinkSearchMap() {
        return linkSearchMap;
    }

    public void setOrigin(String origin) {
        this.origin = origin;
    }

    public String getOrigin()  {

        if (origin != null) return origin.trim();
        return origin;
    }

    public void    setLookup(String lookup)  {

        this.lookup = lookup;
    }
    public String getLookup()  {

        if (lookup == null)
        	return "";

        return lookup.trim();
    }

    public void    setParent(String parent)  {

        this.parent = parent;
    }
    public String getParent()  {

        if (parent != null) return parent.trim();
        return parent;
    }

    public void setLink(String link)  {

        this.link = link;
    }
    public String getLink()  {

        if (link != null) return link.trim();
        return link;
    }

    public void    setAction(String action)  {

        this.action = action;
    }
    public String getAction()  {

        if (action != null) return action.trim();
        return action;
    }

    public void setSearch(String search)  {

        this.search = search;
    }

    public String getSearch()  {
        if ((search == null) || (search == "NULL"))
        	return "";        
        return search.trim().toUpperCase();
    }

    public void setStart(String start)  {

        this.start = start;
    }

    public String getStart() {
        if (start != null) return start.trim();
        return start;
    }

    public void    setImageClicked(String imageClicked)  {

        this.imageClicked = imageClicked;
    }
    public String getImageClicked()  {

        return imageClicked;
    }

    public void    setFromWhere(String fromWhere)  {

        this.fromWhere = fromWhere;
    }

    public String getFromWhere()  {

        return fromWhere;
    }

    /**
     * @return invokedFrom
     */
    public String getInvokedFrom() {
        return invokedFrom;
    }

    /**
     * @param argInvokedFrom
     */
    public void setInvokedFrom(String argInvokedFrom) {
        invokedFrom = argInvokedFrom;
    }

    /**
     * @return type
     */
    public String getType () {
        if (type == null) 
            return "";
        return type;
    }

    /**
     * @param typeArg
     */
    public void setType (String typeArg) {
        this.type = typeArg;
    }

    /**
     * @return role
     */
    public String getRole () {
        return role;
    }

    /**
     * @param roleArg
     */
    public void setRole (String roleArg) {
        this.role = roleArg;
    }
    
    /**
     * @return home
     */
    public String getHome () {
        return home;
    }

    /**
     * @param home
     */
    public void setHome (String home) {
        this.home = home;
    }

    
    
    /**
     *  Responds to search button in home pages.
     */
    protected void respondBtnSearch(HttpServletRequest request, String searchType)
    {
        SessionStore sessionStore = SessionStore.getInstance(request.getSession());
        StackManager stackManager = (StackManager)sessionStore.get(SessionKey.STACK);
        stackManager.createEvent(new OperationInfo("Home", "search_home", searchType, "", "", ""));
    }

    public void setNoOfAddressRecordsToLoad(int noOfAddressRecordsToLoad){
        this.noOfAddressRecordsToLoad = noOfAddressRecordsToLoad;
    }

    public int getNoOfAddressRecordsToLoad() {
        return noOfAddressRecordsToLoad;
    }
    
    public void setNoOfAddressRecordsToLoadStr(String noOfAddressRecordsToLoadStr){
        this.noOfAddressRecordsToLoadStr = noOfAddressRecordsToLoadStr;
    }

    public String getNoOfAddressRecordsToLoadStr() {
        return noOfAddressRecordsToLoadStr;
    }

    public void setSortingOrder(String sortingOrder){
        this.sortingOrder = sortingOrder;
    }

    public String getSortingOrder() {
        return sortingOrder;
    }
    public void setSortingAttribute(String sortingAttribute){
        this.sortingAttribute = sortingAttribute;
    }

    public String getSortingAttribute() {
        return sortingAttribute;
    }

    
    public OrghierarchyModel getOrgModel() {
        return orgModel;
    }

    public void setOrgModel(OrghierarchyModel orgModel) {
        this.orgModel = orgModel;
    }
    
    public List<OrghierarchyModel> getOrgList() {
        return orgList;
    }

    public void setOrgList(List<OrghierarchyModel> orgList) {
        this.orgList = orgList;
    }
    
    public void setServletRequest(HttpServletRequest request) {
        this.request = request;
    }

    public HttpServletRequest getServletRequest() {
        return request;
    }
    
    public String getLoginTimeRoleMsg() {
        return loginTimeRoleMsg;
    }

    public void setLoginTimeRoleMsg(String loginTimeRoleMsg) {
        this.loginTimeRoleMsg = loginTimeRoleMsg;
    }
    
    public String getForward() {
        return forward;
    }

    public void setForward(String forward) {
        this.forward = forward;
    }
    
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
      
    public String getFromTab() {
        return fromTab;
    }

    public void setFromTab(String fromTab) {
        this.fromTab = fromTab;
    }
   
    
    public String getOffset() {
        return pager.offset;
    }

    public void setOffset(String pagerOffset) {
        this.pager.offset = pagerOffset;
    }
    
    public AddressHomeAction.pager getPager() {
        return pager;
    }

    public void setPager(AddressHomeAction.pager pager) {
        this.pager = pager;
    }
    
    public String getPagerOffset() {
        return pagerOffset;
    }

    public void setPagerOffset(String pagerOffset) {
        this.pagerOffset = pagerOffset;
    }
    
    public List<String> getRefTypeStrList() {
        return refTypeStrList;
    }

    public void setRefTypeStrList(List<String> refTypeStrList) {
        this.refTypeStrList = refTypeStrList;
    }
    
    public String getProcess() {
        return process;
    }

    public void setProcess(String process) {
        this.process = process;
    }
    
    public List<Map> getOrgListMap() {
        return orgListMap;
    }

    public void setOrgListMap(List<Map> orgListMap) {
        this.orgListMap = orgListMap;
    }
    
    public String getSelectedInvolvedPartyQualifier() {
        return selectedInvolvedPartyQualifier;
    }

    public void setSelectedInvolvedPartyQualifier(String selectedInvolvedPartyQualifier) {
        this.selectedInvolvedPartyQualifier = selectedInvolvedPartyQualifier;
    }
    
    private List<String> convertRefTypeListToStringList (List<OptionBean> refTypeBeanList) {
        List<String> theRefTypeStrList = new ArrayList<String>();
        
        Iterator<OptionBean> itrRefType = refTypeBeanList.iterator();
        OptionBean optBean = new OptionBean();
        while (itrRefType.hasNext()) {
            optBean = itrRefType.next();
            theRefTypeStrList.add(optBean.getLabel());
           
        }
        
        return theRefTypeStrList;
    }
    
    private String convertRefTypeLabelToValue(String refTypeLabel, List<OptionBean> refTypeBeanList){
        String refTypeValue;
        
        if (refTypeLabel.equals("-1")){
            return "";
        }
        Iterator<OptionBean> itrRefType = refTypeBeanList.iterator();
        OptionBean optBean = new OptionBean();
        while (itrRefType.hasNext()) {
            optBean = itrRefType.next();
            if (optBean.getLabel().equalsIgnoreCase(refTypeLabel)){
                return (optBean.getValue());
            }
        }
        
        return "";
    }
    
    private List<String> convertOrgTypeListToStringList (List<OptionBean> orgTypeListOptBean){
        List<String> theOrgTypeStrList = new ArrayList<String>();
        Iterator<OptionBean> itrOrgType = orgTypeListOptBean.iterator();
        OptionBean optBean = new OptionBean();
        while (itrOrgType.hasNext()) {
            optBean = itrOrgType.next();
            theOrgTypeStrList.add(optBean.getLabel());
            
        }
        return theOrgTypeStrList;
    }
    
    private String convertOrgTypeLabelToValue(String orgTypeLabel, List<OptionBean> orgTypeBeanList){
        String orgTypeValue;
        
        
        if (orgTypeLabel.equals("-1")){
            return "";
        }
        Iterator<OptionBean> itrOrgType = orgTypeBeanList.iterator();
        OptionBean optBean = new OptionBean();
        while (itrOrgType.hasNext()) {
            optBean = itrOrgType.next();
            
            if (optBean.getLabel().equalsIgnoreCase(orgTypeLabel)){
                return (optBean.getValue());
            }
        }
        
        return "";
    }
    
    private String convertOrgTypeValueToLabel(String orgTypeValue, List<OptionBean> orgTypeBeanList){
        String orgTypeLabel;
        
        
        if (orgTypeValue.equals("-1")){
            return "Any";
        }
        Iterator<OptionBean> itrOrgType = orgTypeBeanList.iterator();
        OptionBean optBean = new OptionBean();
        while (itrOrgType.hasNext()) {
            optBean = itrOrgType.next();
            
            if (optBean.getValue().equalsIgnoreCase(orgTypeValue)){
                return (optBean.getLabel());
            }
        }
        
        return "Any";
    }
    
    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }

}

