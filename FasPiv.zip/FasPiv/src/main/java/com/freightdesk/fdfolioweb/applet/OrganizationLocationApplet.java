 /** 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolioweb/applet/OrganizationLocationApplet.java,v 1.6.6.1 2010/08/22 23:08:28 mechevarria Exp $ 
 * 
 *  Modification History:
 *  $Log: OrganizationLocationApplet.java,v $
 *  Revision 1.6.6.1  2010/08/22 23:08:28  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.6  2006/04/10 22:45:51  aarora
 *  Removing redundant code
 *
 *  Revision 1.5  2005/04/26 22:46:23  amrinder
 *  Minor formatting changes
 *
 *  Revision 1.4  2005/04/15 15:23:43  dkhoker
 *  Implemented the getDataObjects() method.
 *
 *  Revision 1.3  2005/04/14 19:51:08  amrinder
 *  Simplifying the framework, by moving getObjectIcon to LocationApplet
 *
 *  Revision 1.2  2005/04/14 19:00:37  amrinder
 *  Returning an emtpy list, not null so that at least the map loads
 *
 *  Revision 1.1  2005/04/14 12:51:34  dkhoker
 *  Organization implementation of the LocationApplet
 *
 */
 package com.freightdesk.fdfolioweb.applet;

import org.apache.log4j.Logger;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.URL;
import java.net.URLConnection;
import java.util.Collection;
//import com.freightdesk.fdfolio.addressbook.model.AddressModel;
/**
 * @author Devendra Khoker
 */
public class OrganizationLocationApplet 
    extends LocationApplet
{
    /**
     * Gets the image path.
	 * @see com.freightdesk.fdfolioweb.applet.LocationApplet#getImagePath()
	 */
	private Logger logger = Logger.getLogger("OrganizationLocationApplet");
	
	public String getImagePath() {
        return "/maps/organization.jpg";
	}

    /**
     * Gets the relevant data objects. 
     * 
     * @return Collection containing organization information
	 * @see com.freightdesk.fdfolioweb.applet.LocationApplet#getDataObjects()
	 */
	public Collection getDataObjects()
    {
        ObjectInputStream ois = null;
        Collection collection = null;
        try {
    
            String domain = getParameter("domainName");
            String orgId = getParameter("orgId");
            // Create an object we can use to communicate with the servlet
            URL url = new URL(getCodeBase() + "OrganizationLocationServlet?domainName="+domain+"&orgId="+orgId);
            URLConnection servletConnection = url.openConnection();
            servletConnection.setDoOutput(true);        // to allow us to read from the URL
            servletConnection.setDoInput(true);         // to allow us to write to the URL
    
            servletConnection.setUseCaches(false);      // so that we do contact the servlet and
                                                        // don't get anything from the browser's cache
        
            // Reads the response from the servlet
            ois = new ObjectInputStream(servletConnection.getInputStream());
            System.out.println ("reading Data from the Stream starts");
            collection = (Collection)ois.readObject();
            System.out.println ("reading Data from the Stream ends");
            System.out.println (collection);

        } catch (Exception e) {
            //e.printStackTrace();
			logger.error("Exception : " + e.getMessage());
        } finally {
            try {
                if (ois != null) {
                    ois.close();
                }
            } catch(IOException io) {}
        }
        return collection;
    }
}
