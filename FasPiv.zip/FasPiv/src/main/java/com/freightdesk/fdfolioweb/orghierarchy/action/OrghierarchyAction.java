package com.freightdesk.fdfolioweb.orghierarchy.action;

import crt.com.freightdesk.fdfolioweb.orghierarchy.action.OrgOrgAssocAuditor;

import java.math.BigInteger;
import java.util.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;



import com.freightdesk.fdcommons.ActionErrors;
import com.freightdesk.fdcommons.ActionMessage;
import com.freightdesk.fdcommons.ActionMessages;

import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.ServletActionContext;
import org.apache.log4j.Logger;



import com.freightdesk.fdfolio.common.BasicButtonsForm;
import com.freightdesk.fdfolio.dao.OrghierarchyDAO;
import com.freightdesk.fdfolio.dao.UserAccessDAO;

import crt.com.freightdesk.fdfolio.orghierarchy.OrghierarchyBeanManager;

import com.freightdesk.fdfolio.orghierarchy.OrghierarchyManager;
import com.freightdesk.fdfolio.orghierarchy.model.OrghierarchyModel;

import crt.com.freightdesk.fdfolioweb.orghierarchy.form.OrgAssocForm;
import crt.com.freightdesk.fdfolioweb.orghierarchy.form.OrgReferenceForm;

import com.freightdesk.fdcommons.ApplicationTabs;
import com.freightdesk.fdcommons.Credentials;
import com.freightdesk.fdcommons.OptionBean;

import crt.com.ntelx.nxcommons.NxUtils;

import com.freightdesk.fdcommons.SessionKey;
import com.freightdesk.fdcommons.SessionStore;
import com.freightdesk.fdcommons.asyncprocess.AsyncProcessManager;
import com.freightdesk.fdcommons.asyncprocess.AsyncProcessingLogModel;
import com.freightdesk.fdfolio.addressbook.model.OrganizationChartModel;
import com.freightdesk.fdfolio.useraccess.model.SystemUserModel;
import com.opensymphony.xwork2.ActionSupport;

import crt.com.ntelx.nxcommons.reporting.OptionCollectionManager;
import crt.com.freightdesk.fdfolio.common.IncludesUtil;

import java.util.ArrayList;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.collections.Factory;
import org.apache.commons.collections.ListUtils;

import crt.com.freightdesk.fdfolio.setup.UserSetupManager;
import crt.com.freightdesk.fdfolioweb.event.form.EventForm;

/**
 * @author Mike Echevarria
 *
 */
public class OrghierarchyAction extends ActionSupport implements ServletRequestAware {

    OrghierarchyManager orgManager = new OrghierarchyManager();
    // for the form -> model and model -> form methods. Easier to read if those big methods are isolated
    OrghierarchyBeanManager beanManager = new OrghierarchyBeanManager();
    protected Logger logger = Logger.getLogger(getClass());
    HttpServletRequest request = ServletActionContext.getRequest();
    private String loginTimeRoleMsg;
    
    private static final long serialVersionUID = 1L;
    private boolean readonly;
    private String type;
    private String context;
    private String action;
    private long orgId;
    private String parentOrgId;
    private String parentOrgName;
    private String parentOrgType;
    private String createUserId;
    private String createTimestamp;
    private String domainName;
    private String lastUpdateUserId;
    private String lastUpdateTimestamp;
    private String orgRoleCode;
    private String contactSalutationCode;
    private String orgHierarchyTypeCode;
    private String orgName;
    private String DUNSNumber;
    private String SCACCode;
    private String EINNumber;
    private String stp;
    private String portCode;
    private String remarks;
    private String status;
    private String contactFirstName;
    private String contactLastName;
    private String contactTitle;
    private String phone;
    private String email;
    private String region;
    private String addressTypeCode;
    private String countryCode;
    private String timeZoneId;
    private String addressLine1;
    private String addressLine2;
    private String city;
    private String stateProvince;
    private String stateProvinceCode;
    private String zipPostCode;
    private String latitude;
    private String longitude;
    // keep track of which orgreference index to delete
    private String refId;
    // keep track of which event index to delete
    private String eventId;
    // keep track of which orgAssoc to delete
    private String orgAssocId;
    private String requiredReporting = "BOTH";
    private String ncspMember;
    private List<OrgReferenceForm> orgRefs = initOrgRefs();
    
    private List<SystemUserModel> loginList;
    private List<OrghierarchyModel> contactList;
    private List<OrghierarchyModel> locationList;
    // pulldown lists
    private List<OptionBean> countryList;
    private List<String> countryStrList;
    private List<OptionBean> roleList;
    private List<String> roleStrList;
    private List<OptionBean> refTypeList;
    private List<String> refTypeStrList;
    private List<String> statusStrList;
    private List<OptionBean> eventTypeList;
    private List<OptionBean> orgAssocTypeList;
    private List<OptionBean> orgApAcAssocTypeList;
    private List<OptionBean> titleList;
    private List<String> titleStrList;
    private List<OptionBean> regionList;
    private List<String> regionStrList;
    // for display on form only. Not a persisted field
    private String orgHierarchyTypeName;
    private OrganizationChartModel chartModel;
    private String parentJsArray;
    private String assocJsArray;
    private String basicBtnClicked;
    private OrgFormFieldBean orgFormFieldBean;
    private String refType;
    private String refValue;
    private long id;
    
    static public final String subsidiaryName = "Subsidiary";
    static public final String entityName = "Entity";
    static public final String organizationName = "Organization";
    
    public String respondBtnSave() throws Exception {
        email = StringEscapeUtils.escapeHtml(getEmail().replaceAll("&lt;", "").replaceAll("&quot;", "").replaceAll("&gt;", ""));
        return saveModel();
    }

    public String respondBtnSaveAndReturn() throws Exception {
        email = StringEscapeUtils.escapeHtml(getEmail().replaceAll("&lt;", "").replaceAll("&quot;", "").replaceAll("&gt;", ""));
        return saveModel();
    }

    private String saveModel() throws Exception {

        
        String saveType = getBasicBtnClicked();

        logger.debug("Save type is " + saveType);
       
        
        request = ServletActionContext.getRequest();
        HttpSession session = request.getSession(false);
        SessionStore store = SessionStore.getInstance(session);
        Credentials credentials = (Credentials) store.get(SessionKey.CREDENTIALS);
        setDomainName(credentials.getDomainName());
        
        loginTimeRoleMsg = IncludesUtil.getWelcomeMsg(credentials)+ "<br>" + IncludesUtil.getExpireMsg(credentials);
        
        Boolean isAirport = getOrgHierarchyTypeCode().equalsIgnoreCase("AIRPT");
        Boolean isNewOrg = getOrgId() == 0 ? true : false;
        

        // get the current model from session store
        SessionStore sessionStore = SessionStore.getInstance(request.getSession());
        OrghierarchyModel model = (OrghierarchyModel) sessionStore.get(SessionKey.ORGHIERARCHY_MODEL);

        // set the orgId to validate against duplicate orgs               
        setOrgId(model.getOrgId());
        

        // Some fields are not shown on Airport profile, but are defaulted here.
        if (isAirport) {
            setOrgRoleCode("AIRPT");
        	setStatus("ACTIVE");
        }

        ActionMessages messages = new ActionMessages();

        OrgFormFieldBean orghierarchyForm = new OrgFormFieldBean();
 
        
        orghierarchyForm.orgHierarchyTypeCode = getOrgHierarchyTypeCode();
        
        orghierarchyForm.action = getAction();
        
        orghierarchyForm.contactFirstName = getContactFirstName();
        orghierarchyForm.contactLastName = getContactLastName();
        orghierarchyForm.addressLine1 = getAddressLine1();
        
        orghierarchyForm.addressLine2 = getAddressLine2();
        orghierarchyForm.assocJsArray = getAssocJsArray();
        orghierarchyForm.chartModel = getChartModel();
        orghierarchyForm.city = getCity();
        
        orghierarchyForm.contactList = getContactList();
        orghierarchyForm.contactSalutationCode = getContactSalutationCode();
        
        orghierarchyForm.context = getContext();
        
        
        orgManager.setOptionLists(orghierarchyForm);
        
        orghierarchyForm.refTypeStrList = convertRefTypeListToStringList (orghierarchyForm.refTypeList);
        setRefTypeStrList (orghierarchyForm.refTypeStrList);
        
        setStatusStrList (initStatusStrList(statusStrList));
        orghierarchyForm.statusStrList = initStatusStrList (orghierarchyForm.statusStrList);
        
        orghierarchyForm.regionStrList =  convertRegionListToStringList (orghierarchyForm.regionList);
        setRegionStrList (orghierarchyForm.regionStrList);
        setRegionList (orghierarchyForm.regionList);
        
        orghierarchyForm.titleStrList =  convertTitleListToStringList (orghierarchyForm.titleList);
        setTitleStrList (orghierarchyForm.titleStrList);
        setTitleList (orghierarchyForm.titleList);
        
        
        orghierarchyForm.countryStrList =  convertCountryListToStringList (orghierarchyForm.countryList);
        setCountryStrList (orghierarchyForm.countryStrList);
        setCountryList (orghierarchyForm.countryList);

        orghierarchyForm.roleStrList = convertRoleListToStringList (orghierarchyForm.roleList);
        setRoleStrList (orghierarchyForm.roleStrList);
        setRoleList (orghierarchyForm.roleList);
        
        
        
        setOrgRoleCode(convertRoleLabelToValue(getOrgRoleCode(), orghierarchyForm.roleList)); 
        orghierarchyForm.orgRoleCode = getOrgRoleCode();
        
        
        setContactTitle(convertTitleLabelToValue(getContactTitle(), orghierarchyForm.titleList)); 
        orghierarchyForm.contactTitle = getContactTitle();
        if ((orghierarchyForm.contactTitle.toString().equalsIgnoreCase("-1"))|| (orghierarchyForm.contactTitle.toString().equalsIgnoreCase("NONE"))){
            orghierarchyForm.contactTitle = null;
        }
        
        
        setCountryCode(convertCountryLabelToValue(getCountryCode(), orghierarchyForm.countryList)); 
        orghierarchyForm.countryCode = getCountryCode();
        
        
        orghierarchyForm.createTimestamp = getCreateTimestamp();
        
        orghierarchyForm.createUserId = getCreateUserId();
        
        orghierarchyForm.domainName = getDomainName();
        
		email = StringEscapeUtils.escapeHtml(getEmail().replaceAll("&lt;", "").replaceAll("&quot;", "").replaceAll("&gt;", ""));
        orghierarchyForm.email = getEmail();
        orghierarchyForm.eventId = getEventId();
        
        orghierarchyForm.eventTypeList = getEventTypeList();
        orghierarchyForm.lastUpdateUserId = getLastUpdateUserId();
        
        orghierarchyForm.lastUpdateTimestamp = getLastUpdateTimestamp();
        
        orghierarchyForm.latitude = getLatitude();
        orghierarchyForm.locationList = getLocationList();
        orghierarchyForm.loginList = getLoginList();
        orghierarchyForm.longitude = getLongitude();
        orghierarchyForm.ncspMember = getNcspMember();
        orghierarchyForm.orgApAcAssocTypeList = getOrgApAcAssocTypeList();
        orghierarchyForm.orgAssocId = getOrgAssocId();
        
        orghierarchyForm.orgAssocTypeList = getOrgAssocTypeList();
        orghierarchyForm.orgHierarchyTypeCode = getOrgHierarchyTypeCode();
        
        orghierarchyForm.orgHierarchyTypeName = getOrgHierarchyTypeName();
        
        orghierarchyForm.orgId = getOrgId();
        
        orghierarchyForm.orgName = getOrgName();
        
        orghierarchyForm.orgRefs = getOrgRefs();
        orghierarchyForm.orgRoleCode = getOrgRoleCode();
        
        orghierarchyForm.contactTitle = getContactTitle();
        if ((orghierarchyForm.contactTitle.toString().equalsIgnoreCase("-1"))|| (orghierarchyForm.contactTitle.toString().equalsIgnoreCase("NONE"))){
            orghierarchyForm.contactTitle = null;
        }
        
        orghierarchyForm.parentJsArray = getParentJsArray();
        orghierarchyForm.parentOrgId = getParentOrgId();
        
        orghierarchyForm.parentOrgName = getParentOrgName();
        
        orghierarchyForm.parentOrgType = getParentOrgType();
        
        orghierarchyForm.phone = getPhone();
        orghierarchyForm.portCode = getPortCode();
        orghierarchyForm.refId = getRefId();
        orghierarchyForm.refTypeList = getRefTypeList();
        
        orghierarchyForm.region = getRegion();
        if ((orghierarchyForm.region.toString().equalsIgnoreCase("-1"))|| (orghierarchyForm.region.toString().equalsIgnoreCase("NONE"))){
            orghierarchyForm.region = null;
        }
        
        
        orghierarchyForm.regionList = getRegionList();
        orghierarchyForm.remarks = getRemarks();
        orghierarchyForm.requiredReporting = getRequiredReporting();
        orghierarchyForm.roleList = getRoleList();
        orghierarchyForm.stateProvince = getStateProvince();
        orghierarchyForm.stateProvinceCode = getStateProvinceCode();
        orghierarchyForm.statusStrList = getStatusStrList();
        orghierarchyForm.status = getStatus();
        
        orghierarchyForm.stp = getStp();
        orghierarchyForm.timeZoneId = getTimeZoneId();
        orghierarchyForm.titleList = getTitleList();
        orghierarchyForm.zipPostCode = getZipPostCode();
        
        
        // validate
        ActionErrors errors = orgManager.validate(orghierarchyForm);
        if (!errors.isEmpty()) {
            
            for (Iterator it = errors.get(); it.hasNext();) {
                ActionMessage msg = (ActionMessage)it.next();
                addActionError(msg.getValues()[0].toString());
            }
            addFieldError("userDetailsErrorsHeader", getText("errors.header"));
            
            orgManager.setOptionLists(orghierarchyForm);
            return "display";
        }
        
        // copy form to model
        model = beanManager.form2model(orghierarchyForm, model, credentials);

        // getOrgAssoc Changes
        OrgOrgAssocAuditor.auditOrgAssoc(model.getOrgId(), model, credentials);

        auditCarrierOrganizationType(model.getOrgId(), model, credentials);
        
        // persist
        OrghierarchyDAO orgDAO = new OrghierarchyDAO();
        model = orgDAO.persist(model);

        
        addActionMessage(getText("Organization.Save"));

        // Specific logic for INACTIVE orghierarchy.  Cascade down in tree and to the systemuser table
        String status = model.getStatus();
        logger.debug("status is " + status);
        if (status.equalsIgnoreCase("INACTIVE")) {
            int numOrgs = orgDAO.cascadeStatusOrghierarchy(model.getOrgId(), status);
            int numLogins = new UserAccessDAO().cascadeStatusSystemUser(model.getOrgId(), status);
           
			addActionMessage("0 child objects and 0 logins set to status of INACTIVE.");
        }

        
        
        if (messages.size() > 0) {
            addActionMessage(messages.toString());
        }

        
        // update options drop down when airports are saved
        if (isAirport) {
            OptionCollectionManager.getInstance().reset();
            logger.debug("Updating airport drop downs.");
            
        }
        
        if (isNewOrg)
        {
        	setOrgId(model.getOrgId());
        	logAction(credentials, "CREATE ADDRESS", "created", orghierarchyForm);
        } else {
        	logAction(credentials, "EDIT ADDRESS", "edited", orghierarchyForm);
        }
        
        
        if (BasicButtonsForm.SAVE_RETURN.equalsIgnoreCase(saveType)) {
            clearSessionStore(request);

            logger.debug("Finished saving, returning to Address homepage");

            // finished the save action, returning home
            return "home";
        }

        // copy model to form
        beanManager.model2form(orghierarchyForm, model);
        
       
        
        setOrgRoleCode(convertRoleValueToLabel(getOrgRoleCode(), orghierarchyForm.roleList));
        
        setContactTitle(convertTitleValueToLabel(getContactTitle(), orghierarchyForm.titleList));
        
        setCountryCode(convertCountryValueToLabel(getCountryCode(), orghierarchyForm.countryList));
        
        
        
        setRegion(getRegion());
        
        // put the model in the session store to be updated on saving
        sessionStore.put(SessionKey.ORGHIERARCHY_MODEL, model);

       
        // action is now edit, button action is now null
        setContext("EDIT");
        setBasicBtnClicked(null);

        
        // set pulldowns on form
        orgManager.setOptionLists(orghierarchyForm);
        
        // go back to page
        logger.debug("Finished saving, display orghierarchy page");
        		
		UserSetupManager userSetupManager = new UserSetupManager();
        List<SystemUserModel> loginList = new ArrayList<SystemUserModel>();
        if ((getOrgId()) != 0){
            loginList = userSetupManager.getAllSystemUsers(getOrgId());
            if (! (loginList.isEmpty())){
                setLoginList(loginList);
                
                
            }
        }		
		
        return "display";
    }

    static public void auditCarrierOrganizationType(Long orgId, OrghierarchyModel mutatedOrgModel, Credentials credentials) {
        if (orgId != null && orgId != 0) {
            OrghierarchyDAO orgDAO = new OrghierarchyDAO();
            OrghierarchyModel originalModel = orgDAO.retrieve(orgId, null);


            if (originalModel != null && originalModel.getParentOrgId() != null && mutatedOrgModel.getParentOrgId() == null) {
                logAction(credentials, "REVERT SUBSIDIARY", originalModel.getOrgId() + " was converted into an organization. Removed parent " + originalModel.getParentOrgId(), null);
            } else if (originalModel != null && originalModel.getParentOrgId() == null && mutatedOrgModel.getParentOrgId() != null) {
                logAction(credentials, "CREATE SUBSIDIARY", mutatedOrgModel.getOrgId() + " was converted into a subsidiary under " + mutatedOrgModel.getParentOrgId(), null);
            }
        }
    }

    static public void logAction(Credentials credentials, String action, String actionFeedbackText, OrgFormFieldBean orgForm) {
        AsyncProcessingLogModel asyncLogModel = new AsyncProcessingLogModel();
        AsyncProcessManager asyncManager = new AsyncProcessManager();

        String module = "ADDRESS";
        String feedback;
        String completedFeedback;

        if ("REVERT SUBSIDIARY".equals(action) || "CREATE SUBSIDIARY".equals(action))
        {
            feedback = "Beginning process for: " + action;
            completedFeedback = actionFeedbackText;
            
        } else if ("AIRPT".equals(orgForm.getOrgRoleCode())) {
            feedback = "Beginning process for: " + orgForm.getOrgRoleCode() + "\"" + orgForm.getOrgName() + "\" (" + orgForm.getOrgId()+ ") was " + actionFeedbackText + " by " + credentials.getUserId();
            completedFeedback = orgForm.getOrgRoleCode() + " \"" + orgForm.getOrgName() + "\" (" + orgForm.getOrgId() + ") was " + actionFeedbackText + " by " + credentials.getUserId();
            
        } else {
            feedback = "Beginning process for: " + orgForm.getOrgRoleCode() + " " + orgForm.getOrgHierarchyTypeName() + " \"" + orgForm.getOrgName() + "\" (" + orgForm.getOrgId() + ") was " + actionFeedbackText + " by " + credentials.getUserId();
            completedFeedback = orgForm.getOrgRoleCode() + " " + orgForm.getOrgHierarchyTypeName() + " \"" + orgForm.getOrgName() + "\" (" + orgForm.getOrgId() + ") was " + actionFeedbackText + " by " + credentials.getUserId();
            
        }


        try {
            // Record attempted logins in the ASYNCPROCESSINGLOG table
            asyncLogModel.init(credentials.getUserId(), credentials.getDomainName(), action, module, feedback, credentials.getIpAddress());

            // Record successful login in the ASYNCPROCESSINGLOG table
            asyncLogModel = asyncManager.createAsyncProcessLog(asyncLogModel);
            asyncManager.logResult(asyncLogModel, true, completedFeedback, "logAction");
        } catch (Exception ex) {
            asyncManager.logResult(asyncLogModel, false, "Failed " + action + " for Address Org ID: " + orgForm.getOrgId(), "Exception");
        }
    }

    
    private void clearSessionStore(HttpServletRequest request) {
        // clear any items from session store
        SessionStore sessionStore = SessionStore.getInstance(request.getSession());
        sessionStore.remove(SessionKey.ORGHIERARCHY_MODEL);
        sessionStore.remove(SessionKey.USER_CONTACT_MODEL);
    }

    public String respondBtnCancel() throws Exception {
        logger.debug("Canceling");

        clearSessionStore(request);

        
        addActionMessage(getText("Organization.Cancel"));
        return "home";
    }

    
    public String execute() throws Exception {
        logger.debug("Generic action.  Going to logic tree to determine specific method");
        
        
        request = ServletActionContext.getRequest();
        HttpSession session = request.getSession(false);
        SessionStore store = SessionStore.getInstance(session);
        Credentials credentials = (Credentials) store.get(SessionKey.CREDENTIALS);
        
        String origOrgHierarchyTypeCode = getOrgHierarchyTypeCode();
        
        
        loginTimeRoleMsg = IncludesUtil.getWelcomeMsg(credentials)+ "<br>" + IncludesUtil.getExpireMsg(credentials);
        setDomainName(credentials.getDomainName());
        
        // POAM HttpOnly Secure
        HttpServletResponse response = (HttpServletResponse)ServletActionContext.getResponse();
        String secure = "";
        if (request.isSecure())
        {
          secure = "; Secure";
        }
        response.setHeader("SET-COOKIE", "JSESSIONID=" + request.getSession().getId()
                         + "; Path=" + request.getContextPath() + "; HttpOnly" + secure);
        
        
        if ("CANCEL".equalsIgnoreCase(basicBtnClicked)) {
    
            return respondBtnCancel();
        } else if ("SAVE".equalsIgnoreCase(basicBtnClicked)) {
            
            return respondBtnSave();
        } else if ("SAVE_RETURN".equalsIgnoreCase(basicBtnClicked)) {
            
            return respondBtnSaveAndReturn();
        }
        
        OrgFormFieldBean orghierarchyForm = new OrgFormFieldBean();
        
        
        orghierarchyForm.setOrgName(getOrgName());
        
        
        orghierarchyForm.setPortCode(getPortCode());
        
        
        orghierarchyForm.setAddressLine1(getAddressLine1());
        
        
        orghierarchyForm.setAddressLine2(getAddressLine2());
        
        
        orghierarchyForm.setCity(getCity());
        
        
        orghierarchyForm.setStateProvinceCode(getStateProvinceCode());
        
        
        orghierarchyForm.setStateProvince(getStateProvince());
        
        
        orghierarchyForm.setCountryCode(getCountryCode());
        
        
        orghierarchyForm.setZipPostCode(getZipPostCode());
        
        
        orghierarchyForm.setRemarks(getRemarks());
        
        

        SessionStore sessionStore = SessionStore.getInstance(request.getSession());

        // Set the tab on the UI to the address tab
        sessionStore.put(SessionKey.CURRENT_TAB, ApplicationTabs.ADDRESS);

        // Context is either Add, Edit or Delete. New request from other page has context as request variable
        
        if (NxUtils.isEmptyOrBlank(getContext())) {
            setContext(request.getParameter("context"));
            
        }

        
        // Action is an edit to a child object, such as orgReference. New request from other page has action as request variable
        if (NxUtils.isEmptyOrBlank(getAction())) {
            setAction(request.getParameter("action"));
            
        }

        if (NxUtils.isEmptyOrBlank(getOrgHierarchyTypeCode())) {
            setOrgHierarchyTypeCode(request.getParameter("type"));
            
        }

       
        
        String context = getContext();
        String action = getAction();
        String type = getOrgHierarchyTypeCode();
        
        orghierarchyForm.setContext(getContext());
        
        if ((orgHierarchyTypeCode != null) && (orgHierarchyTypeCode.equalsIgnoreCase("Airpt"))) {
            orgHierarchyTypeName = "Airport";
            
        } else if ((orgHierarchyTypeCode != null) && (orgHierarchyTypeCode.equalsIgnoreCase("Con"))) {
            orgHierarchyTypeName = "Profile";
            
        }

        String orgId = request.getParameter("id");

        logger.debug("!! Context= " + context + ", Action=" + action + ", OrgType= " + type + ", orgId= " + orgId);
        

        // Add, Edit or View
        if (NxUtils.isEmptyOrBlank(action)) {
            if (context.equalsIgnoreCase("add") || context.equalsIgnoreCase("edit") || (context.equalsIgnoreCase("view"))) {
                OrghierarchyModel orgModel = new OrghierarchyModel();

                // if adding, make a new model
                if (context.equalsIgnoreCase("add")) {
                    orgModel = orgManager.prepareNewModel(type, credentials);
                } else {
                    try {        
                        // set pulldowns on form
                        orgManager.setOptionLists(orghierarchyForm);
        
                        orghierarchyForm.countryStrList =  convertCountryListToStringList (orghierarchyForm.countryList);
                        setCountryStrList (orghierarchyForm.countryStrList);
        
                        orghierarchyForm.refTypeStrList = convertRefTypeListToStringList (orghierarchyForm.refTypeList);
                        setRefTypeStrList (orghierarchyForm.refTypeStrList);
        
                        setStatusStrList(initStatusStrList (statusStrList));
                        orghierarchyForm.statusStrList = initStatusStrList (orghierarchyForm.statusStrList);
        
                        orghierarchyForm.titleStrList =  convertTitleListToStringList (orghierarchyForm.titleList);
                        setTitleStrList (orghierarchyForm.titleStrList);
        
                        orghierarchyForm.regionStrList =  convertRegionListToStringList (orghierarchyForm.regionList);
                        setRegionStrList (orghierarchyForm.regionStrList);
        
                        orghierarchyForm.roleStrList = convertRoleListToStringList (orghierarchyForm.roleList);
                        setRoleStrList (orghierarchyForm.roleStrList);
                    } catch  (Exception e) {
                        logger.debug("Excaption:" + e.getMessage());
						
                    }
                    
                    logger.debug("Retrieving model for edit or view");
                    
                    OrghierarchyDAO orgDAO = new OrghierarchyDAO();
                    orgModel = orgDAO.retrieve(new Long(orgId), null);
                    
                    
                    setOrgId(orgModel.getOrgId());
                    setOrgName(orgModel.getOrgName());
                    setPortCode(orgModel.getPortCode());
                    
                    
                    setContactFirstName(orgModel.getContactFirstName());
                    setContactLastName(orgModel.getContactLastName());
                    setParentOrgName(orgModel.getParentOrgName());
                    
                    String emailTemp = StringEscapeUtils.escapeHtml(orgModel.getEmail().replaceAll("&lt;", "").replaceAll("&quot;", "").replaceAll("&gt;", ""));					
					setEmail(emailTemp);
                    setPhone(orgModel.getPhone());
                    
                    
                    setOrgRoleCode(convertRoleValueToLabel(orgModel.getOrgRoleCode(), orghierarchyForm.roleList));
                    
                    setStatus(orgModel.getStatus());
                    
                    setContactTitle(convertTitleValueToLabel(orgModel.getContactTitle(), orghierarchyForm.titleList));
                    
                    setCountryCode(convertCountryValueToLabel(orgModel.getCountryCode(), orghierarchyForm.countryList));
                    
                    
                    setRegion(orgModel.getRegionCode());
                   
            
                    setAddressLine1(orgModel.getAddressLine1());
                    setAddressLine2(orgModel.getAddressLine2());
                    setCity(orgModel.getCity());
                    setStateProvinceCode(orgModel.getStateProvinceCode());
                    setStateProvince(orgModel.getStateProvince());
                    
                    
                    setZipPostCode(orgModel.getZipPostCode());
                }

                // copy model to form
                beanManager.model2form(orghierarchyForm, orgModel);
                
                setCreateUserId (orgModel.getCreateUserId());
                setCreateTimestamp (orgModel.getCreateTimestamp().toString());
                setLastUpdateUserId (orgModel.getLastUpdateUserId());
                setLastUpdateTimestamp (orgModel.getLastUpdateTimestamp().toString());
                setRemarks(orgModel.getRemarks());
                
                
                
                // put the model in the session store to be updated on saving
                sessionStore.put(SessionKey.ORGHIERARCHY_MODEL, orgModel);

                // if viewing, set readonly
                if (context.equalsIgnoreCase("view")) {
                    setReadonly(true);
                }

            }
        }
        
        
        ActionMessages messages = new ActionMessages();
        OrghierarchyDAO orgDAO = new OrghierarchyDAO();

        if (action.equalsIgnoreCase("roleSelected")) {
            
            if ("ORG".equals(getOrgHierarchyTypeCode())) {              
                
                if (!getParentOrgId().isEmpty()) {
                    
                    // throw validation error...
                    messages.add("error.filecontent", new ActionMessage("error.file.content", "Cannot change roles while still a subsidiary - Make into an Organization first."));
                    logger.debug("Illegal Role switch, resetting orgForm");
                    
                    addActionMessage(messages.toString());
                    
                    OrghierarchyModel orgModel = orgDAO.retrieve(new Long(getOrgId()), null);
                    // reset OrgRoleCode
                    if (orgModel == null)
                    {
                        
                        setOrgRoleCode(null);
                    }
                    else
                    {
                        
                        setOrgRoleCode(orgModel.getOrgRoleCode());              
                    }
                }

            }
            
            if ("ORG".equals(getOrgHierarchyTypeCode()))
            {
                if ("CAR".equals(getOrgRoleCode()) && getParentOrgId() != null)
                {
                    setOrgHierarchyTypeName(subsidiaryName);
                } else {
                    setOrgHierarchyTypeName(organizationName);
                }
            }
        }

        // Make Subsidiary
        if (action.equalsIgnoreCase("makeSub")) {
            if (!"".equals(getParentOrgId()) && orgDAO.retrieve(new Long(getParentOrgId()), null) != null) {
                logger.debug("Converting to Subsidiary");               
                setOrgHierarchyTypeName(subsidiaryName);
            } else {
                messages.add("error.filecontent", new ActionMessage("error.file.content", "A valid Parent Entity must be chosen to convert an organization to a subsidiary."));
                
                addActionError(messages.toString());
            }
        }

                        
        // Make Organization
        if (action.equalsIgnoreCase("makeOrg")) {
            logger.debug("Converting to Organization");

            setOrgHierarchyTypeName(organizationName);
            setParentOrgId(null);
            setParentOrgType(null);
            setParentOrgName(null);
        }
        
        // Add OrgReference
        if (action.equalsIgnoreCase("addRef")) {
            logger.debug("Adding new OrgReference");
            
            List<OrgReferenceForm> orgRefs = getOrgRefs();
            
            orgRefs.add(new OrgReferenceForm());
            setOrgRefs(orgRefs);
        }

        // Delete OrgReference
        if (action.equalsIgnoreCase("delRef")) {
            int index = Integer.parseInt(getRefId());
            logger.debug("Deleting OrgReference at index " + index);

            List<OrgReferenceForm> orgRefs = getOrgRefs();
            orgRefs.remove(index);
            setOrgRefs(orgRefs);
        }

        

        // add location or add contact
        if (action.equalsIgnoreCase("addLocation") || action.equalsIgnoreCase("addContact")) {
            
            if (action.equalsIgnoreCase("addLocation")) {
                type = "LOC";
            } else {
                type = "CON";
            }

            
            // make a new model
            OrghierarchyModel orgModel = orgManager.prepareNewModel(type, credentials);

            // set the parent values in the new model           
            orgModel.setParentOrgId(BigInteger.valueOf(10012878));
            orgModel.setParentOrgName("TSA HQ (LOC)");
            
            // set context to add on form
            setContext("ADD");
            

            // copy model to form
            beanManager.model2form(orghierarchyForm, orgModel);
           
            // put the model in the session store to be updated on saving
            sessionStore.put(SessionKey.ORGHIERARCHY_MODEL, orgModel);

            

        }

        // add login
        if (action.equalsIgnoreCase("addLogin")) {
            
            OrghierarchyModel contactModel = null;

            try {
                contactModel = (OrghierarchyModel) sessionStore.get(SessionKey.ORGHIERARCHY_MODEL);
                
                String parentOrgName = orgDAO.retrieveOrgNameByOrgID(contactModel.getParentOrgId().longValue());
                

                contactModel.setParentOrgName(parentOrgName);
            } catch (Exception ex) {
                logger.error("Failed to retreive OrgHierarchyModel:" + ex.getMessage());
             
            }
            
            if (null != contactModel) {
            // clear out orgModel from session
            sessionStore.remove(SessionKey.ORGHIERARCHY_MODEL);

            // put contact model in session store
            sessionStore.put(SessionKey.USER_CONTACT_MODEL, contactModel);
            
            }
            // forward to userDetails
            return "addLogin";
        } try {        
        // set pulldowns on form
        orgManager.setOptionLists(orghierarchyForm);
        
        orghierarchyForm.countryStrList =  convertCountryListToStringList (orghierarchyForm.countryList);
        setCountryStrList (orghierarchyForm.countryStrList);
        
        orghierarchyForm.refTypeStrList = convertRefTypeListToStringList (orghierarchyForm.refTypeList);
        setRefTypeStrList (orghierarchyForm.refTypeStrList);
        
        setStatusStrList(initStatusStrList (statusStrList));
        orghierarchyForm.statusStrList = initStatusStrList (orghierarchyForm.statusStrList);
        
        orghierarchyForm.titleStrList =  convertTitleListToStringList (orghierarchyForm.titleList);
        setTitleStrList (orghierarchyForm.titleStrList);
        
        orghierarchyForm.regionStrList =  convertRegionListToStringList (orghierarchyForm.regionList);
        setRegionStrList (orghierarchyForm.regionStrList);
        
        orghierarchyForm.roleStrList = convertRoleListToStringList (orghierarchyForm.roleList);
        setRoleStrList (orghierarchyForm.roleStrList);
} catch  (Exception e) {
    logger.error("Exception:" + e.getMessage());
	
}
        
        UserSetupManager userSetupManager = new UserSetupManager();
        List<SystemUserModel> loginList = new ArrayList<SystemUserModel>();
        if ((getOrgId()) != 0){
            loginList = userSetupManager.getAllSystemUsers(getOrgId());
            if (! (loginList.isEmpty())){
                setLoginList(loginList);
                
                
            }
        }
               
        
        return "display";
    }


    
    public List<OrgReferenceForm> initOrgRefs(){
        List<OrgReferenceForm> theOrgRefs;
        theOrgRefs = ListUtils.lazyList(new ArrayList<OrgReferenceForm>(), new Factory() {
            public Object create() {
                return new OrgReferenceForm();
            }
        });
            
        return theOrgRefs;
    }
    
    public List<OrgAssocForm> initOrgAssocForm(){
        List<OrgAssocForm> theOrgAssoc;
        theOrgAssoc = ListUtils.lazyList(new ArrayList<OrgAssocForm>(), new Factory() {
            public Object create() {
                return new OrgAssocForm();
            }
        });
            
        return theOrgAssoc;
    }

    public void setServletRequest(HttpServletRequest request) {
        this.request = request;
    }

    public HttpServletRequest getServletRequest() {
        return request;
    }
    
    public void setRefType(String refType) {
        this.refType = refType;
    }

    public String getRefType() {
        return refType;
    }
    
    public void setRefValue(String refValue) {
        this.refValue = refValue;
    }

    public String getRefValue() {
        return refValue;
    }
    
    
    public OrgFormFieldBean getOrgFormFieldBean() {
        return orgFormFieldBean;
    }

    public void setOrgFormFieldBean(OrgFormFieldBean orgFormFieldBean) {
        this.orgFormFieldBean = orgFormFieldBean;
    }
    
    
    public String getAssocJsArray() {
        return assocJsArray;
    }

    public void setAssocJsArray(String assocJsArray) {
        this.assocJsArray = assocJsArray;
    }

    public List<OptionBean> getOrgAssocTypeList() {
        return orgAssocTypeList;
    }

    public void setOrgAssocTypeList(List<OptionBean> orgAssocTypeList) {
        this.orgAssocTypeList = orgAssocTypeList;
    }

    public String getOrgAssocId() {
        return orgAssocId;
    }

    public void setOrgAssocId(String orgAssocId) {
        this.orgAssocId = orgAssocId;
    }
    
    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getEventId() {
        return eventId;
    }

    public void setEventId(String eventId) {
        this.eventId = eventId;
    }

    public List<OptionBean> getEventTypeList() {
        return eventTypeList;
    }

    public void setEventTypeList(List<OptionBean> eventTypeList) {
        this.eventTypeList = eventTypeList;
    }



    public String getParentJsArray() {
        return parentJsArray;
    }

    public void setParentJsArray(String parentJsArray) {
        this.parentJsArray = parentJsArray;
    }

    public OrganizationChartModel getChartModel() {
        return chartModel;
    }

    public void setChartModel(OrganizationChartModel chartModel) {
        this.chartModel = chartModel;
    }

    public String getAction() {
        if (action == null) {
            return "";
        } else {
            return action.toUpperCase();
        }
    }

    public void setAction(String action) {
        this.action = action;
    }

    public long getOrgId() {
        return orgId;
    }

    public void setOrgId(long orgId) {
        this.orgId = orgId;
    }

    public String getRefId() {
        return refId;
    }

    public void setRefId(String refId) {
        this.refId = refId;
    }

    public String getAddressTypeCode() {
        if (addressTypeCode == null) {
            return "";
        } else {
            return addressTypeCode.toUpperCase();
        }
    }

    public void setAddressTypeCode(String addressTypeCode) {
        this.addressTypeCode = addressTypeCode;
    }

    public String getCountryCode() {
        if (countryCode == null) {
            return "";
        } else {
            return countryCode.toUpperCase();
        }
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    
    public String getTimeZoneId() {
        if (timeZoneId == null) {
            return "";
        } else {
            return timeZoneId.toUpperCase();
        }
    }

    public void setTimeZoneId(String timeZoneId) {
        this.timeZoneId = timeZoneId;
    }

    public String getAddressLine1() {
        if (addressLine1 == null) {
            return "";
        } else {
            return addressLine1.toUpperCase();
        }
    }

    public void setAddressLine1(String addressLine1) {
        this.addressLine1 = addressLine1;
    }

    public String getAddressLine2() {
        if (addressLine2 == null) {
            return "";
        } else {
            return addressLine2.toUpperCase();
        }
    }

    public void setAddressLine2(String addressLine2) {
        this.addressLine2 = addressLine2;
    }

    public String getCity() {
        if (city == null) {
            return "";
        } else {
            return city.toUpperCase();
        }
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getStateProvince() {
        if (stateProvince == null) {
            return "";
        } else {
            return stateProvince.toUpperCase();
        }
    }

    public void setStateProvince(String stateProvince) {
        this.stateProvince = stateProvince;
    }

    public String getStateProvinceCode() {
        if (stateProvinceCode == null) {
            return "";
        } else {
            return stateProvinceCode.toUpperCase();
        }
    }

    public void setStateProvinceCode(String stateProvinceCode) {
        this.stateProvinceCode = stateProvinceCode;
    }

    public String getZipPostCode() {
        if (zipPostCode == null) {
            return "";
        } else {
            return zipPostCode.toUpperCase();
        }
    }

    public void setZipPostCode(String zipPostCode) {
        this.zipPostCode = zipPostCode;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getCreateUserId() {
        if (createUserId == null) {
            return "";
        } else {
            return StringEscapeUtils.escapeHtml(createUserId.toUpperCase());
        }
    }

    public void setCreateUserId(String createUserId) {
        this.createUserId = createUserId;
    }

    public String getCreateTimestamp() {
        if (createTimestamp != null) {
            this.createTimestamp = StringEscapeUtils.escapeHtml(createTimestamp);
        }
        return createTimestamp;
    }

    public void setCreateTimestamp(String createTimestamp) {
        this.createTimestamp = createTimestamp;
    }

    public String getDomainName() {
        if (domainName == null) {
            return "";
        } else {
            return domainName.toUpperCase();
        }
    }

    public void setDomainName(String domainName) {
        this.domainName = domainName;
    }

    public String getLastUpdateUserId() {
        if (lastUpdateUserId == null) {
            return "";
        } else {
            return StringEscapeUtils.escapeHtml(lastUpdateUserId.toUpperCase());
        }
    }

    public void setLastUpdateUserId(String lastUpdateUserId) {
        this.lastUpdateUserId = lastUpdateUserId;
    }

    public String getLastUpdateTimestamp() {
        if (lastUpdateTimestamp != null) {
            this.lastUpdateTimestamp = StringEscapeUtils.escapeHtml(lastUpdateTimestamp);
        }
        return lastUpdateTimestamp;
    }

    public void setLastUpdateTimestamp(String lastUpdateTimestamp) {
        this.lastUpdateTimestamp = lastUpdateTimestamp;
    }

    public List<OrghierarchyModel> getContactList() {
        if (contactList == null) {
            return new ArrayList<OrghierarchyModel>();
        } else {
            return contactList;
        }
    }

    public void setContactList(List<OrghierarchyModel> contactList) {
        this.contactList = contactList;
    }

    public List<OrghierarchyModel> getLocationList() {
        if (locationList == null) {
            return new ArrayList<OrghierarchyModel>();
        } else {
            return locationList;
        }
    }

    public void setLocationList(List<OrghierarchyModel> locationList) {
        this.locationList = locationList;
    }

    public boolean isReadonly() {
        return readonly;
    }
    
    public boolean getReadonly() {
        return readonly;
    }

    public void setReadonly(boolean readonly) {
        this.readonly = readonly;
    }

    public List<OptionBean> getTitleList() {
        return titleList;
    }

    public void setTitleList(List<OptionBean> titleList) {
        this.titleList = titleList;
    }
    
    public List<String> getTitleStrList() {
        return titleStrList;
    }

    public void setTitleStrList(List<String> titleStrList) {
        this.titleStrList = titleStrList;
    }

    public List<OptionBean> getRegionList() {
        return regionList;
    }

    public void setRegionList(List<OptionBean> regionList) {
        this.regionList = regionList;
    }
    
    public List<String> getRegionStrList() {
        return regionStrList;
    }

    public void setRegionStrList(List<String> regionStrList) {
        this.regionStrList = regionStrList;
    }

    public List<OptionBean> getCountryList() {
        return countryList;
    }

    public void setCountryList(List<OptionBean> countryList) {
        this.countryList = countryList;
    }
    
    public List<String> getCountryStrList() {
        return countryStrList;
    }

    public void setCountryStrList(List<String> countryStrList) {
        this.countryStrList = countryStrList;
    }

    public List<OptionBean> getRefTypeList() {
        return refTypeList;
    }

    public void setRefTypeList(List<OptionBean> refTypeList) {
        this.refTypeList = refTypeList;
    }
    
    public List<String> getRefTypeStrList() {
        return refTypeStrList;
    }

    public void setRefTypeStrList(List<String> refTypeStrList) {
        this.refTypeStrList = refTypeStrList;
    }
    
    public List<String> getStatusStrList() {
        return statusStrList;
    }

    public void setStatusStrList(List<String> statusStrList) {
        this.statusStrList = statusStrList;
    }

    public List<OptionBean> getRoleList() {
        return roleList;
    }

    public void setRoleList(List<OptionBean> roleList) {
        this.roleList = roleList;
    }
    
    public List<String> getRoleStrList() {
        return roleStrList;
    }

    public void setRoleStrList(List<String> roleStrList) {
        this.roleStrList = roleStrList;
    }

    public String getOrgHierarchyTypeName() {
        if (orgHierarchyTypeName == null) {
            return "";
        } else {
            return orgHierarchyTypeName;
        }
    }

    public void setOrgHierarchyTypeName(String orgHierarchyTypeName) {
        this.orgHierarchyTypeName = orgHierarchyTypeName;
    }

    public String getContext() {
        if (context == null) {
            return "";
        } else {
            return StringEscapeUtils.escapeHtml(context.toUpperCase());
        }
    }

    public void setContext(String context) {
        this.context = context;
    }

    public List<SystemUserModel> getLoginList() {
        return loginList;
    }

    public void setLoginList(List<SystemUserModel> loginList) {
        this.loginList = loginList;
    }

    public String getParentOrgId() {
        return parentOrgId;
    }

    public void setParentOrgId(String parentOrgId) {
        this.parentOrgId = parentOrgId;
    }

    public String getParentOrgName() {
        if (parentOrgName == null) {
            return "";
        } else {
            return parentOrgName.toUpperCase();
        }
    }

    public void setParentOrgName(String parentOrgName) {
        this.parentOrgName = parentOrgName;
    }

    public String getParentOrgType() {
        if (parentOrgType == null) {
            return "";
        } else {
            return parentOrgType.toUpperCase();
        }
    }

    public void setParentOrgType(String parentOrgType) {
        this.parentOrgType = parentOrgType;
    }

    public String getOrgRoleCode() {
        if (orgRoleCode == null) {
            return "";
        } else {
            return orgRoleCode.toUpperCase();
        }
    }

    public void setOrgRoleCode(String orgRoleCode) {
        this.orgRoleCode = orgRoleCode;
    }

    public String getContactSalutationCode() {
        if (contactSalutationCode == null) {
            return "";
        } else {
            return contactSalutationCode.toUpperCase();
        }
    }

    public void setContactSalutationCode(String contactSalutationCode) {
        this.contactSalutationCode = contactSalutationCode.toUpperCase();
    }

    public String getOrgHierarchyTypeCode() {
        if (orgHierarchyTypeCode == null) {
            return "";
        } else {
            return StringEscapeUtils.escapeHtml(orgHierarchyTypeCode.toUpperCase());
        }
    }

    public void setOrgHierarchyTypeCode(String orgHierarchyTypeCode) {
        this.orgHierarchyTypeCode = orgHierarchyTypeCode;
    }

    public String getOrgName() {
        if (orgName == null) {
            return "";
        } else {
            return orgName.toUpperCase();
        }
    }

    public void setOrgName(String orgName) {
        this.orgName = orgName;
    }

    public String getDUNSNumber() {
        if (DUNSNumber == null) {
            return "";
        } else {
            return DUNSNumber.toUpperCase();
        }
    }

    public void setDUNSNumber(String dUNSNumber) {
        DUNSNumber = dUNSNumber;
    }

    public String getSCACCode() {
        if (SCACCode == null) {
            return "";
        } else {
            return SCACCode.toUpperCase();
        }
    }

    public void setSCACCode(String sCACCode) {
        SCACCode = sCACCode;
    }

    public String getEINNumber() {
        if (EINNumber == null) {
            return "";
        } else {
            return EINNumber.toUpperCase();
        }
    }

    public void setEINNumber(String eINNumber) {
        EINNumber = eINNumber;
    }

    public String getStp() {
        if (stp == null) {
            return "";
        } else {
            return stp.toUpperCase();
        }
    }

    public void setStp(String stp) {
        this.stp = stp;
    }

    public String getPortCode() {
        if (portCode == null) {
            return "";
        } else {
            return portCode.toUpperCase();
        }
    }

    public void setPortCode(String portCode) {
        this.portCode = portCode;
    }

    public String getRemarks() {
        if (remarks == null) {
            return "";
        } else {
            return remarks.toUpperCase();
        }
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getContactFirstName() {
        if (contactFirstName == null) {
            return "";
        } else {
            return contactFirstName.toUpperCase();
        }
    }

    public void setContactFirstName(String contactFirstName) {
        this.contactFirstName = contactFirstName;
    }

    public String getContactLastName() {
        if (contactLastName == null) {
            return "";
        } else {
            return contactLastName.toUpperCase();
        }
    }

    public void setContactLastName(String contactLastName) {
        this.contactLastName = contactLastName;
    }

    public String getContactTitle() {
        if (contactTitle == null) {
            return "";
        } else {
            return contactTitle.toUpperCase();
        }
    }

    public void setContactTitle(String contactTitle) {
        this.contactTitle = contactTitle;
    }

    public String getPhone() {
        if (phone == null) {
            return "";
        } else {
            return phone.toUpperCase();
        }
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
    
	public String getEmail() {
        if (email == null) {
            return "";
        } else {
            return StringEscapeUtils.escapeHtml(email.toUpperCase());
        }
    }
   
    public void setEmail(String email) {
        this.email = email;
    }

    public String getRegion() {
        if (region == null) {
            return "";
        } else {
            return region.toUpperCase();
        }
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public List<OrgReferenceForm> getOrgRefs() {
        return orgRefs;
    }

    public void setOrgRefs(final List<OrgReferenceForm> orgRefs) {
        this.orgRefs = orgRefs;
    }

    public OrgReferenceForm getOrgReferenceForm(int index) {
        return (OrgReferenceForm) orgRefs.get(index);
    }

    public void setOrgReferenceForm(int index, OrgReferenceForm orgRef) {
        orgRefs.set(index, orgRef);
    }



    public List<OptionBean> getOrgApAcAssocTypeList() {
        return orgApAcAssocTypeList;
    }

    public void setOrgApAcAssocTypeList(List<OptionBean> orgApAcAssocTypeList) {
        this.orgApAcAssocTypeList = orgApAcAssocTypeList;
    }

    public String getRequiredReporting() {
        return requiredReporting;
    }

    public void setRequiredReporting(String requiredReporting) {
        this.requiredReporting = requiredReporting;
    }

    public String getNcspMember() {
        return ncspMember;
    }

    public void setNcspMember(String ncspMember) {
        this.ncspMember = ncspMember;
    }
    
    public String getLoginTimeRoleMsg() {
        return loginTimeRoleMsg;
    }

    public void setLoginTimeRoleMsg(String loginTimeRoleMsg) {
        this.loginTimeRoleMsg = loginTimeRoleMsg;
    }
    
    public String getBasicBtnClicked() {
        return basicBtnClicked;
    }

    public void setBasicBtnClicked(String basicBtnClicked) {
        this.basicBtnClicked = basicBtnClicked;
    }
    
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }
    
public class OrgFormFieldBean {
    private boolean readonly;
    private long orgId;
    private String parentOrgId;
    private String parentOrgName;
    private String parentOrgType;
    private String createUserId;
    private String createTimestamp;
    private String domainName;
    private String lastUpdateUserId;
    private String lastUpdateTimestamp;
    private String orgRoleCode;
    private String contactSalutationCode;
    private String orgHierarchyTypeCode;
    private String orgName;
    private String DUNSNumber;
    private String SCACCode;
    private String EINNumber;
    private String stp;
    private String portCode;
    private String remarks;
    private String status;
    private String contactFirstName;
    private String contactLastName;
    private String contactTitle;
    private String phone;
    private String email;
    private String region;
    private String addressTypeCode;
    private String countryCode;
    private String roleCode;
    private String timeZoneId;
    private String addressLine1;
    private String addressLine2;
    private String city;
    private String stateProvince;
    private String stateProvinceCode;
    private String zipPostCode;
    private String latitude;
    private String longitude;
    // keep track of which orgreference index to delete
    private String refId;
    // keep track of which event index to delete
    private String eventId;
    // keep track of which orgAssoc to delete
    private String orgAssocId;
    private String requiredReporting = "BOTH";
    private String ncspMember;
    private List<OrgReferenceForm> orgRefs = initOrgRefs();
    
    private List<OrgAssocForm> orgAssocList = initOrgAssocForm();
    private List<SystemUserModel> loginList;
    private List<OrghierarchyModel> contactList;
    private List<OrghierarchyModel> locationList;
    private List<EventForm> eventList;
    // pulldown lists
    private List<OptionBean> countryList;
    private List<String> countryStrList;
    private List<OptionBean> roleList;
    private List<String> roleStrList;
    private List<OptionBean> refTypeList;
    private List<String> refTypeStrList;
    private List<String> statusStrList;
    private List<OptionBean> eventTypeList;
    private List<OptionBean> orgAssocTypeList;
    private List<OptionBean> orgApAcAssocTypeList;
    private List<OptionBean> titleList;
    private List<String> titleStrList;
    private List<OptionBean> regionList;
    private List<String> regionStrList;
    // for display on form only. Not a persisted field
    private String orgHierarchyTypeName;
    private OrganizationChartModel chartModel;
    private String parentJsArray;
    private String assocJsArray;
    private String action;
    private String context;
    private String refType;
    private String refValue;
    
    public void setRefType(String refType) {
        this.refType = refType;
    }

    public String getRefType() {
        return refType;
    }
    
    public void setRefValue(String refValue) {
        this.refValue = refValue;
    }

    public String getRefValue() {
        return refValue;
    }
    
    public boolean isReadonly() {
        return readonly;
    }
    
    public boolean getReadonly() {
        return readonly;
    }
    
    public void setEventList(List<EventForm> eventList) {
	this.eventList = eventList;
    }

    public void setReadonly(boolean readonly) {
        this.readonly = readonly;
    }
        
    public String getOrgHierarchyTypeCode() {
        if (orgHierarchyTypeCode == null) {
            return "";
        } else {
            return StringEscapeUtils.escapeHtml(orgHierarchyTypeCode.toUpperCase());
        }
    }

    public void setOrgHierarchyTypeCode(String orgHierarchyTypeCode) {
        this.orgHierarchyTypeCode = orgHierarchyTypeCode;
    }
    
    public String getAssocJsArray() {
        return assocJsArray;
    }

    public void setAssocJsArray(String assocJsArray) {
        this.assocJsArray = assocJsArray;
    }

    public List<OptionBean> getOrgAssocTypeList() {
        return orgAssocTypeList;
    }

    public void setOrgAssocTypeList(List<OptionBean> orgAssocTypeList) {
        this.orgAssocTypeList = orgAssocTypeList;
    }

    public String getOrgAssocId() {
        return orgAssocId;
    }

    public void setOrgAssocId(String orgAssocId) {
        this.orgAssocId = orgAssocId;
    }

    public String getEventId() {
        return eventId;
    }

    public void setEventId(String eventId) {
        this.eventId = eventId;
    }

    public List<OptionBean> getEventTypeList() {
        return eventTypeList;
    }

    public void setEventTypeList(List<OptionBean> eventTypeList) {
        this.eventTypeList = eventTypeList;
    }



    public String getParentJsArray() {
        return parentJsArray;
    }

    public void setParentJsArray(String parentJsArray) {
        this.parentJsArray = parentJsArray;
    }

    public OrganizationChartModel getChartModel() {
        return chartModel;
    }

    public void setChartModel(OrganizationChartModel chartModel) {
        this.chartModel = chartModel;
    }

    public String getAction() {
        if (action == null) {
            return "";
        } else {
            return action.toUpperCase();
        }
    }

    public void setAction(String action) {
        this.action = action;
    }

    public long getOrgId() {
        return orgId;
    }

    public void setOrgId(long orgId) {
        this.orgId = orgId;
    }

    public String getRefId() {
        return refId;
    }

    public void setRefId(String refId) {
        this.refId = refId;
    }

    public String getAddressTypeCode() {
        if (addressTypeCode == null) {
            return "";
        } else {
            return addressTypeCode.toUpperCase();
        }
    }

    public void setAddressTypeCode(String addressTypeCode) {
        this.addressTypeCode = addressTypeCode;
    }

    public String getCountryCode() {
        if (countryCode == null) {
            return "";
        } else {
            return countryCode.toUpperCase();
        }
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

        public String getRoleCode() {
            return roleCode;
        }

        public void setRoleCode(String roleCode) {
            this.roleCode = roleCode;
        }

    
    public String getTimeZoneId() {
        if (timeZoneId == null) {
            return "";
        } else {
            return timeZoneId.toUpperCase();
        }
    }

    public void setTimeZoneId(String timeZoneId) {
        this.timeZoneId = timeZoneId;
    }

    public String getAddressLine1() {
        if (addressLine1 == null) {
            return "";
        } else {
            return addressLine1.toUpperCase();
        }
    }

    public void setAddressLine1(String addressLine1) {
        this.addressLine1 = addressLine1;
    }

    public String getAddressLine2() {
        if (addressLine2 == null) {
            return "";
        } else {
            return addressLine2.toUpperCase();
        }
    }

    public void setAddressLine2(String addressLine2) {
        this.addressLine2 = addressLine2;
    }

    public String getCity() {
        if (city == null) {
            return "";
        } else {
            return city.toUpperCase();
        }
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getStateProvince() {
        if (stateProvince == null) {
            return "";
        } else {
            return stateProvince.toUpperCase();
        }
    }

    public void setStateProvince(String stateProvince) {
        this.stateProvince = stateProvince;
    }

    public String getStateProvinceCode() {
        if (stateProvinceCode == null) {
            return "";
        } else {
            return stateProvinceCode.toUpperCase();
        }
    }

    public void setStateProvinceCode(String stateProvinceCode) {
        this.stateProvinceCode = stateProvinceCode;
    }

    public String getZipPostCode() {
        if (zipPostCode == null) {
            return "";
        } else {
            return zipPostCode.toUpperCase();
        }
    }

    public void setZipPostCode(String zipPostCode) {
        this.zipPostCode = zipPostCode;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getCreateUserId() {
        if (createUserId == null) {
            return "";
        } else {
            return StringEscapeUtils.escapeHtml(createUserId.toUpperCase());
        }
    }

    public void setCreateUserId(String createUserId) {
        this.createUserId = createUserId;
    }

    public String getCreateTimestamp() {
        if (createTimestamp != null) {
            this.createTimestamp = StringEscapeUtils.escapeHtml(createTimestamp);
        }
        return createTimestamp;
    }

    public void setCreateTimestamp(String createTimestamp) {
        this.createTimestamp = createTimestamp;
    }

    public String getDomainName() {
        if (domainName == null) {
            return "";
        } else {
            return domainName.toUpperCase();
        }
    }

    public void setDomainName(String domainName) {
        this.domainName = domainName;
    }

    public String getLastUpdateUserId() {
        if (lastUpdateUserId == null) {
            return "";
        } else {
            return StringEscapeUtils.escapeHtml(lastUpdateUserId.toUpperCase());
        }
    }

    public void setLastUpdateUserId(String lastUpdateUserId) {
        this.lastUpdateUserId = lastUpdateUserId;
    }

    public String getLastUpdateTimestamp() {
        if (lastUpdateTimestamp != null) {
            this.lastUpdateTimestamp = StringEscapeUtils.escapeHtml(lastUpdateTimestamp);
        }
        return lastUpdateTimestamp;
    }

    public void setLastUpdateTimestamp(String lastUpdateTimestamp) {
        this.lastUpdateTimestamp = lastUpdateTimestamp;
    }

    public List<OrghierarchyModel> getContactList() {
        if (contactList == null) {
            return new ArrayList<OrghierarchyModel>();
        } else {
            return contactList;
        }
    }

    public void setContactList(List<OrghierarchyModel> contactList) {
        this.contactList = contactList;
    }

    public List<OrghierarchyModel> getLocationList() {
        if (locationList == null) {
            return new ArrayList<OrghierarchyModel>();
        } else {
            return locationList;
        }
    }

    public void setLocationList(List<OrghierarchyModel> locationList) {
        this.locationList = locationList;
    }

    public List<OptionBean> getTitleList() {
        return titleList;
    }

    public void setTitleList(List<OptionBean> titleList) {
        this.titleList = titleList;
    }
    
    public List<String> getTitleStrList() {
        return titleStrList;
    }

    public void setTitleStrList(List<String> titleStrList) {
        this.titleStrList = titleStrList;
    }

    public List<OptionBean> getRegionList() {
        return regionList;
    }

    public void setRegionList(List<OptionBean> regionList) {
        this.regionList = regionList;
    }
    
    public List<String> getRegionStrList() {
        return regionStrList;
    }

    public void setRegionStrList(List<String> regionStrList) {
        this.regionStrList = regionStrList;
    }

    public List<OptionBean> getCountryList() {
        return countryList;
    }

    public void setCountryList(List<OptionBean> countryList) {
        this.countryList = countryList;
    }
    
    public List<String> getCountryStrList() {
        return countryStrList;
    }

    public void setCountryStrList(List<String> countryStrList) {
        this.countryStrList = countryStrList;
    }

    public List<OptionBean> getRefTypeList() {
        return refTypeList;
    }

    public void setRefTypeList(List<OptionBean> refTypeList) {
        this.refTypeList = refTypeList;
    }
    
    public List<String> getRefTypeStrList() {
        return refTypeStrList;
    }

    public void setRefTypeStrList(List<String> refTypeStrList) {
        this.refTypeStrList = refTypeStrList;
    }
    
    public List<String> getStatusStrList() {
        return statusStrList;
    }

    public void setStatusStrList(List<String> statusStrList) {
        this.statusStrList = statusStrList;
    }

    public List<OptionBean> getRoleList() {
        return roleList;
    }

    public void setRoleList(List<OptionBean> roleList) {
        this.roleList = roleList;
    }
    
    public List<String> getRoleStrList() {
        return roleStrList;
    }

    public void setRoleStrList(List<String> roleStrList) {
        this.roleStrList = roleStrList;
    }

    public String getOrgHierarchyTypeName() {
        if (orgHierarchyTypeName == null) {
            return "";
        } else {
            return orgHierarchyTypeName;
        }
    }

    public void setOrgHierarchyTypeName(String orgHierarchyTypeName) {
        this.orgHierarchyTypeName = orgHierarchyTypeName;
    }

    public String getContext() {
        if (context == null) {
            return "";
        } else {
            return StringEscapeUtils.escapeHtml(context.toUpperCase());
        }
    }

    public void setContext(String context) {
        this.context = context;
    }

    public List<SystemUserModel> getLoginList() {
        return loginList;
    }

    public void setLoginList(List<SystemUserModel> loginList) {
        this.loginList = loginList;
    }

    public String getParentOrgId() {
        return parentOrgId;
    }

    public void setParentOrgId(String parentOrgId) {
        this.parentOrgId = parentOrgId;
    }

    public String getParentOrgName() {
        if (parentOrgName == null) {
            return "";
        } else {
            return parentOrgName.toUpperCase();
        }
    }

    public void setParentOrgName(String parentOrgName) {
        this.parentOrgName = parentOrgName;
    }

    public String getParentOrgType() {
        if (parentOrgType == null) {
            return "";
        } else {
            return parentOrgType.toUpperCase();
        }
    }

    public void setParentOrgType(String parentOrgType) {
        this.parentOrgType = parentOrgType;
    }

    public String getOrgRoleCode() {
        if (orgRoleCode == null) {
            return "";
        } else {
            return orgRoleCode.toUpperCase();
        }
    }

    public void setOrgRoleCode(String orgRoleCode) {
        this.orgRoleCode = orgRoleCode;
    }

    public String getContactSalutationCode() {
        if (contactSalutationCode == null) {
            return "";
        } else {
            return contactSalutationCode.toUpperCase();
        }
    }

    public void setContactSalutationCode(String contactSalutationCode) {
        this.contactSalutationCode = contactSalutationCode.toUpperCase();
    }

    public String getOrgName() {
        if (orgName == null) {
            return "";
        } else {
            return orgName.toUpperCase();
        }
    }

    public void setOrgName(String orgName) {
        this.orgName = orgName;
    }

    public String getDUNSNumber() {
        if (DUNSNumber == null) {
            return "";
        } else {
            return DUNSNumber.toUpperCase();
        }
    }

    public void setDUNSNumber(String dUNSNumber) {
        DUNSNumber = dUNSNumber;
    }

    public String getSCACCode() {
        if (SCACCode == null) {
            return "";
        } else {
            return SCACCode.toUpperCase();
        }
    }

    public void setSCACCode(String sCACCode) {
        SCACCode = sCACCode;
    }

    public String getEINNumber() {
        if (EINNumber == null) {
            return "";
        } else {
            return EINNumber.toUpperCase();
        }
    }

    public void setEINNumber(String eINNumber) {
        EINNumber = eINNumber;
    }

    public String getStp() {
        if (stp == null) {
            return "";
        } else {
            return stp.toUpperCase();
        }
    }

    public void setStp(String stp) {
        this.stp = stp;
    }

    public String getPortCode() {
        if (portCode == null) {
            return "";
        } else {
            return portCode.toUpperCase();
        }
    }

    public void setPortCode(String portCode) {
        this.portCode = portCode;
    }

    public String getRemarks() {
        if (remarks == null) {
            return "";
        } else {
            return remarks.toUpperCase();
        }
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getContactFirstName() {
        if (contactFirstName == null) {
            return "";
        } else {
            return contactFirstName.toUpperCase();
        }
    }

    public void setContactFirstName(String contactFirstName) {
        this.contactFirstName = contactFirstName;
    }

    public String getContactLastName() {
        if (contactLastName == null) {
            return "";
        } else {
            return contactLastName.toUpperCase();
        }
    }

    public void setContactLastName(String contactLastName) {
        this.contactLastName = contactLastName;
    }

    public String getContactTitle() {
        if (contactTitle == null) {
            return "";
        } else {
            return contactTitle.toUpperCase();
        }
    }

    public void setContactTitle(String contactTitle) {
        this.contactTitle = contactTitle;
    }

    public String getPhone() {
        if (phone == null) {
            return "";
        } else {
            return phone.toUpperCase();
        }
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
    
	public String getEmail() {
        if (email == null) {
            return "";
        } else {
            return StringEscapeUtils.escapeHtml(email.toUpperCase());
        }
    }
    
    public void setEmail(String email) {
        this.email = email;
    }

    public String getRegion() {
        if (region == null) {
            return "";
        } else {
            return region.toUpperCase();
        }
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public List<OrgReferenceForm> getOrgRefs() {
        return orgRefs;
    }

    public void setOrgRefs(final List<OrgReferenceForm> orgRefs) {
        this.orgRefs = orgRefs;
    }

    public OrgReferenceForm getOrgReferenceForm(int index) {
        return (OrgReferenceForm) orgRefs.get(index);
    }

    public void setOrgReferenceForm(int index, OrgReferenceForm orgRef) {
        orgRefs.set(index, orgRef);
    }



    public List<OrgAssocForm> getOrgAssocList() {
        return orgAssocList;
    }

    public void setOrgAssocList(final List<OrgAssocForm> orgAssocList) {
        this.orgAssocList = orgAssocList;
    }

    public OrgAssocForm getOrgAssocForm(int index) {
        return (OrgAssocForm) orgAssocList.get(index);
    }

    public void setOrgAssocForm(int index, OrgAssocForm orgAssocForm) {
        
        return;
    }

    public List<OptionBean> getOrgApAcAssocTypeList() {
        return orgApAcAssocTypeList;
    }

    public void setOrgApAcAssocTypeList(List<OptionBean> orgApAcAssocTypeList) {
        this.orgApAcAssocTypeList = orgApAcAssocTypeList;
    }

    public String getRequiredReporting() {
        return requiredReporting;
    }

    public void setRequiredReporting(String requiredReporting) {
        this.requiredReporting = requiredReporting;
    }

    public String getNcspMember() {
        return ncspMember;
    }

    public void setNcspMember(String ncspMember) {
        this.ncspMember = ncspMember;
    }
        
}

    private List<String> convertCountryListToStringList (List<OptionBean> countryBeanList) {
        List<String> theCountryStrList = new ArrayList<String>();
        
        Iterator<OptionBean> itrCountry = countryBeanList.iterator();
        OptionBean optBean = new OptionBean();
        while (itrCountry.hasNext()) {
            optBean = itrCountry.next();
            theCountryStrList.add(optBean.getLabel());
            
        }
        
        return theCountryStrList;
    }
    
    private String convertCountryLabelToValue(String countryLabel, List<OptionBean> countryBeanList){
        String countryValue;
        
        if (countryLabel.equals("-1")){
            return "US";
        }
        Iterator<OptionBean> itrCountry = countryBeanList.iterator();
        OptionBean optBean = new OptionBean();
        while (itrCountry.hasNext()) {
            optBean = itrCountry.next();
            if (optBean.getLabel().equalsIgnoreCase(countryLabel)){
                
                return (optBean.getValue());
            }
        }
        
        return "US";
    }
    
    private String convertCountryValueToLabel(String countryValue, List<OptionBean> countryBeanList){
        
        if (countryValue.equals("-1")){
            return "UNITED  STATES";
        }
        Iterator<OptionBean> itrCountry = countryBeanList.iterator();
        OptionBean optBean = new OptionBean();
        while (itrCountry.hasNext()) {
            optBean = itrCountry.next();
            if (optBean.getValue().equalsIgnoreCase(countryValue)){
                return (optBean.getLabel());
            }
        }
        
        return "UNITED  STATES";
    }
    
    
    private String convertRoleLabelToValue(String roleLabel, List<OptionBean> roleBeanList){
        
        if (roleLabel.equals("-1")){
            return "ANALY";
        }
        Iterator<OptionBean> itrRole = roleBeanList.iterator();
        OptionBean optBean = new OptionBean();
        while (itrRole.hasNext()) {
            optBean = itrRole.next();
            if (optBean.getLabel().equalsIgnoreCase(roleLabel)){
                return (optBean.getValue());
            }
        }
        
        return "ANALY";
    }
    
    private String convertRoleValueToLabel(String roleValue, List<OptionBean> roleBeanList){
        
        if (roleValue.equals("-1")){
            return "TSA-FAS ANALYTICAL TEAM";
        }
        Iterator<OptionBean> itrRole = roleBeanList.iterator();
        OptionBean optBean = new OptionBean();
        while (itrRole.hasNext()) {
            optBean = itrRole.next();
            if (optBean.getValue().equalsIgnoreCase(roleValue)){
                return (optBean.getLabel());
            }
        }
        
        return "TSA-FAS ANALYTICAL TEAM";
    }
    
    private String convertTitleLabelToValue(String titleLabel, List<OptionBean> titleBeanList){
        
        if (titleLabel.equals("-1")){
            return "None";
        }
        Iterator<OptionBean> itrTitle = titleBeanList.iterator();
        OptionBean optBean = new OptionBean();
        while (itrTitle.hasNext()) {
            optBean = itrTitle.next();
            if (optBean.getLabel().equalsIgnoreCase(titleLabel)){
                
                return (optBean.getValue());
            }
        }
        
        return "None";
    }
    
    private String convertTitleValueToLabel(String titleValue, List<OptionBean> titleBeanList){
        
        
        if (titleValue.equals("None")){
            return null;
        }
        Iterator<OptionBean> itrTitle = titleBeanList.iterator();
        OptionBean optBean = new OptionBean();
        while (itrTitle.hasNext()) {
            optBean = itrTitle.next();
            if (optBean.getValue().equalsIgnoreCase(titleValue)){
                
                return (optBean.getLabel());
            }
        }
        
        return null;
    }
    
    private List<String> convertRefTypeListToStringList (List<OptionBean> refTypeBeanList) {
        List<String> theRefTypeStrList = new ArrayList<String>();
        
        Iterator<OptionBean> itrRefType = refTypeBeanList.iterator();
        OptionBean optBean = new OptionBean();
        while (itrRefType.hasNext()) {
            optBean = itrRefType.next();
            theRefTypeStrList.add(optBean.getLabel());
            
        }
        
        return theRefTypeStrList;
    }
    
    private List<String> convertRoleListToStringList (List<OptionBean> roleBeanList) {
            
        List<String> theRoleStrList = new ArrayList<String>();
        
        Iterator<OptionBean> itrRole = roleBeanList.iterator();
        OptionBean optBean = new OptionBean();
        while (itrRole.hasNext()) {
            optBean = itrRole.next();
            theRoleStrList.add(optBean.getLabel());
            
        }
        
        return theRoleStrList;
    }
    
    private List<String> initStatusStrList(List<String> statusStrList) {
        List<String> theStatusStrList = new ArrayList<String>();
        
        theStatusStrList.add("ACTIVE");
        theStatusStrList.add("INACTIVE");
        
        Iterator<String> itrStatusStrList = theStatusStrList.iterator();
        while (itrStatusStrList.hasNext()) {
            logger.debug ("*** initStatusStrList: " + itrStatusStrList.next().toString());
			
        }
        
        return theStatusStrList;
    }
    
    private List<String> convertTitleListToStringList (List<OptionBean> titleBeanList) {
        List<String> theTitleStrList = new ArrayList<String>();
        
        Iterator<OptionBean> itrTitle = titleBeanList.iterator();
        OptionBean optBean = new OptionBean();
        while (itrTitle.hasNext()) {
            optBean = itrTitle.next();
            optBean.setLabel(optBean.getLabel().toUpperCase());
            optBean.setValue(optBean.getValue().toUpperCase());
            theTitleStrList.add(optBean.getLabel());
            
        }
        
        return theTitleStrList;
    }
    
    private List<String> convertRegionListToStringList (List<OptionBean> regionBeanList) {
        List<String> theRegionStrList = new ArrayList<String>();
        
        Iterator<OptionBean> itrRegion = regionBeanList.iterator();
        OptionBean optBean = new OptionBean();
        while (itrRegion.hasNext()) {
            optBean = itrRegion.next();
            optBean.setLabel(optBean.getLabel().toUpperCase());
            optBean.setValue(optBean.getValue().toUpperCase());
            theRegionStrList.add(optBean.getLabel());
            
        }
        
        return theRegionStrList;
    }

}
