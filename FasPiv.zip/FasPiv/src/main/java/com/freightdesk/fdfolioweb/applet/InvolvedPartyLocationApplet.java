 /** 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolioweb/applet/InvolvedPartyLocationApplet.java,v 1.6.6.1 2010/08/22 23:08:28 mechevarria Exp $ 
 * 
 *  Modification History:
 *  $Log: InvolvedPartyLocationApplet.java,v $
 *  Revision 1.6.6.1  2010/08/22 23:08:28  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.6  2006/04/10 22:44:15  aarora
 *  Removed redundant code
 *
 *  Revision 1.5  2005/04/26 22:46:52  amrinder
 *  Fixed the fatal flaw in ip applet
 *
 *  Revision 1.4  2005/04/16 14:09:23  dkhoker
 *  implemented the getDataObjects method
 *
 *  Revision 1.3  2005/04/14 19:51:08  amrinder
 *  Simplifying the framework, by moving getObjectIcon to LocationApplet
 *
 *  Revision 1.2  2005/04/14 19:00:34  amrinder
 *  Returning an emtpy list, not null so that at least the map loads
 *
 *  Revision 1.1  2005/04/14 12:50:20  dkhoker
 *  Involved Party implementation of the LocationApplet
 *
 */
 package com.freightdesk.fdfolioweb.applet;

import org.apache.log4j.Logger; 
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.URL;
import java.net.URLConnection;
import java.util.Collection;

 /**
 * @author Devendra Khoker
 *
 */
public class InvolvedPartyLocationApplet extends LocationApplet {

    /**
     * Gets the image path for the involved party icon. 
	 * @see com.freightdesk.fdfolioweb.applet.LocationApplet#getImagePath()
	 */
	
	private static Logger logger = Logger.getLogger("InvolvedPartyLocationApplet");
	
	public String getImagePath() {
        return "/maps/involvedParty.jpg";
	}

    /**
     * Gets the relevant data objects. 
     * 
     * @return Collection containing involved party information
	 * @see com.freightdesk.fdfolioweb.applet.LocationApplet#getDataObjects()
	 */
	public Collection getDataObjects()
    {
        ObjectInputStream ois = null;
        Collection collection = null;
        try {
            String domainName = getParameter("domainName");
            String shipId = getParameter("shipId");
            System.out.println ("Getting data objects, domainName: " + domainName + ", shipId: " + shipId);
            // Create an object we can use to communicate with the servlet
            URL url = new URL(getCodeBase() + "InvolvedPartyLocationServlet?domainName="+domainName+"&shipId="+shipId);
            URLConnection servletConnection = url.openConnection();
            servletConnection.setDoOutput(true);        // to allow us to read from the URL
            servletConnection.setDoInput(true);         // to allow us to write to the URL
    
            servletConnection.setUseCaches(false);      // so that we do contact the servlet and
                                                        // don't get anything from the browser's cache
        
            // Reads the response from the servlet
            ois = new ObjectInputStream(servletConnection.getInputStream());
            System.out.println ("reading Data from the Stream starts");
            collection = (Collection)ois.readObject();
            System.out.println ("reading Data from the Stream ends");
            System.out.println (collection);

        } catch (Exception e) {
            //e.printStackTrace();
			logger.error("Exception: " + e.getMessage());
        } finally {
            try {
                if (ois != null) {
                    ois.close();
                }
            } catch(IOException io) {}
        }
        return collection;
    }
}
