/** 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolioweb/setup/action/Attic/AddPropertiesAction.java,v 1.3.4.3 2010/12/01 21:57:01 mechevarria Exp $ 
 * 
 *  Modification History:
 *  $Log: AddPropertiesAction.java,v $
 *  Revision 1.3.4.3  2010/12/01 21:57:01  mechevarria
 *  use just runtime home
 *
 *  Revision 1.3.4.2  2010/12/01 19:01:27  mechevarria
 *  use new simplified properties
 *
 *  Revision 1.3.4.1  2010/08/22 23:08:38  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.3  2006/04/19 09:17:28  dkumar
 *  replaced References to LCP_RUNTIME_HOME with FD-RUNTIME_HOME and some other minor changes
 *
 *  Revision 1.2  2006/03/28 22:17:34  aarora
 *  Repackaging of fdcommons
 *
 *  Revision 1.1  2006/03/08 23:31:44  ranand
 *  Add application property using UI
 *
 *  Revision 1.4  2005/10/01 15:51:37  amrinder
 *  Added comments
 *
 *  Revision 1.3  2005/07/28 08:13:06  pjain
 *  added constant APPLICATION_PROPERTY_FILE
 *
 *  Revision 1.2  2005/07/27 08:25:37  pjain
 *  changed LcpProperties.getInstance()
 *
 *  Revision 1.1  2005/07/27 08:08:20  pjain
 *  Baseline
 */
package com.freightdesk.vaudit.action;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//import org.apache.struts.action.ActionForm;
//import org.apache.struts.action.ActionForward;
//import org.apache.struts.action.ActionMapping;

import com.freightdesk.fdcommons.ApplicationProperties;
import com.freightdesk.fdcommons.Credentials;
import com.freightdesk.fdcommons.LoggedInAction;
//import com.freightdesk.vaudit.form.AddPropertiesForm;

/**
 * Handles the requests to and from the edit data JSP, which is
 * used to edit the application properties.
 *
 * @author Pankaj Jain
 * @author Amrinder Arora 
 */
//public class AddPropertiesAction 
//    extends LoggedInAction 
//{
//	String FDFOLIO_RUNTIME_HOME = System.getProperty ("RUNTIME_HOME") +  File.separator + "FDfolio-runtime" + File.separator;

    /** Executes the request. */
//    public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response, Credentials credentials) 
//        throws Exception 
//    {
//        logger.debug("execute(): begin");
//        AddPropertiesForm addPropertiesForm = (AddPropertiesForm) form;
//        String process = addPropertiesForm.getProcess();
//        
//        logger.debug("process is : "+process);
//        if ("SAVE".equalsIgnoreCase(process))
//        {
//            saveProperties(addPropertiesForm);
//            return mapping.findForward("home");
//        }
//        else if ("CANCEL".equalsIgnoreCase(process))
//        {
//            return mapping.findForward("home");
//        }
//        
//        return displayPage(mapping,addPropertiesForm,request,response,credentials);
//    }
//
//    public ActionForward displayPage(ActionMapping mapping, AddPropertiesForm addPropertiesForm, HttpServletRequest request, HttpServletResponse response, Credentials credentials) 
//        throws Exception 
//    {
//        logger.debug("displayPage() : begin");
//        return mapping.findForward("display");
//    }
//
//    private void saveProperties(AddPropertiesForm addPropertiesForm)
//    {
//        logger.debug("saveReferenceData(): begin");
//
//        try {
//            Properties referenceProperties = ApplicationProperties.getProps();
//            String[] referenceKey  = addPropertiesForm.getPropertyKey();
//            String[] referenceValue = addPropertiesForm.getPropertyValue();
//
//            for(int i = 0; i < referenceKey.length; i++)
//            {
//                referenceProperties.setProperty(referenceKey[i], referenceValue[i]);
//            }
//            findAndReplace(referenceKey, referenceValue);
//
//            ApplicationProperties.setProps(referenceProperties);
//        }
//        catch(Exception e)
//        {
//            logger.error("Error in saveReferenceData",e);
//        }
//     }
//
//    private void findAndReplace(String[] referenceKey, String[] referenceValue)
//    {
//        RandomAccessFile inFile = null;
//        try {
//            
//            inFile = new RandomAccessFile(FDFOLIO_RUNTIME_HOME + ApplicationProperties.APPLICATION_PROPERTY_FILE,"rw");;
//            inFile.skipBytes((int)inFile.length());
//            
//            inFile.write((int)'\n');
//            for(int i = 0; i < referenceKey.length; i++)
//            {
//                inFile.writeBytes(referenceKey[i]);
//                inFile.writeBytes("=");
//                inFile.writeBytes(referenceValue[i]);
//                inFile.write((int)'\n');
//            }
//            inFile.close();
//        }
//        catch(Exception e)
//        {
//            logger.error("Error in findAndReplace ",e);
//        }finally
//        {
//            try
//            {
//                if(inFile != null)
//                    inFile.close();
//            }catch(IOException io){}
//        }
//    }
//}

