/**
 * Copyright (c) NTELX
 *  All rights reserved.
 *
 * This software is the confidential and proprietary information of NTELX
 * ("Confidential Information").  You shall not disclose such Confidential Information
 * and shall use it only in accordance with the terms of the license agreement you entered
 * into with NTELX.
 *
 *
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolio/dao/UserAccessDAO.java,v 1.7.2.14 2010/08/22 23:08:30 mechevarria Exp $
 *
 *  Modification History:
 *  $Log: UserAccessDAO.java,v $
 *  Revision 1.7.2.14  2010/08/22 23:08:30  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.7.2.13  2010/07/19 20:18:08  mechevarria
 *  add sendmail for user creation
 *
 *  Revision 1.7.2.12  2010/06/22 22:45:00  mechevarria
 *  default uom to engl
 *
 *  Revision 1.7.2.11  2010/02/11 22:12:44  mechevarria
 *  moved systemusermodel to commons
 *
 *  Revision 1.7.2.10  2010/02/05 15:59:12  mechevarria
 *  remove unneccessary debug
 *
 *  Revision 1.7.2.9  2010/02/03 20:32:36  mechevarria
 *  remove unnecssary db lookups
 *
 *  Revision 1.7.2.8  2009/10/29 21:39:14  mechevarria
 *  remove the getDomainsList method and move to commons
 *
 *  Revision 1.7.2.7  2009/09/23 18:02:19  mechevarria
 *  import clean via eclipse
 *
 *  Revision 1.7.2.6  2009/09/22 19:32:42  mechevarria
 *  updated user management
 *
 *  Revision 1.7.2.5  2009/08/17 15:17:28  mechevarria
 *  removed logging for user creation
 *
 *  Revision 1.7.2.4  2009/04/15 15:30:07  mechevarria
 *  change deleteRecord method to use non-deprecated version
 *
 *  Revision 1.7.2.3  2008/12/11 13:56:11  mechevarria
 *  passwordhasher reference now in commons
 *
 *  Revision 1.7.2.2  2007/08/15 15:08:36  mechevarria
 *  added async logging of user updates and user creation
 *
 *  Revision 1.7.2.1  2007/06/14 14:15:22  mechevarria
 *  added code to reset user passwords
 *
 *  Revision 1.7  2007/01/30 14:02:32  atripathi
 *  null inserted when orgId is null
 *
 *  Revision 1.6  2006/10/11 07:52:08  ranand
 *  removed dependency on USERSYSTEMROLE table
 *
 *  Revision 1.5  2006/04/10 22:54:59  aarora
 *  Removed redundant code
 *
 *  Revision 1.4  2006/03/28 21:28:06  aarora
 *  Repackaging of fdcommons
 *
 *  Revision 1.3  2006/03/28 21:22:59  aarora
 *  Repackaging of fdcommons
 *
 *  Revision 1.2  2005/08/23 12:16:41  pjain
 *  changed updateSystemUser access
 *
 *  Revision 1.1  2005/08/20 12:30:16  pjain
 *  centralized DAO package
 *
 *  Revision 1.5  2005/06/15 12:00:36  ranand
 *  delete method calls to Base DAO delete method
 *
 *  Revision 1.4  2004/11/22 22:34:31  amrinder
 *  Changing the log level for debug messages
 *
 *  Revision 1.3  2004/10/20 04:05:39  amrinder
 *  Corrected the load and create methods - we are no longer using PASSWORD column.  It was STILL there.  Now caching an instance of UserPreferenceDAO
 *
 *  Revision 1.2  2004/10/20 00:57:21  amrinder
 *  Added comments
 *  Standardized logging
 *  Standardized exception throwing
 *  Removed commented out method
 *
 *  Revision 1.1  2004/09/15 13:07:11  ranand
 *  2.6 Baseline
 */


package com.freightdesk.fdfolio.dao;

import org.apache.log4j.Logger;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.HashMap;

import javax.ejb.CreateException;
import javax.ejb.DuplicateKeyException;
import javax.ejb.EJBException;

import crt.com.ntelx.nxcommons.AuthenticationUtils;
import com.freightdesk.fdcommons.BaseDao;
import com.freightdesk.fdcommons.ConnectionUtil;
import com.freightdesk.fdcommons.Credentials;
import com.freightdesk.fdcommons.LcpConstants;
import com.freightdesk.fdcommons.PasswordHasher;
import com.freightdesk.fdfolio.useraccess.model.SystemUserModel;

/**
 * Data access object for the UserAccess section.
 */
public class UserAccessDAO extends BaseDao
{
	protected final Logger logger = Logger.getLogger("UserAccessDAO");
	
	protected UserPreferenceDAO userPreferenceDAO;

    /** Creates an instance. */
    public UserAccessDAO()
    {
        super();
        userPreferenceDAO = new UserPreferenceDAO();
    }
    
	public int cascadeStatusSystemUser(long orgId, String status) {
		String isActive = "N";
		
		if(status.equalsIgnoreCase("ACTIVE"))
			isActive = "Y";
		
		// use ctrl+f7 to format in sqldeveloper
		String query="UPDATE systemuser SET isactive=? WHERE orgid IN (SELECT orgid FROM orghierarchy WHERE orghierarchytypecode = 'CON' START WITH orgid=? CONNECT BY PRIOR orgid = parentorgid)";
		
		HashMap<Integer, Object> params = new HashMap<Integer, Object>();
		params.put(1,isActive);
		params.put(2,orgId);
		
		return executeUpdate(query,params);
	}

    public SystemUserModel create(SystemUserModel systemUserModel, Credentials credentials)
        throws CreateException, DuplicateKeyException
    {
        try
        {
            logger.debug("create(SystemUserModel): " + systemUserModel.getSystemUserId() + ", " +
                    systemUserModel.getOrgId() + ", " +systemUserModel.getTimeZoneId());
            createSystemUser(systemUserModel);
            //createUserSystemRole(systemUserModel.getUserSystemRoleList());
        }
        catch (Exception e)
        {
            logger.error ("Exception in create(SystemUserModel)", e);
            throw new EJBException(e);
        }
        return systemUserModel;
    }


    private void deleteSystemUser(SystemUserModel systemUserModel)
        throws SQLException
    {
        logger.debug("deleteSystemUser() ... begins ");
        String delQuery = "DELETE FROM SYSTEMUSER WHERE SYSTEMUSERID = ?";
        deleteRecord (delQuery,systemUserModel.getSystemUserId());
    }

    private void createSystemUser(SystemUserModel systemUserModel)
        throws SQLException
    {
        logger.debug("createSystemUser: " + systemUserModel.getSystemUserId() + ", " + systemUserModel.getOrgId() + ", " +systemUserModel.getTimeZoneId() + ", " +systemUserModel.getUserId() + ", " +systemUserModel.getPassword() + ", " +systemUserModel.getIsActive() + ", " +systemUserModel.getUomCode());
        String insQuery = "INSERT INTO SYSTEMUSER(SYSTEMUSERID, ORGID, TIMEZONEID,  USERID,  PASSWORDEXPIRATIONDATE , ISPASSWORDAUTOEXPIRE, AUTOEXPIREDAYS, DOMAINNAME, UOMCODE, CURRENCYCODE,  DATEFORMAT,ISACTIVE, PASSPHRASEHASH,CREATEUSERID, SYSTEMROLECODE) VALUES ( ?, ?,  ?,  ?,  ?,  ?,  ?,  ?,  ?,  ?, ?, ?, ?, ?, ?)";
        Connection connection = null;
        PreparedStatement pStmt = null;
        try
        {
            String passwordHash = (new PasswordHasher()).hashPassword(systemUserModel.getPassword());
            connection = getConnection();
            pStmt = connection.prepareStatement(insQuery);

            pStmt.setLong(1, systemUserModel.getSystemUserId());
            if(systemUserModel.getOrgId()!= 0L)
                pStmt.setLong(2, systemUserModel.getOrgId());
            else
            	 pStmt.setNull(2, Types.NUMERIC);
            //logger.debug("TimeZoneId::"+systemUserModel.getTimeZoneId());
            pStmt.setString(3, (systemUserModel.getTimeZoneId()==null ||"".equals(systemUserModel.getTimeZoneId()))?LcpConstants.PreferenceDefaultValues.TIMEZONEID:systemUserModel.getTimeZoneId());
            pStmt.setString(4, systemUserModel.getUserId());
            pStmt.setTimestamp(5, systemUserModel.getPasswordExpirationDate());
            pStmt.setLong(6, systemUserModel.getIsPasswordAutoExpire());
            pStmt.setLong(7, systemUserModel.getAutoExpireDays());
            pStmt.setString(8, systemUserModel.getDomainName());
            
            if(systemUserModel.getUomCode() == null || systemUserModel.getUomCode().equalsIgnoreCase(""))
            	systemUserModel.setUomCode(LcpConstants.PreferenceDefaultValues.UOMCODE);
            
            pStmt.setString(9, systemUserModel.getUomCode());
            pStmt.setString(10, (systemUserModel.getCurrencyCode()==null|| "".equals(systemUserModel.getCurrencyCode()))?LcpConstants.PreferenceDefaultValues.CURRENCYCODE:systemUserModel.getCurrencyCode());
            pStmt.setString(11, (systemUserModel.getCurrencyCode()==null || "".equals(systemUserModel.getDateFormat()))?LcpConstants.PreferenceDefaultValues.DATEFORMAT:systemUserModel.getDateFormat());
            pStmt.setString(12, systemUserModel.getIsActive());
            pStmt.setString(13, passwordHash);
            pStmt.setString(14, systemUserModel.getCreateUserId());
            pStmt.setString(15, systemUserModel.getSystemRoleCode());
            pStmt.executeUpdate();
            logger.debug("createSystemUser -- created " + systemUserModel.getSystemUserId() + ", " + systemUserModel.getOrgId() + ", " +systemUserModel.getUomCode() + ", " +systemUserModel.getUserId() + ", " +passwordHash + ", " +systemUserModel.getIsActive());
        }
        catch (SQLException sqEx)
        {
            logger.error("createSystemUser()" , sqEx);
            throw sqEx;
        }
        finally
        {
            ConnectionUtil.closeResources(connection, pStmt, null);
        }
    }
    
    /*
     * FAS specific query
     * Queries the asyncprocessinglog table to find the number of logins in the past day
     */
    public int getNumLoginsIn24() {
    	logger.debug("Getting count of logins within past 24 hours");
    	int numLogins = 0;
    	String query = "select count(asyncprocessinglogid) from asyncprocessinglog where description='LOGIN' and status ='COMPLETED' and createtimestamp > sysdate-1";
    	
    	Connection connection = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        
        try {
        	connection = getConnection();
        	pStmt = connection.prepareStatement(query);
        	rs = pStmt.executeQuery();
        	
        	if(rs.next())
        	  numLogins = rs.getInt(1);
        	
        	rs.close();
        	pStmt.close();
        	connection.close();
        } catch (Exception ex) {
        	//logger.error("Failed to get number of past logins from asyncprocessinglog.  Returning zero");
        	//ex.printStackTrace();
			logger.error("Exception - Failed to get number of past logins from asyncprocessinglog.  Returning zero: " + ex.getMessage());
        } finally {
        	ConnectionUtil.closeResources(connection,pStmt,rs);
        }
        
    	return numLogins;
    }

    public SystemUserModel loadSystemUser(String userId, long orgId)
        throws SQLException
    {
        logger.debug("loadSystemUser(): begin");
        String systemUserQuery = "SELECT SYSTEMUSERID, TIMEZONEID, PASSWORDEXPIRATIONDATE, ISPASSWORDAUTOEXPIRE, AUTOEXPIREDAYS, DOMAINNAME, UOMCODE, CURRENCYCODE, DATEFORMAT,ISACTIVE, PASSPHRASEHASH P, SYSTEMROLECODE FROM SYSTEMUSER WHERE ORGID = ? AND USERID = ? ";
        Connection connection = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        SystemUserModel systemUserModel = new SystemUserModel();
        try
        {
            connection = getConnection();
            pStmt = connection.prepareStatement(systemUserQuery);
            pStmt.setLong(1, orgId);
            pStmt.setString(2, userId);
            for(rs = pStmt.executeQuery(); rs.next();)
            {
                long systemUserId = rs.getLong(1);
                String timeZoneId = rs.getString(2);
                java.sql.Timestamp passwordExpirationDate = rs.getTimestamp(3);
                long isPasswordAutoExpire = rs.getLong(4);
                long autoExpireDays = rs.getLong(5);
                String domainName = rs.getString(6);
                String uomCode = rs.getString(7);
                String currencyCode = rs.getString(8);
                String dateFormat = rs.getString(9);
                String active = rs.getString(10);
                String passphraseHash = rs.getString(11);
                String roleCode = rs.getString("SYSTEMROLECODE");
                //ArrayList systemRoleList = (ArrayList)retrieveRoleList(userId, orgId, connection);
                systemUserModel = new SystemUserModel(systemUserId,orgId, timeZoneId, userId, "", passwordExpirationDate, isPasswordAutoExpire, autoExpireDays, domainName, uomCode, currencyCode,  dateFormat, active);
                systemUserModel.setPassphraseHash(passphraseHash);
                systemUserModel.setSystemRoleCode(roleCode);
                logger.debug("SystemUserId: " + systemUserId);
            }
        }
        catch (SQLException sqEx)
        {
            logger.error ("loadSystemUser(userId: " + userId + ")", sqEx);
            throw sqEx;
        }
        finally
        {
            ConnectionUtil.closeResources(connection, pStmt, rs);
        }
        return systemUserModel;
    }

    public void delete(SystemUserModel systemUserModel)
        throws SQLException
    {
        logger.debug("delete() ... begins ");
        try
        {
            //deleteSystemRoleList(systemUserModel.getUserSystemRoleList());
            deleteSystemUser(systemUserModel);
        }
        catch (Exception sqEx)
        {
            logger.error ("delete(SystemUserModel systemUserModel)", sqEx);
            throw new EJBException(sqEx);
        }
    }

    public void update(SystemUserModel systemUserModel, Credentials credentials)
        throws SQLException
    {
        logger.debug("update() ... begins ");
        try
        {
            AuthenticationUtils.updateSystemUser(systemUserModel, credentials);
            //updateSystemRoleList(systemUserModel.getUserSystemRoleList());
        }
        catch (Exception sqEx)
        {
            logger.error ("update(SystemUserModel systemUserModel)", sqEx);
            throw new EJBException(sqEx);
        }
    }


   public boolean checkUserExists( SystemUserModel systemUserModel) throws SQLException
   {
        logger.debug("checkUserExists() ... begins ");
        logger.debug("checkUserExists: " + systemUserModel.getUserId()  );
        String validateQuery = "SELECT SYSTEMUSERID FROM SYSTEMUSER WHERE USERID = ? AND DOMAINNAME = ?";
        Connection connection = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try
        {
            connection    = getConnection();
            pStmt = connection.prepareStatement(validateQuery);
            pStmt.setString(1, systemUserModel.getUserId());
            pStmt.setString(2, systemUserModel.getDomainName());
            rs = pStmt.executeQuery();
            while(rs.next())
            {
             return true;
            }
        }
        catch(SQLException sqEx)
        {
              logger.error("checkUserExists(SystemUserModel systemUserModel)" , sqEx);
              throw sqEx;
        }
        catch(Exception ex)
        {
              logger.error("checkUserExists(SystemUserModel systemUserModel)" , ex);
              throw new RuntimeException(ex);
        }
        finally
        {
              ConnectionUtil.closeResources(connection, pStmt,rs);
        }
        return false;
   }

   /**
    * Retrieves the preferences for the user.
    *
    * @param systemUserId
    * @return SystemUserModel
    * @throws SQLException
    */
   public SystemUserModel getUserPreferenceDetails(long systemUserId)
            throws SQLException
        {
            String systemUserQuery = "SELECT SYSTEMUSERID, TIMEZONEID, UOMCODE, CURRENCYCODE, DATEFORMAT FROM SYSTEMUSER WHERE SYSTEMUSERID=? ";
            Connection connection = null;
            PreparedStatement pStmt = null;
            ResultSet rs = null;
            SystemUserModel systemUserModel = null;
            try
            {
                logger.debug("getUserPreferenceDetails::begin");
                connection = getConnection();
                pStmt = connection.prepareStatement(systemUserQuery);
                pStmt.setLong(1, systemUserId);
                rs = pStmt.executeQuery();
                while (rs.next())
                {
                    systemUserModel = new SystemUserModel();
                    systemUserModel.setSystemUserId(rs.getLong("SYSTEMUSERID"));
                    systemUserModel.setTimeZoneId(rs.getString("TIMEZONEID"));
                    systemUserModel.setUomCode(rs.getString("UOMCODE"));
                    systemUserModel.setCurrencyCode(rs.getString("CURRENCYCODE"));
                    systemUserModel.setDateFormat(rs.getString("DATEFORMAT"));

                    //List userPreferenceList = userPreferenceDAO.retrieveAllPreferencesByUserId(systemUserId) ;
                    //systemUserModel.setUserPreferenceList(userPreferenceList);
                }
            }
            catch(SQLException sqEx)
            {
                logger.error("getUserPreferenceDetails" , sqEx);
                throw sqEx;
            }
            catch(Exception ex)
            {
                logger.error("getUserPreferenceDetails" , ex);
                throw new RuntimeException();
            }
            finally
            {
                ConnectionUtil.closeResources(connection, pStmt, rs);
            }
            return systemUserModel;
        }


    /**
     * Updates the preferences for the user.
     *
     * @param SystemUserModel
     * @throws SQLException
     */
    public void updateUserPreferences(SystemUserModel systemUserModel)
        throws SQLException
    {
        String query = "UPDATE SYSTEMUSER SET UOMCODE =? WHERE SYSTEMUSERID=?";
        Connection connection = null;
        PreparedStatement pStmt = null;
         try
        {
            logger.debug("updateUserPreferences:begin");
            connection = getConnection();
            pStmt = connection.prepareStatement(query);
            pStmt.setString(1, systemUserModel.getUomCode());
            //logger.debug("UOM code is " + systemUserModel.getUomCode());
            pStmt.setLong(2, systemUserModel.getSystemUserId());
            //logger.debug("SysetmUserID is " + systemUserModel.getSystemUserId());
            pStmt.executeUpdate();
            /*
            userPreferenceDAO.deleteAllByUserId(systemUserModel.getSystemUserId());
            List userPreferenceList = systemUserModel.getUserPreferenceList();
            if(userPreferenceList != null && userPreferenceList.size() > 0)
            {
                 for (int i=0; i<userPreferenceList.size();i++ )
                 {
                     UserPreferenceModel userPreferenceModel = (UserPreferenceModel)userPreferenceList.get(i);
                     userPreferenceModel.setSystemUserId(systemUserModel.getSystemUserId());
                     userPreferenceDAO.create(userPreferenceModel);
                 }
            }
            */
        }
        catch(SQLException sqEx)
        {
            logger.error("updateUserPreferences" , sqEx);
            throw sqEx;
        }
        catch(Exception ex)
        {
            logger.error("updateUserPreferences" , ex);
            throw new RuntimeException(ex);
        }
        finally
        {
            ConnectionUtil.closeResources(connection, pStmt, null);
        }
    }

    /**
     * Updates the LastLoginTimestamp for the specified user.
     *
     * @param systemUserId
     * @throws SQLException
     */
    public void updateLastLoginTimestamp (long systemUserId)
        throws SQLException
    {
        logger.debug("updateLastLoginTimestamp(): begin, systemUserId: " + systemUserId);

        String query = "UPDATE SYSTEMUSER SET LASTLOGINTIMESTAMP = ? WHERE SYSTEMUSERID=?";
        Connection connection = null;
        PreparedStatement pStmt = null;
        try
        {
            connection = getConnection();
            pStmt = connection.prepareStatement(query);
            pStmt.setTimestamp(1, new Timestamp(System.currentTimeMillis()));
            pStmt.setLong(2, systemUserId);
            pStmt.executeUpdate();
            logger.debug ("Finished updateLastLoginTimestamp()");
        }
        catch (SQLException sqEx)
        {
            logger.error("Exception in updateLastLoginTimestamp()" , sqEx);
            throw sqEx;
        }
        finally
        {
            ConnectionUtil.closeResources(connection, pStmt, null);
        }
    }
}

