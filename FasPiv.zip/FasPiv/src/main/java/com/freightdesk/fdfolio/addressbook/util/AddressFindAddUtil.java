
package com.freightdesk.fdfolio.addressbook.util;

import java.util.Collections;
import java.util.List;

import org.apache.log4j.Logger;

import com.freightdesk.fdcommons.LcpApplicationException;

public class AddressFindAddUtil {
	private static Logger logger = Logger.getLogger(AddressFindAddUtil.class);

	/**
	 * pick best match based on the rules configured
	 * 
	 * This method assume the input addresses are sorted based on
	 * lastUpdateTimestamp. So if the rule is configured for lastUpdateTimestamp
	 * it wont try to sort again
	 * 
	 * If the rule is configured for addressId, it will sort the list first and then it 
	 * pick the best match based on 'MIN' or 'MAX' value
	 * 
	 * @param addrIds - list of address Ids
	 * 
	 * @return - best match
	 * 
	 * @throws LcpApplicationException - if the rule is not configured correctly
	 */
	 
	
	public static long pickBestMatch(List addrIds) throws LcpApplicationException {
		logger.info("pickBestMatch begin");
		String filterAttr = "addressId";
		String filterCriteria = "MIN";
		if(AddressFindAddProperties.getProperty("filterAttr") != null) {
			filterAttr = AddressFindAddProperties.getProperty("filterAttr");
			if(AddressFindAddProperties.getProperty("filterCriteria") != null) {
				filterCriteria = AddressFindAddProperties.getProperty("filterCriteria");
			}
		}
		if("lastUpdateTimestamp".equals(filterAttr)) {
			if("MIN".equalsIgnoreCase(filterCriteria)) {
				return ((Long)addrIds.get(0)).longValue();				
			}
			return ((Long)addrIds.get((addrIds.size()-1))).longValue();
		}
		else if("addressId".equals(filterAttr)) {
			Collections.sort(addrIds);
			if("MIN".equalsIgnoreCase(filterCriteria)) {
				return ((Long)addrIds.get(0)).longValue();				
			}
			return ((Long)addrIds.get((addrIds.size()-1))).longValue();
		}		
		throw new LcpApplicationException("Can not identify filterAttr property val !!");
	}
	

	/**
	 * If input string length is more than the thresholdLength, it returns the 
	 * substring of the input string in theresholdLength
	 * 	 * 
	 * @param string - input string 
	 * @param thresholdLength - threshold Length : in which the substring is to be made
	 * 
	 * @return substring
	 */
	private static String getInThresholdLength(String string, int thresholdLength) {		
		if(string.length()>thresholdLength) {
			return string.substring(0,thresholdLength);
		}		
		return string;
	}

	/**
	 * A convinience method to trim the trailing and leading 
	 * white spaces if the trim rule configured so.
	 * 
	 * @param string 
	 * @param trim - boolean val says whether to trim or not
	 * @return String
	 */
	private static String trim(String string, boolean trim) {
		if(trim) {
			return string.trim();
		}
		return string;
	}

	/**
	 * A convinience method to change the  case if the caseSensitive
	 * rule is configured so
	 * 
	 * @param string
	 * @param caseSensitive - change the case if the val is false
	 * @return String - steing in upper case
	 */
	private static String changeCase(String string, boolean caseSensitive) {
		if(caseSensitive) {
			return string;
		}		
		return string.toUpperCase();
	}    
  
}
