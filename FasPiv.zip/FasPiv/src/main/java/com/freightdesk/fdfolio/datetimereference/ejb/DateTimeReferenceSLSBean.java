/** 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolio/datetimereference/ejb/DateTimeReferenceSLSBean.java,v 1.5.4.1 2010/08/22 23:08:40 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: 
 */



package com.freightdesk.fdfolio.datetimereference.ejb;

import java.sql.SQLException;

import javax.ejb.CreateException;
import javax.ejb.EJBException;

import com.freightdesk.fdcommons.BaseSLSBean;
import com.freightdesk.fdfolio.dao.DateTimestampReferenceDAO;
import com.freightdesk.fdfolio.invoice.model.DateTimestampReferenceModel;


/**
 * Business logic facade for Datetimestamp reference.
 * Provides wrappers around DAO methods.
 *
 * @author 
 */
public class DateTimeReferenceSLSBean extends BaseSLSBean
{ 
    /** An instance of DateTimestampReferenceDAO */
    protected DateTimestampReferenceDAO dateTimestampReferenceDAO = null;

    /**
     * Calls the DAO create method to create DateTimeStampRefrence.
     *
     * @param dateTimestampReferenceModel The dateTimestampReference model to be saved
     * @return The DateTimestampReferenceModel that was saved
     * @throws SQLException If there is a problem accessing the DB
     */
    public DateTimestampReferenceModel createDateTimeReference(DateTimestampReferenceModel dateTimestampReferenceModel)
        throws SQLException
    {
        try
        {
            dateTimestampReferenceDAO.create(dateTimestampReferenceModel);
        }
        catch(Exception e)
        {
            logger.error("createDateTimeReference(): Exception while  trying to create DateTimestampReference\t"+e);
            throw new EJBException(e);
        }
        return dateTimestampReferenceModel;
    }

    /**
     * Calls the DAO update method.
     *
     * @param dateTimestampReferenceModel The dateTimestampReference model to be updated
     * @return The DateTimestampReferenceModel that was updated
     * @throws SQLException If there is a problem accessing the DB
     */
    public DateTimestampReferenceModel updateDateTimeReference(DateTimestampReferenceModel dateTimestampReferenceModel)
        throws SQLException
    { 
        try
        {
            logger.info("DateTimeReferenceSLSBean::updateDateTimeReference:begin");
            dateTimestampReferenceDAO.update(dateTimestampReferenceModel);
        }
        catch(Exception e)
        {
            logger.error("updateDateTimeReference(): Exception while  trying to update  DateTimestampReference\t"+ e);
            throw new EJBException(e);
        } 
        return dateTimestampReferenceModel;
    }

    /** Initializes the instance of DateTimestampReferenceDAO.  */
    public void ejbCreate() throws CreateException
    {
        dateTimestampReferenceDAO = new DateTimestampReferenceDAO();
    }
}
