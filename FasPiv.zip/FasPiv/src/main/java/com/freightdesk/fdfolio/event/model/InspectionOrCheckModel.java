/** 
 * 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolio/event/model/InspectionOrCheckModel.java,v 1.3.4.2 2010/08/22 23:08:38 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: InspectionOrCheckModel.java,v $
 *  Revision 1.3.4.2  2010/08/22 23:08:38  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.3.4.1  2008/06/03 12:39:04  mechevarria
 *  gov_solutions merge updates
 *
 *  Revision 1.5  2007/04/12 09:41:09  dkumar
 *  Minor Changes.
 *
 *  Revision 1.4  2007/04/12 09:32:54  nsehra
 *  added method applyPartitionTimeStamp for Data Partitioning
 *
 *  Revision 1.3  2006/03/28 21:23:02  aarora
 *  Repackaging of fdcommons
 *
 *  Revision 1.2  2005/08/01 09:41:08  pjain
 *  refactored UserModel to BaseModel
 *
 *  Revision 1.1  2004/09/15 13:12:45  ranand
 *  2.6 Baseline
 *
 * 
 */

package com.freightdesk.fdfolio.event.model;

import java.sql.Timestamp;

import com.freightdesk.fdcommons.BaseModel;


public class InspectionOrCheckModel extends BaseModel 
{

	private long inspectionorCheckId; 
	private String inspectionorCheckTypeCode; 
	private Timestamp inspectionorCheckDate; 
	private String inspectionorCheckValue; 
	private String inspectionorCheckStatus; 
	private String inspectionorCheckQualifier; 
	private String inspectionreMarks; 
    private long eventId; 


	public long getPrimaryKey()
	   {
		   return this.inspectionorCheckId;
	   }


    
    /**
     * @return
     */
    public Timestamp getInspectionorCheckDate()
    {
        return inspectionorCheckDate;
    }

    /**
     * @return
     */
    public long getInspectionorCheckId()
    {
        return inspectionorCheckId;
    }

    /**
     * @return
     */
    public String getInspectionorCheckQualifier()
    {
        return inspectionorCheckQualifier;
    }

    /**
     * @return
     */
    public String getInspectionorCheckStatus()
    {
        return inspectionorCheckStatus;
    }

    /**
     * @return
     */
    public String getInspectionorCheckTypeCode()
    {
        return inspectionorCheckTypeCode;
    }

    /**
     * @return
     */
    public String getInspectionorCheckValue()
    {
        return inspectionorCheckValue;
    }

    /**
     * @return
     */
    public String getInspectionreMarks()
    {
        return inspectionreMarks;
    }

    /**
     * @param inspectionorCheckDate
     */
    public void setInspectionorCheckDate(Timestamp inspectionorCheckDate)
    {
        this.inspectionorCheckDate = inspectionorCheckDate;
    }

    /**
     * @param inspectionorCheckId
     */
    public void setInspectionorCheckId(long inspectionorCheckId)
    {
        this.inspectionorCheckId = inspectionorCheckId;
    }

    /**
     * @param inspectionorCheckQualifier
     */
    public void setInspectionorCheckQualifier(String inspectionorCheckQualifier)
    {
        this.inspectionorCheckQualifier = inspectionorCheckQualifier;
    }

    /**
     * @param inspectionorCheckStatus
     */
    public void setInspectionorCheckStatus(String inspectionorCheckStatus)
    {
        this.inspectionorCheckStatus = inspectionorCheckStatus;
    }

    /**
     * @param inspectionorCheckTypeCode
     */
    public void setInspectionorCheckTypeCode(String inspectionorCheckTypeCode)
    {
        this.inspectionorCheckTypeCode = inspectionorCheckTypeCode;
    }

    /**
     * @param inspectionorCheckValue
     */
    public void setInspectionorCheckValue(String inspectionorCheckValue)
    {
        this.inspectionorCheckValue = inspectionorCheckValue;
    }

    /**
     * @param inspectionreMarks
     */
    public void setInspectionreMarks(String inspectionreMarks)
    {
        this.inspectionreMarks = inspectionreMarks;
    }

	/**
	 * Returns the eventId.
	 * @return long
	 */
	public long getEventId() {
		return eventId;
	}

	/**
	 * Sets the eventId.
	 * @param eventId The eventId to set
	 */
	public void setEventId(long eventId) {
		this.eventId = eventId;
	}

}
