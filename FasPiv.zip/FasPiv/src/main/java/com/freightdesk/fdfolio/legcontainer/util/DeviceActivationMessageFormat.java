/** 
 * 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolio/legcontainer/util/DeviceActivationMessageFormat.java,v 1.2.4.1 2010/08/22 23:08:33 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: DeviceActivationMessageFormat.java,v $
 *  Revision 1.2.4.1  2010/08/22 23:08:33  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.2  2006/04/12 23:44:32  aarora
 *  Removed extra code
 *
 *  Revision 1.1  2004/09/15 13:19:23  ranand
 *  2.6 Baseline
 *
 * 
 */

package com.freightdesk.fdfolio.legcontainer.util;

import java.io.Serializable;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;

/**
 * @author Ajeet Sachan [ajeet.sachan]
 *
 */
public class DeviceActivationMessageFormat implements Serializable
{

    private String origin;
    private String destination;
    private String cont;
    private String contChk;
    private String contTag;
    private String ESeal;
	private String ContGPS;
    private String HazMat="N";
    private String Inspector;
	private Timestamp dateTime;
	private String dateTimeInUTCFormat;
    /**
     * Default Constructor 
     */
    public DeviceActivationMessageFormat()
    {
        super();
    }

    /**
     * @param string
     */
    public void setCont(String string)
    {
        cont = string;
    }

    /**
     * @param string
     */
    public void setContChk(String string)
    {
        contChk = string;
    }

    /**
     * @param string
     */
    public void setContTag(String string)
    {
        contTag = string;
    }

    /**
     * @param string
     */
    public void setDestination(String string)
    {
        destination = string;
    }

    /**
     * @param string
     */
    public void setESeal(String string)
    {
        ESeal = string;
    }

    /**
     * @param string
     */
    public void setHazMat(String string)
    {
        HazMat = string;
    }

    /**
     * @param string
     */
    public void setInspector(String string)
    {
        Inspector = string;
    }

    /**
     * @param string
     */
    public void setOrigin(String string)
    {
        origin = string;
    }

    /**
     * @param string
     */
    public void setDateTime(Timestamp dateTime)
    {
        this.dateTime = dateTime;
		dateTimeInUTCFormat = getDateTimeInUTCFormat(dateTime);
    }

	/**
     * retun string
     */
    public String getDateTimeInUTCFormat(Timestamp dateTime)
    {
		SimpleDateFormat smpdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss S");		
        return smpdf.format(dateTime);
    }

    /**
     * @return String
     */
    public String getAttachmentName()
    {
		StringBuffer strAttachementName = new StringBuffer("Events_Cotecna");
		String utcDate =  getDateTimeInUTCFormat(dateTime);

		String[] splittedDateTime = utcDate.split(" ");

		String dateSection = splittedDateTime[0].replaceAll("-","");
		String timeSection = splittedDateTime[1].replaceAll(":","");
		String milliSection= splittedDateTime[2];
		while(milliSection.length()!=3)
		{
			milliSection += "0"; 		
		}

		strAttachementName.append("_"+dateSection);
		strAttachementName.append("_"+timeSection);
		strAttachementName.append("_"+milliSection);
		strAttachementName.append(".txt");

        return strAttachementName.toString();
    }



    public String getMessage()
    {
		StringBuffer message = new StringBuffer("\nLogon (User=Cotecna, App=Events, Ver=1.0);\n");
		message.append("\nEvent ( Loc=" + (getFormattedValue(origin))+",");
        message.append("\n\tDir=" + "Out,");
        message.append("\n\tDest=" + (getFormattedValue(destination))+",");
		message.append("\n\tTime=\""+(getFormattedValue(dateTimeInUTCFormat))+"\""+",");
        message.append("\n\tCont=" + (getFormattedValue(cont))+",");
        message.append("\n\tContChk=" + (getFormattedValue(contChk))+",");
        /* Condition based message*/
        if(contTag != null && !"".equals(contTag.trim())){
			message.append("\n\tContTag=\"" + contTag +"\",");
        }
		if(ESeal != null && !"".equals(ESeal.trim())){
        
            message.append("\n\tESeal=\""   + ESeal   +"\",");
		}
		if(ContGPS != null && !"".equals(ContGPS.trim())){
		    message.append("\n\tContGPS=\"" + ContGPS +"\",");
     	}
        message.append("\n\tHazmat=" + (getFormattedValue(HazMat))+",");
        message.append("\n\tInspector=" + (getFormattedValue(Inspector)));
        message.append(");");
        
		return message.toString();                                
    }

	public String getFormattedValue(String value) {
		
		if(value == null || value.trim().equals("")) {
			return "\"\"";
		}
		return value;

	}

    /**
     * @param string
     */
    public void setContGPS(String string)
    {
        ContGPS = string;
    }

}
