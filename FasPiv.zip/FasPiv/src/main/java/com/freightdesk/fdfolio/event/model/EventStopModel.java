/** 
 * 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolio/event/model/EventStopModel.java,v 1.4.4.2 2010/08/22 23:08:38 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: EventStopModel.java,v $
 *  Revision 1.4.4.2  2010/08/22 23:08:38  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.4.4.1  2008/06/03 12:39:04  mechevarria
 *  gov_solutions merge updates
 *
 *  Revision 1.5  2007/04/12 09:32:54  nsehra
 *  added method applyPartitionTimeStamp for Data Partitioning
 *
 *  Revision 1.4  2006/03/28 21:23:02  aarora
 *  Repackaging of fdcommons
 *
 *  Revision 1.3  2006/03/02 22:17:13  aarora
 *  Removed redundant code
 *
 *  Revision 1.2  2005/08/01 09:41:08  pjain
 *  refactored UserModel to BaseModel
 *
 *  Revision 1.1  2004/09/15 13:12:45  ranand
 *  2.6 Baseline
 *
 * 
 */

package com.freightdesk.fdfolio.event.model;

import java.io.Serializable;
import java.sql.Timestamp;

import com.freightdesk.fdcommons.BaseModel;

public class EventStopModel extends BaseModel
    implements Serializable
{
    private long eventId;
    private long eventStopId;
	private long eventStopAddressId;
    private String stopFunctionCode;
    private String eventTimeQualifer;
    //private long sequence;
    private String  locationName;
    private String locationQualifer;
    private String locationIdentifer;
    //private XMLLocation location;
    private Timestamp eventDate;
    private String eventTimeZone;
	private Timestamp ETD;
	private Timestamp ATD;
	private Timestamp ETA;
	private Timestamp ATA;

    /** Creates new EventStopModel */
    public EventStopModel() 
    {
        eventId = 0L;
        eventStopId = 0L;
		eventStopAddressId = 0L;
        stopFunctionCode = null;
        eventTimeQualifer = null;
        //sequence = 0L;
        locationName = null;
        locationQualifer = null;
        locationIdentifer = null;
        eventDate = null;
        eventTimeZone = null;
    }

	public EventStopModel(long eventId, long eventStopId,long eventStopAddressId,Timestamp ETD,
							Timestamp ATD,Timestamp ETA,Timestamp ATA,String createUserId,Timestamp createTimestamp,
							String lastUpdateUserId,Timestamp lastUpdateTimestamp, String domainName)
	{
		this.eventId = eventId;
		this.eventStopId = eventStopId;
		this.eventStopAddressId = eventStopAddressId;
		this.ETD = ETD;
		this.ATD = ATD;
		this.ETA = ETA;
		this.ATA = ATA;

		super.createUserId = createUserId;
        super.createTimestamp = createTimestamp;
        super.lastUpdateUserId = lastUpdateUserId;
        super.lastUpdateTimestamp = lastUpdateTimestamp;
        super.domainName = domainName;
	}
	public EventStopModel(long eventId,long eventStopId,String stopFunctionCode,
					String eventTimeQualifer,String  locationName,
					String locationQualifer,String locationIdentifer,Timestamp eventDate,
					String eventTimeZone,String createUserId,Timestamp createTimestamp,
					String lastUpdateUserId, Timestamp lastUpdateTimestamp, String domainName)
	{
		this.eventId = eventId;
        this.eventStopId = eventStopId;
        this.stopFunctionCode = stopFunctionCode;
        this.eventTimeQualifer = eventTimeQualifer;
        //this.sequence = sequence;
        this.locationName = locationName;
        this.locationQualifer = locationQualifer;
        this.locationIdentifer = locationIdentifer;
        this.eventDate = eventDate;
        //this.eventTime = eventTime;
        this.eventTimeZone = eventTimeZone;
		super.createUserId = createUserId;
        super.createTimestamp = createTimestamp;
        super.lastUpdateUserId = lastUpdateUserId;
        super.lastUpdateTimestamp = lastUpdateTimestamp;
        super.domainName = domainName;
		
	}

	/**
	 * Implements the abstract method defined by BaseModel.
	 * @return primaryKey  the unique id key for this model object.
	 */
	public long getPrimaryKey(){
		return this.eventStopId;
	}  
	
    public void setEventId(long eventId)
    {
        this.eventId = eventId;
    }
    public long getEventId()
    {
        return eventId;
    }
    public void setEventStopId(long eventStopId)
    {
        this.eventStopId = eventStopId;
    }
    public long getEventStopId()
    {
        return eventStopId;
    }
	public void setEventStopAddressId(long eventStopAddressId)
	{
		this.eventStopAddressId = eventStopAddressId;
	}
	public long getEventStopAddressId()
	{
		return eventStopAddressId;
	}
    
    public void setStopFunctionCode(String stopFunctionCode)
    {
        this.stopFunctionCode = stopFunctionCode;
    }
    public String getStopFunctionCode()
    {
        return stopFunctionCode;
    }
    public void setEventTimeQualifer(String eventTimeQualifer)
    {
        this.eventTimeQualifer = eventTimeQualifer;
    }
    public String getEventTimeQualifer()
    {
        return eventTimeQualifer;
    }
//    public void setSequence(long sequence)
//    {
//        this.sequence = sequence;
//    }
//    public long getSequence()
//    {
//        return sequence;
//    }
     public void setLocationName(String locationName)
    {
        this.locationName = locationName;
    }
    public String  getLocationName()
    {
        return locationName;
    }
    public void setLocationQualifer(String locationQualifer)
    {
        this.locationQualifer = locationQualifer;
    }
    public String getLocationQualifer()
    {
        return locationQualifer;
    }
    public void setLocationIdentifer(String locationIdentifer)
    {
        this.locationIdentifer = locationIdentifer;
    }
    public String getLocationIdentifer()
    {
        return locationIdentifer;
    }
    
    public void setEventDate(Timestamp eventDate)
    {
        this.eventDate = eventDate;
    }
    public Timestamp getEventDateTime()
    {
        return eventDate;
    }
//    public void setEventTime(Timestamp eventTime)
//    {
//        this.eventTime = eventTime;
//    }
//    public Timestamp getEventTime()
//    {
//        return eventTime;
//    }
    public void setEventTimeZone(String eventTimeZone)
    {
        this.eventTimeZone = eventTimeZone;
    }
    public String getEventTimeZone()
    {
        return eventTimeZone;
    }
	public void setETD(Timestamp ETD)
	{
		this.ETD = ETD;
	}
	public Timestamp getETD()
	{
		return ETD;
	}
	public void setATD(Timestamp ATD)
	{
		this.ATD = ATD;
	}
	public Timestamp getATD()
	{
		return ATD;
	}
	public void setETA(Timestamp ETA)
	{
		this.ETA = ETA;
	}
	public Timestamp getETA()
	{
		return ETA;
	}
	public void setATA(Timestamp ATA)
	{
		this.ATA = ATA;
	}
	public Timestamp getATA()
	{
		return ATA;
	}

}
