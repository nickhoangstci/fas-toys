
package com.freightdesk.fdfolio.addressbook.util;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import org.apache.log4j.Logger;


/**
 * Encapsulates all the properties of AddressFindAdd rules  that can be set
 * differently for each deployment, but are not saved to the DB 
 * currently.
 * 
 * Implemented as a singleton, and only allows a visiting
 * BootstrapServlet to initialize it.
 *
 * @author  Biju Joseph
 * @version 1.0
 */
public class AddressFindAddProperties {
    
    protected static Logger logger = Logger.getLogger("com.freightdesk.fdfolio.addressbook.util.AddressFindAddProperties");
	/**
     * The (only) instance of this Singleton
     */
    protected static AddressFindAddProperties _instance;

    /**
     * The interal data structure used to store the properties
     */
    private Properties inner;

    /**
     * Gets the file URI for the given property.  The returned
     * URI has the correct file separator and uses the system
     * property LCP_RUNTIME_HOME the file root, and uses the property specified
     * in lcp.properties as the relative URL off of the LCP_RUNTIME_HOME.
     *
     * @param key The key for the property in lcp.properties
     * @return The URI for the file property corresponding to the key
     */
    public static String getURI (String key)
    {
        String uri = System.getProperty ("RUNTIME_HOME") + File.separator + getProperty (key);
        logger.info("uri (" + key + "): " + uri);
        return uri;
    }

    /**
     * Gets the property using the given key
     * @param key The key for the mapping
     * @return The property corresponding to the key
     */
    public static String getProperty (String key) {
        return getInstance().inner.getProperty(key);
    }
    
    /**
     * Requires a secret to be initialized.
     */
    public synchronized static void load (InputStream inputStream, int secret) 
        throws IOException 
    {
        if (secret != 187568912) {
            logger.debug("Where are you coming from?");
            throw new RuntimeException ("Unauthorized access to AddressFindAddProperties.load()");
        }
        logger.debug("AddressFindAddProperties.load(): begin");
        getInstance().inner.load(inputStream);
    }    

    /**
     * Only constructor is declared private.
     */
    private AddressFindAddProperties() {
        inner = new Properties();
    }
    
    /**
     * The getInstance() method for this Singleton.
     * Creates an instance if necessary.
     */
    private static AddressFindAddProperties getInstance() {
        if (_instance == null) {
            _instance = new AddressFindAddProperties();
        }
        return _instance;
    }
}
