#!/bin/bash

##clear

## Compile the code
#ant -f `cygpath --path --windows ~/src/lcp/Build/build.xml` dataGenerator
#compileStatus=$?

##cd /lcp/Build
##ant dataGenerator
##compileStatus=$?
##cd -

## Only run this if the compile is successful
#if [ "0" = $compileStatus ]; 
#then
	## Execute the test app
	JAVA_CP=/cygdrive/d/Data/FreightDesk/src/lcp/Build/release/jar
	JBOSS_HOME=/cygdrive/d/Data/FreightDesk/src/jboss-lcp
	JBOSS_LIB=${JBOSS_HOME}/server/default/lib

	JAVA_CP=${JAVA_CP}:${JBOSS_LIB}/log4j.jar
	JAVA_CP=`cygpath --path --windows "${JAVA_CP}"`

	java -classpath ${JAVA_CP} com.freightdesk.fdfolio.document.datagenerator.camir.CamirTestDriver $*
#else
#	echo "Please fix the compiler errors before running CamitTextDriver"
#fi
