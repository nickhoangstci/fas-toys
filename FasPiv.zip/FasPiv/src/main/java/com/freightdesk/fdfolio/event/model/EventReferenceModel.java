/** 
 * 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolio/event/model/EventReferenceModel.java,v 1.3.4.2 2010/08/22 23:08:38 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: EventReferenceModel.java,v $
 *  Revision 1.3.4.2  2010/08/22 23:08:38  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.3.4.1  2008/06/03 12:39:04  mechevarria
 *  gov_solutions merge updates
 *
 *  Revision 1.4  2007/04/12 09:32:54  nsehra
 *  added method applyPartitionTimeStamp for Data Partitioning
 *
 *  Revision 1.3  2006/03/28 21:23:02  aarora
 *  Repackaging of fdcommons
 *
 *  Revision 1.2  2005/08/01 09:41:08  pjain
 *  refactored UserModel to BaseModel
 *
 *  Revision 1.1  2004/09/15 13:12:45  ranand
 *  2.6 Baseline
 *
 * 
 */



package com.freightdesk.fdfolio.event.model;

import java.io.Serializable;
import java.sql.Timestamp;

import com.freightdesk.fdcommons.BaseModel;

public class EventReferenceModel extends BaseModel
    implements Serializable
{
	private long eventId;
	private long eventReferenceId;
	private String eventReferenceTypeCode;
	private String eventReferenceValue;
	
	public EventReferenceModel()
	{
	}
	public EventReferenceModel(long eventReferenceId,long eventId,String eventReferenceTypeCode,
								String eventReferenceValue,String status, String createUserId,Timestamp createTimestamp,
							String lastUpdateUserId,Timestamp lastUpdateTimestamp, String domainName)
	{
		this.eventReferenceId = eventReferenceId;
		this.eventId = eventId;
		this.eventReferenceTypeCode = eventReferenceTypeCode;
		this.eventReferenceValue = eventReferenceValue;
		super.status = status;
		super.createUserId = createUserId;
        super.createTimestamp = createTimestamp;
        super.lastUpdateUserId = lastUpdateUserId;
        super.lastUpdateTimestamp = lastUpdateTimestamp;
        super.domainName = domainName;
	}

	/**
	 * Implements the abstract method defined by BaseModel.
	 * @return primaryKey  the unique id key for this model object.
	 */
	public long getPrimaryKey(){
		return this.eventReferenceId;
	}  
	
	public long getEventId()
	{
		return eventId;
	}
	public void setEventId(long eventId)
	{
		this.eventId = eventId;
	}
	
	public long getEventReferenceId()
	{
		return eventReferenceId;
	}
	public void setEventReferenceId(long eventReferenceId)
	{
		this.eventReferenceId = eventReferenceId;
	}
	
	public String getEventReferenceTypeCode()
	{
		return eventReferenceTypeCode;
	}
	public void setEventReferenceTypeCode(String eventReferenceTypeCode)
	{
		this.eventReferenceTypeCode = eventReferenceTypeCode;
	}
	public String getEventReferenceValue()
	{
		return eventReferenceValue;
	}
	public void setEventReferenceValue(String eventReferenceValue)
	{
		this.eventReferenceValue = eventReferenceValue;
	}

}

