/** 
 * 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolio/invoice/model/FinancialAccountingModel.java,v 1.3.4.1 2010/08/22 23:08:32 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: FinancialAccountingModel.java,v $
 *  Revision 1.3.4.1  2010/08/22 23:08:32  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.3  2006/03/28 21:23:01  aarora
 *  Repackaging of fdcommons
 *
 *  Revision 1.2  2005/08/01 09:41:08  pjain
 *  refactored UserModel to BaseModel
 *
 *  Revision 1.1  2004/09/23 13:41:20  ranand
 *  package changed from settlement to invoice
 *
 *  Revision 1.1  2004/09/15 13:20:00  ranand
 *  2.6 Baseline
 *
 * 
 */

package com.freightdesk.fdfolio.invoice.model;


import com.freightdesk.fdcommons.BaseModel;

/**
 * @author rajender.anand
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class FinancialAccountingModel extends BaseModel{


   private long financialAccountingId;
   private String shipmentChargeTypeCode;
   private String financialInformation;
   private String breakDownStructure;
   private long breakDownStructureOrgId;
   private double percentage;
   private double rate;
   private double amount;
   private String currencycode;
   private long invoiceChargeId;
   private long orgId;
   
   
    /**
     * Implements the abstract method defined by BaseModel.
     * @return primaryKey  the unique id key for this model object.
     */
    public long getPrimaryKey(){
        return this.financialAccountingId;
    }  

    /**
     * Returns the amount.
     * @return double
     */
    public double getAmount() {
    	return amount;
    }
    
    /**
     * Returns the breakDownStructure.
     * @return String
     */
    public String getBreakDownStructure() {
    	return breakDownStructure;
    }
    
    /**
     * Returns the breakDownStructureOrgId.
     * @return long
     */
    public long getBreakDownStructureOrgId() {
    	return breakDownStructureOrgId;
    }
    
    /**
     * Returns the currencycode.
     * @return String
     */
    public String getCurrencycode() {
    	return currencycode;
    }
    
    /**
     * Returns the financialAccountingId.
     * @return long
     */
    public long getFinancialAccountingId() {
    	return financialAccountingId;
    }
    
    /**
     * Returns the financialInformation.
     * @return String
     */
    public String getFinancialInformation() {
    	return financialInformation;
    }
    
    /**
     * Returns the percentage.
     * @return double
     */
    public double getPercentage() {
    	return percentage;
    }
    
    /**
     * Returns the rate.
     * @return double
     */
    public double getRate() {
    	return rate;
    }
    
    /**
     * Returns the shipmentChargeTypeCode.
     * @return String
     */
    public String getShipmentChargeTypeCode() {
    	return shipmentChargeTypeCode;
    }
    
    /**
     * Sets the amount.
     * @param amount The amount to set
     */
    public void setAmount(double amount) {
    	this.amount = amount;
    }
    
    /**
     * Sets the breakDownStructure.
     * @param breakDownStructure The breakDownStructure to set
     */
    public void setBreakDownStructure(String breakDownStructure) {
    	this.breakDownStructure = breakDownStructure;
    }
    
    /**
     * Sets the breakDownStructureOrgId.
     * @param breakDownStructureOrgId The breakDownStructureOrgId to set
     */
    public void setBreakDownStructureOrgId(long breakDownStructureOrgId) {
    	this.breakDownStructureOrgId = breakDownStructureOrgId;
    }
    
    /**
     * Sets the currencycode.
     * @param currencycode The currencycode to set
     */
    public void setCurrencycode(String currencycode) {
    	this.currencycode = currencycode;
    }
    
    /**
     * Sets the financialAccountingId.
     * @param financialAccountingId The financialAccountingId to set
     */
    public void setFinancialAccountingId(long financialAccountingId) {
    	this.financialAccountingId = financialAccountingId;
    }
    
    /**
     * Sets the financialInformation.
     * @param financialInformation The financialInformation to set
     */
    public void setFinancialInformation(String financialInformation) {
    	this.financialInformation = financialInformation;
    }
    
    /**
     * Sets the percentage.
     * @param percentage The percentage to set
     */
    public void setPercentage(double percentage) {
    	this.percentage = percentage;
    }
    
    /**
     * Sets the rate.
     * @param rate The rate to set
     */
    public void setRate(double rate) {
    	this.rate = rate;
    }
    
    /**
     * Sets the shipmentChargeTypeCode.
     * @param shipmentChargeTypeCode The shipmentChargeTypeCode to set
     */
    public void setShipmentChargeTypeCode(String shipmentChargeTypeCode) {
    	this.shipmentChargeTypeCode = shipmentChargeTypeCode;
    }

/**
 * Returns the invoiceChargeId.
 * @return long
 */
public long getInvoiceChargeId() {
	return invoiceChargeId;
}

/**
 * Sets the invoiceChargeId.
 * @param invoiceChargeId The invoiceChargeId to set
 */
public void setInvoiceChargeId(long invoiceChargeId) {
	this.invoiceChargeId = invoiceChargeId;
}

/**
 * Returns the orgId.
 * @return long
 */
public long getOrgId() {
	return orgId;
}

/**
 * Sets the orgId.
 * @param orgId The orgId to set
 */
public void setOrgId(long orgId) {
	this.orgId = orgId;
}

}
