/** 
 * 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolio/datetimereference/ejb/DateTimeReferenceSLSHome.java,v 1.1.10.1 2010/08/22 23:08:40 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: 
 * 
 */



package com.freightdesk.fdfolio.datetimereference.ejb;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.ejb.EJBHome;


public interface DateTimeReferenceSLSHome
    extends EJBHome
{

    public abstract DateTimeReferenceSLS create()
        throws CreateException, RemoteException;
}

