/** 
 * 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolio/dao/DateTimestampReferenceDAO.java,v 1.2.6.4 2010/10/01 19:57:27 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: DateTimestampReferenceDAO.java,v $
 *  Revision 1.2.6.4  2010/10/01 19:57:27  mechevarria
 *  jboss6 upgrade
 *
 *  Revision 1.2.6.3  2010/08/22 23:08:30  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.2.6.2  2009/09/23 18:02:20  mechevarria
 *  import clean via eclipse
 *
 *  Revision 1.2.6.1  2008/06/09 16:29:12  mechevarria
 *  gs code merge
 *
 *  Revision 1.4  2007/04/26 05:01:57  atripathi
 *  unwanted import statements removed.
 *
 *  Revision 1.3  2007/04/26 04:58:48  atripathi
 *  moved to hibernate 3
 *
 *  Revision 1.2  2006/03/28 21:22:58  aarora
 *  Repackaging of fdcommons
 *
 *  Revision 1.1  2005/08/20 12:30:16  pjain
 *  centralized DAO package
 *
 *  Revision 1.5  2005/06/15 11:24:26  ranand
 *  delete method calls to Base DAO delete method
 *
 *  Revision 1.4  2005/06/14 11:57:19  ranand
 *  delete method calls to Base DAO delete method
 *
 *  Revision 1.3  2004/11/30 09:32:44  asingh
 *  Minimize log statements, changed level from INFO to DEBUG where necessary.
 *
 *  Revision 1.2  2004/11/10 10:25:30  biju
 *  method name changes + removal of NamingException
 *
 *  Revision 1.1  2004/09/23 13:41:20  ranand
 *  package changed from settlement to invoice
 *
 *  Revision 1.1  2004/09/15 13:20:00  ranand
 *  2.6 Baseline
 *
 * 
 */

package com.freightdesk.fdfolio.dao;

import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;

import com.freightdesk.fdcommons.BaseDao;
import com.freightdesk.fdfolio.common.SessionFactoryUtil;
import com.freightdesk.fdfolio.invoice.model.DateTimestampReferenceModel;

/** 
 * This class defines the methods for performing insert, update, delete, read 
 * operations on DATETIMESTAMPREFERENCE table.
 *
 *  @author Sangeeta Taneja
 */
public class DateTimestampReferenceDAO extends BaseDao {  
	
   /**
    * create
    * @param dateTimestampReferenceModel
    * @throws SQLException
    */
    public void create(DateTimestampReferenceModel dateTimestampReferenceModel) 
        throws SQLException
    {
    	logger.debug("crete begins");
    	Session session = null;
    	try{
    		session = SessionFactoryUtil.getSession();
    		Transaction tx = session.beginTransaction();
    		session.save(dateTimestampReferenceModel);
    		session.flush();
    		tx.commit();
    	}catch(Exception e){
    		logger.error("exception in creating date time reference model"+e);
    		throw new SQLException(e.toString());
    	}finally{
    		SessionFactoryUtil.closeSession(session);
    	}       
    }
    /**
     * update
     * @param dateTimestampReferenceModel
     * @throws SQLException
     */
    public void update(DateTimestampReferenceModel dateTimestampReferenceModel) throws SQLException
    {
    	logger.debug("update begins");
    	Session session = null;
    	try{
    		session = SessionFactoryUtil.getSession();
    		Transaction tx = session.beginTransaction();
    		session.update(dateTimestampReferenceModel);
    		session.flush();
    		tx.commit();
    	}catch(Exception e){
    		logger.error("exception in updating date time reference model"+e);
    		throw new SQLException(e.toString());
    	}finally{
    		SessionFactoryUtil.closeSession(session);
    	}        
    }
    /**
     * retrieve
     * @param dateTimestampReferenceId
     * @return
     * @throws SQLException
     */
    public DateTimestampReferenceModel retrieve(long dateTimestampReferenceId) 
        throws SQLException
    {
    	logger.debug("retrieve begins for dateTimestampReferenceId"+dateTimestampReferenceId);
    	Session session = null;
        try
        {
        	session = SessionFactoryUtil.getSession();
        	DateTimestampReferenceModel dateTimestampReferenceModel = (DateTimestampReferenceModel)session.load(DateTimestampReferenceModel.class, new Long(dateTimestampReferenceId));        	
            return dateTimestampReferenceModel;
        }
        catch (Exception e)
        {
        	logger.error("exception in retrieve date time reference model"+e);
    		throw new SQLException(e.toString());
        }
        finally
        {
            SessionFactoryUtil.closeSession(session);
        }       
    }
    /**
     * retrieveAllByInvoiceId
     * @param invoiceId
     * @return
     * @throws SQLException
     */

    public List retrieveAllByInvoiceId(long invoiceId) 
        throws SQLException
    {
    	logger.debug("retrieveAllByInvoiceId(invoiceId[" + invoiceId + "]) begin.");
    	Session session = null;
        try
        {
        	session = SessionFactoryUtil.getSession();
            Criteria criteria = session.createCriteria(DateTimestampReferenceModel.class);
            List dateTimeReferenceList = criteria.add(Restrictions.eq("invoiceId",new Long(invoiceId))).list();
            return dateTimeReferenceList;
        }
        catch (Exception e)
        {
            logger.error(" Exception in DateTimestampReferenceDAO::retrieveAllByInvoiceId(invoiceId): ", e);
            throw new SQLException(e.toString());
        }
        finally
        {
        	SessionFactoryUtil.closeSession(session);
        }        
    }
    /**
     * retrieveAllByInvoiceDetailId
     * @param invoiceDetailId
     * @return
     * @throws SQLException
     */
    
    public List retrieveAllByInvoiceDetailId(long invoiceDetailId) 
        throws SQLException
    {
    	logger.debug("retrieveAllByInvoiceDetailId(invoiceDetailId["+ invoiceDetailId +"]) begin.");
    	Session session = null;
        try
        {
        	session = SessionFactoryUtil.getSession();
            Criteria criteria = session.createCriteria(DateTimestampReferenceModel.class);
            List dateTimeReferenceList = criteria.add(Restrictions.eq("invoiceDetailId",new Long(invoiceDetailId))).list();
            return dateTimeReferenceList;
        }
        catch (Exception e)
        {
            logger.error(" Exception in DateTimestampReferenceDAO::retrieveAllByInvoiceDetailId(invoiceDetailId): ", e);
            throw new SQLException(e.toString());
        }
        finally
        {
        	SessionFactoryUtil.closeSession(session);
        }       
    }
    

    public List retrieveAllByInvoiceLineId(long invoiceLineId) 
        throws SQLException
    {
    	logger.debug("retrieveAllByInvoiceLineId(invoicelineId["+ invoiceLineId +"]) begin.");
    	Session session = null;
        try
        {
        	session = SessionFactoryUtil.getSession();
            Criteria criteria = session.createCriteria(DateTimestampReferenceModel.class);
            List dateTimeReferenceList = criteria.add(Restrictions.eq("invoiceLineItemId",new Long(invoiceLineId))).list();
            return dateTimeReferenceList;
        }
        catch (Exception e)
        {
            logger.error(" Exception in DateTimestampReferenceDAO::retrieveAllByInvoiceLineId(invoicelineId): ", e);
            throw new SQLException(e.toString());
        }
        finally
        {
        	SessionFactoryUtil.closeSession(session);
        }        
    }

    /** Retrieves all DateTimestamp Reference Models by event ID. */
    public List retrieveAllByEventId (long eventId) 
        throws SQLException
    {
    	logger.debug("retrieveAllByEventId(eventId["+ eventId +"]) begin."); 
    	Session session = null;
        try
        {
        	session = SessionFactoryUtil.getSession();
            Criteria criteria = session.createCriteria(DateTimestampReferenceModel.class);
            List dateTimeReferenceList = criteria.add(Restrictions.eq("eventId",new Long(eventId))).list();
            return dateTimeReferenceList; 
        }
        catch (Exception e)
        {
            logger.error(" Exception in DateTimestampReferenceDAO::retrieveAllByEventId(eventId): ", e);
            throw new SQLException(e.toString());
        }
        finally
        {
        	SessionFactoryUtil.closeSession(session);
        }
        
    }
    /**
     * retrieveAllByLegId
     * @param legId
     * @return
     * @throws SQLException
     */

    public List retrieveAllByLegId(long legId) 
        throws SQLException
    {
    	logger.debug("retrieveAllByLegId(legId["+ legId +"]) begin.");
    	Session session = null;
        try
        {
        	session = SessionFactoryUtil.getSession();
            Criteria criteria = session.createCriteria(DateTimestampReferenceModel.class);
            List dateTimeReferenceList = criteria.add(Restrictions.eq("legId",new Long(legId))).list();
            return dateTimeReferenceList; 
        }
        catch (Exception e)
        {
            logger.error(" Exception in DateTimestampReferenceDAO::retrieveAllByLegId(legId): ", e);
            throw new SQLException(e.toString());
        }
        finally
        {
        	SessionFactoryUtil.closeSession(session);
        }
        
    }
    /**
     * retrieveAllByLegContainerId
     * @param legContainerId
     * @return
     * @throws SQLException
     */

    public List retrieveAllByLegContainerId (long legContainerId) 
        throws SQLException
    {
    	logger.debug("retrieveAllByLegContainerId(legContainerId["+ legContainerId +"]) begin."); 
    	Session session = null;
        try
        {
        	session = SessionFactoryUtil.getSession();
            Criteria criteria = session.createCriteria(DateTimestampReferenceModel.class);
            List dateTimeReferenceList = criteria.add(Restrictions.eq("legContainerId",new Long(legContainerId))).list();
            return dateTimeReferenceList; 
        }
        catch (Exception e)
        {
            logger.error(" Exception in DateTimestampReferenceDAO::retrieveAllByLegContainerId(legContainerId): ", e);
            throw new SQLException(e.toString());
        }
        finally
        {
        	SessionFactoryUtil.closeSession(session);
        }
       
    }
    /**
     * retrieveAllByOrderId
     * @param orderId
     * @return
     * @throws SQLException
     */

    public List retrieveAllByOrderId(long orderId) throws SQLException
    {
    	logger.debug("retrieveAllByOrderId(orderId[" + orderId + "]) begin.");
    	Session session = null;
        try
        {
        	session = SessionFactoryUtil.getSession();
            Criteria criteria = session.createCriteria(DateTimestampReferenceModel.class);
            List dateTimeReferenceList = criteria.add(Restrictions.eq("orderId",new Long(orderId))).list();
            return dateTimeReferenceList; 
        }
        catch (Exception e)
        {
            logger.error(" Exception in DateTimestampReferenceDAO::retrieveAllByOrderId(orderId): ", e);
            throw new SQLException(e.toString());
        }
        finally
        {
        	SessionFactoryUtil.closeSession(session);
        }
        
    }
    /**
     * retrieveAllByPackageId
     * @param packageId
     * @return
     * @throws SQLException
     */

    public List retrieveAllByPackageId(long packageId) 
        throws SQLException
    {
    	logger.debug("retrieveAllByPackageId(packageId["+ packageId +"]) begin.");
    	Session session = null;
        try
        {
        	session = SessionFactoryUtil.getSession();
            Criteria criteria = session.createCriteria(DateTimestampReferenceModel.class);
            List dateTimeReferenceList = criteria.add(Restrictions.eq("packageId",new Long(packageId))).list();
            return dateTimeReferenceList; 
        }
        catch (Exception e)
        {
            logger.error(" Exception in DateTimestampReferenceDAO::retrieveAllByPackageId(): ", e);
            throw new SQLException(e.toString());
        }
        finally
        {
        	SessionFactoryUtil.closeSession(session);
        }       
    }
    /**
     * retrieveAllByOrderReleaseId
     * @param orderReleaseId
     * @return
     * @throws SQLException
     */

    public List retrieveAllByOrderReleaseId(long orderReleaseId) 
        throws SQLException
    {
    	logger.debug("retrieve(orderReleaseId["+ orderReleaseId +"]) begin.");
    	Session session = null;
        try
        {
        	session = SessionFactoryUtil.getSession();
            Criteria criteria = session.createCriteria(DateTimestampReferenceModel.class);
            List dateTimeReferenceList = criteria.add(Restrictions.eq("orderReleaseId",new Long(orderReleaseId))).list();
            return dateTimeReferenceList; 
        }
        catch (Exception e)
        {
            logger.error(" Exception in DateTimestampReferenceDAO::retrieveAllByOrderReleaseId(): ", e);
            throw new SQLException(e.toString());
        }
        finally
        {
        	SessionFactoryUtil.closeSession(session);
        }        
    }
    /**
     * delete
     * @param dateTimestampReferenceModel
     * @throws SQLException
     */

    public void delete(DateTimestampReferenceModel dateTimestampReferenceModel) 
        throws SQLException
    {
    	logger.debug("delete begins");
    	Session session = null;
    	try{
    		session = SessionFactoryUtil.getSession();
    		Transaction tx = session.beginTransaction();
    		session.delete(dateTimestampReferenceModel);    		
    		tx.commit();
    	}catch(Exception e){
    		logger.error("exception in deleting date time reference model"+e);
    		throw new SQLException(e.toString());
    	}finally{
    		SessionFactoryUtil.closeSession(session);
    	}       
    }
    /**
     * delete
     * @param dateTimestampReferenceId
     * @throws SQLException
     */

    public void delete(long dateTimestampReferenceId) 
        throws SQLException
    {
    	logger.debug("delete begins");
    	Session session = null;
    	try{
    		session = SessionFactoryUtil.getSession();
    		Transaction tx = session.beginTransaction();
    		DateTimestampReferenceModel dateTimestampReferenceModel = (DateTimestampReferenceModel)session.load(DateTimestampReferenceModel.class,new Long(dateTimestampReferenceId));
    		session.delete(dateTimestampReferenceModel);    		
    		tx.commit();
    	}catch(Exception e){
    		logger.error("exception in deleting date time reference model"+e);
    		throw new SQLException(e.toString());
    	}finally{
    		SessionFactoryUtil.closeSession(session);
    	} 
       
    }
    /**
     * deleteAllByInvoiceId
     * @param invoiceId
     * @throws SQLException
     */

    public void deleteAllByInvoiceId(long invoiceId) throws SQLException
    {
    	logger.debug("deleteAllByInvoiceId begins");
    	Session session = null;
    	try{
    		session = SessionFactoryUtil.getSession();
    		Transaction tx = session.beginTransaction();
    		Criteria criteria = session.createCriteria(DateTimestampReferenceModel.class);
    		List dateTimestampReferenceList = criteria.add(Restrictions.eq("invoiceId",new Long(invoiceId))).list();
    		Iterator iterator = dateTimestampReferenceList.iterator();
    		while(iterator.hasNext()){
    			DateTimestampReferenceModel dateTimestampReferenceModel = (DateTimestampReferenceModel)iterator.next();
    			session.delete(dateTimestampReferenceModel);
    		}
    		tx.commit();
    	}catch(Exception e){
    		logger.error("exception in deleteAllByInvoiceId date time reference model"+e);
    		throw new SQLException(e.toString());
    	}finally{
    		SessionFactoryUtil.closeSession(session);
    	} 
    }
    /**
     * deleteAllByInvoiceLineId
     * @param invoiceLineId
     * @throws SQLException
     */

    public void deleteAllByInvoiceLineId(long invoiceLineId) throws SQLException
    {
    	logger.debug("deleteAllByInvoiceLineId begins");
    	Session session = null;
    	try{
    		session = SessionFactoryUtil.getSession();
    		Transaction tx = session.beginTransaction();
    		Criteria criteria = session.createCriteria(DateTimestampReferenceModel.class);
    		List dateTimestampReferenceList = criteria.add(Restrictions.eq("invoiceLineItemId",new Long(invoiceLineId))).list();
    		Iterator iterator = dateTimestampReferenceList.iterator();
    		while(iterator.hasNext()){
    			DateTimestampReferenceModel dateTimestampReferenceModel = (DateTimestampReferenceModel)iterator.next();
    			session.delete(dateTimestampReferenceModel);
    		}
    		tx.commit();
    	}catch(Exception e){
    		logger.error("exception in deleteAllByInvoiceLineId date time reference model"+e);
    		throw new SQLException(e.toString());
    	}finally{
    		SessionFactoryUtil.closeSession(session);
    	} 
    }
    /**
     * deleteAllByInvoiceDetailId
     * @param invoiceDetailId
     * @throws SQLException
     */
    
    public void deleteAllByInvoiceDetailId(long invoiceDetailId) throws SQLException
       {
    	logger.debug("deleteAllByInvoiceDetailId begins");
    	Session session = null;
    	try{
    		session = SessionFactoryUtil.getSession();
    		Transaction tx = session.beginTransaction();
    		Criteria criteria = session.createCriteria(DateTimestampReferenceModel.class);
    		List dateTimestampReferenceList = criteria.add(Restrictions.eq("invoiceDetailId",new Long(invoiceDetailId))).list();
    		Iterator iterator = dateTimestampReferenceList.iterator();
    		while(iterator.hasNext()){
    			DateTimestampReferenceModel dateTimestampReferenceModel = (DateTimestampReferenceModel)iterator.next();
    			session.delete(dateTimestampReferenceModel);
    		}
    		tx.commit();
    	}catch(Exception e){
    		logger.error("exception in deleteAllByInvoiceDetailId date time reference model"+e);
    		throw new SQLException(e.toString());
    	}finally{
    		SessionFactoryUtil.closeSession(session);
    	}  
       }
    /**
     * deleteAllByEventId
     * @param eventId
     * @throws SQLException
     */
    
    public void deleteAllByEventId(long eventId) throws SQLException
    {
    	logger.debug("deleteAllByEventId begins");
    	Session session = null;
    	try{
    		session = SessionFactoryUtil.getSession();
    		Transaction tx = session.beginTransaction();
    		Criteria criteria = session.createCriteria(DateTimestampReferenceModel.class);
    		List dateTimestampReferenceList = criteria.add(Restrictions.eq("eventId",new Long(eventId))).list();
    		Iterator iterator = dateTimestampReferenceList.iterator();
    		while(iterator.hasNext()){
    			DateTimestampReferenceModel dateTimestampReferenceModel = (DateTimestampReferenceModel)iterator.next();
    			session.delete(dateTimestampReferenceModel);
    		}
    		tx.commit();
    	}catch(Exception e){
    		logger.error("exception in deleteAllByEventId date time reference model"+e);
    		throw new SQLException(e.toString());
    	}finally{
    		SessionFactoryUtil.closeSession(session);
    	}   
    }
    /**
     * deleteAllByLegContainerId
     * @param legContainerId
     * @throws SQLException
     */
    public void deleteAllByLegContainerId(long legContainerId) throws SQLException
    {
    	logger.debug("deleteAllByLegContainerId begins");
    	Session session = null;
    	try{
    		session = SessionFactoryUtil.getSession();
    		Transaction tx = session.beginTransaction();
    		Criteria criteria = session.createCriteria(DateTimestampReferenceModel.class);
    		List dateTimestampReferenceList = criteria.add(Restrictions.eq("legContainerId",new Long(legContainerId))).list();
    		Iterator iterator = dateTimestampReferenceList.iterator();
    		while(iterator.hasNext()){
    			DateTimestampReferenceModel dateTimestampReferenceModel = (DateTimestampReferenceModel)iterator.next();
    			session.delete(dateTimestampReferenceModel);
    		}
    		tx.commit();
    	}catch(Exception e){
    		logger.error("exception in deleteAllByLegContainerId date time reference model"+e);
    		throw new SQLException(e.toString());
    	}finally{
    		SessionFactoryUtil.closeSession(session);
    	}   
    }
    /**
     * deleteAllByOrderId
     * @param orderId
     * @throws SQLException
     */
    public void deleteAllByOrderId(long orderId) throws SQLException
    {
    	logger.debug("deleteAllByOrderId begins");
    	Session session = null;
    	try{
    		session = SessionFactoryUtil.getSession();
    		Transaction tx = session.beginTransaction();
    		Criteria criteria = session.createCriteria(DateTimestampReferenceModel.class);
    		List dateTimestampReferenceList = criteria.add(Restrictions.eq("orderId",new Long(orderId))).list();
    		Iterator iterator = dateTimestampReferenceList.iterator();
    		while(iterator.hasNext()){
    			DateTimestampReferenceModel dateTimestampReferenceModel = (DateTimestampReferenceModel)iterator.next();
    			session.delete(dateTimestampReferenceModel);
    		}
    		tx.commit();
    	}catch(Exception e){
    		logger.error("exception in deleteAllByOrderId date time reference model"+e);
    		throw new SQLException(e.toString());
    	}finally{
    		SessionFactoryUtil.closeSession(session);
    	}    
    }
    /**
     * deleteAllByOrderReleaseId
     * @param orderReleaseId
     * @throws SQLException
     */
    public void deleteAllByOrderReleaseId(long orderReleaseId) throws SQLException
    {
    	logger.debug("deleteAllByOrderReleaseId begins");
    	Session session = null;
    	try{
    		session = SessionFactoryUtil.getSession();
    		Transaction tx = session.beginTransaction();
    		Criteria criteria = session.createCriteria(DateTimestampReferenceModel.class);
    		List dateTimestampReferenceList = criteria.add(Restrictions.eq("orderReleaseId",new Long(orderReleaseId))).list();
    		Iterator iterator = dateTimestampReferenceList.iterator();
    		while(iterator.hasNext()){
    			DateTimestampReferenceModel dateTimestampReferenceModel = (DateTimestampReferenceModel)iterator.next();
    			session.delete(dateTimestampReferenceModel);
    		}
    		tx.commit();
    	}catch(Exception e){
    		logger.error("exception in deleteAllByOrderReleaseId date time reference model"+e);
    		throw new SQLException(e.toString());
    	}finally{
    		SessionFactoryUtil.closeSession(session);
    	}    
    }
    /**
     * deleteAllByPackageId
     * @param packageId
     * @throws SQLException
     */
    public void deleteAllByPackageId(long packageId) throws SQLException
    {
    	logger.debug("deleteAllByPackageId begins");
    	Session session = null;
    	try{
    		session = SessionFactoryUtil.getSession();
    		Transaction tx = session.beginTransaction();
    		Criteria criteria = session.createCriteria(DateTimestampReferenceModel.class);
    		List dateTimestampReferenceList = criteria.add(Restrictions.eq("packageId",new Long(packageId))).list();
    		Iterator iterator = dateTimestampReferenceList.iterator();
    		while(iterator.hasNext()){
    			DateTimestampReferenceModel dateTimestampReferenceModel = (DateTimestampReferenceModel)iterator.next();
    			session.delete(dateTimestampReferenceModel);
    		}
    		tx.commit();
    	}catch(Exception e){
    		logger.error("exception in deleteAllByPackageId date time reference model"+e);
    		throw new SQLException(e.toString());
    	}finally{
    		SessionFactoryUtil.closeSession(session);
    	}    
    }
    /**
     * deleteAllByShipmentId
     * @param shipmentId
     * @throws SQLException
     */

    public void deleteAllByShipmentId(long shipmentId) 
        throws SQLException
    {
    	logger.debug("deleteAllByShipmentId begins");
    	Session session = null;
    	try{
    		session = SessionFactoryUtil.getSession();
    		Transaction tx = session.beginTransaction();
    		Criteria criteria = session.createCriteria(DateTimestampReferenceModel.class);
    		List dateTimestampReferenceList = criteria.add(Restrictions.eq("shipmentId",new Long(shipmentId))).list();
    		Iterator iterator = dateTimestampReferenceList.iterator();
    		while(iterator.hasNext()){
    			DateTimestampReferenceModel dateTimestampReferenceModel = (DateTimestampReferenceModel)iterator.next();
    			session.delete(dateTimestampReferenceModel);
    		}
    		tx.commit();
    	}catch(Exception e){
    		logger.error("exception in deleteAllByShipmentId date time reference model"+e);
    		throw new SQLException(e.toString());
    	}finally{
    		SessionFactoryUtil.closeSession(session);
    	}    
    }
    /**
     * retrieveAllByShipmentId
     * @param shipmentId
     * @return
     * @throws SQLException
     */
    
    public List retrieveAllByShipmentId (long shipmentId) 
        throws SQLException
    {
    	logger.debug("retrieveAllByShipmentId(shipmentId["+ shipmentId +"]) begin.");
    	Session session = null;
    	try{
    		session = SessionFactoryUtil.getSession();    		
    		Criteria criteria = session.createCriteria(DateTimestampReferenceModel.class);
    		List dateTimestampReferenceList = criteria.add(Restrictions.eq("shipmentId",new Long(shipmentId))).list();    	
    		return dateTimestampReferenceList;
    	}catch(Exception e){
    		logger.error("exception in deleteAllByShipmentId date time reference model"+e);
    		throw new SQLException(e.toString());
    	}finally{
    		SessionFactoryUtil.closeSession(session);
    	}    
    }
}
