/** 
 * 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolio/common/RecordNotFoundException.java,v 1.4.4.1 2010/08/22 23:08:26 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: RecordNotFoundException.java,v $
 *  Revision 1.4.4.1  2010/08/22 23:08:26  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.4  2006/03/28 21:23:00  aarora
 *  Repackaging of fdcommons
 *
 *  Revision 1.3  2004/09/15 13:03:45  ranand
 *  2.6 Baseline
 *
 * 
 */


package com.freightdesk.fdfolio.common;

import com.freightdesk.fdcommons.LcpApplicationException;


/**
 * @author Ajeet Sachan [ajeet.sachan]
 *
 */
public class RecordNotFoundException extends LcpApplicationException {

    /**
     *
     */
    public RecordNotFoundException() {
        super();
    }

    /**
     * @param message
     */
    public RecordNotFoundException(String message) {
        super(message);
    }

    /**
     * @param message
     * @param cause
     */
    public RecordNotFoundException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * @param cause
     */
    public RecordNotFoundException(Throwable cause) {
        super(cause);
    }

}
