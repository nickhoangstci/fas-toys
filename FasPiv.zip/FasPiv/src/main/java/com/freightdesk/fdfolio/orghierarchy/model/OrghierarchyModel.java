/**
 * Copyright (c) NTELX All rights reserved.
 *
 * This software is the confidential and proprietary information of NTELX, LLC
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the license
 * agreement you entered into with NTELX, LLC.
 *
 *
 * $Header:
 * /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolio/orghierarchy/model/OrgHierarchyModel.java,v
 * 1.9.4.3 2010/11/17 15:55:35 jhansford Exp $
 *
 * Modification History: $Log: OrgHierarchyModel.java,v $ Revision 1.9.4.3
 * 2010/11/17 15:55:35 jhansford Added Exception Dates for required to submit on
 * locations
 *
 * Revision 1.9.4.2 2010/08/23 20:03:18 mechevarria updates to support
 * requiredSubmit and stp fields
 *
 * Revision 1.9.4.1 2010/08/22 23:08:34 mechevarria update with company name in
 * copyright
 *
 * Revision 1.9 2006/04/10 22:53:02 aarora Changed the type of orgreflist from
 * ArrayList to List
 *
 * Revision 1.8 2006/03/28 21:23:06 aarora Repackaging of fdcommons
 *
 * Revision 1.7 2005/09/28 08:35:54 ranand Code clean up of Address Module
 *
 * Revision 1.6 2005/09/18 01:37:30 amrinder Moved Org References to base class
 *
 * Revision 1.5 2005/09/01 10:25:28 pjain added availableCapacity field
 *
 * Revision 1.4 2005/08/25 13:47:48 nsehra capacity for address
 *
 * Revision 1.3 2005/08/01 09:41:08 pjain refactored UserModel to BaseModel
 *
 * Revision 1.2 2004/12/16 06:43:10 amrinder General rework of organization
 * module
 *
 * Revision 1.1 2004/09/16 07:22:24 ranand moved from organization package
 *
 * Revision 1.1 2004/09/15 13:24:34 ranand 2.6 Baseline
 */
package com.freightdesk.fdfolio.orghierarchy.model;

import java.io.Serializable;
import java.math.BigInteger;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.freightdesk.fdfolio.event.model.EventModel;
import com.freightdesk.fdcommons.BaseModel;
import crt.com.ntelx.nxcommons.NxUtils;
import crt.com.ntelx.nxcommons.model.OrgAssocModel;

/**
 * Models an organization, organizational location or a contact. Ports/Airports
 * and Carriers are also considered organizations with some distinguishing
 * attributes set.
 *
 * @author Mike Echevarria
 */
@Entity
@Table(name = "FD.ORGHIERARCHY")
public class OrghierarchyModel extends BaseModel implements Serializable {
    
    
    /**
     *
     */
    private static final long serialVersionUID = -1106837298377580912L;
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "ORGID")
    @SequenceGenerator(name = "ORGID", sequenceName = "ORGID")
    private long orgId;
    // foreign key reference back to OrgHierarchy
    private BigInteger parentOrgId;
    private String orgRoleCode;
    private String contactSalutationCode;
    private String orgHierarchyTypeCode;
    private String orgName;
    private String contactFirstName;
    private String contactLastName;
    private String contactTitle;
    private String DUNSNumber;
    private String SCACCode;
    private String EINNumber;
    private String stp;
    private String regionCode;
    @Column(name = "REQUIRED")
    private String requiredSubmit = "Y";
    private Timestamp reqExBeginDate;
    private Timestamp reqExEndDate;
    private String portCode;
    private String requiredReporting = "BOTH";
    private String ncspMember;
    private String remarks;
    private String amendmentCode;
    private String email;
    private String phone;
    // ADDRESS
    private String addressTypeCode = "SA";
    private String countryCode = "US";
    private String timeZoneId;
    private String isPrimary;
    private String contactName;
    private String addressLine1;
    private String addressLine2;
    private String city;
    private String stateProvince;
    private String stateProvinceCode;
    private String zipPostCode;
    private String latitude;
    private String longitude;
    private String notes;
    // child objects
    @OneToMany(orphanRemoval = true, mappedBy = "orghierarchy", cascade = CascadeType.ALL)
    private Set<OrgReferenceModel> orgReferenceList;
    @OneToMany(orphanRemoval = true, mappedBy = "orghierarchy", cascade = CascadeType.ALL)
    private Set<EventModel> eventModelList;
    @OneToMany(orphanRemoval = true, mappedBy = "orghierarchy", cascade = CascadeType.ALL)
    private Set<OrgAssocModel> orgAssocList;
    @Transient
    private String parentOrgName;
    @Transient
    private String parentOrgType;
    @Transient
    private List<OrghierarchyModel> locModelList;
    @Transient
    private List<OrghierarchyModel> conModelList;
    // ADDRESS
    @Transient
    private String addressTypeName;
    @Transient
    private String hierarchyTypeCode;
    @Transient
    private String countryName;

    public OrghierarchyModel() {
    }

    public OrghierarchyModel(long orgId, BigInteger parentOrgId, String orgName, String contactFirstName, String contactLastName, String parentOrgName, String orgHierarchyTypeCode, String city, String stateProvinceCode, String countryName) {							 
        this.orgId = orgId;
        this.parentOrgId = parentOrgId;
        this.orgName = orgName;
        this.contactFirstName = contactFirstName;
        this.contactLastName = contactLastName;
						
		this.parentOrgName = parentOrgName;
		this.orgHierarchyTypeCode = orgHierarchyTypeCode;
		this.city = city;
		this.stateProvinceCode = stateProvinceCode;
		this.countryName = countryName;		
    }

    public Set<OrgAssocModel> getOrgAssocList() {
        if (orgAssocList == null) {
            orgAssocList = new HashSet<OrgAssocModel>();
        }
        return orgAssocList;
    }

    public void setOrgAssocList(Set<OrgAssocModel> orgAssocList) {
        this.orgAssocList = orgAssocList;
    }

    public Set<EventModel> getEventModelList() {
        if (eventModelList == null) {
            eventModelList = new HashSet<EventModel>();
        }
        return eventModelList;
    }

    public void setEventModelList(Set<EventModel> eventModelList) {
        this.eventModelList = eventModelList;
    }

    public String getRegionCode() {
        return regionCode;
    }

    public void setRegionCode(String regionCode) {
        this.regionCode = regionCode;
    }

    public String getParentOrgType() {
        return parentOrgType;
    }

    public void setParentOrgType(String parentOrgType) {
        this.parentOrgType = parentOrgType;
    }

    public String getAmendmentCode() {
        return amendmentCode;
    }

    public void setAmendmentCode(String amendmentCode) {
        this.amendmentCode = amendmentCode;
    }

    public List<OrghierarchyModel> getLocModelList() {
        if (locModelList == null) {
            return new ArrayList<OrghierarchyModel>();
        } else {
            return locModelList;
        }
    }

    public void setLocModelList(List<OrghierarchyModel> locModelList) {
        this.locModelList = locModelList;
    }

    public List<OrghierarchyModel> getConModelList() {
        if (conModelList == null) {
            return new ArrayList<OrghierarchyModel>();
        } else {
            return conModelList;
        }
    }

    public void setConModelList(List<OrghierarchyModel> conModelList) {
        this.conModelList = conModelList;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public String getPortCode() {
        return portCode;
    }

    public void setPortCode(String portCode) {
        this.portCode = portCode;
    }

    public Timestamp getReqExBeginDate() {
        return reqExBeginDate;
    }

    public void setReqExBeginDate(Timestamp reqExBeginDate) {
        this.reqExBeginDate = reqExBeginDate;
    }

    public Timestamp getReqExEndDate() {
        return reqExEndDate;
    }

    public void setReqExEndDate(Timestamp reqExEndDate) {
        this.reqExEndDate = reqExEndDate;
    }

    /**
     * Implements the abstract method defined by BaseModel.
     *
     * @return primaryKey the unique id key for this model object.
     */
    public long getPrimaryKey() {
        return this.orgId;
    }

    public String getStp() {
        return stp;
    }

    public void setStp(String stp) {
        this.stp = stp;
    }

    public String getRequiredSubmit() {
        return requiredSubmit;
    }

    public void setRequiredSubmit(String requiredSubmit) {
        this.requiredSubmit = requiredSubmit;
    }

    public String getContactFirstName() {
        if (contactFirstName == null) {
            contactFirstName = "";
        }
        return contactFirstName;
    }

    public String getContactLastName() {
        if (contactLastName == null) {
            contactLastName = "";
        }
        return contactLastName;
    }

    public String getContactSalutationCode() {
        if (contactSalutationCode == null) {
            contactSalutationCode = "";
        }
        return contactSalutationCode;
    }

    public String getContactTitle() {
        if (contactTitle == null) {
            contactTitle = "";
        }
        return contactTitle;
    }

    public String getDUNSNumber() {
        if (DUNSNumber == null) {
            DUNSNumber = "";
        }
        return DUNSNumber;
    }

    public String getEINNumber() {
        if (EINNumber == null) {
            EINNumber = "";
        }
        return EINNumber;
    }

    public String getOrgHierarchyTypeCode() {
        if (orgHierarchyTypeCode == null) {
            orgHierarchyTypeCode = "";
        }
        return orgHierarchyTypeCode;
    }

    public long getOrgId() {
        return orgId;
    }

    public String getOrgName() {
        if (orgName == null) {
            orgName = "";
        }
        return orgName;
    }

    public String getOrgRoleCode() {
        if (orgRoleCode == null) {
            orgRoleCode = "";
        }
        return orgRoleCode;
    }

    public BigInteger getParentOrgId() {
        return parentOrgId;
    }

    public String getSCACCode() {
        if (SCACCode == null) {
            SCACCode = "";
        }
        return SCACCode;
    }

    public void setContactFirstName(String contactFirstName) {
        this.contactFirstName = contactFirstName;
    }

    public void setContactLastName(String contactLastName) {
        this.contactLastName = contactLastName;
    }

    public void setContactSalutationCode(String contactSalutationCode) {
        this.contactSalutationCode = contactSalutationCode;
    }

    public void setContactTitle(String contactTitle) {
        this.contactTitle = contactTitle;
    }

    public void setDUNSNumber(String DUNSNumber) {
        this.DUNSNumber = DUNSNumber;
    }

    public void setEINNumber(String EINNumber) {
        this.EINNumber = EINNumber;
    }

    public void setOrgHierarchyTypeCode(String orgHierarchyTypeCode) {
        this.orgHierarchyTypeCode = orgHierarchyTypeCode;
    }

    public void setOrgId(long orgId) {
        this.orgId = orgId;
    }

    public void setOrgName(String orgName) {
        this.orgName = orgName;
    }

    public void setOrgRoleCode(String orgRoleCode) {
        this.orgRoleCode = orgRoleCode;
    }

    public void setParentOrgId(BigInteger parentOrgId) {
        this.parentOrgId = parentOrgId;
    }

    public void setSCACCode(String SCACCode) {
        this.SCACCode = SCACCode;
    }

    public Set<OrgReferenceModel> getOrgReferenceList() {
        if (orgReferenceList == null) {
            orgReferenceList = new HashSet<OrgReferenceModel>();
        }
        return orgReferenceList;
    }

    public void setOrgReferenceList(Set<OrgReferenceModel> orgReferenceList) {
        this.orgReferenceList = orgReferenceList;
    }

    /**
     * @return Returns the parentOrgName.
     */
    public String getParentOrgName() {
        if (parentOrgName == null) {
            return "";
        } else {
            return parentOrgName;
        }
    }

    /**
     * @param parentOrgName The parentOrgName to set.
     */
    public void setParentOrgName(String parentOrgName) {
        this.parentOrgName = parentOrgName;
    }

    public OrgReferenceModel getOrgReference(long searchId) {

        if (orgReferenceList != null) {
            for (OrgReferenceModel model : orgReferenceList) {
                long id = model.getOrgReferenceId();

                if (id == searchId) {
                    return model;
                }

            }
        }
        logger.debug("No OrgReference found with id = " + searchId);
        return null;
    }

    public EventModel getEvent(long searchId) {
        if (eventModelList != null) {
            for (EventModel model : eventModelList) {
                long id = model.getEventId();

                if (id == searchId) {
                    return model;
                }
            }
        }
        logger.debug("No event found with id = " + searchId);
        return null;
    }

    public OrgAssocModel getAssociation(long searchId) {
        if (orgAssocList != null) {
            for (OrgAssocModel model : orgAssocList) {
                long id = model.getOrgOrgAssocId();

                if (id == searchId) {
                    return model;
                }
            }
        }
        logger.debug("No OrgAssociation found with id = " + searchId);
        return null;
    }

    public String getCert() {
        OrgReferenceModel model = getOrgReference("CERT");
        String cert = model.getOrgReferenceValue();

        if (NxUtils.isEmptyOrBlank(cert)) {
            return "-";
        } else {
            return cert;
        }
    }

    public OrgReferenceModel getOrgReference(String type) {

        if (orgReferenceList != null) {
            for (OrgReferenceModel model : orgReferenceList) {
                String typeCode = model.getOrgReferenceTypeCode();

                if (typeCode.equalsIgnoreCase(type)) {
                    return model;
                }

            }
        }
        logger.debug("No OrgReference found with typeCode = " + type);
        return null;
    }

    /**
     * @return the email
     */
    public String getEmail() {
        if (email == null) {
            email = "";
        }
        return email;
    }

    /**
     * @param email the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * @return the phone
     */
    public String getPhone() {
        if (phone == null) {
            phone = "";
        }
        return phone;
    }

    /**
     * @param phone the phone to set
     */
    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getAddressLine1() {
        if (addressLine1 == null) {
            addressLine1 = "";
        }
        return addressLine1;
    }

    public String getAddressLine2() {
        if (addressLine2 == null) {
            addressLine2 = "";
        }
        return addressLine2;
    }

    public String getCity() {
        if (city == null) {
            city = "";
        }
        return city;
    }

    public String getContactName() {
        if (contactName == null) {
            contactName = "";
        }
        return contactName;
    }

    public String getCountryCode() {
        if (countryCode == null) {
            countryCode = "";
        }
        return countryCode;
    }

    public String getCountryName() {
        if (countryName == null) {
            countryName = "";
        }
        return countryName;
    }

    public Timestamp getCreateTimestamp() {
        return createTimestamp;
    }

    public String getCreateUserId() {
        return createUserId;
    }

    public String getDomainName() {
        return domainName;
    }

    public String getHierarchyTypeCode() {
        if (hierarchyTypeCode == null) {
            hierarchyTypeCode = "";
        }
        return hierarchyTypeCode;
    }

    public String getIsPrimary() {
        return isPrimary;
    }

    public Timestamp getLastUpdateTimestamp() {
        return lastUpdateTimestamp;
    }

    public String getLastUpdateUserId() {
        return lastUpdateUserId;
    }

    public String getLatitude() {
        if (latitude == null) {
            latitude = "";
        }
        return latitude;
    }

    public String getAddressTypeCode() {
        if (addressTypeCode == null) {
            addressTypeCode = "";
        }
        return addressTypeCode;
    }

    public String getAddressTypeName() {
        if (addressTypeName == null) {
            addressTypeName = "";
        }
        return addressTypeName;
    }

    public String getLongitude() {
        if (longitude == null) {
            longitude = "";
        }
        return longitude;
    }

    public String getNotes() {
        if (notes == null) {
            notes = "";
        }
        return notes;
    }

    public String getStateProvince() {
        if (stateProvince == null) {
            stateProvince = "";
        }
        return stateProvince;
    }

    public String getStateProvinceCode() {
        if (stateProvinceCode == null) {
            stateProvinceCode = "";
        }
        return stateProvinceCode;
    }

    public String getTimeZoneId() {
        if (timeZoneId == null) {
            timeZoneId = "";
        }
        return timeZoneId;
    }

    public String getZipPostCode() {
        if (zipPostCode == null) {
            zipPostCode = "";
        }
        return zipPostCode;
    }

    public void setAddressLine1(String addressLine1) {
        this.addressLine1 = addressLine1;
    }

    public void setAddressLine2(String addressLine2) {
        this.addressLine2 = addressLine2;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public void setContactName(String contactName) {
        this.contactName = contactName;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }

    public void setCreateTimestamp(Timestamp createTimestamp) {
        super.createTimestamp = createTimestamp;
    }

    public void setCreateUserId(String createUserId) {
        super.createUserId = createUserId;
    }

    public void setDomainName(String domainName) {
        super.domainName = domainName;
    }

    public void setHierarchyTypeCode(String hierarchyTypeCode) {
        this.hierarchyTypeCode = hierarchyTypeCode;
    }

    public void setIsPrimary(String isPrimary) {
        this.isPrimary = isPrimary;
    }

    public void setLastUpdateTimestamp(Timestamp lastUpdateTimestamp) {
        super.lastUpdateTimestamp = lastUpdateTimestamp;
    }

    public void setLastUpdateUserId(String lastUpdateUserId) {
        super.lastUpdateUserId = lastUpdateUserId;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public void setAddressTypeCode(String addressTypeCode) {
        this.addressTypeCode = addressTypeCode;
    }

    public void setAddressTypeName(String addressTypeName) {
        this.addressTypeName = addressTypeName;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public void setStateProvince(String stateProvince) {
        this.stateProvince = stateProvince;
    }

    public void setStateProvinceCode(String stateProvinceCode) {
        this.stateProvinceCode = stateProvinceCode;
    }

    public void setTimeZoneId(String timeZoneId) {
        this.timeZoneId = timeZoneId;
    }

    public void setZipPostCode(String zipPostCode) {
        this.zipPostCode = zipPostCode;
    }

    public String getRequiredReporting() {
        return requiredReporting;
    }

    public void setRequiredReporting(String requiredReporting) {
        this.requiredReporting = requiredReporting;
    }

    public String getNcspMember() {
        return ncspMember;
    }

    public void setNcspMember(String ncspMember) {
        this.ncspMember = ncspMember;
    }

    @Override
    public String toString() {
        return "OrghierarchyModel{" + "orgId=" + orgId + ", parentOrgId=" + parentOrgId + ", orgRoleCode=" + orgRoleCode + ", contactSalutationCode=" + contactSalutationCode + ", orgHierarchyTypeCode=" + orgHierarchyTypeCode + ", orgName=" + orgName + ", contactFirstName=" + contactFirstName + ", contactLastName=" + contactLastName + ", contactTitle=" + contactTitle + ", DUNSNumber=" + DUNSNumber + ", SCACCode=" + SCACCode + ", EINNumber=" + EINNumber + ", stp=" + stp + ", regionCode=" + regionCode + ", requiredSubmit=" + requiredSubmit + ", reqExBeginDate=" + reqExBeginDate + ", reqExEndDate=" + reqExEndDate + ", portCode=" + portCode + ", requiredReporting=" + requiredReporting + ", ncspMember=" + ncspMember + ", remarks=" + remarks + ", amendmentCode=" + amendmentCode + ", email=" + email + ", phone=" + phone + ", addressTypeCode=" + addressTypeCode + ", countryCode=" + countryCode + ", timeZoneId=" + timeZoneId + ", isPrimary=" + isPrimary + ", contactName=" + contactName + ", addressLine1=" + addressLine1 + ", addressLine2=" + addressLine2 + ", city=" + city + ", stateProvince=" + stateProvince + ", stateProvinceCode=" + stateProvinceCode + ", zipPostCode=" + zipPostCode + ", latitude=" + latitude + ", longitude=" + longitude + ", notes=" + notes + ", orgReferenceList=" + orgReferenceList + ", eventModelList=" + eventModelList + ", orgAssocList=" + orgAssocList + ", parentOrgName=" + parentOrgName + ", parentOrgType=" + parentOrgType + ", locModelList=" + locModelList + ", conModelList=" + conModelList + ", addressTypeName=" + addressTypeName + ", hierarchyTypeCode=" + hierarchyTypeCode + ", countryName=" + countryName + "]";
    }    	
    
}
