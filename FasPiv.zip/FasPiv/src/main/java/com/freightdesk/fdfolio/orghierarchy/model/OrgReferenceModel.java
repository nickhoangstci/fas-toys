/** 
 * 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolio/orghierarchy/model/OrgReferenceModel.java,v 1.3.4.1 2010/08/22 23:08:34 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: OrgReferenceModel.java,v $
 *  Revision 1.3.4.1  2010/08/22 23:08:34  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.3  2006/03/28 21:23:06  aarora
 *  Repackaging of fdcommons
 *
 *  Revision 1.2  2005/08/01 09:41:08  pjain
 *  refactored UserModel to BaseModel
 *
 *  Revision 1.1  2004/09/16 07:22:24  ranand
 *  moved from organization package
 *
 *  Revision 1.1  2004/09/15 13:24:34  ranand
 *  2.6 Baseline
 *
 * 
 */



package com.freightdesk.fdfolio.orghierarchy.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.freightdesk.fdcommons.BaseModel;

@Entity
@Table(name="FD.ORGREFERENCE")
public class OrgReferenceModel extends BaseModel
    implements Serializable
{

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	@Id @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="ORGREFERENCEID") 
	@SequenceGenerator(name="ORGREFERENCEID", sequenceName = "ORGREFERENCEID")
	private long orgReferenceId;
	
    private String orgReferenceTypeCode;
    private String orgReferenceValue;
    
    @ManyToOne @JoinColumn(name="orgId")
	private OrghierarchyModel orghierarchy;

    public OrgReferenceModel()
    {
    }

    public OrgReferenceModel(long orgReferenceId, String orgReferenceTypeCode, long orgId, String orgReferenceValue, String createUserId,
            Timestamp createTimestamp, String lastUpdateUserId, Timestamp lastUpdateTimestamp, String domainName)
    {
        this.orgReferenceId = orgReferenceId;
        this.orgReferenceTypeCode = orgReferenceTypeCode;
        this.orgReferenceValue = orgReferenceValue;
        super.createUserId = createUserId;
        super.createTimestamp = createTimestamp;
        super.lastUpdateUserId = lastUpdateUserId;
        super.lastUpdateTimestamp = lastUpdateTimestamp;
        super.domainName = domainName;
    }

	public OrghierarchyModel getOrghierarchy() {
		return orghierarchy;
	}

	public void setOrghierarchy(OrghierarchyModel orghierarchy) {
		this.orghierarchy = orghierarchy;
	}

	/**
	 * Implements the abstract method defined by BaseModel.
	 * @return primaryKey  the unique id key for this model object.
	 */
	public long getPrimaryKey(){
		return this.orgReferenceId;
	}  

    public String getOrgReferenceValue()
	{
		if(orgReferenceValue == null)
			orgReferenceValue = "";
		return orgReferenceValue;
    }

    public long getOrgReferenceId()
    {
        return orgReferenceId;
    }

    public String getOrgReferenceTypeCode()
    {
        if(orgReferenceTypeCode == null)
            orgReferenceTypeCode = "";
        return orgReferenceTypeCode;
    }

    public void setOrgReferenceValue(String orgReferenceValue)
	{
	    this.orgReferenceValue = orgReferenceValue;
    }

    public void setOrgReferenceId(long orgReferenceId)
    {
        this.orgReferenceId = orgReferenceId;
    }

    public void setOrgReferenceTypeCode(String orgReferenceTypeCode)
    {
        this.orgReferenceTypeCode = orgReferenceTypeCode;
    }

	public String toString() {
		return "OrgReferenceModel [orgReferenceId=" + orgReferenceId + ", orgReferenceTypeCode=" + orgReferenceTypeCode + ", orgReferenceValue=" + orgReferenceValue + ", orghierarchy=" + orghierarchy + "]";
	}

}

