
This folder has all the equipment related classes.