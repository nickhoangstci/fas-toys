/** 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolio/common/BasicButtonsAction.java,v 1.6.4.1 2010/08/22 23:08:26 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: BasicButtonsAction.java,v $
 *  Revision 1.6.4.1  2010/08/22 23:08:26  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.6  2006/05/11 16:55:27  aarora
 *  Many changes as the SessionKey class has been added to com.freightdesk.fdfolio.commons
 *
 *  Revision 1.5  2006/03/28 21:23:00  aarora
 *  Repackaging of fdcommons
 *
 *  Revision 1.4  2005/03/01 23:22:42  amrinder
 *  Formatting and log messages changes
 *
 *  Revision 1.3  2004/09/15 13:03:45  ranand
 *  2.6 Baseline
 */

package com.freightdesk.fdfolio.common;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//import org.apache.struts.action.ActionForm;
//import org.apache.struts.action.ActionForward;
//import org.apache.struts.action.ActionMapping;

import com.freightdesk.fdcommons.Credentials;
import com.freightdesk.fdcommons.LoggedInAction;

/**
 * A base class for all Actions that correspond to JSPs that have 
 * four basic buttons on top.
 *
 * @author Amrinder Arora
 */
public abstract class BasicButtonsAction extends LoggedInAction
{
//    public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response, Credentials credentials)
//        throws Exception
//    {
//        logger.debug("execute(): begin");
//
//        BasicButtonsForm basicButtonsForm = (BasicButtonsForm) form;
//        String basicBtnClicked = basicButtonsForm.getBasicBtnClicked();
//
//        logger.debug("basicBtnClicked: " + basicBtnClicked);
//
//        if (BasicButtonsForm.SAVE.equalsIgnoreCase(basicBtnClicked)) {
//            return respondBtnSave(mapping, basicButtonsForm, request, response, credentials);
//        } else if (BasicButtonsForm.SAVE_RETURN.equalsIgnoreCase(basicBtnClicked)) {
//            return respondBtnSaveAndReturn(mapping, basicButtonsForm, request, response, credentials);
//        } else if (BasicButtonsForm.SAVE_ALL.equalsIgnoreCase(basicBtnClicked)) {
//            return respondBtnSaveAll(mapping, basicButtonsForm, request, response, credentials);
//        } else if (BasicButtonsForm.CANCEL.equalsIgnoreCase(basicBtnClicked)) {
//            return respondBtnCancel(mapping, basicButtonsForm, request, response, credentials);
//        } else {
//            // the basic button does not match any known value
//            logger.debug("forwarding to respondNonBasicBtnClick in concrete subclass");
//            return respondNonBasicBtnClick(mapping, basicButtonsForm, request, response, credentials);
//        }
//    }
//
//    public abstract ActionForward respondBtnSave(ActionMapping mapping, BasicButtonsForm form, HttpServletRequest request, HttpServletResponse response, Credentials credentials)
//        throws Exception;
//
//    public abstract ActionForward respondBtnSaveAndReturn(ActionMapping mapping, BasicButtonsForm form, HttpServletRequest request, HttpServletResponse response,
//            Credentials credentials)
//        throws Exception;

//    public ActionForward respondBtnSaveAll(ActionMapping mapping, BasicButtonsForm form, HttpServletRequest request, HttpServletResponse response, Credentials credentials)
//        throws Exception
//    {
//        return null;
//    }
//
//    public abstract ActionForward respondBtnCancel(ActionMapping mapping, BasicButtonsForm form, HttpServletRequest request, HttpServletResponse response, Credentials credentials)
//        throws Exception;
//
//    public abstract ActionForward respondNonBasicBtnClick(ActionMapping mapping, BasicButtonsForm form, HttpServletRequest request, HttpServletResponse response,
//            Credentials credentials)
//        throws Exception;
//
//}
}
