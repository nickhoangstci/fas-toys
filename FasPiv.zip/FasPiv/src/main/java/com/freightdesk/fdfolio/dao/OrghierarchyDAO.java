/**
 * Copyright (c) NTELX All rights reserved.
 *
 * This software is the confidential and proprietary information of NTELX
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the license
 * agreement you entered into with NTELX.
 *
 */
package com.freightdesk.fdfolio.dao;

import org.apache.log4j.Logger;
import java.math.BigInteger;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import com.freightdesk.fdfolio.addressbook.model.OrganizationChartModel;
import com.freightdesk.fdfolio.common.SessionFactoryUtil;
import com.freightdesk.fdfolio.orghierarchy.model.OrghierarchyModel;
import com.freightdesk.fdcommons.BaseDao;
import com.freightdesk.fdcommons.ConnectionUtil;
import crt.com.ntelx.nxcommons.NxUtils;
import com.freightdesk.fdcommons.OptionBean;

/**
 * Data access object to retrieve and persist OrgHierarchy related data.
 *
 * @author Mike Echevarria
 */
public class OrghierarchyDAO extends BaseDao {

    protected static Logger logger = Logger.getLogger("OrghierachyDAO");
	
	public OrghierarchyModel retrieve(long orgId, String type) {
        logger.debug("Attempting to retrieve OrgHierarchyModel for ID " + orgId);
        

        OrghierarchyModel orgModel = null;
        Session session = null;

        try {
            session = SessionFactoryUtil.getSession();
            Criteria criteria = session.createCriteria(OrghierarchyModel.class);
            criteria.add(Restrictions.eq("orgId", orgId));

            if (NxUtils.notEmptyOrBlank(type)) {
                logger.info("Restricting type to " + type);
                
                criteria.add(Restrictions.eq("orgHierarchyTypeCode", type));
            } else {
                logger.debug("Type not restricted");
                
            }

            orgModel = (OrghierarchyModel) criteria.uniqueResult();

            // this is called to filter out any Associations that are not 'ACTIVE'
            orgModel.setOrgAssocList(filterActiveList(orgModel.getOrgAssocList(), session));

        } catch (Exception ex) {
            
			logger.error("Exception: " + ex.getMessage());
        } finally {
            if (session != null) {
			  session.close();
			}
        }

        return orgModel;
    }

    @SuppressWarnings("unchecked")
    public List<OptionBean> getParentOrgOptions(String typeCode, long currentOrgId) {
        logger.debug("Getting list of possible parentOrgs for OrghierarchyType " + typeCode);

        List<OptionBean> parentOrgOptions = new ArrayList<OptionBean>();
        List<OrghierarchyModel> parentOrgs = new ArrayList<OrghierarchyModel>();
        List<String> parentOrgTypes = new ArrayList<String>();

        // Locations can only have ORGS as parents.  Orgs can use list for assocations
        if (typeCode.equalsIgnoreCase("LOC") || (typeCode.equalsIgnoreCase("ORG"))) {
            parentOrgTypes.add("ORG");

            // Contacts can either have ORG or LOC as parent	
        } else if (typeCode.equalsIgnoreCase("CON")) {
            parentOrgTypes.add("ORG");
            parentOrgTypes.add("LOC");

            // ORG, CAR, AIRPT do not have parent orgs.  Do nothing	
        } else {
            logger.debug("Not setting parentOrgList for OrgHierarchyTypeCode " + typeCode);
            return parentOrgOptions;
        }

        Session session = null;

        try {
            session = SessionFactoryUtil.getSession();

            // not editing this list, used for pulldown selection
            session.setDefaultReadOnly(true);

            Criteria criteria = session.createCriteria(OrghierarchyModel.class);

            criteria.add(Restrictions.eq("status", "ACTIVE"));
            criteria.add(Restrictions.in("orgHierarchyTypeCode", parentOrgTypes));

            // make sure to not pull back the org we are working on in the list
            criteria.add(Restrictions.not(Restrictions.eq("orgId", currentOrgId)));

            criteria.addOrder(Order.desc("orgName"));

            parentOrgs = criteria.list();

            // make the option bean list
            for (OrghierarchyModel orgModel : parentOrgs) {
                OptionBean option = new OptionBean();
                option.setLabel(orgModel.getOrgName() + " (" + orgModel.getOrgHierarchyTypeCode() + ")");
                option.setValue(String.valueOf(orgModel.getOrgId()));

                parentOrgOptions.add(option);
            }

        } catch (Exception ex) {
            
			logger.error("Exception: " + ex.getMessage());
        } finally {
		    if (session != null) {
              session.close();
			}
        }

        return parentOrgOptions;
    }

    public List<OptionBean> retrieveAddFacilityList(String parentOrgId, String orgRoleCode) {
        List<OptionBean> facilityList = new ArrayList<OptionBean>();

        // ctrl+f7 in sqldevelper to format.
        // conditions: gotta have certnum, gotta be active, same rolecode and not be in a hierarchy tree below you
        String query = "select o.orgname||'('||o.orgrolecode|| ')' as label,o.orgid as value from orghierarchy o, orgreference oref where o.orgid = oref.orgid and o.status = 'ACTIVE' and oref.orgreferencetypeCode = 'CRTNM' and o.orgrolecode=? and o.orgid not in (select orgid from orghierarchy start with orgid=? connect by prior orgid=parentorgid) order by o.orgname";
        Connection connection = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            connection = ConnectionUtil.getConnection();

            pstmt = connection.prepareStatement(query);
            pstmt.setString(1, orgRoleCode);
            pstmt.setString(2, parentOrgId);

            rs = pstmt.executeQuery();

            while (rs.next()) {
                OptionBean facility = new OptionBean(rs.getString("LABEL"), rs.getString("VALUE"));
                facilityList.add(facility);
            }
        } catch (Exception ex) {
            logger.error("Query: " + query + "\nParams: [ " + orgRoleCode + " ],[" + parentOrgId + "]");
            
        } finally {
            ConnectionUtil.closeResources(connection, pstmt, rs);
        }
        return facilityList;
    }

    @SuppressWarnings("unchecked")
    public List<OptionBean> retrievePossiblePartners(String orgRoleCode, String orgTypeCode, long currentOrgId) {
        logger.debug("Retrieving possible partners for orgRoleCode " + orgRoleCode);

        List<OptionBean> partnerOptions = new ArrayList<OptionBean>();
        List<OrghierarchyModel> orgList = new ArrayList<OrghierarchyModel>();
        Session session = null;
        try {
            session = SessionFactoryUtil.getSession();

            // not editing this list, used for pulldown selection
            session.setDefaultReadOnly(true);

            Criteria criteria = session.createCriteria(OrghierarchyModel.class);

            criteria.add(Restrictions.eq("status", "ACTIVE"));
            criteria.add(Restrictions.eq("orgRoleCode", orgRoleCode));
            criteria.add(Restrictions.eq("orgHierarchyTypeCode", orgTypeCode));

            // make sure to not pull back the org we are working on in the list
            criteria.add(Restrictions.not(Restrictions.eq("orgId", currentOrgId)));


            criteria.addOrder(Order.desc("orgName"));

            orgList = criteria.list();

            // make the option bean list
            for (OrghierarchyModel orgModel : orgList) {
                OptionBean option = new OptionBean();
                option.setLabel(orgModel.getOrgName() + " (" + orgModel.getOrgRoleCode() + ")");
                option.setValue(String.valueOf(orgModel.getOrgId()));

                partnerOptions.add(option);
            }

        } catch (Exception ex) {
            
			logger.error("Exception: " + ex.getMessage());
        } finally {
            if (session != null) {
			   session.close();
			}
        }

        return partnerOptions;

    }

    public boolean isOrgInActive(long orgId) {
        String query = "select orgid from orghierarchy where orgid=? and status=?";

        HashMap<Integer, Object> params = new HashMap<Integer, Object>();
        params.put(1, orgId);
        params.put(2, "INACTIVE");

        orgId = executeQuery_long(query, params);

        if (orgId > 0) {
            return true;
        } else {
            return false;
        }
    }

    // returns list of active carriers including parent organization
    public List<OptionBean> retrieveRelatedCarriers(long rootCarrier) {
        logger.debug("Retrieving all related Carriers for org " + rootCarrier);

        List<OptionBean> carrierList = new ArrayList<OptionBean>();
        Connection connection = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        // ctrl+f7 in sqlDeveloper to format
        String query = "SELECT orgname as LABEL,orgid as VALUE FROM orghierarchy start with orgid=? connect by scaccode is not null and status='ACTIVE' and prior orgid=parentorgid";

        try {
            connection = ConnectionUtil.getConnection();

            pstmt = connection.prepareStatement(query);
            pstmt.setLong(1, rootCarrier);

            rs = pstmt.executeQuery();

            while (rs.next()) {
                OptionBean carrier = new OptionBean(rs.getString("LABEL"), rs.getString("VALUE"));
                carrierList.add(carrier);
            }

        } catch (Exception ex) {
            logger.error("SQL is " + query + " Exception: " + ex.getMessage());
            
        } finally {
            ConnectionUtil.closeResources(connection, pstmt, rs);
        }

        return carrierList;
    }

    @SuppressWarnings("unchecked")
    // Type should either be CON or LOC
    public List<OrghierarchyModel> retrieveChildOrgs(long orgid, String type) {
        logger.debug("Retrieving child orgs of type " + type + " for parentOrgId=" + orgid);
        List<OrghierarchyModel> contactList = new ArrayList<OrghierarchyModel>();
        Session session = null;

        try {
            // convert the long orgId to a BigInteger value
            BigInteger parentOrgId = new BigInteger(String.valueOf(orgid));

            // restriction on parentOrgId and TypeCode
            session = SessionFactoryUtil.getSession();
            Criteria criteria = session.createCriteria(OrghierarchyModel.class);
            criteria.add(Restrictions.eq("parentOrgId", parentOrgId));
            criteria.add(Restrictions.eq("orgHierarchyTypeCode", type));
            criteria.addOrder(Order.desc("lastUpdateTimestamp"));

            contactList = criteria.list();

        } catch (Exception ex) {
            
			logger.error("Exception: " + ex.getMessage());
        } finally {
		    if (session != null) {
              session.close();
			}
        }
        logger.debug("Retrieved " + contactList.size() + " child objects");
        return contactList;
    }

    public boolean delete(long orgId) {
        logger.debug("Deleting org=" + orgId);
        boolean deleted = false;
        Session session = null;
        try {
            session = SessionFactoryUtil.getSession();
            session.beginTransaction();
            OrghierarchyModel model = (OrghierarchyModel) session.get(OrghierarchyModel.class, new Long(orgId));

            session.delete(model);
            deleted = true;
        } catch (Exception ex) {
            
			logger.error("Exception: " + ex.getMessage());
        } finally {
            if (session != null) {
			  session.getTransaction().commit();
              session.close();
			}  
        }
        return deleted;
    }

    public boolean delete(OrghierarchyModel model) {
        return delete(model.getOrgId());
    }

    /**
     * Retrieves the organization name for the specified organization ID.
     *
     * @return Organization Name corresponding to the given organization ID null
     * if no matching ID is found
     */
    public String retrieveOrgNameByOrgID(long orgId) {
        String nameQuery = "SELECT ORGNAME FROM ORGHIERARCHY WHERE ORGID=?";
        logger.debug("retrieveOrgNameByOrgID : ORGNAME - Query is " + nameQuery.substring(0, nameQuery.length() - 1) + orgId);

        try {
            long[] larray = {orgId};
            return executeQuery_String(nameQuery, larray);
        } catch (Exception e) {
            logger.error("Exception in retrieveOrgNameByOrgID (orgId)", e);
            
            return null;
        }
    }

    public String retrieveScacCodeByOrgID(long orgId) {
        String scacCode = null;

        try {
            // only carriers should have SCAC codes.  The have typecode=ORG and orgrolecode=CAR	
            OrghierarchyModel orgModel = retrieve(orgId, "ORG");
            scacCode = orgModel.getSCACCode();
        } catch (Exception ex) {
            logger.debug("Could not retrieve SCAC code for " + orgId);
        }
        return scacCode;
    }

    public Long retrieveOrgIDByScacCode(String scaccode) throws Exception {

        // SCACCODE is an exact field of 4 characters. Padding is necessary for
        // input less than 4 chars
        String paddedScaccode = NxUtils.rightPad(scaccode, 4);

        String query = "SELECT ORGID FROM ORGHIERARCHY WHERE SCACCODE=?";
        String printQuery = query.replaceAll("\\?", paddedScaccode);
        logger.debug("retrieveScacCodeByOrgID : SCACCODE - Query is " + printQuery + ".");

        Connection connection = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            connection = ConnectionUtil.getConnection();
            pstmt = connection.prepareStatement(query);
            pstmt.setString(1, paddedScaccode);
            rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getLong(1);
            } else {
                logger.debug("Could not find orgid for SCACCODE=" + paddedScaccode + ".");
                return 0L;
            }
        } catch (Exception e) {
            logger.error("Exception while executing query " + printQuery + ".  ", e);
            return 0L;
        } finally {
            ConnectionUtil.closeResources(connection, pstmt, rs);
        }
    }

    public OrghierarchyModel persist(OrghierarchyModel model) throws Exception {
        logger.info("Attempting to persist model " + model.toString());
        // for FAS 5.0
        if (!"AIRPT".equals(model.getOrgHierarchyTypeCode())) {
            
            logger.info("Not AIRPT - After persist model " + model.toString());
        }
        else {
            model.setOrgRoleCode("ANALY"); 
            model.setContactTitle("PCSA");
        }

        Session session = null;
        try {
            session = SessionFactoryUtil.getSession();
            session.beginTransaction();

            // for some reason this deletes orphan objects properly?  saveOrUpdate didn't do it for some reason and I'm not smart enough to understand :/
            model = (OrghierarchyModel) session.merge(model);

        } catch (Exception e) {
		    if (session != null) {
               session.getTransaction().rollback();
            }
			logger.error("Exception: " + e.getMessage());
            throw (SQLException) new Exception().initCause(e);
        } finally {
            if (session != null) {
			  session.getTransaction().commit();
              session.close();
			}  
        }
        return model;
    }

    /**
     * Gets the list of organization reference type codes as a list of
     * OptionBean elements.
     *
     * @param domainName The domain for which the list of organization referece
     * type codes is to be retrieved.
     *
     * @return The list of OptionBean elements, each of which is a code-name
     * mapping of organization reference type.
     */
    public List<OptionBean> retrieveOrgRefTypeCodeList(String domainName) throws SQLException {
        String query = "SELECT ORGREFERENCETYPECODE, ORGREFERENCETYPENAME FROM ORGREFERENCETYPE WHERE DOMAINNAME IN(?,'PUBLIC')";
        Connection connection = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        List<OptionBean> referenceTypeCodesList = new ArrayList<OptionBean>();
        try {
            connection = getConnection();
            pStmt = connection.prepareStatement(query);
            pStmt.setString(1, domainName);
            logger.debug("query is " + query);
            OptionBean codename;
            for (rs = pStmt.executeQuery(); rs.next(); referenceTypeCodesList.add(codename)) {
                codename = new OptionBean(rs.getString(2), rs.getString(1));
            }
        } catch (SQLException sqEx) {
            logger.error("getOrganizationReferenceTypeCodes()", sqEx);
            throw sqEx;
        } finally {
            ConnectionUtil.closeResources(connection, pStmt, rs);
        }
        return referenceTypeCodesList;
    }

    /*
     * Check to see another org has this same orgreference
     */
    public boolean checkDuplicateReference(String type, String value, Long orgID) {
        boolean duplicate = true;
        PreparedStatement pStmt = null;
        Connection connection = null;
        ResultSet rs = null;
        String query = "SELECT COUNT(*) FROM ORGREFERENCE WHERE ORGREFERENCETYPECODE=? AND ORGREFERENCEVALUE=? AND ORGREFERENCEID <> ?";
        try {
            connection = getConnection();
            pStmt = connection.prepareStatement(query);
            pStmt.setString(1, type);
            pStmt.setString(2, value);
            pStmt.setLong(3, orgID);

            rs = pStmt.executeQuery();
            rs.next();
            int count = rs.getInt(1);
            logger.debug("Found " + count + " existing type/values in ORGREFERENCE.");
            if (count < 1) {
                duplicate = false;
            }

            rs.close();
            pStmt.close();
            connection.close();
        } catch (Exception ex) {
            
			logger.error("Exception: " + ex.getMessage());
        } finally {
            ConnectionUtil.closeResources(connection, pStmt, rs);
        }

        return duplicate;
    }

    public int cascadeStatusOrghierarchy(long orgId, String status) {
        logger.debug("Setting status = " + status + " for all child orghierarchy records of " + orgId);

        // use ctrl+f7 to format in sqldeveloper
        String query = "UPDATE orghierarchy SET status=? WHERE orgid IN (SELECT orgid FROM orghierarchy where orgid<>? START WITH orgid=? CONNECT BY PRIOR orgid = parentorgid)";

        HashMap<Integer, Object> params = new HashMap<Integer, Object>();
        params.put(1, status);
        params.put(2, orgId);
        params.put(3, orgId);

        return executeUpdate(query, params);
    }

    public boolean checkDuplicateOrgHierarchy(long orgId, String orgTypeCode, String orgRoleCode, String orgName, String contactFirstName, String contactLastName) {
        logger.debug("Checking for duplicate orghierarchy values");
        boolean duplicate = true;
        PreparedStatement pStmt = null;
        Connection connection = null;
        ResultSet rs = null;
        HashMap<Integer, Object> paramMap = new HashMap<Integer, Object>();
        int paramIndex = 1;
        String query = "SELECT COUNT(ORGID) FROM ORGHIERARCHY WHERE ORGID <>?";
        try {
            paramMap.put(paramIndex, orgId);
            paramIndex++;

            if (orgTypeCode.length() > 0) {
                query = query + " AND ORGHIERARCHYTYPECODE=?";
                paramMap.put(paramIndex, orgTypeCode);
                paramIndex++;
            }

            if (orgRoleCode.length() > 0) {
                query = query + " AND ORGROLECODE=?";
                paramMap.put(paramIndex, orgRoleCode);
                paramIndex++;
            }

            if (orgName.length() > 0) {
                query = query + " AND ORGNAME=?";
                paramMap.put(paramIndex, orgName);
                paramIndex++;
            }

            if (contactFirstName.length() > 0) {
                query = query + " AND CONTACTFIRSTNAME=?";
                paramMap.put(paramIndex, contactFirstName);
                paramIndex++;
            }

            if (contactLastName.length() > 0) {
                query = query + " AND CONTACTLASTNAME=?";
                paramMap.put(paramIndex, contactLastName);
                paramIndex++;
            }

            connection = getConnection();
            logger.debug("Query: " + query);
            pStmt = connection.prepareStatement(query);

            pStmt = bindParams(pStmt, paramMap);
            rs = pStmt.executeQuery();
            rs.next();
            int count = rs.getInt(1);
            logger.debug("Found " + count + " matching orghiearchy values");
            if (count < 1) {
                duplicate = false;
            }

            rs.close();
            pStmt.close();
            connection.close();
        } catch (Exception ex) {
            
			logger.error("Exception: " + ex.getMessage());
        } finally {
            ConnectionUtil.closeResources(connection, pStmt, rs);
        }

        return duplicate;
    }

    public boolean checkDuplicatePortCode(String orgPortCode) {
        logger.debug("Checking for duplicate orghierarchy values");
        boolean duplicate = true;
        PreparedStatement pStmt = null;
        Connection connection = null;
        ResultSet rs = null;
        HashMap<Integer, Object> paramMap = new HashMap<Integer, Object>();
        int paramIndex = 1;
        String query = "SELECT COUNT(ORGID) FROM ORGHIERARCHY WHERE ";
        if (orgPortCode.length() > 0) {
            try {
                query = query + " PORTCODE=?";
                paramMap.put(paramIndex, orgPortCode);
                paramIndex++;

                connection = getConnection();
                logger.debug("Query: " + query);
                pStmt = connection.prepareStatement(query);

                pStmt = bindParams(pStmt, paramMap);
                rs = pStmt.executeQuery();
                rs.next();
                int count = rs.getInt(1);
                logger.debug("Found " + count + " matching orghiearchy values");
                if (count < 1) {
                    duplicate = false;
                }

                rs.close();
                pStmt.close();
                connection.close();
            } catch (Exception ex) {
                
				logger.error("Exception: " + ex.getMessage());
            } finally {
                ConnectionUtil.closeResources(connection, pStmt, rs);
            }
        }

        return duplicate;
    }

    /*
     * Check to see if the give orgreference is related to contact id
     */
    public boolean relatedOrgRef(String refValue, String refType, long contactId) {
        boolean exists = false;

        // ctrl +f7 in sqldeveloper to format
        // starting with parentorg, find all orgreferences in tree below
        String orgQuery = "select orf.orgreferencevalue from orghierarchy o, orgreference orf where o.orgid = orf.orgid and orf.orgreferencetypecode=? and orf.orgreferencevalue=? and o.status='ACTIVE' and o.orgid in (select orgid from orghierarchy START WITH orgid=(select parentorgid from orghierarchy where orgid=?) CONNECT BY PRIOR orgid = parentorgid)";

        // take contactid and match to orgorgassoc to find an associated orgreference
        String assocQuery = "select orf.orgreferencevalue from orghierarchy o, orgreference orf, orgorgassoc a where o.orgid = orf.orgid and orf.orgreferencetypecode=? and orf.orgreferencevalue=? and o.status='ACTIVE' and destorgid = orf.orgid and srcorgid=? and relationshiptypecode='ALOC'";

        // combine the results of both the queries to get a unique result
        String totalQuery = orgQuery + " UNION " + assocQuery;

        Connection connection = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            connection = getConnection();
            pStmt = connection.prepareStatement(totalQuery);

            pStmt.setString(1, refType);
            pStmt.setString(2, refValue);
            pStmt.setLong(3, contactId);
            pStmt.setString(4, refType);
            pStmt.setString(5, refValue);
            pStmt.setLong(6, contactId);

            rs = pStmt.executeQuery();

            // if a match, a row is returned.  Otherwise now
            if (rs.next()) {
                exists = true;
            }

            rs.close();
            pStmt.close();
            connection.close();
        } catch (Exception ex) {
            logger.error("Error executing query with params orgid=" + contactId + ", reference type=" + refType + ", reference value=" + refValue);
            logger.error(totalQuery);
            
        } finally {
            ConnectionUtil.closeResources(connection, pStmt, rs);
        }
        return exists;
    }

    /*
     * Gets the orgname this orgreference is attached to
     */
    public String getOrgNameFromReference(String orgRefValue, String orgRefType) {
        Connection connection = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        String query = "select orgname from orghierarchy where orgid = (select orgid from orgreference where orgreferencevalue=? and orgreferencetypecode=?)";
        String orgName = "Reference not in system.";
        try {
            connection = ConnectionUtil.getConnection();
            pStmt = connection.prepareStatement(query);
            pStmt.setString(1, orgRefValue);
            pStmt.setString(2, orgRefType);
            rs = pStmt.executeQuery();

            if (rs.next()) {
                orgName = rs.getString(1);
            } else {
                logger.debug("Failed to find orgname for orgreference value of " + orgRefValue);
            }
            rs.close();
            pStmt.close();
            connection.close();
        } catch (SQLException ex) {
            logger.error("Exception while looking up ORGNAME for ORGREF.", ex);
        } finally {
            ConnectionUtil.closeResources(connection, pStmt, rs);
        }

        return orgName;
    }

    public String getOrgDomain(long orgId) {
        Connection connection = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        String query = "SELECT DOMAINNAME FROM ORGHIERARCHY WHERE ORGID=?";
        String domainName = "";
        try {
            connection = ConnectionUtil.getConnection();
            pStmt = connection.prepareStatement(query);
            pStmt.setLong(1, orgId);
            rs = pStmt.executeQuery();

            if (rs.next()) {
                domainName = rs.getString(1);
                logger.debug("DOMAINNAME for ORG " + orgId + " is " + domainName);
            } else {
                logger.debug("Failed to find domain for org " + orgId);
            }
            rs.close();
            pStmt.close();
            connection.close();
        } catch (SQLException ex) {
            logger.error("Exception while looking up DOMAINNAME for ORG.", ex);
        } finally {
            ConnectionUtil.closeResources(connection, pStmt, rs);
        }
        return domainName;
    }

    /*
     * For the contact, get all org references attached to the parent org, and
     * its child orgs if any
     */
    public List<OptionBean> getRelatedOrgRefs(long contactId, String refType) {
        List<OptionBean> references = new ArrayList<OptionBean>();

        logger.debug("contactId=" + contactId + ", refType=" + refType);
        // ctrl +f7 in sqldeveloper to format
        // starting with parentorg, find all orgreferences in tree below
        String orgQuery = "select orf.orgreferencevalue from orghierarchy o, orgreference orf where o.orgid = orf.orgid and orf.orgreferencetypecode=? and o.status='ACTIVE' and o.orgid in (select orgid from orghierarchy START WITH orgid=(select parentorgid from orghierarchy where orgid=?) CONNECT BY PRIOR orgid = parentorgid)";

        // take contactid and match to orgorgassoc to find an associated orgreference
        String assocQuery = "select orf.orgreferencevalue from orghierarchy o, orgreference orf, orgorgassoc a where o.orgid = orf.orgid and orf.orgreferencetypecode=? and o.status='ACTIVE' and destorgid = orf.orgid and srcorgid=? and relationshiptypecode='ALOC'";

        // combine the results of both the queries to get a unique result
        String totalQuery = orgQuery + " UNION " + assocQuery;

        Connection connection = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            connection = getConnection();
            pStmt = connection.prepareStatement(totalQuery);

            pStmt.setString(1, refType);
            pStmt.setLong(2, contactId);
            pStmt.setString(3, refType);
            pStmt.setLong(4, contactId);

            rs = pStmt.executeQuery();

            // while there are results in the set, add each result to the list
            while (rs.next()) {
                references.add(new OptionBean(rs.getString(1), rs.getString(1)));
            }

            rs.close();
            pStmt.close();
            connection.close();
        } catch (Exception ex) {
            logger.error("Error attempting to retrieve related references for orgid " + contactId + ", reference type " + refType);
            logger.error(totalQuery);
            
        } finally {
            ConnectionUtil.closeResources(connection, pStmt, rs);
        }

        logger.debug("Contact " + contactId + " has " + references.size() + " related orgReferences of type " + refType);
        return references;

    }

    public long getAirportOrgID(long userOrgID) throws SQLException {
        long airportID = -1L;
        String qryString = "SELECT " + "        airRef.orgID " + "FROM " + "       ORGHIERARCHY oh, " + "       ORGHIERARCHY locOh, " + "       ORGREFERENCE airRef " + "WHERE "
                + "       oh.ORGID                   = ? " + "   AND locOh.ORGID                = oh.PARENTORGID " + "   AND locOh.ORGHIERARCHYTYPECODE = 'LOC' "
                + "   AND airRef.ORGREFERENCEVALUE    = locOh.PORTCODE " + "   AND airRef.ORGID               <> locOh.orgID";

        Connection connection = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;

        try {
            connection = getConnection();
            logger.debug("getAirportOrgID: " + qryString);
            pStmt = connection.prepareStatement(qryString);

            pStmt.setLong(1, userOrgID);

            rs = pStmt.executeQuery();

            if (rs.next()) {
                airportID = rs.getLong(1);
            }

            rs.close();
            pStmt.close();
            connection.close();

            return airportID;
        } catch (SQLException sqEx) {
            logger.error("Exception in getContactParentID: ", sqEx);
            throw sqEx;
        } finally {
            ConnectionUtil.closeResources(connection, pStmt, rs);
        }

    }

    /**
     * This method returns the type code of the org given ORG ID.
     *
     * @param orgId The ID of the org
     * @return "ORG", "LOC", "CON" or "" if no orgID is found.
     */
    public String getOrgType(long orgId) {
        Connection connection = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        String orgType = "";
        try {
            String typeQuery = "SELECT ORGHIERARCHYTYPECODE  FROM ORGHIERARCHY WHERE ORGID= ?";
            logger.debug("getOrgType(): typeQuery is " + typeQuery);
            connection = getConnection();
            pStmt = connection.prepareStatement(typeQuery);
            pStmt.setLong(1, orgId);
            rs = pStmt.executeQuery();
            if (rs.next()) {
                orgType = rs.getString(1);
            }

            rs.close();
            pStmt.close();
            connection.close();
        } catch (Exception ex) {
            
			logger.error("Exception: " + ex.getMessage());
        } finally {
            ConnectionUtil.closeResources(connection, pStmt, rs);
        }
        return orgType;
    }

    public OrganizationChartModel getOrganizationChart(long currentOrgId) throws SQLException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            // ctrl + f7 in sqldeveloper to format
            String query = "select parentorgid, orgname, orgid, ORGHIERARCHYTYPECODE, STATUS from orghierarchy CONNECT BY PRIOR orgid=parentorgid START WITH orgid= (select orgid from (SELECT o.parentorgid,o.orgid FROM orghierarchy o CONNECT BY PRIOR o.parentorgid=o.orgid START WITH o.orgid=? )where parentorgid is null) order siblings by orghierarchytypecode,orgname";
            connection = ConnectionUtil.getConnection();
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setLong(1, currentOrgId);
            resultSet = preparedStatement.executeQuery();
            Map<Long, OrganizationChartModel> objectMap = new LinkedHashMap<Long, OrganizationChartModel>();
            // the code generates all the objects, puts them in the map with key
            // parentorgId
            while (resultSet.next()) {
                String orgName = resultSet.getString("ORGNAME");
                long tempParentId = resultSet.getLong("PARENTORGID");
                long orgId = resultSet.getLong("ORGID");
                String typeCode = resultSet.getString("ORGHIERARCHYTYPECODE");
                String status = resultSet.getString("STATUS");
                logger.debug("tempParentId: " + tempParentId + ", orgId: " + orgId + ", orgName: " + orgName + ", status: " + status);
                OrganizationChartModel organizationChartModel = objectMap.get(new Long(tempParentId));
                if (organizationChartModel == null) {
                    organizationChartModel = new OrganizationChartModel();
                    objectMap.put(new Long(tempParentId), organizationChartModel);
                }
                organizationChartModel.getChildOrgChartModelList().add(new OrganizationChartModel(orgName, orgId, tempParentId, typeCode, status));

            }
            Iterator<?> iterator = objectMap.entrySet().iterator();
            OrganizationChartModel organizationChartModel = null;
            // this code takes out child lists from the map and sets into the
            // root model that is returned
            if (iterator.hasNext()) {
                Map.Entry<?, ?> pairs = (Map.Entry<?, ?>) iterator.next();
                organizationChartModel = (OrganizationChartModel) pairs.getValue();
                List<OrganizationChartModel> firstLevelList = organizationChartModel.getChildOrgChartModelList();
                setChildListToOrganizationGraph(firstLevelList, objectMap);
            }

            resultSet.close();
            preparedStatement.close();
            connection.close();

            return organizationChartModel;
        } catch (SQLException e) {
            logger.error("Exception in getChildList" + e);
            throw e;
        } finally {
            ConnectionUtil.closeResources(connection, preparedStatement, resultSet);
        }
    }

    /**
     * the method takes a list and parent object map searches for child lists
     * and sets them up in the parent model, so the disjoint hierarchy
     * maintained in the model is brought into the child list of root model.
     *
     * @param childList
     * @param objectMap
     */
    private void setChildListToOrganizationGraph(List<OrganizationChartModel> childList, Map<Long, OrganizationChartModel> objectMap) {
        if (childList != null && childList.size() > 0) {
            Iterator<OrganizationChartModel> listIterator = childList.iterator();
            while (listIterator.hasNext()) {
                OrganizationChartModel organizationChartModel = listIterator.next();
                OrganizationChartModel temporganizationChartModel = objectMap.get(new Long(organizationChartModel.getOrgId()));

                if (temporganizationChartModel != null && objectMap.get(new Long(organizationChartModel.getOrgId())) != null) {
                    organizationChartModel.setChildOrgChartModelList(temporganizationChartModel.getChildOrgChartModelList());
                    objectMap.remove(new Long(organizationChartModel.getOrgId()));
                    List<OrganizationChartModel> secondLevelList = organizationChartModel.getChildOrgChartModelList();
                    if (secondLevelList != null && secondLevelList.size() > 0) {
                        setChildListToOrganizationGraph(secondLevelList, objectMap);
                    }
                }

            }
        }
    }

    /*
     * checks for duplicate communication type, value pairs
     */
    public boolean checkForDuplicateEmail(String email, long orgID) {
        boolean duplicate = true;
        PreparedStatement pStmt = null;
        Connection connection = null;
        ResultSet rs = null;
        String query = "SELECT COUNT(*) FROM FD.ORGHIERARCHY WHERE EMAIL=? AND ORGID <> ?";
        try {
            connection = getConnection();
            pStmt = connection.prepareStatement(query);
            pStmt.setString(1, email);
            pStmt.setLong(2, orgID);

            rs = pStmt.executeQuery();
            rs.next();
            int count = rs.getInt(1);
            logger.debug("Found " + count + " existing type/values in ORGHIERARCHY.");
            if (count < 1) {
                duplicate = false;
            }

            rs.close();
            pStmt.close();
            connection.close();
        } catch (Exception ex) {
            
			logger.error("Exception: " + ex.getMessage());
        } finally {
            ConnectionUtil.closeResources(connection, pStmt, rs);
        }

        return duplicate;
    }
    
    public long getImmediateParent(long currentOrgId) throws SQLException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            long parentOrgId = 0;
            // ctrl + f7 in sqldeveloper to format
            String query = "select parentorgid from orghierarchy where orgid = ?";
            connection = ConnectionUtil.getConnection();
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setLong(1, currentOrgId);
            resultSet = preparedStatement.executeQuery();
 
            // the code generates all the objects, puts them in the map with key
            // parentorgId
            while (resultSet.next()) {
                parentOrgId = resultSet.getLong("PARENTORGID");
            }

            resultSet.close();
            preparedStatement.close();
            connection.close();

            return parentOrgId;
        } catch (SQLException e) {
            logger.error("Exception in getChildList" + e);
            throw e;
        } finally {
            ConnectionUtil.closeResources(connection, preparedStatement, resultSet);
        }
    }
}
