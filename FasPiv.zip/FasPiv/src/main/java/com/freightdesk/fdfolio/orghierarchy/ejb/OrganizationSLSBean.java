/** 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolio/orghierarchy/ejb/OrganizationSLSBean.java,v 1.24.2.16 2010/09/23 19:35:22 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: OrganizationSLSBean.java,v $
 *  Revision 1.24.2.16  2010/09/23 19:35:22  mechevarria
 *  remove ejb layer for instantiating objects.  direct calls to bean class now made
 *
 *  Revision 1.24.2.15  2010/08/22 23:08:35  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.24.2.14  2010/01/28 01:52:38  mechevarria
 *  uom update
 *
 *  Revision 1.24.2.13  2009/09/23 18:04:31  mechevarria
 *  import cleanup via eclipse
 *
 *  Revision 1.24.2.12  2009/09/22 19:32:42  mechevarria
 *  updated user management
 *
 *  Revision 1.24.2.11  2009/09/02 19:34:48  jhansford
 *  Changes for UAT on 9/3/2009
 *
 *  Revision 1.24.2.10  2009/08/12 18:16:02  jhansford
 *  Added Pull Down to switch domains on edit user page.
 *
 *  Revision 1.24.2.9  2009/03/13 13:36:48  mechevarria
 *  add domainname to where clause
 *
 *  Revision 1.24.2.8  2009/03/12 18:29:11  mechevarria
 *  remove StringBuilder.  Causes I/O errors
 *
 *  Revision 1.24.2.7  2009/03/12 17:44:37  mechevarria
 *  change StringBuffer to StringBuider.  jdk 1.6 performance enhancement
 *
 *  Revision 1.24.2.6  2009/03/12 17:41:32  jhansford
 *  Fixed some Refence data lookups
 *
 *  Revision 1.24.2.5  2009/03/11 13:30:38  jhansford
 *  no message
 *
 *  Revision 1.24.2.4  2009/03/09 14:05:16  jhansford
 *  STD can COC Jsp are added
 *
 *  Revision 1.24.2.3  2009/02/26 20:33:30  jhansford
 *  Cached Carrier ID and Airport Lookups
 *
 *  Revision 1.24.2.2  2009/01/28 20:46:49  mechevarria
 *  updates for air carrier screening reporting.  caching of air carrier and airport lists
 *
 *  Revision 1.24.2.1  2007/02/27 17:36:14  mechevarria
 *  changed Carrier pulldown query to remove check for type='ORG'
 *
 *  Revision 1.24  2006/11/01 14:07:10  dkumar
 *  minor change
 *
 *  Revision 1.23  2006/10/31 05:47:38  ranand
 *  impact of adding new column orgname in address table
 *
 *  Revision 1.22  2006/10/27 09:25:30  dkumar
 *  added address import/export functinality
 *
 *  Revision 1.21  2006/05/11 16:55:28  aarora
 *  Many changes as the SessionKey class has been added to com.freightdesk.fdfolio.commons
 *
 *  Revision 1.20  2006/04/12 23:44:31  aarora
 *  Removed extra code
 *
 *  Revision 1.19  2006/03/28 21:23:06  aarora
 *  Repackaging of fdcommons
 *
 *  Revision 1.18  2005/10/19 00:49:26  pjain
 *  changed getParent to get appropriate parent location orgid and parent organization orgid
 *
 *  Revision 1.17  2005/10/13 11:29:10  ranand
 *  roll back the changes of 1.14
 *
 *  Revision 1.16  2005/10/13 11:19:16  ranand
 *  changed getParents method
 *
 *  Revision 1.15  2005/10/04 05:38:39  ranand
 *  removed OrganizationDAO and split it to OrghierarchyDAO and AddressDAO
 *
 *  Revision 1.14  2005/09/29 10:41:02  ranand
 *  changed method  getParents
 *
 *  Revision 1.13  2005/09/28 08:35:54  ranand
 *  Code clean up of Address Module
 *
 *  Revision 1.12  2005/09/18 01:38:47  amrinder
 *  Changes due to changes in OrganizationDAO
 *
 *  Revision 1.11  2005/09/16 16:32:19  ranand
 *  code clean up
 *
 *  Revision 1.10  2005/09/15 19:41:32  amrinder
 *  Removed redundant methods
 *
 *  Revision 1.9  2005/09/15 10:34:45  pjain
 *  removed redundant methods
 *
 *  Revision 1.8  2005/09/15 03:40:02  amrinder
 *  attempts at putting *some* structure
 *
 *  Revision 1.7  2005/09/15 02:36:44  amrinder
 *  attempts at improving logging and putting *some* structure
 *
 *  Revision 1.6  2005/09/13 02:19:49  amrinder
 *  Caching OrganizationDAO
 *
 *  Revision 1.5  2005/09/01 14:03:51  nsehra
 *  orgRoleList  added
 *
 *  Revision 1.4  2005/08/20 12:35:36  pjain
 *  DAO movement impact
 *
 *  Revision 1.3  2005/08/09 21:56:40  amrinder
 *  Added another method of same impl
 *
 *  Revision 1.2  2004/12/02 20:37:16  bdealey
 *  Changed logger.info to logger.debug
 *
 *  Revision 1.1  2004/09/16 07:22:24  ranand
 *  moved from organization package
 *
 *  Revision 1.1  2004/09/15 13:24:34  ranand
 *  2.6 Baseline
 */

package com.freightdesk.fdfolio.orghierarchy.ejb;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import javax.ejb.EJBException;

import com.freightdesk.fdfolio.common.LcpReferenceData;
import com.freightdesk.fdfolio.dao.OrghierarchyDAO;
import com.freightdesk.fdcommons.BaseSLSBean;
import com.freightdesk.fdcommons.ConnectionUtil;
import com.freightdesk.fdcommons.OptionBean;

/**
 * Business logic facade for Organization module.
 * 
 * @author Pratiksha Jain
 * @author Biju Joseph
 * @author Amrinder Arora
 */
public class OrganizationSLSBean extends BaseSLSBean {
	/** An instance of Organization DAO */
	protected OrghierarchyDAO orghierarchyDAO = new OrghierarchyDAO();

	/**
	 * Deletes organization, given the orgID. Delegates it to DAO.
	 * 
	 * @param organizationId
	 *            The ID of the organization to be deleted
	 */
	public void deleteOrganization(long organizationId) {
		logger.debug("deleteOrganization(orgID: " + organizationId + "): begin");
		try {
			orghierarchyDAO.delete(organizationId);
		} catch (Exception ex) {
			logger.error("Exception in deleteOrganization(): organizationId = " + organizationId, ex);
			throw new EJBException(ex);
		}
	}

	public Vector getOrgId(long orgId, String type) throws SQLException {
	    Map map = new HashMap();
		Connection connection = null;
		Statement stmt = null;
		Vector vector = new Vector();
		ResultSet rs = null;
		try {
			connection = getConnection();
			stmt = connection.createStatement();
			String query = "SELECT PARENTORGID FROM ORGHIERARCHY WHERE ORGID=" + orgId;
			if (type.equals("LOC")) {
				
				for (rs = stmt.executeQuery(query); rs.next(); vector.addElement("ORG")) {
					long id = rs.getLong(1);
					vector.addElement(new Long(id));
				}
			} else if (type.equals("CON")) {
				
				long id = 0L;
				for (rs = stmt.executeQuery(query); rs.next();) {
					id = rs.getLong(1);
				    map.put("CON", new Long(id));
				}
				rs.close();
				String typeQuery = "SELECT ORGHIERARCHYTYPECODE  FROM ORGHIERARCHY WHERE ORGID=" + id;
				rs = stmt.executeQuery(typeQuery);
				ConnectionUtil.closeResources(null, null, rs);
				String typeId;
				for (typeId = ""; rs.next(); typeId = rs.getString(1))
					;
				if (typeId.equals("LOC")) {
					String locQuery = "SELECT PARENTORGID FROM ORGHIERARCHY WHERE ORGID=" + id;
					for (rs = stmt.executeQuery(locQuery); rs.next();)
						id = rs.getLong(1);
					ConnectionUtil.closeResources(null, null, rs);
					vector.addElement(new Long(id));
					vector.addElement("LOC");
				} else if (typeId.equals("ORG")) {
					vector.addElement(new Long(id));
					vector.addElement("ORG");
				}
			}
		} catch (SQLException sqEx) {
			logger.error("getOrgId(orgId,type) ", sqEx);
			throw new EJBException(sqEx);
		} finally {
			ConnectionUtil.closeResources(connection, stmt, rs);
		}
		return vector;
	}

	public boolean orgIdExists(long orgId, String domainName) throws SQLException {
		String query = "SELECT ORGID FROM ORGHIERARCHY WHERE ORGID =? AND DOMAINNAME IN(?,'PUBLIC')";
		Connection connection = null;
		PreparedStatement pStmt = null;
		ResultSet rs = null;
		try {
			connection = getConnection();
			pStmt = connection.prepareStatement(query);
			pStmt.setLong(1, orgId);
			pStmt.setString(2, domainName);
			rs = pStmt.executeQuery();
			if (rs.next()) {
				return true;
			} else {
				return false;
			}
		} catch (SQLException sqEx) {
			logger.error("orgIdExists(Orgid,domainName) ", sqEx);
			throw sqEx;
		} finally {
			ConnectionUtil.closeResources(connection, pStmt, rs);
		}
	}
	
	public List<OptionBean> getPublicSecurityDeviceModels() throws SQLException
	{
		String query = "select SECURITYDEVICETYPEID, DEVICEMODEL from SECURITYDEVICETYPE where DOMAINNAME='PUBLIC' ORDER BY DEVICEMODEL";
		Connection        connection   = null;
		PreparedStatement pStmt        = null;
		ResultSet         rs           = null;
		List<OptionBean> orgList = new ArrayList<OptionBean>();
		
		try {
			logger.debug("getPublicSecurityDeviceModels query: " + query );
			connection = getConnection();
			pStmt = connection.prepareStatement(query);
			for (rs = pStmt.executeQuery(); rs.next();) {
				orgList.add(new OptionBean(rs.getString(2), rs.getString(1)));
			}
		} catch (SQLException sqEx) {
			logger.error("getPublicSecurityDeviceModels() ", sqEx);
			throw sqEx;
		} finally {
			ConnectionUtil.closeResources(connection, pStmt, rs);
		}
		return orgList;
	}
	
	public List<OptionBean> getChainOfCustodyTypeCodes() throws SQLException
	{
		String query = "SELECT ChainOfCustodyTypeCode, chainofcustodytypename FROM chainofcustodytype where DOMAINNAME='PUBLIC'";
		Connection        connection   = null;
		PreparedStatement pStmt        = null;
		ResultSet         rs           = null;
		List<OptionBean> orgList = new ArrayList<OptionBean>();
		
		try {
			logger.debug("getChainOfCustodyTypeCodes query: " + query );
			connection = getConnection();
			pStmt = connection.prepareStatement(query);
			for (rs = pStmt.executeQuery(); rs.next();) {
				orgList.add(new OptionBean(rs.getString(2), rs.getString(1)));
			}
		} catch (SQLException sqEx) {
			logger.error("getChainOfCustodyTypeCodes ", sqEx);
			throw sqEx;
		} finally {
			ConnectionUtil.closeResources(connection, pStmt, rs);
		}
		return orgList;

	}

	public List<OptionBean> getPackageTypeCodeList() throws SQLException
	{
		String query = "SELECT PACKAGETYPECODE, PACKAGETYPENAME FROM PACKAGETYPE WHERE DOMAINNAME='PUBLIC' ORDER BY PACKAGETYPENAME";
		Connection        connection   = null;
		PreparedStatement pStmt        = null;
		ResultSet         rs           = null;
		List<OptionBean> orgList = new ArrayList<OptionBean>();
		
		try {
			logger.debug("getPackageTypeCodeLists query: " + query );
			connection = getConnection();
			pStmt = connection.prepareStatement(query);
			for (rs = pStmt.executeQuery(); rs.next();) {
				orgList.add(new OptionBean(rs.getString(2), rs.getString(1)));
			}
		} catch (SQLException sqEx) {
			logger.error("getPackageTypeCodeList() ", sqEx);
			throw sqEx;
		} finally {
			ConnectionUtil.closeResources(connection, pStmt, rs);
		}
		return orgList;

	}
	
	public List<OptionBean> getCommodityCodeList() throws SQLException
	{
		String query = "SELECT COMMODITYCLASSTYPECODE, COMMODITYCLASSTYPENAME FROM COMMODITYCLASSTYPE WHERE DOMAINNAME='PUBLIC' ORDER BY  COMMODITYCLASSTYPENAME";
		Connection        connection   = null;
		PreparedStatement pStmt        = null;
		ResultSet         rs           = null;
		List<OptionBean> orgList = new ArrayList<OptionBean>();
		
		try {
			logger.debug("getCommodityCodeList query: " + query );
			connection = getConnection();
			pStmt = connection.prepareStatement(query);
			for (rs = pStmt.executeQuery(); rs.next();) {
				orgList.add(new OptionBean(rs.getString(2), rs.getString(1)));
			}
		} catch (SQLException sqEx) {
			logger.error("getCommodityCodeList() ", sqEx);
			throw sqEx;
		} finally {
			ConnectionUtil.closeResources(connection, pStmt, rs);
		}
		return orgList;
	}
	
	public List<OptionBean> getAlarmTypeCodeList() throws SQLException
	{
		String query = "SELECT ALARMTYPECODE, ALARMTYPENAME FROM ALARMTYPE WHERE DOMAINNAME='PUBLIC' ORDER BY ALARMTYPENAME";
		Connection        connection   = null;
		PreparedStatement pStmt        = null;
		ResultSet         rs           = null;
		List<OptionBean> orgList = new ArrayList<OptionBean>();
		
		try {
			logger.debug("getAlarmTypeCodeList query: " + query );
			connection = getConnection();
			pStmt = connection.prepareStatement(query);
			for (rs = pStmt.executeQuery(); rs.next();) {
				orgList.add(new OptionBean(rs.getString(2), rs.getString(1)));
			}
		} catch (SQLException sqEx) {
			logger.error("getAlarmTypeCodeList() ", sqEx);
			throw sqEx;
		} finally {
			ConnectionUtil.closeResources(connection, pStmt, rs);
		}
		return orgList;

	}
		
	public List<OptionBean> getMethodOfResolutionTypeCodeList() throws SQLException
	{
		String query = "SELECT INSPECTIONORCHECKTYPECODE, INSPECTIONORCHECKTYPENAME FROM INSPECTIONORCHECKTYPE where DOMAINNAME='PUBLIC' ORDER BY INSPECTIONORCHECKTYPENAME";
		Connection        connection   = null;
		PreparedStatement pStmt        = null;
		ResultSet         rs           = null;
		List<OptionBean> orgList = new ArrayList<OptionBean>();
		
		try {
			logger.debug("getMethodOfResolutionTypeCodeList query: " + query );
			connection = getConnection();
			pStmt = connection.prepareStatement(query);
			for (rs = pStmt.executeQuery(); rs.next();) {
				orgList.add(new OptionBean(rs.getString(2), rs.getString(1)));
			}
		} catch (SQLException sqEx) {
			logger.error("getMethodOfResolutionTypeCodeList() ", sqEx);
			throw sqEx;
		} finally {
			ConnectionUtil.closeResources(connection, pStmt, rs);
		}
		return orgList;

	}
	
	public List<OptionBean> getExtPackagingCodeList() throws SQLException
	{
		String query = "SELECT EXTPACKAGINGTYPECODE, EXTPACKAGINGTYPENAME FROM EXTPACKAGINGTYPE where DOMAINNAME='PUBLIC' ORDER BY EXTPACKAGINGTYPENAME";
		Connection        connection   = null;
		PreparedStatement pStmt        = null;
		ResultSet         rs           = null;
		List<OptionBean> orgList       = new ArrayList<OptionBean>();
		
		try {
			logger.debug("getExtPackagingTypeCodeList query: " + query );
			connection = getConnection();
			pStmt = connection.prepareStatement(query);
			for (rs = pStmt.executeQuery(); rs.next();) {
				orgList.add(new OptionBean(rs.getString(2), rs.getString(1)));
			}
		} catch (SQLException sqEx) {
			logger.error("getExtPackagingTypeCodeList() ", sqEx);
			throw sqEx;
		} finally {
			ConnectionUtil.closeResources(connection, pStmt, rs);
		}
		return orgList;

	}
	
	public List<OptionBean> getFillerCodeList() throws SQLException
	{
		String query = "SELECT FILLERTYPECODE, FILLERTYPENAME FROM FILLERTYPE where DOMAINNAME='PUBLIC' ORDER BY FILLERTYPENAME";
		Connection        connection   = null;
		PreparedStatement pStmt        = null;
		ResultSet         rs           = null;
		List<OptionBean> orgList       = new ArrayList<OptionBean>();
		
		try {
			logger.debug("getFillerCodeListt query: " + query );
			connection = getConnection();
			pStmt = connection.prepareStatement(query);
			for (rs = pStmt.executeQuery(); rs.next();) {
				orgList.add(new OptionBean(rs.getString(2), rs.getString(1)));
			}
		} catch (SQLException sqEx) {
			logger.error("getFillerCodeList() ", sqEx);
			throw sqEx;
		} finally {
			ConnectionUtil.closeResources(connection, pStmt, rs);
		}
		return orgList;

	}

	public List getOrganizationIDNames(String domainName, String roleCode) throws SQLException {
		 String query =
		"SELECT ORGID,ORGNAME FROM ORGHIERARCHY WHERE ORGHIERARCHYTYPECODE='ORG' AND ORGROLECODE=? AND DOMAINNAME IN(?,'PUBLIC') ORDER BY ORGNAME";
		Connection connection = null;
		PreparedStatement pStmt = null;
		ResultSet rs = null;
		List orgList = new ArrayList();
		try {
			logger.debug("getOrganizationIDNames query: " + query);
			connection = getConnection();
			pStmt = connection.prepareStatement(query);
			pStmt.setString(1, roleCode);
			pStmt.setString(2, domainName);
			for (rs = pStmt.executeQuery(); rs.next();) {
				orgList.add(new OptionBean(rs.getString(2), rs.getString(1))); // label,
																				// value
			}
		} catch (SQLException sqEx) {
			logger.error("getOrganizationIDNames(domainName, roleCode) ", sqEx);
			throw sqEx;
		} finally {
			ConnectionUtil.closeResources(connection, pStmt, rs);
		}
		return orgList;
	}

	public List getOrganizationReferenceTypeCodesList(String domainName) throws SQLException {
		try {
			List referenceTypeCodesList = orghierarchyDAO.retrieveOrgRefTypeCodeList(domainName);
			return referenceTypeCodesList;
		} catch (SQLException sqEx) {
			logger.error("getOrganizationReferenceTypeCodesList(domainName)  " + sqEx);
			throw sqEx;
		} catch (Exception ex) {
			logger.error("getOrganizationReferenceTypeCodesList(domainName)  " + ex);
			throw new EJBException(ex);
		}
	}

	public void fillLcpReferenceData(LcpReferenceData lcpReferenceData, String domainName) throws SQLException {
		Connection connection = null;
		PreparedStatement pStmt = null;
		ResultSet rs = null;
		String qStr[] = new String[3];
		qStr[0] = "SELECT ORGREFERENCETYPECODE, ORGREFERENCETYPENAME FROM ORGREFERENCETYPE WHERE DOMAINNAME IN(?,'PUBLIC') ORDER BY ORGREFERENCETYPENAME";
		qStr[1] = "SELECT ORGHIERARCHYTYPECODE,ORGHIERARCHYTYPENAME FROM ORGHIERARCHYTYPE WHERE DOMAINNAME IN(?,'PUBLIC') ORDER BY ORGHIERARCHYTYPENAME";
		qStr[2] = "SELECT ORGROLECODE,ORGROLENAME FROM ORGROLE WHERE DOMAINNAME IN(?,'PUBLIC') ORDER BY ORGROLENAME";
		try {
			List aList[] = new ArrayList[qStr.length];
			Map aMap[] = new HashMap[qStr.length];
			aList[0] = lcpReferenceData.getOrganizationReferenceTypeCodesList();
			aList[1] = lcpReferenceData.getOrghierarchyTypeCodesList();
			aList[2] = lcpReferenceData.getOrgRoleCodesList();
			aMap[0] = lcpReferenceData.getOrganizationReferenceTypeCodesMap();
			aMap[1] = lcpReferenceData.getOrghierarchyTypeCodesMap();
			aMap[2] = lcpReferenceData.getOrgRoleCodesMap();
			connection = getConnection();
			for (int i = 0; i < qStr.length; i++) {
				logger.debug("Query " + i + ": " + qStr[i]);
				pStmt = connection.prepareStatement(qStr[i]);
				pStmt.clearParameters();
				pStmt.setString(1, domainName);
				rs = pStmt.executeQuery();
				while (rs.next()) {
					aList[i].add(new OptionBean(rs.getString(2), rs.getString(1))); // label,
																					// value
					aMap[i].put(rs.getString(1), rs.getString(2)); // code and
																	// name pair
																	// where
																	// code is
																	// the key
				}
				ConnectionUtil.closeResources(null, pStmt, rs);
				logger.debug("Query " + i + " finished successfully");
			}
			// NO NEED TO SET THE LISTS/MAPS BACK ON THE LcpReferenceData (WE
			// ONLY HAD REFERENCES)
		} catch (SQLException sqEx) {
			logger.error("fillLcpReferenceData(lcpReferenceData,domainName) ", sqEx);
			throw sqEx;
		} finally {
			ConnectionUtil.closeResources(connection, pStmt, rs);
		}
		return;
	}

	/**
	 * This method returns the type code of the org given ORG ID.
	 * 
	 * @param orgId
	 *            The ID of the org
	 * @return "ORG", "LOC", "CON" or "" if no orgID is found.
	 */
	public String getOrgType(long orgId) throws SQLException {
		Connection connection = null;
		PreparedStatement pStmt = null;
		ResultSet rs = null;
		String orgType = "";
		try {
			String typeQuery = "SELECT ORGHIERARCHYTYPECODE  FROM ORGHIERARCHY WHERE ORGID=?";
			logger.debug("getOrgType(): typeQuery is " + typeQuery);
			connection = getConnection();
			pStmt = connection.prepareStatement(typeQuery);
			pStmt.setLong(1,orgId);
			rs = pStmt.executeQuery();
			if (rs.next())
				orgType = rs.getString(1);
		} catch (SQLException sqEx) {
			logger.error("getOrgName(addressId)", sqEx);
			throw sqEx;
		} finally {
			ConnectionUtil.closeResources(connection, pStmt, rs);
		}
		return orgType;
	}

	/**
	 * Gets list of all parent and child Ids, as defined below.
	 * <OL>
	 * <LI>If org Id is passed as argument it will return a list of all the
	 * childIds.
	 * <LI>If LocId is passed as a parameter then first it will get the OrgId
	 * whose type is ORG using getRootOrgId method and returns a list of all the
	 * childIds
	 * <LI>If conId is passed as a parameter then first it will get the OrgId
	 * whose type is ORG using getRootOrgId method irrespective of it's parent
	 * and returns a list of all the childIds.
	 * </OL>
	 * 
	 * @return List of java.lang.Long objects that contain IDs of ORGs as
	 *         defined above
	 */
	public List getOrgIdList(long actualOrgId) throws SQLException {
		long orgId = actualOrgId;
		List orgIdsList = new ArrayList();
		Connection connection = null;
		ResultSet rs = null;
		PreparedStatement pStmt = null;
		try {
			String query = "SELECT ORGID, ORGHIERARCHYTYPECODE FROM ORGHIERARCHY WHERE PARENTORGID=?";
			logger.debug("getOrgIdList : ORGHIERARCHY Query is " + query);
			// Gets the orgHierarchyTypeCode for the actualOrgId
			String orgHierarchyTypeCode = getOrgType(actualOrgId);
			connection = getConnection();
			if (!orgHierarchyTypeCode.equalsIgnoreCase("ORG")) {
				orgId = getRootOrgId(orgId);
				orgIdsList.add(new Long(orgId));
				List locationIdsList = new ArrayList();
				pStmt = connection.prepareStatement(query);
				pStmt.setLong(1, orgId);
				rs = pStmt.executeQuery();
				while (rs.next()) {
					String hierarchyType = rs.getString(2);
					if (hierarchyType.equals("LOC"))
						locationIdsList.add(new Long(rs.getLong(1)));
					else if (hierarchyType.equals("CON"))
						orgIdsList.add(new Long(rs.getLong(1)));
				}
				ConnectionUtil.closeResources(null, pStmt, rs);

				if (locationIdsList.size() > 0) {
					pStmt = connection.prepareStatement(query);
					for (int i = 0; i < locationIdsList.size(); i++) {
						long locationId = ((Long) locationIdsList.get(i)).longValue();
						orgIdsList.add(new Long(locationId));
						pStmt.setLong(1, locationId);
						rs = pStmt.executeQuery();
						while (rs.next()) {
							orgIdsList.add(new Long(rs.getLong(1)));
							orgHierarchyTypeCode = rs.getString(2);
						}
						ConnectionUtil.closeResources(null, null, rs);
					}
				}
			} else {
				orgIdsList.add(new Long(orgId));
				ArrayList locationIdsList = new ArrayList();
				pStmt = connection.prepareStatement(query);
				pStmt.setLong(1, orgId);
				for (rs = pStmt.executeQuery(); rs.next();) {
					String hierarchyType = rs.getString(2);
					if (hierarchyType.equals("LOC"))
						locationIdsList.add(new Long(rs.getLong(1)));
					else if (hierarchyType.equals("CON"))
						orgIdsList.add(new Long(rs.getLong(1)));
				}
				ConnectionUtil.closeResources(null, pStmt, rs);
				if (locationIdsList.size() > 0) {
					pStmt = connection.prepareStatement(query);
					for (int i = 0; i < locationIdsList.size(); i++) {
						long locationId = ((Long) locationIdsList.get(i)).longValue();
						orgIdsList.add(new Long(locationId));

						pStmt.setLong(1, locationId);
						for (rs = pStmt.executeQuery(); rs.next(); orgIdsList.add(new Long(rs.getLong(1))))
							orgHierarchyTypeCode = rs.getString(2);

						ConnectionUtil.closeResources(null, null, rs);
					}
				}
			}
		} catch (SQLException sqEx) {
			logger.error("getOrgIdList(orgId)", sqEx);
			throw sqEx;
		} finally {
			ConnectionUtil.closeResources(connection, pStmt, rs);
		}
		return orgIdsList;
	}

	/**
	 * This method returns Id whose type is ORG. If Id passed is of type "ORG"
	 * then it will return the same Id If Id passed is of type "LOC" then it
	 * will search for its root of Type "ORG" and return that Id If Id passed is
	 * of type "CON" then it will search for its root of Type "ORG" and return
	 * that Id
	 */
	public long getRootOrgId(long actualOrgId) throws SQLException {
		long orgId = 0L;
		Connection connection = null;
		PreparedStatement pStmt = null;
		ResultSet rs = null;
		String query = "SELECT PARENTORGID, ORGHIERARCHYTYPECODE FROM ORGHIERARCHY WHERE ORGID=?";
		try {
			logger.debug("getRootOrgId(): ORGHIERARCHY Query is " + query);
			String orgHierarchyType = getOrgType(actualOrgId);
			connection = getConnection();
			if (orgHierarchyType.equalsIgnoreCase("LOC")) {
				pStmt = connection.prepareStatement(query);
				pStmt.setLong(1, actualOrgId);
				for (rs = pStmt.executeQuery(); rs.next();) {
					orgId = rs.getLong(1);
				}
				ConnectionUtil.closeResources(null, pStmt, rs);
			} else if (orgHierarchyType.equalsIgnoreCase("CON")) {
				long contactParentOrgId = 0L;
				pStmt = connection.prepareStatement(query);
				pStmt.setLong(1, actualOrgId);
				for (rs = pStmt.executeQuery(); rs.next();) {
					String hierarchyType = rs.getString(2);
					if (hierarchyType.equals("ORG"))
						orgId = rs.getLong(1);
					else
						contactParentOrgId = rs.getLong(1);
				}
				ConnectionUtil.closeResources(null, pStmt, rs);
				pStmt = null;
				rs = null;
				if (orgId == 0L && contactParentOrgId != 0L) {
					pStmt = connection.prepareStatement(query);
					pStmt.setLong(1, actualOrgId);
					for (rs = pStmt.executeQuery(); rs.next();) {
						orgId = rs.getLong(1);
					}
					ConnectionUtil.closeResources(null, pStmt, rs);
				}
			}
		} catch (SQLException sqEx) {
			logger.error("getRootOrgId(orgId)", sqEx);
			throw sqEx;
		} finally {
			ConnectionUtil.closeResources(connection, pStmt, rs);
		}
		logger.debug("Root OrgId: " + orgId);
		return orgId;
	}


	/**
	 * Finds if the given type code and value exist in the data base.
	 */
	public boolean orgRefValuePairExist(String orgRefCode, String orgRefValue) throws SQLException {
		logger.debug("orgRefValuePairExist() begin ");

		String query = "SELECT ORGREFERENCETYPECODE,ORGREFERENCEVALUE FROM ORGREFERENCE WHERE ORGREFERENCETYPECODE='" + orgRefCode + "' AND ORGREFERENCEVALUE ='" + orgRefValue + "'";
		logger.debug("orgRefValuePairExist : ORGHIERARCHY Query is: " + query);
		Connection connection = getConnection();
		Statement statement = connection.createStatement();
		ResultSet rs = null;
		try {
			rs = statement.executeQuery(query);
			if (rs.next()) {
				return true;
			} else {
				return false;
			}		
		} catch (Exception sqEx) {
			logger.error("getOrgId(orgId,type) ", sqEx);
			throw new EJBException(sqEx);
		} finally {
			ConnectionUtil.closeResources(connection, statement, rs);
		}		
	}

	/**
	 * Gets the map of parent org ids.
	 */
	public Map getParents(long orgId, String type) throws SQLException {
		logger.debug("getParents(): begin");

		Map map = new HashMap();

		Connection connection = null;
		Statement stmt = null;
		ResultSet rs = null;

		try {
			if (type == null) {
				type = getOrgType(orgId);
			}

			logger.debug("Type: " + type);

			connection = getConnection();
			stmt = connection.createStatement();
			String query = "SELECT PARENTORGID FROM ORGHIERARCHY WHERE ORGID=" + orgId;
			if (type.equals("LOC")) {				

				for (rs = stmt.executeQuery(query); rs.next();) {
					long id = rs.getLong(1);
					map.put("ORG", new Long(id));
				}
			} else if (type.equals("CON")) {				

				long id = 0L;				
				for (rs = stmt.executeQuery(query); rs.next();) {
					id = rs.getLong(1);
                    map.put("CON", new Long(id));				
			    }	
				rs.close();
				String typeQuery = "SELECT ORGHIERARCHYTYPECODE FROM ORGHIERARCHY WHERE ORGID=" + id;

				rs = stmt.executeQuery(typeQuery);
                ConnectionUtil.closeResources(null, null, rs);
				String typeId;

				for (typeId = ""; rs.next(); typeId = rs.getString(1)) {
				}

				if (typeId.equals("LOC")) {
					map.put("LOC", new Long(id));

					String orgQuery = "SELECT PARENTORGID FROM ORGHIERARCHY WHERE ORGID=" + id;

					long grandParentOrgid = 0L; // assuming parent of location
												// is of type ORG
					for (rs = stmt.executeQuery(orgQuery); rs.next();)
						grandParentOrgid = rs.getLong(1);

					map.put("ORG", new Long(grandParentOrgid));
					ConnectionUtil.closeResources(null, null, rs);
				} else if (typeId.equals("ORG")) {
					map.put("ORG", new Long(id));
				}
			}
		} catch (Exception sqEx) {
			logger.error("Exception in getParents (" + orgId + ",type) ", sqEx);
			throw new EJBException(sqEx);
		} finally {
			ConnectionUtil.closeResources(connection, stmt, rs);
		}
		return map;
	}
}
