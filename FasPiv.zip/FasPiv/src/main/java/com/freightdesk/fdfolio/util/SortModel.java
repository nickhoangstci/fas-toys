/** 
 * 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolio/util/SortModel.java,v 1.1.10.1 2010/08/22 23:08:34 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: SortModel.java,v $
 *  Revision 1.1.10.1  2010/08/22 23:08:34  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.1  2004/09/15 13:05:24  ranand
 *  2.6 Baseline
 *
 * 
 */



package com.freightdesk.fdfolio.util;

import java.util.ArrayList;
import java.util.Date;

import org.apache.log4j.Logger;

// Referenced classes of package com.freightdesk.fdfolio.util:
//            Logger

public class SortModel
{

    static Logger logger = Logger.getLogger("com.freightdesk.fdfolio.utilesk.fdfolio.util.SortModel");

    public SortModel()
    {
    }

    private static int partition(String strArry[][], int low, int high, String typeOfSort)
    {
        int up = low;
        int down = high;
        String compareStr = strArry[low][0];
        String tmpStr = "";
        String tmpIndex = "";
        do
        {
            if(typeOfSort.equals("up"))
            {
                for(; strArry[up][0].compareToIgnoreCase(compareStr) <= 0 && up < high; up++);
                for(; strArry[down][0].compareToIgnoreCase(compareStr) > 0; down--);
            } else
            {
                for(; strArry[up][0].compareToIgnoreCase(compareStr) >= 0 && up < high; up++);
                for(; strArry[down][0].compareToIgnoreCase(compareStr) < 0; down--);
            }
            if(up < down)
            {
                tmpStr = strArry[up][0];
                logger.debug("tmpStr is .............. "+tmpStr);
                tmpIndex = strArry[up][1];
                strArry[up][0] = strArry[down][0];
                strArry[up][1] = strArry[down][1];
                strArry[down][0] = tmpStr;
                strArry[down][1] = tmpIndex;
            }
        } while(up < down);
        tmpStr = strArry[low][0];
        tmpIndex = strArry[low][1];
        strArry[low][0] = strArry[down][0];
        strArry[low][1] = strArry[down][1];
        strArry[down][0] = tmpStr;
        strArry[down][1] = tmpIndex;
        int split = down;
        return split;
    }

    public void printAll()
    {
    }

    public static String[][] quickSort(String strArry[][], int low, int high, String typeOfSort)
    {
        int mid = 0;
        if(high > low)
        {
            mid = partition(strArry, low, high, typeOfSort);
            quickSort(strArry, low, mid - 1, typeOfSort);
            quickSort(strArry, mid + 1, high, typeOfSort);
        }
        return strArry;
    }


	private static int partition(Date dteArray[], int positions[],int low, int high, String typeOfSort)
	{
		int up = low;
		int down = high;
		logger.debug("in partition  dteArray "+dteArray);
		Date compareDate = dteArray[low];
		Date tmpDate = null;
		int tmpIndex = 0;
		do
		{
			logger.debug("in partition dteArray is "+dteArray);
        	logger.debug("in partition  positions is "+positions);
        	logger.debug("in partition  compareDate is "+compareDate);

			if(typeOfSort.equals("up"))			{
				for(; dteArray[up].compareTo(compareDate) <= 0 && up < high; up++);
				for(; dteArray[down].compareTo (compareDate) > 0; down--);
			}
			else {
				for(; dteArray[up].compareTo(compareDate) >= 0 && up < high; up++);
				for(; dteArray[down].compareTo(compareDate) < 0; down--);
			}

			if(up < down)
			{
				tmpDate = dteArray[up];
				logger.debug("tmpTimeStamp is .............. "+tmpDate);
				tmpIndex = positions[up];
				dteArray[up] = dteArray[down];
				positions[up] = positions[down];
				dteArray[down] = tmpDate;
				positions[down] = tmpIndex;
			}
		} while(up < down);
		tmpDate = dteArray[low];
		tmpIndex = positions[low];
		dteArray[low] = dteArray[down];
		positions[low] = positions[down];
		dteArray[down] = tmpDate;
		positions[down] = tmpIndex;
		int split = down;
		return split;
	}


	public static int [] quickSort(Date dteArray[], int positions[],int low, int high, String typeOfSort) {
		int mid = 0;
		logger.debug("in quickSort dteArray is "+dteArray);
        logger.debug("in quickSort  positions is "+positions);
		if(high > low)
		{
			mid = partition(dteArray, positions,low, high, typeOfSort);
			quickSort(dteArray, positions,low, mid - 1, typeOfSort);
			quickSort(dteArray, positions,mid + 1, high, typeOfSort);
		}
		return positions;
	}

    public static ArrayList sortByColumn(ArrayList orderSessionList, String typeOfSort, int columnNo)
    {
        ArrayList orderList = new ArrayList();
        String strArry[][] = new String[orderSessionList.size()][2];
        for(int loop = 0; loop < orderSessionList.size(); loop++)
        {
            strArry[loop][0] = ((String[])orderSessionList.get(loop))[columnNo];
            new String();
            strArry[loop][1] = String.valueOf(loop);
        }

        strArry = quickSort(strArry, 0, strArry.length - 1, typeOfSort);
        try
        {
            for(int loop = 0; loop < orderSessionList.size(); loop++)
                orderList.add((String[])orderSessionList.get(Integer.parseInt(strArry[loop][1])));

        }
        catch(Exception e)
        {
            logger.error("doSortByColumn() Exception ......." + e);
        }
        return orderList;
    }



}

