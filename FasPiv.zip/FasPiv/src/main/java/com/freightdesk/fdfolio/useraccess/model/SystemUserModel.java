/** 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolio/useraccess/model/SystemUserModel.java,v 1.5.2.1 2009/10/06 18:22:23 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: SystemUserModel.java,v $
 *  Revision 1.5.2.1  2009/10/06 18:22:23  mechevarria
 *  add email attribute to the model
 *
 *  Revision 1.5  2006/10/11 07:52:08  ranand
 *  removed dependency on USERSYSTEMROLE table
 *
 *  Revision 1.4  2006/03/28 21:23:07  aarora
 *  Repackaging of fdcommons
 *
 *  Revision 1.3  2005/08/01 09:41:08  pjain
 *  refactored UserModel to BaseModel
 *
 *  Revision 1.2  2004/10/20 04:04:07  amrinder
 *  Corrected JavaDoc comments
 *
 *  Revision 1.1  2004/09/15 13:07:11  ranand
 *  2.6 Baseline
 */

package com.freightdesk.fdfolio.useraccess.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.freightdesk.fdcommons.BaseModel;

/**  
 * Models a system user.
 * @author Mike Echevarria
 */

@Entity
@Table(name = "SYSTEMUSER")
public class SystemUserModel extends BaseModel
    implements Serializable
{

	/**
	 * 
	 */
	private static final long serialVersionUID = -3391212492559455550L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SYSTEMUSERID")
	@SequenceGenerator(name = "SYSTEMUSERID", sequenceName = "SYSTEMUSERID")
	private long systemUserId;
	
	private long orgId;

	private String timeZoneId;
    private String userId;

    private String passphraseHash;
    private Timestamp passwordExpirationDate;
    private Timestamp lastLoginTimestamp;
    private long isPasswordAutoExpire;
    private long autoExpireDays;
    private String uomCode;
    private String currencyCode;
    private String dateFormat;
    private String isActive;
    private String systemRoleCode;
    private int numFailedLogin;
    
    // not to be persisted in database.
    @Transient
    private String password;
    
    @Transient
    private String orgName;
    
    @Transient
    private String contactFirstName;
    
    @Transient
    private String contactLastName;
    
    @Transient
    private String communicationMethod;
    
    @Transient
    private String confirmPassword;
    
    @Transient
    private String email;

    public SystemUserModel()
    {

    }

    public int getNumFailedLogin() {
		return numFailedLogin;
	}


	public void setNumFailedLogin(int numFailedLogin) {
		this.numFailedLogin = numFailedLogin;
	}

	public SystemUserModel(long systemUserId, long orgId, String timeZoneId, String userId, String password, Timestamp passwordExpirationDate, long isPasswordAutoExpire, long autoExpireDays, String domainName, String uomCode, String currencyCode, 
            String dateFormat, String isActive)
    {
        this.systemUserId = systemUserId;
        this.orgId = orgId;
        this.timeZoneId = timeZoneId;
        this.userId = userId;
        this.password = password;
        this.passwordExpirationDate = passwordExpirationDate;
        this.isPasswordAutoExpire = isPasswordAutoExpire;
        this.autoExpireDays = autoExpireDays;
        this.domainName = domainName;
        this.uomCode = uomCode;
        this.currencyCode = currencyCode;
        this.dateFormat = dateFormat;
		this.systemRoleCode = systemRoleCode;
        this.isActive = isActive;

    }

//added by Sangeeta
public SystemUserModel(long systemUserId,long orgId, String timeZoneId, String userId, String password, Timestamp passwordExpirationDate, long passwordAutoExpire, long autoExpireDays, String domainName, String uomCode, String currencyCode, 
            String dateFormat, String orgName, String contactFirstName,String contactLastName,String communicationMethod,Timestamp lastLoginTimestamp, String isActive)
    {
           this(systemUserId,orgId, timeZoneId, userId, password,  passwordExpirationDate,  passwordAutoExpire, autoExpireDays, domainName, uomCode,  currencyCode,  dateFormat, isActive);
         this.orgName = orgName;
         this.contactFirstName = contactFirstName;
         this.contactLastName = contactLastName;
         this.communicationMethod = communicationMethod;
         this.lastLoginTimestamp = lastLoginTimestamp;
		 this.systemRoleCode = systemRoleCode;
         this.isActive = isActive;
    }

    /**
     * Implements the abstract method defined by BaseModel.
     * @return primaryKey  the unique id key for this model object.
     */
    public long getPrimaryKey(){
        return this.systemUserId;
    }  

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		if(email == null)
			this.email="";
		this.email = email;
	}

	public long getSystemUserId()
    {
        return this.systemUserId;
    }

    public long getAutoExpireDays()
    {
        return autoExpireDays;
    }

    public String getCurrencyCode()
    {
       return (this.currencyCode==null?"":this.currencyCode);

    }

    public String getDateFormat()
    {
         return (this.dateFormat==null?"":this.dateFormat);
    }

    public String getDomainName()
    {
        return (this.domainName==null?"":this.domainName);
    }

    public long getIsPasswordAutoExpire()
    {
        return isPasswordAutoExpire;
    }

    public long getOrgId()
    {
        return orgId;
    }

    public String getPassword()
    {
        return (this.password==null?"":this.password);
    }

    public Timestamp getPasswordExpirationDate()
    {
        return passwordExpirationDate;
    }

    public java.sql.Timestamp getLastLoginTimestamp()
    {
        return lastLoginTimestamp;
    }

    public String getTimeZoneId()
    {
        return (this.timeZoneId==null?"":this.timeZoneId);
    }

    public String getUomCode()
    {
        return (this.uomCode==null?"":this.uomCode);
    }

    public String getUserId()
    {
        return (this.userId==null?"":this.userId);
    }


    public void setSystemUserId(long systemUserId)
    {
        this.systemUserId = systemUserId;
    }

    public void setAutoExpireDays(long autoExpireDays)
    {
        this.autoExpireDays = autoExpireDays;
    }

    public void setCurrencyCode(String currencyCode)
    {
        this.currencyCode = currencyCode;
    }

    public void setDateFormat(String dateFormat)
    {
        this.dateFormat = dateFormat;
    }

    public void setDomainName(String domainName)
    {
        this.domainName = domainName;
    }

    public void setIsPasswordAutoExpire(long isPasswordAutoExpire)
    {
        this.isPasswordAutoExpire = isPasswordAutoExpire;
    }

    public void setOrgId(long orgId)
    {
        this.orgId = orgId;
    }

    public void setPassword(String password)
    {
        this.password = password;
    }

    public void setPasswordExpirationDate(Timestamp passwordExpirationDate)
    {
        this.passwordExpirationDate = passwordExpirationDate;
    }

    public void setLastLoginTimestamp(Timestamp lastLoginTimestamp)
    {
        this.lastLoginTimestamp = lastLoginTimestamp;
    }
  
    public void setTimeZoneId(String TimeZoneId)
    {
        timeZoneId = TimeZoneId;
    }

    public void setUomCode(String uomCode)
    {
        this.uomCode = uomCode;
    }

    public void setUserId(String userId)
    {
        this.userId = userId;
    }

   //added by Sangeeta
    public String getOrgName()
    {
        return (this.orgName==null?"":this.orgName);
    }

    public void setOrgName(String orgName)
    {
        this.orgName = orgName;
    }

    public String getContactFirstName()
    {
        return (this.contactFirstName==null?"":this.contactFirstName);
    }

    public void setContactFirstName(String contactFirstName)
    {
        this.contactFirstName = contactFirstName;
    }

     public String getContactLastName()
     {
        return (this.contactLastName==null?"":this.contactLastName);
     }

     public void setContactLastName(String contactLastName)
     {
            this.contactLastName = contactLastName;
       }

     public String getCommunicationMethod()
      {
           return (this.communicationMethod==null?"":this.communicationMethod);
     }

     public void setCommunicationMethod(String communicationMethod)
     {
          this.communicationMethod = communicationMethod;
        }

     public String getIsActive()
      {
           return (this.isActive==null?"":this.isActive);
     }

     public void setIsActive(String isActive)
     {
          this.isActive = isActive;
        }



       public String getFullName()
     {
        String name;

        if ((!getContactFirstName().equals(""))&&(!getContactLastName().equals("")))
         {
               name = getContactFirstName()+" "+getContactLastName();
         }
         else if  (getContactFirstName().equals(""))
         {
             name=getContactLastName();
         }
         else
         {
              name=getContactFirstName();
         }
         return name;
    }

    /**
     * @return
     */
    public String getPassphraseHash() {
        return passphraseHash;
    }

    /**
     * @param string
     */
    public void setPassphraseHash(String passphraseHash) {
        this.passphraseHash = passphraseHash;
    }

    /**
     * @return
     */
    public String getConfirmPassword() {
        return confirmPassword;
    }

    /**
     * @param confirmPassword
     */
    public void setConfirmPassword(String confirmPassword) {
        this.confirmPassword = confirmPassword;
    }

    /**
     * @return Returns the systemRoleCode.
     */
    public String getSystemRoleCode()
    {
        return systemRoleCode;
    }

    /**
     * @param systemRoleCode The systemRoleCode to set.
     */
    public void setSystemRoleCode(String systemRoleCode)
    {
        this.systemRoleCode = systemRoleCode;
    }
    
	public String toString() {
		return "SystemUserModel [systemUserId=" + systemUserId + ", timeZoneId=" + timeZoneId + ", userId=" + userId + ", password=" + password + ", passphraseHash=" + passphraseHash
				+ ", passwordExpirationDate=" + passwordExpirationDate + ", lastLoginTimestamp=" + lastLoginTimestamp + ", isPasswordAutoExpire=" + isPasswordAutoExpire + ", autoExpireDays="
				+ autoExpireDays + ", domainName=" + domainName + ", uomCode=" + uomCode + ", currencyCode=" + currencyCode + ", dateFormat=" + dateFormat + ", isActive=" + isActive + ", systemRoleCode="
				+ systemRoleCode + ", createUserId=" + createUserId + ", createTimestamp=" + createTimestamp + ", lastUpdateUserId=" + lastUpdateUserId + ", lastUpdateTimestamp="
				+ lastUpdateTimestamp + ", status=" + status + "]";
	}
}

