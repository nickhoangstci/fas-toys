/** 
 * 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolio/invoice/model/OtherWeightsAndMeasureModel.java,v 1.4.4.2 2010/08/22 23:08:32 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: OtherWeightsAndMeasureModel.java,v $
 *  Revision 1.4.4.2  2010/08/22 23:08:32  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.4.4.1  2008/06/03 12:39:04  mechevarria
 *  gov_solutions merge updates
 *
 *  Revision 1.6  2007/04/12 05:32:37  dkumar
 *  method applyPartitionTimestamp added.
 *
 *  Revision 1.5  2007/04/11 11:59:27  nsehra
 *  added method applyPartitionTimeStamp for Data Partitioning
 *
 *  Revision 1.4  2006/03/28 21:23:01  aarora
 *  Repackaging of fdcommons
 *
 *  Revision 1.3  2005/08/01 09:41:08  pjain
 *  refactored UserModel to BaseModel
 *
 *  Revision 1.2  2005/03/15 15:59:13  kdinh
 *  Added legId and legContainerId
 *
 *  Revision 1.1  2004/09/23 13:41:20  ranand
 *  package changed from settlement to invoice
 *
 *  Revision 1.1  2004/09/15 13:20:00  ranand
 *  2.6 Baseline
 *
 * 
 */


package com.freightdesk.fdfolio.invoice.model;

import java.sql.Timestamp;

import com.freightdesk.fdcommons.BaseModel;

/**
 * @author Biju.Joseph
 *
 * This class describes a OtherWeightsAndMeasure object. It defines getter and setter methods
 * for accessing individual fields.
 *
 */

public class OtherWeightsAndMeasureModel extends BaseModel {
	private long otherWeightsAndMeasureId;
	private long domainObjectId;
	private long eventId;
	private long invoiceLineItemId;
	private String domainObjectType;
	private String measureQualifer;
	private String measureTypeCode;
	private double measureValue;
	private String unitOfMeasure;
    private long invoiceId;
    private long invoiceDetailId;
    private long legContainerId;
    private long legId;
	
	// added shipmentid    
	private long shipmentId;
	


	/**
	 * Default Constructor for OtherWeightsAndMeasureModel.
	 */
	public OtherWeightsAndMeasureModel() {
		super();
	}

	public OtherWeightsAndMeasureModel(
		long otherWeightsAndMeasureId,
		long domainObjectId,
		long eventId,
		long invoiceLineItemId,
		String measureTypeCode,
		double measureValue,
		String measureQualifer,
		String unitOfMeasure,
		String domainObjectType,
		String createUserId,
		Timestamp createTimestamp,
		String lastUpdateUserId,
		Timestamp lastUpdateTimestamp,
		String domainName) {

		super(
			createUserId,
			createTimestamp,
			lastUpdateUserId,
			lastUpdateTimestamp,
			domainName);

		this.domainObjectId = domainObjectId;
		this.domainObjectType = domainObjectType;
		this.eventId = eventId;
		this.invoiceLineItemId = invoiceLineItemId;
		this.measureQualifer = measureQualifer;
		this.measureTypeCode = measureTypeCode;
		this.measureValue = measureValue;
		this.otherWeightsAndMeasureId = otherWeightsAndMeasureId;
		this.unitOfMeasure = unitOfMeasure;
	}

	/**
	 * Returns the domainObjectId.
	 * @return long
	 */
	public long getDomainObjectId() {
		return domainObjectId;
	}

	/**
	 * Returns the domainObjectType.
	 * @return String
	 */
	public String getDomainObjectType() {
		if (domainObjectType == null)
			return "";
		return domainObjectType;
	}

	/**
	 * Returns the eventId.
	 * @return long
	 */
	public long getEventId() {
		return eventId;
	}

	/**
	 * Returns the invoiceLineItemId.
	 * @return long
	 */
	public long getInvoiceLineItemId() {
		return invoiceLineItemId;
	}

	/**
	 * Returns the measureQualifer.
	 * @return String
	 */
	public String getMeasureQualifer() {
		if (measureQualifer == null)
			return "";
		return measureQualifer;
	}

	/**
	 * Returns the measureTypeCode.
	 * @return String
	 */
	public String getMeasureTypeCode() {
		if (measureTypeCode == null)
			return "";
		return measureTypeCode;
	}

	/**
	 * Returns the measureValue.
	 * @return double
	 */
	public double getMeasureValue() {
		return measureValue;
	}

	/**
	 * Returns the unitOfMeasure.
	 * @return long
	 */
	public String getUnitOfMeasure() {
		return unitOfMeasure;
	}

	/**
	 * Sets the domainObjectId.
	 * @param domainObjectId The domainObjectId to set
	 */
	public void setDomainObjectId(long domainObjectId) {
		this.domainObjectId = domainObjectId;
	}

	/**
	 * Sets the domainObjectType.
	 * @param domainObjectType The domainObjectType to set
	 */
	public void setDomainObjectType(String domainObjectType) {
		this.domainObjectType = domainObjectType;
	}

	/**
	 * Sets the eventId.
	 * @param eventId The eventId to set
	 */
	public void setEventId(long eventId) {
		this.eventId = eventId;
	}

	/**
	 * Sets the invoiceLineItemId.
	 * @param invoiceLineItemId The invoiceLineItemId to set
	 */
	public void setInvoiceLineItemId(long invoiceLineItemId) {
		this.invoiceLineItemId = invoiceLineItemId;
	}

	/**
	 * Sets the measureQualifer.
	 * @param measureQualifer The measureQualifer to set
	 */
	public void setMeasureQualifer(String measureQualifer) {
		this.measureQualifer = measureQualifer;
	}

	/**
	 * Sets the measureTypeCode.
	 * @param measureTypeCode The measureTypeCode to set
	 */
	public void setMeasureTypeCode(String measureTypeCode) {
		this.measureTypeCode = measureTypeCode;
	}

	/**
	 * Sets the measureValue.
	 * @param measureValue The measureValue to set
	 */
	public void setMeasureValue(double measureValue) {
		this.measureValue = measureValue;
	}

	/**
	 * Sets the unitOfMeasure.
	 * @param unitOfMeasure The unitOfMeasure to set
	 */
	public void setUnitOfMeasure(String unitOfMeasure) {
		this.unitOfMeasure = unitOfMeasure;
	}

	/**
	 * @returns the otherWeightsAndMeasureId
	 */
	public long getOtherWeightsAndMeasureId() {
		return otherWeightsAndMeasureId;
	}

	/**
	 * @param otherWeightsAndMeasureId
	 */
	public void setOtherWeightsAndMeasureId(long otherWeightsAndMeasureId) {
		this.otherWeightsAndMeasureId = otherWeightsAndMeasureId;
	}

	/*
	com.freightdesk.fdfolio.utilesk.fdfolio.util.UserModel#getPrimaryKey()
	 */
	public long getPrimaryKey() {
		return otherWeightsAndMeasureId;
	}

    /**
     * @return
     */
    public long getShipmentId()
    {
        return shipmentId;
    }

    /**
     * @param  shipmentId
     */
    public void setShipmentId(long shipmentId)
    {
        this.shipmentId = shipmentId;
    }

	/**
	 * Returns the invoiceId.
	 * @return String
	 */
	public long getInvoiceId() {
		return invoiceId;
	}

	/**
	 * Sets the invoiceId.
	 * @param invoiceId The invoiceId to set
	 */
	public void setInvoiceId(long invoiceId) {
		this.invoiceId = invoiceId;
	}

	/**
	 * Returns the invoiceDetailId.
	 * @return long
	 */
	public long getInvoiceDetailId() {
		return invoiceDetailId;
	}

	/**
	 * Sets the invoiceDetailId.
	 * @param invoiceDetailId The invoiceDetailId to set
	 */
	public void setInvoiceDetailId(long invoiceDetailId) {
		this.invoiceDetailId = invoiceDetailId;
	}

	/**
	 * @return Returns the legContainerId.
	 */
	public long getLegContainerId() {
		return legContainerId;
	}
	/**
	 * @param legContainerId The legContainerId to set.
	 */
	public void setLegContainerId(long legContainerId) {
		this.legContainerId = legContainerId;
	}
	/**
	 * @return Returns the legId.
	 */
	public long getLegId() {
		return legId;
	}
	/**
	 * @param legId The legId to set.
	 */
	public void setLegId(long legId) {
		this.legId = legId;
	}

}
