/** 
 * 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolio/util/SetPassword.java,v 1.2.4.2 2010/08/22 23:08:34 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: SetPassword.java,v $
 *  Revision 1.2.4.2  2010/08/22 23:08:34  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.2.4.1  2008/12/11 13:56:11  mechevarria
 *  passwordhasher reference now in commons
 *
 *  Revision 1.2  2006/05/11 16:55:27  aarora
 *  Many changes as the SessionKey class has been added to com.freightdesk.fdfolio.commons
 *
 *  Revision 1.1  2004/09/15 13:05:24  ranand
 *  2.6 Baseline
 *
 * 
 */


package com.freightdesk.fdfolio.util;
import org.apache.log4j.Logger;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import com.freightdesk.fdcommons.PasswordHasher;
/**                                                                                                                                
  * Updates the passwords in the DB with their hashes.                                                                              
  *                                                                                                                                 
  * @author nitin.gupta                                                                                                          
  */

public class SetPassword
{
    protected static Logger logger = Logger.getLogger(SetPassword.class);
	
	//	   using java.sql.{Statement, DriverManager, Connection, ResultSet,SQLEx.}                                                         
    /** Target database driver */
    public static String DBDriver = "oracle.jdbc.driver.OracleDriver";
    /** Target database userid */
    public static String dbUser = "scott";
    /** Target database password */
    public static String dbPass = "tiger";
    public static String dbUrl = "192.168.20.10:1521:LCPDB";
    public static String userName = null;
    public static String passPhrase = null;
    public static String domainName = null;
    public static void main(String args[])
    {
        try {
            if (args.length < 5) {
			    logger.debug ("USAGE IS: Java SetPassword DB_URL DB_USER DB_PW Username Passpharse");
                
                
            }
            /* Database URL */
            dbUrl = args[0];
            /* UserName  */
            dbUser = args[1];
            /* password  */
            dbPass = args[2];
            try {
                // separates the userName and domainName from userId
                int index = args[3].indexOf('.');
                userName = args[3].substring(index + 1, args[3].length());
                domainName = args[3].substring(0, index);
                passPhrase = args[4];
            }catch (Exception e) {
                 logger.debug ("Please enter Username properly. It should be username.domain:  " + e); 
				 
            }
            // load the Oracle driver by referencing it
            String conString = "jdbc:oracle:thin:@" + dbUrl;
            
            Class.forName(DBDriver);
            
            Connection con = DriverManager.getConnection(conString, dbUser, dbPass);
            
            PasswordHasher passwordHasher = new PasswordHasher();
            String passwordHash = passwordHasher.hashPassword(passPhrase);
            Statement stmt1 = con.createStatement();
            // Create an update statement here                                                                             
            String updateSql = "UPDATE SYSTEMUSER SET PASSPHRASEHASH = '" + passwordHash + "' WHERE USERID = '" + userName + "' and DOMAINNAME = '" + domainName + "'";
            // Run the update statement     
            
            int rowUpdated = stmt1.executeUpdate(updateSql);
            if(rowUpdated == 0){
			    logger.debug("User/Domain not found : " + args[3]);
            	
            } else{
				logger.debug("Password set for : " + args[3]);
				
            }
        } catch (SQLException sqle) {
            
			logger.error("Exception : " + sqle.getMessage());
        } catch (ClassNotFoundException cnfe) {
		    logger.debug("Failed to load JDBC/ODBC driver");
            
        }
        catch (Exception e)
        {
            
			logger.error("Exception : " + e.getMessage());
        }
    }
}
