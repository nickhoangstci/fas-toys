/**
 * Copyright (c) NTELX
 *  All rights reserved. 
 *
 * This software is the confidential and proprietary information of NTELX
 * ("Confidential Information").  You shall not disclose such Confidential Information
 * and shall use it only in accordance with the terms of the license agreement you entered
 * into with NTELX. 
 *
 *
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolio/securitydevice/util/DeviceHomeView.java,v 1.1 2007/07/12 10:53:49 atripathi Exp $
 *
 *  Modification History:
 *  $Log: DeviceHomeView.java,v $
 *  Revision 1.1  2007/07/12 10:53:49  atripathi
 *  moved from legcontainer.util package.
 *
 *  Revision 1.1  2007/02/13 05:31:56  atripathi
 *  database paging implemented
 *
 */
package com.freightdesk.fdfolio.securitydevice.util;

import java.util.ArrayList;
import java.util.List;

public class DeviceHomeView {
private List deviceList;
private long count;

/** Creates an instance of deviceList. */
public DeviceHomeView(){
	deviceList=new ArrayList();
}
/** 
 * Creates an instance of deviceList.
 * @param deviceList List of security devices
 * @param count 
 */
public DeviceHomeView(List deviceList, long count) {
    this.deviceList = deviceList;
    this.count = count;
}
public long getCount() {
	return count;
}
public void setCount(long count) {
	this.count = count;
}
public List getDeviceList() {
	return deviceList;
}
public void setDeviceList(List deviceList) {
	this.deviceList = deviceList;
}

}
