/**
 * Copyright (c) NTELX All rights reserved.
 *
 * This software is the confidential and proprietary information of NTELX
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the license
 * agreement you entered into with NTELX.
 *
 *
 * $Header:
 * /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolio/useraccess/ejb/UserAccessSLSBean.java,v
 * 1.31.2.37 2010/12/02 15:54:27 jhansford Exp $
 *
 * Modification History: $Log: UserAccessSLSBean.java,v $ Revision 1.31.2.37
 * 2010/12/02 15:54:27 jhansford Add UserID search
 *
 * Revision 1.31.2.36 2010/09/27 20:30:55 mechevarria pull in lastupdateuserid
 * and createuserid and timestamps
 *
 * Revision 1.31.2.35 2010/09/23 19:35:23 mechevarria remove ejb layer for
 * instantiating objects. direct calls to bean class now made
 *
 * Revision 1.31.2.34 2010/08/22 23:08:44 mechevarria update with company name
 * in copyright
 *
 * Revision 1.31.2.33 2010/06/21 22:15:54 mechevarria remove
 * checkruleconformance
 *
 * Revision 1.31.2.32 2010/06/16 19:06:54 mechevarria log all passwords in
 * history
 *
 * Revision 1.31.2.31 2010/04/30 22:31:47 mechevarria fix open resultsset
 *
 * Revision 1.31.2.30 2010/04/23 18:47:15 mechevarria cleanup function witn bind
 * vars
 *
 * Revision 1.31.2.29 2010/04/21 20:27:38 mechevarria fix open jdbc statements
 *
 * Revision 1.31.2.28 2010/04/21 19:39:36 mechevarria removed unused sql
 * statement
 *
 * Revision 1.31.2.27 2010/04/20 19:16:18 mechevarria close open result sets for
 * jdbc
 *
 * Revision 1.31.2.26 2010/03/15 14:44:38 mechevarria add ip address to loggin
 *
 * Revision 1.31.2.25 2010/02/11 22:12:43 mechevarria moved systemusermodel to
 * commons
 *
 * Revision 1.31.2.24 2010/02/03 20:32:52 mechevarria parameterize list
 *
 * Revision 1.31.2.23 2009/12/21 17:08:05 mechevarria add list of logins on
 * contact page
 *
 * Revision 1.31.2.22 2009/11/02 21:15:06 mechevarria use the
 * optioncollectionmanager
 *
 * Revision 1.31.2.21 2009/10/29 21:39:00 mechevarria use systemreferencedata in
 * fdcommons
 *
 * Revision 1.31.2.20 2009/10/06 18:22:10 mechevarria change getuserdetails to
 * outer join communiationmethod to get email
 *
 * Revision 1.31.2.19 2009/10/02 18:29:11 jhansford OPEN - issue FAS-67: Create
 * 9 pilot users http://jira.ntelx.net/browse/FAS-67
 *
 * Had to fix a bug that allows users to Updated through UI
 *
 * Revision 1.31.2.18 2009/09/30 15:09:48 jhansford Graceful handling of
 * updating and creating users with existing IDs. Previously it was oops.
 *
 * Revision 1.31.2.17 2009/09/23 18:02:58 mechevarria import clean via eclipse
 *
 * Revision 1.31.2.16 2009/09/22 19:32:42 mechevarria updated user management
 *
 * Revision 1.31.2.15 2009/08/17 15:17:43 mechevarria add logging for user
 * update
 *
 * Revision 1.31.2.14 2009/08/12 18:16:02 jhansford Added Pull Down to switch
 * domains on edit user page.
 *
 * Revision 1.31.2.13 2008/12/11 13:56:11 mechevarria passwordhasher reference
 * now in commons
 *
 * Revision 1.31.2.12 2007/12/05 14:12:52 mechevarria changed
 * getAllSystemUsers() to use bind variables in query
 *
 * Revision 1.31.2.11 2007/08/16 13:12:43 mechevarria added async logging to
 * user deletion
 *
 * Revision 1.31.2.10 2007/08/15 15:08:36 mechevarria added async logging of
 * user updates and user creation
 *
 * Revision 1.31.2.9 2007/08/13 19:20:06 mechevarria fix errorneous lookup keep
 * in the application properties
 *
 * Revision 1.31.2.8 2007/07/12 13:06:22 mechevarria removed prefixes from
 * queries
 *
 * Revision 1.31.2.7 2007/07/10 15:24:13 mechevarria bug fix for omission of
 * password in foliox messages
 *
 * Revision 1.31.2.6 2007/06/21 14:08:00 mechevarria update to fix bug with
 * password check removal. Password checking is now controlled by app.properties
 *
 * Revision 1.31.2.5 2007/06/14 14:15:05 mechevarria updated password change to
 * reset autoexpiredays and lastupdate in db
 *
 * Revision 1.31.2.4 2007/06/12 12:13:28 mechevarria change password history
 * variable to read from application properties instead of hard coded
 *
 * Revision 1.31.2.3 2007/06/01 16:14:05 mechevarria update checkruleconformance
 * and add additional methods to record and check password history
 *
 * Revision 1.31.2.2 2007/05/04 18:39:53 mechevarria change to restrict user
 * list to user domain
 *
 * Revision 1.31.2.1 2007/03/28 20:25:13 mechevarria merged changes from head
 * branch to fix domain admin rights issue
 *
 * Revision 1.31 2007/01/31 13:09:37 atripathi Query changed to show records
 * without a record in Orghierarchy.
 *
 * Revision 1.30 2007/01/16 06:54:31 atripathi query modified to show role name
 * instead of role code
 *
 * Revision 1.29 2007/01/04 19:35:34 ranand fixed SQlException corrected the
 * query
 *
 * Revision 1.28 2006/10/11 12:31:38 ranand removed dependency on
 * SYSTEMNAVIGATIONTYPE
 *
 * Revision 1.27 2006/10/11 09:55:42 ranand removed dependency on USERSYSTEMROLE
 * table
 *
 * Revision 1.26 2006/10/11 07:52:08 ranand removed dependency on USERSYSTEMROLE
 * table
 *
 * Revision 1.25 2006/08/11 20:31:01 dkumar changes for common login
 * functionality in FDSuite [moved exception classes to fdcommons]
 *
 * Revision 1.24 2006/04/26 22:38:56 ranand removed the logging of the password
 * and passpharse
 *
 * Revision 1.23 2006/04/15 01:25:22 aarora Removed redundant code
 *
 * Revision 1.22 2006/04/12 23:44:31 aarora Removed extra code
 *
 * Revision 1.21 2006/03/28 21:23:02 aarora Repackaging of fdcommons
 *
 * Revision 1.20 2005/09/13 13:15:05 nsehra role to permission mapping changes
 *
 * Revision 1.19 2005/09/09 00:33:05 amrinder Removed boolean
 * domainAdminsitrator argument to getAllSystemUsers method
 *
 * Revision 1.18 2005/08/24 08:41:58 pjain changed isActive types
 *
 * Revision 1.17 2005/08/23 12:18:16 pjain password expiry customization
 *
 * Revision 1.16 2005/08/20 12:35:36 pjain DAO movement impact
 *
 * Revision 1.15 2005/08/11 11:01:08 pjain added getOIDCredentials
 *
 * Revision 1.14 2005/02/16 21:53:25 amrinder Now using UserAccessDAO as an
 * instance variable
 *
 * Revision 1.13 2004/12/20 21:15:52 amrinder Added method comments
 *
 * Revision 1.12 2004/12/17 00:07:51 amrinder Creating invalid user exception
 * with a parameter no
 *
 * Revision 1.11 2004/12/01 08:40:57 asaxena InvalidUserExceptionMethod was
 * throwing null , corrected it to a errorString.
 *
 * Revision 1.10 2004/11/30 15:31:40 biju changed the log level
 *
 * Revision 1.9 2004/11/30 09:46:11 asingh 1) Minimize log statements, changed
 * level from INFO to DEBUG where necessary.
 *
 * Revision 1.8 2004/11/23 07:14:29 biju removed last login timestamp update
 * call from getCredentials method
 *
 * Revision 1.7 2004/11/22 22:28:21 amrinder Changing the log status
 *
 * Revision 1.6 2004/10/28 13:00:24 asaxena overloaded function
 * isValidUser(String userId, String password,String domain ,String
 * assocSystemFunctioncode) to check the valid user permission also
 *
 * Revision 1.5 2004/10/20 04:11:14 amrinder 1) Removed NamingException - DAO
 * constructors need not throw this exception anymore 2) Now caching an instance
 * of UserPreferenceDAO 3) Changed Exception handling to throw EJBException
 * whereever possible 4) Changed funny name isValidate to validateUser
 *
 * Revision 1.4 2004/10/12 18:05:50 amrinder Removing the code that uses the
 * PASSWORD column
 *
 * Revision 1.3 2004/10/06 00:03:39 amrinder Now retrieveing only first 10 chars
 * of the timezone name, so page doesnt get screwed if data is not proper, and
 * also trying to sort by hours difference
 *
 * Revision 1.2 2004/09/16 07:25:21 ranand package name changed from
 * organization to orghierarchy in fdfolio
 *
 * Revision 1.1 2004/09/15 13:07:11 ranand 2.6 Baseline
 */
package com.freightdesk.fdfolio.useraccess.ejb;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import javax.ejb.EJBException;
import javax.naming.directory.Attributes;

import com.freightdesk.fdfolio.dao.UserAccessDAO;
import com.freightdesk.fdfolio.dao.UserPreferenceDAO;
import com.freightdesk.fdfolio.orghierarchy.ejb.OrganizationSLSBean;
import com.freightdesk.fdfolio.setup.model.DataSetupModel;
import com.freightdesk.fdcommons.ApplicationProperties;
import com.freightdesk.fdcommons.BaseDao;
import com.freightdesk.fdcommons.BaseSLSBean;
import com.freightdesk.fdcommons.ConnectionUtil;
import com.freightdesk.fdcommons.Credentials;
import com.freightdesk.fdcommons.DuplicateRecordFoundException;
import com.freightdesk.fdcommons.InvalidUserException;
import com.freightdesk.fdcommons.OptionBean;
import com.freightdesk.fdcommons.PasswordExpiredException;
import com.freightdesk.fdcommons.PasswordHasher;
import com.freightdesk.fdcommons.ServiceLocator;
import com.freightdesk.fdcommons.UserNotActiveException;
import com.freightdesk.fdcommons.asyncprocess.AsyncProcessManager;
import com.freightdesk.fdcommons.asyncprocess.AsyncProcessingLogModel;
import com.freightdesk.fdfolio.useraccess.model.SystemUserModel;
import crt.com.ntelx.nxcommons.reporting.OptionCollectionManager;

/**
 * Facade for user management module.
 *
 * @author Biju Joseph
 * @author Nitin Gupta
 * @author Dheeraj Dhamija
 * @author Sangeeta Taneja
 */
public class UserAccessSLSBean extends BaseSLSBean {

    /**
     *
     */
    private static final long serialVersionUID = 1L;
    /**
     * An instance of user access DAO
     */
    protected UserAccessDAO userAccessDAO;
    /**
     * An instance of user preference DAO
     */
    protected UserPreferenceDAO userPreferenceDAO;
    private OptionCollectionManager collectionManager;

    /**
     * Creates a UserAccess SLS bean.
     */
    public UserAccessSLSBean() {
        userAccessDAO = new UserAccessDAO();
        userPreferenceDAO = new UserPreferenceDAO();
        collectionManager = OptionCollectionManager.getInstance();
    }

    /**
     * Creates a user.
     */
    public SystemUserModel createUser(SystemUserModel systemUserModel, Credentials credentials)
            throws DuplicateRecordFoundException {

        long systemUserId = 0L;

        try {
            logger.info("createUser(SystemUserModel) begin.");
            if (userAccessDAO.checkUserExists(systemUserModel)) {
                throw new DuplicateRecordFoundException("Duplicate record found!");
            }
            systemUserId = userAccessDAO.getNextID("SYSTEMUSERID");
            systemUserModel.setSystemUserId(systemUserId);

            
            userAccessDAO.create(systemUserModel, credentials);
            collectionManager.reset();
        } catch (DuplicateRecordFoundException ex) {
            logger.error("createUser(SystemUserModel): User exists, throwing a DuplicateRecordFoundException: ", ex);
            throw ex;
        } catch (Exception ex) {
            logger.error("Exception in createUser(SystemUserModel)", ex);
            throw new EJBException(ex);
        }
        return systemUserModel;
    }

    /**
     * Deletes specified system navigation types.
     */
    public void deleteSystemNavigationTypes(DataSetupModel dataSetupModel) {
        Connection connection = null;
        PreparedStatement pStmt = null;
        String deleteQuery = "DELETE FROM SYSTEMNAVIGATIONTYPE WHERE SYSTEMNAVIGATIONTYPECODE = ? ";
        try {
            connection = getConnection();
            pStmt = connection.prepareStatement(deleteQuery);
            pStmt.setString(1, dataSetupModel.getTypeCode());
            pStmt.executeUpdate();
        } catch (Exception e) {
            logger.error("Error occurred during deleteSystemNavigationTypes(DataSetupModel dataSetupModel): ", e);
            throw new EJBException(e);
        } finally {
            ConnectionUtil.closeResources(connection, pStmt, null);
        }
    }

    /**
     * Deletes specified system roles.
     */
    public void deleteSystemRoles(DataSetupModel dataSetupModel) {
        Connection connection = null;
        PreparedStatement pStmt = null;
        String deleteQuery = "DELETE FROM SYSTEMROLE WHERE SYSTEMROLECODE = ? ";
        try {
            connection = getConnection();
            pStmt = connection.prepareStatement(deleteQuery);
            pStmt.setString(2, dataSetupModel.getTypeCode());
            pStmt.executeUpdate();
        } catch (SQLException e) {
            logger.error("Error occurred during deleteSystemRoles(DataSetupModel)", e);
            throw new EJBException(e);
        } finally {
            ConnectionUtil.closeResources(connection, pStmt, null);
        }
    }

    private void editSystemNavigationTypes(DataSetupModel dataSetupModel, Connection connection) {
        PreparedStatement pStmt = null;
        String updateQuery = "UPDATE SYSTEMNAVIGATIONTYPE SET SYSTEMNAVIGATIONTYPENAME = ?, STATUS = ?, CREATEUSERID = ?, CREATETIMESTAMP = ?, LASTUPDATEUSERID = ?, LASTUPDATETIMESTAMP = ?, DOMAINNAME = ?  WHERE SYSTEMNAVIGATIONTYPECODE = ?";
        try {
            pStmt = connection.prepareStatement(updateQuery);
            pStmt.setString(1, dataSetupModel.getTypeName());
            pStmt.setString(2, dataSetupModel.getDataSetupStatus());
            pStmt.setString(3, dataSetupModel.getCreateUserId());
            pStmt.setTimestamp(4, dataSetupModel.getCreateTimestamp());
            pStmt.setString(5, dataSetupModel.getLastUpdateUserId());
            pStmt.setTimestamp(6, dataSetupModel.getLastUpdateTimestamp());
            pStmt.setString(7, dataSetupModel.getDomainName());
            pStmt.setString(8, dataSetupModel.getTypeCode());
            pStmt.executeUpdate();
        } catch (Exception e) {
            logger.error("Error occurred during editSystemNavigationTypes(dataSetupModel, connection)", e);
            throw new EJBException(e);
        } finally {
            ConnectionUtil.closeResources(null, pStmt, null);
        }
    }

    public void editSystemRoles(DataSetupModel dataSetupModel, Connection connection) {
        PreparedStatement pStmt = null;
        String updateQuery = "UPDATE SYSTEMROLE SET SYSTEMROLENAME = ?, STATUS = ?, CREATEUSERID = ?, CREATETIMESTAMP = ?, LASTUPDATEUSERID = ?, LASTUPDATETIMESTAMP = ?, DOMAINNAME = ?  WHERE  SYSTEMROLECODE = ?";
        try {
            pStmt = connection.prepareStatement(updateQuery);
            pStmt.setString(1, dataSetupModel.getTypeName());
            pStmt.setString(2, dataSetupModel.getDataSetupStatus());
            pStmt.setString(3, dataSetupModel.getCreateUserId());
            pStmt.setTimestamp(4, dataSetupModel.getCreateTimestamp());
            pStmt.setString(5, dataSetupModel.getLastUpdateUserId());
            pStmt.setTimestamp(6, dataSetupModel.getLastUpdateTimestamp());
            pStmt.setString(7, dataSetupModel.getDomainName());
            pStmt.setString(9, dataSetupModel.getTypeCode());
            pStmt.executeUpdate();
        } catch (Exception e) {
            logger.error("Exception in editSystemRoles(dataSetupModel, connection)", e);
            throw new EJBException(e);
        } finally {
            ConnectionUtil.closeResources(null, pStmt, null);
        }
    }

    /**
     * Loads the user preferences for the specified user.
     *
     * @param systemUserId
     * @return Map of user preferences
     */
    public Map loadUserPreferences(long systemUserId) {
        try {
            logger.debug("loadUserPreferences(systemUserId) " + systemUserId);
            
            Map preferenceMap = userPreferenceDAO.retrieveAllByUserId(systemUserId);
            return preferenceMap;
        } catch (Exception e) {
            logger.error("Exception in loadUserPreferences(systemUserId)", e);
            throw new EJBException(e);
        }
    }

    public Hashtable getFDRolePermissionList(List roleList, String domain) {
        Connection connection = null;
        ResultSet result = null;
        PreparedStatement pstmt = null;
        String listOfValues = "";
        Hashtable functionsList = new Hashtable();
        StringBuffer query = new StringBuffer("SELECT F.SYSTEMFUNCTIONCODE, F.SYSTEMFUNCTIONNAME FROM SYSTEMFUNCTION F, SYSTEMROLEFUNCTION R WHERE R.SYSTEMROLECODE  IN (?) AND   R.DOMAINNAME IN (? ,'PUBLIC')  AND R.SYSTEMFUNCTIONCODE=F.SYSTEMFUNCTIONCODE AND R.DOMAINNAME = F.DOMAINNAME");

        try {
            logger.debug("getFDRolePermissionList(roleList,domain) begin.\n [DQL]" + query.toString());
            connection = getConnection();
            pstmt = connection.prepareStatement(query.toString());
            // assumption is that user has only one role
            pstmt.setString(1, (String) roleList.get(0));
            pstmt.setString(2, domain);
            String functionCode;
            String functionName;
            for (result = pstmt.executeQuery(); result.next(); functionsList.put(functionCode, functionName)) {
                functionCode = result.getString(1);
                functionName = result.getString(2);
            }
            result.close();
            pstmt.close();
            connection.close();
        } catch (Exception sqEx) {
            logger.error("Error occurred during getFDRolePermissionList(roleList, domain)", sqEx);
            throw new EJBException(sqEx);
        } finally {
            ConnectionUtil.closeResources(connection, pstmt, result);
        }
        return functionsList;
    }

    public ArrayList getSystemNavigationTypes() {
        Connection connection = null;
        Statement stmt = null;
        ResultSet rs = null;
        ArrayList systemNavigationList = new ArrayList();
        String selQuery = "SELECT SYSTEMNAVIGATIONTYPECODE, SYSTEMNAVIGATIONTYPENAME, STATUS, CREATEUSERID, CREATETIMESTAMP, LASTUPDATEUSERID, LASTUPDATETIMESTAMP, DOMAINNAME FROM SYSTEMNAVIGATIONTYPE";
        try {
            connection = getConnection();
            stmt = connection.createStatement();
            String systemNavigationTypeCode;
            String systemNavigationTypeName;
            String status;
            String createUserId;
            java.sql.Timestamp createTimestamp;
            String lastUpdateUserId;
            java.sql.Timestamp lastUpdateTimestamp;
            String domainName;
            for (rs = stmt.executeQuery(selQuery); rs.next(); systemNavigationList.add(new DataSetupModel(systemNavigationTypeCode, systemNavigationTypeName, status, createUserId, createTimestamp, lastUpdateUserId, lastUpdateTimestamp, domainName))) {
                systemNavigationTypeCode = rs.getString(1);
                systemNavigationTypeName = rs.getString(2);
                status = rs.getString(3);
                createUserId = rs.getString(4);
                createTimestamp = rs.getTimestamp(5);
                lastUpdateUserId = rs.getString(6);
                lastUpdateTimestamp = rs.getTimestamp(7);
                domainName = rs.getString(8);
            }
        } catch (Exception e) {
            logger.error("Error occurred during getSystemNavigationTypes()", e);
            throw new EJBException(e);
        } finally {
            ConnectionUtil.closeResources(connection, stmt, rs);
        }
        return systemNavigationList;
    }

    /**
     * Gets the sytem roles.
     */
    public ArrayList getSystemRoles() {
        Connection connection = null;
        Statement stmt = null;
        ResultSet rs = null;
        ArrayList systemRoleList = new ArrayList();
        String selQuery = "SELECT  SYSTEMROLECODE, SYSTEMROLENAME, STATUS, CREATEUSERID, CREATETIMESTAMP, LASTUPDATEUSERID, LASTUPDATETIMESTAMP, DOMAINNAME FROM SYSTEMROLE";
        try {
            connection = getConnection();
            stmt = connection.createStatement();
            String systemRoleCode;
            String systemRoleName;
            String status;
            String createUserId;
            java.sql.Timestamp createTimestamp;
            String lastUpdateUserId;
            java.sql.Timestamp lastUpdateTimestamp;
            String domainName;
            for (rs = stmt.executeQuery(selQuery); rs.next(); systemRoleList.add(new DataSetupModel(systemRoleCode, systemRoleName, status, createUserId, createTimestamp, lastUpdateUserId, lastUpdateTimestamp, domainName))) {
                systemRoleCode = rs.getString(2);
                systemRoleName = rs.getString(3);
                status = rs.getString(4);
                createUserId = rs.getString(5);
                createTimestamp = rs.getTimestamp(6);
                lastUpdateUserId = rs.getString(7);
                lastUpdateTimestamp = rs.getTimestamp(8);
                domainName = rs.getString(9);
            }
        } catch (SQLException e) {
            logger.error("Error occurred during getSystemRoles(): ", e);
            throw new EJBException(e);
        } finally {
            ConnectionUtil.closeResources(connection, stmt, rs);
        }
        return systemRoleList;
    }

    /**
     * Gets the list of time zones. Is used by LcpReferenceData
     *
     * @return The list of OptionBean elements for time zones
     */
    public ArrayList getTimeZoneOBs()
            throws SQLException {
        Connection connection = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            connection = getConnection();
            stmt = connection.createStatement();
            String timeZoneQuery = "SELECT DISTINCT TIMEZONECODE, SUBSTR (TIMEZONENAME,0,10), HOURSDIFFERENCEZULU FROM TIMEZONE ORDER BY HOURSDIFFERENCEZULU";

            rs = stmt.executeQuery(timeZoneQuery);
            ArrayList aList = new ArrayList();
            while (rs.next()) {
                String timeZoneCode = rs.getString(1);
                String timeZoneName = rs.getString(2);
                OptionBean timeZone = new OptionBean(timeZoneName, timeZoneCode);
                aList.add(timeZone);
            }
            return aList;
        } catch (SQLException sqEx) {
            logger.error("SQL Error occurred during getTimeZoneOBs()", sqEx);
            throw sqEx;
        } finally {
            ConnectionUtil.closeResources(connection, stmt, rs);
        }
    }

    public boolean isValidUser(String userId, String password, String domain)
            throws InvalidUserException {
        logger.debug("isValidUser(userId,password,domain)::BEGIN");
        // Check to see if password authentication is disabled for xml messages
        // This DOES NOT disable web portal password authentication
        boolean checkPassword = true;
        String passwordHash = "";
        logger.debug("Remote Authorization is set to " + ApplicationProperties.getProperty("password.remoteAuthorization"));
        if (ApplicationProperties.getProperty("password.remoteAuthorization").equals("false")) {
            checkPassword = false;
        } else {
            passwordHash = (new PasswordHasher()).hashPassword(password);
        }
        userId = userId.toUpperCase();
        StringBuffer query = new StringBuffer("SELECT USERID FROM SYSTEMUSER WHERE USERID=? AND DOMAINNAME=? ");
        if (checkPassword) {
            query.append("AND PASSPHRASEHASH=? ");
        }
        boolean hasFound = false;
        Connection connection = null;
        PreparedStatement pstmt = null;
        ResultSet result = null;
        try {
            connection = getConnection();
            pstmt = connection.prepareStatement(query.toString());
            pstmt.setString(1, userId);
            pstmt.setString(2, domain);
            if (checkPassword) {
                pstmt.setString(3, passwordHash);
            }
            for (result = pstmt.executeQuery(); result.next();) {
                hasFound = true;
            }
            if (!hasFound) {
                throw new InvalidUserException("User not found");
            }
        } catch (SQLException sqEx) {
            logger.error("SQLException in isValidUser(userId,password,domain)", sqEx);
            throw new EJBException(sqEx);
        } finally {
            ConnectionUtil.closeResources(connection, pstmt, result);
        }
        return hasFound;
    }

    /**
     * Checks if the specified user is valid or not.
     *
     * @param userId The userID of the user
     * @param password The cleartext of the password. This method does not log
     * the password in any log messages.
     * @param domain
     * @param assocSystemFunctioncode
     *
     * @return true if the user is valid
     * @exception InvalidUserException If the user is not valid.
     */
    public boolean isValidUser(String userId, String password, String domain, String assocSystemFunctionCode)
            throws InvalidUserException {
        userId = userId.toUpperCase();
        String passwordHash = (new PasswordHasher()).hashPassword(password);
        String query = " SELECT * FROM USERSYSTEMROLE USR , SYSTEMROLEFUNCTION SRF ,SYSTEMUSER SYSU WHERE SYSU.USERID='" + userId + "' AND SYSU.PASSPHRASEHASH='" + passwordHash + "' AND  SYSU.DOMAINNAME='" + domain + "'AND USR.USERSYSTEMROLEID= SYSU.SYSTEMUSERID AND USR.SYSTEMROLECODE = SRF.SYSTEMROLECODE AND SRF.SYSTEMFUNCTIONCODE = '" + assocSystemFunctionCode + "'";

        Connection connection = null;
        Statement stmt = null;
        ResultSet result = null;
        try {
            connection = getConnection();
            stmt = connection.createStatement();
            for (result = stmt.executeQuery(query); result.next();) {
                return true;
            }
            throw new InvalidUserException("Aunthetication Failed - User is not authorized");
        } catch (SQLException sqEx) {
            logger.error("SQLException in isValidUser(userId,password,domain,assocSystemFunctionCode)", sqEx);
            throw new EJBException(sqEx);
        } finally {
            ConnectionUtil.closeResources(connection, stmt, result);
        }
        
    }

    private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
        in.defaultReadObject();
    }

    public void updateSystemNavigationTypes(List systemNavigationList) {
        Connection connection = null;
        PreparedStatement pStmt = null;
        DataSetupModel dataSetupModel = null;
        String insQuery = "INSERT INTO SYSTEMNAVIGATIONTYPE (SYSTEMNAVIGATIONTYPECODE, SYSTEMNAVIGATIONTYPENAME, STATUS, CREATEUSERID, CREATETIMESTAMP, LASTUPDATEUSERID, LASTUPDATETIMESTAMP, DOMAINNAME) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try {
            connection = getConnection();
            pStmt = connection.prepareStatement(insQuery);
            for (int i = 0; i < systemNavigationList.size(); i++) {
                pStmt.clearParameters();
                dataSetupModel = (DataSetupModel) systemNavigationList.get(i);
                String operationMode = dataSetupModel.getOperationMode();
                if (operationMode.equalsIgnoreCase("Add")) {
                    pStmt.setString(1, dataSetupModel.getTypeCode());
                    pStmt.setString(2, dataSetupModel.getTypeName());
                    pStmt.setString(3, dataSetupModel.getDataSetupStatus());
                    pStmt.setString(4, dataSetupModel.getCreateUserId());
                    pStmt.setTimestamp(5, dataSetupModel.getCreateTimestamp());
                    pStmt.setString(6, dataSetupModel.getLastUpdateUserId());
                    pStmt.setTimestamp(7, dataSetupModel.getLastUpdateTimestamp());
                    pStmt.setString(8, dataSetupModel.getDomainName());
                    pStmt.executeUpdate();
                } else if (operationMode.equalsIgnoreCase("Edit")) {
                    editSystemNavigationTypes(dataSetupModel, connection);
                }
            }
        } catch (SQLException e) {
            logger.error("Error occurred during updateSystemNavigationTypes (systemNavigationList)", e);
            throw new EJBException(e);
        } finally {
            ConnectionUtil.closeResources(connection, pStmt, null);
        }
    }

    public void updateSystemRoles(ArrayList systemRoleList) {
        Connection connection = null;
        PreparedStatement pStmt = null;
        DataSetupModel dataSetupModel = null;
        String insQuery = "INSERT INTO SYSTEMROLE (SYSTEMROLECODE, SYSTEMROLENAME, STATUS, CREATEUSERID, CREATETIMESTAMP, LASTUPDATEUSERID, LASTUPDATETIMESTAMP, DOMAINNAME) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try {
            connection = getConnection();
            pStmt = connection.prepareStatement(insQuery);
            for (int i = 0; i < systemRoleList.size(); i++) {
                pStmt.clearParameters();
                dataSetupModel = (DataSetupModel) systemRoleList.get(i);
                String operationMode = dataSetupModel.getOperationMode();
                if (operationMode.equalsIgnoreCase("Add")) {
                    pStmt.setString(2, dataSetupModel.getTypeCode());
                    pStmt.setString(3, dataSetupModel.getTypeName());
                    pStmt.setString(4, dataSetupModel.getDataSetupStatus());
                    pStmt.setString(5, dataSetupModel.getCreateUserId());
                    pStmt.setTimestamp(6, dataSetupModel.getCreateTimestamp());
                    pStmt.setString(7, dataSetupModel.getLastUpdateUserId());
                    pStmt.setTimestamp(8, dataSetupModel.getLastUpdateTimestamp());
                    pStmt.setString(9, dataSetupModel.getDomainName());
                    pStmt.executeUpdate();
                } else if (operationMode.equalsIgnoreCase("Edit")) {
                    editSystemRoles(dataSetupModel, connection);
                }
            }
        } catch (Exception e) {
            logger.error("Error occurred during updateSystemRoles(systemRoleList) ", e);
            throw new EJBException(e);
        } finally {
            ConnectionUtil.closeResources(connection, pStmt, null);
        }
    }

    // Added logging of this event in the asyncprocesslog table
    public SystemUserModel updateUser(SystemUserModel systemUserModel, Credentials credentials) throws DuplicateRecordFoundException {
        AsyncProcessingLogModel asyncLogModel = new AsyncProcessingLogModel();
        AsyncProcessManager asyncRequestManager = new AsyncProcessManager();

        String domainUser = systemUserModel.getDomainName() + "." + systemUserModel.getUserId();
        try {
            // log user modifications to data.
            asyncLogModel.init(credentials.getUserId(), credentials.getDomainName(), "EDIT", "SECURITY", "Modifying user " + domainUser, credentials.getIpAddress());
            asyncLogModel = asyncRequestManager.createAsyncProcessLog(asyncLogModel);

            try {
                userAccessDAO.update(systemUserModel, credentials);
            } catch (EJBException ejbEx) {
                if (userAccessDAO.checkUserExists(systemUserModel)) {
                    throw new DuplicateRecordFoundException("Duplicate record found!");
                }
            }
            collectionManager.reset();

            // log the successful results
            asyncRequestManager.logResult(asyncLogModel, true, "Successfully modified user " + domainUser, "updateUser");
        } catch (DuplicateRecordFoundException duEx) {
            throw duEx;
        } catch (Exception ex) {
            logger.error("Error occurred during updateUser(systemUserModel)", ex);
            asyncRequestManager.logResult(asyncLogModel, false, "Failed to modify user " + domainUser, "updateUser");
            throw new EJBException(ex);
        }
        return systemUserModel;
    }

    private void writeObject(ObjectOutputStream out) throws IOException {
        out.defaultWriteObject();
    }

    public List<SystemUserModel> searchSystemUsers(String srchID, String srchName, String srchDomain, String srchEmail, Credentials credentials) {
        List<SystemUserModel> usersList = new ArrayList<SystemUserModel>();
        String qry =
                "SELECT  "
                + "	U.SYSTEMUSERID,U.ORGID, U.TIMEZONEID, U.USERID, U.PASSWORDEXPIRATIONDATE, U.ISPASSWORDAUTOEXPIRE,  "
                + "	U.AUTOEXPIREDAYS, U.DOMAINNAME, U.UOMCODE, U.CURRENCYCODE, U.DATEFORMAT,P.ORGNAME, O.CONTACTFIRSTNAME,  "
                + "	O.CONTACTLASTNAME,O.EMAIL,U.LASTLOGINTIMESTAMP,decode(ISACTIVE,'Y','YES','NO') ISACTIVE, U.PASSPHRASEHASH,  "
                + "	R.SYSTEMROLENAME  "
                + "FROM  "
                + "	SYSTEMUSER U,ORGHIERARCHY O,SYSTEMROLE R,ORGHIERARCHY P "
                + "WHERE  "
                + "	O.ORGID(+) = U.ORGID  "                				
				+ " AND (O.STATUS(+) IN ('ACTIVE','INACTIVE')) "
                + " AND U.SYSTEMROLECODE=R.SYSTEMROLECODE  "
                + " AND P.ORGID(+) = O.PARENTORGID  ";

        if ("OGS".equalsIgnoreCase(credentials.getRole())) {
            qry += " AND P.COUNTRYCODE <> 'US' AND U.SYSTEMROLECODE IN ('OGS','CAR') ";
        }





        Connection connection = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        HashMap<Integer, Object> params = new HashMap<Integer, Object>();
        int paramIndex = 0;

        // build query based on variables.
        if (srchID.length() > 0) {
            qry = qry + " AND U.USERID like ?";
            paramIndex++;
            params.put(paramIndex, "%" + srchID + "%");
        }
        if (srchName.length() > 0) {
            qry = qry + " AND O.CONTACTLASTNAME like ?";
            paramIndex++;
            params.put(paramIndex, "%" + srchName + "%");
        }
        if (srchDomain.length() > 0) {
            qry = qry + " AND U.DOMAINNAME = ?";
            paramIndex++;
            params.put(paramIndex, srchDomain);
        }

        if (srchEmail.length() > 0) {
            qry = qry + " AND O.EMAIL like ?";
            paramIndex++;
            params.put(paramIndex, "%" + srchEmail + "%");
        }

        // if no search params, don' return everything in the damn database.
        if (paramIndex == 0) {
            return usersList;
        }

        try {
            connection = getConnection();
            pstmt = connection.prepareStatement(qry);
           logger.debug("running User search query: " + qry);
           

            // bind parameter values
            pstmt = new BaseDao().bindParams(pstmt, params);

            rs = pstmt.executeQuery();

            while (rs.next()) {
                long systemUserId = rs.getLong("SYSTEMUSERID");
                long orgId = rs.getLong("ORGID");
                String timeZoneId = rs.getString("TIMEZONEID");
                String userId = rs.getString("USERID");
                String password = "";
                java.sql.Timestamp passwordExpirationDate = rs.getTimestamp("PASSWORDEXPIRATIONDATE");
                long isPasswordAutoExpire = rs.getLong("ISPASSWORDAUTOEXPIRE");
                long autoExpireDays = rs.getLong("AUTOEXPIREDAYS");
                String domain = rs.getString("DOMAINNAME");
                String uomCode = rs.getString("UOMCODE");
                String currencyCode = rs.getString("CURRENCYCODE");
                String dateFormat = rs.getString("DATEFORMAT");
                String orgName = rs.getString("ORGNAME");
                String contactFirstName = rs.getString("CONTACTFIRSTNAME");
                String contactLastName = rs.getString("CONTACTLASTNAME");
                String email = rs.getString("EMAIL");
                java.sql.Timestamp lastLoginTimeStamp = rs.getTimestamp("LASTLOGINTIMESTAMP");
                String isActive = rs.getString("ISACTIVE");
                String roleCode = rs.getString("SYSTEMROLENAME");
                
                SystemUserModel systemUserModel = new SystemUserModel(systemUserId, orgId, timeZoneId, userId, password, passwordExpirationDate, isPasswordAutoExpire, autoExpireDays, domain, uomCode, currencyCode, dateFormat, orgName, contactFirstName, contactLastName, email, lastLoginTimeStamp, isActive);
                systemUserModel.setPassphraseHash("");
                systemUserModel.setSystemRoleCode(roleCode);
                systemUserModel.setEmail(email);
                usersList.add(systemUserModel);
            }

        } catch (Exception e) {
            logger.error("Error occurred during searchSystemUsers(domainName)", e);
            throw new EJBException(e);
        } finally {
            ConnectionUtil.closeResources(connection, pstmt, rs);
        }

        return usersList;
    }

    /**
     * Gets the list of System users. It also fetches the roles and the
     * organization the user belongs to.
     */
    public List<SystemUserModel> getAllSystemUsers(String domainName, Long contactOrgId) {
        logger.debug("getAllSystemUsers(domainName): begin");
        String query = new String("SELECT U.SYSTEMUSERID,U.ORGID, U.TIMEZONEID, U.USERID, U.PASSWORDEXPIRATIONDATE, U.ISPASSWORDAUTOEXPIRE, U.AUTOEXPIREDAYS, U.DOMAINNAME, U.UOMCODE, U.CURRENCYCODE, ");
        query = query + "U.DATEFORMAT,P.ORGNAME, O.CONTACTFIRSTNAME, O.CONTACTLASTNAME,O.EMAIL,U.LASTLOGINTIMESTAMP,decode(ISACTIVE,'Y','YES','NO') ISACTIVE, U.PASSPHRASEHASH, R.SYSTEMROLENAME   ";
        query = query + " FROM SYSTEMUSER U,ORGHIERARCHY O,SYSTEMROLE R,ORGHIERARCHY P ";
        query = query + " WHERE O.ORGID(+) = U.ORGID AND U.SYSTEMROLECODE=R.SYSTEMROLECODE AND P.ORGID(+) = O.PARENTORGID AND (O.STATUS IN ('ACTIVE','INACTIVE'))";

        // add appropriate where clause
        if (domainName != null) {
            query = query + " AND U.DOMAINNAME=?";
        } else {
            query = query + " AND U.ORGID=?";
        }

        Connection connection = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        List<SystemUserModel> usersList = new ArrayList<SystemUserModel>();

        logger.debug("getAllSystemUsers(" + domainName + "): DQL: " + query);
        try {
            connection = getConnection();
            pstmt = connection.prepareStatement(query);
            if (query.indexOf("DOMAINNAME=") > -1) {
                pstmt.setString(1, domainName);
            } else {
                pstmt.setLong(1, contactOrgId);
            }
            rs = pstmt.executeQuery();
            while (rs.next()) {
                long systemUserId = rs.getLong("SYSTEMUSERID");
                long orgId = rs.getLong("ORGID");
                String timeZoneId = rs.getString("TIMEZONEID");
                String userId = rs.getString("USERID");
                String password = "";
                java.sql.Timestamp passwordExpirationDate = rs.getTimestamp("PASSWORDEXPIRATIONDATE");
                long isPasswordAutoExpire = rs.getLong("ISPASSWORDAUTOEXPIRE");
                long autoExpireDays = rs.getLong("AUTOEXPIREDAYS");
                String domain = rs.getString("DOMAINNAME");
                String uomCode = rs.getString("UOMCODE");
                String currencyCode = rs.getString("CURRENCYCODE");
                String dateFormat = rs.getString("DATEFORMAT");
                String orgName = rs.getString("ORGNAME");
                String contactFirstName = rs.getString("CONTACTFIRSTNAME");
                String contactLastName = rs.getString("CONTACTLASTNAME");
                String email = rs.getString("EMAIL");
                java.sql.Timestamp lastLoginTimeStamp = rs.getTimestamp("LASTLOGINTIMESTAMP");
                String isActive = rs.getString("ISACTIVE");
                String roleCode = rs.getString("SYSTEMROLENAME");
                
                SystemUserModel systemUserModel = new SystemUserModel(systemUserId, orgId, timeZoneId, userId, password, passwordExpirationDate, isPasswordAutoExpire, autoExpireDays, domain, uomCode, currencyCode, dateFormat, orgName, contactFirstName, contactLastName, email, lastLoginTimeStamp, isActive);
                systemUserModel.setPassphraseHash("");
                systemUserModel.setSystemRoleCode(roleCode);
                usersList.add(systemUserModel);
            }
        } catch (Exception e) {
            logger.error("Error occurred during getAllSystemUsers(domainName)", e);
            throw new EJBException(e);
        } finally {
            ConnectionUtil.closeResources(connection, pstmt, rs);
        }
        return usersList;
    }

    public void deleteUser(SystemUserModel systemUserModel, Credentials credentials) {
        AsyncProcessingLogModel asyncLogModel = new AsyncProcessingLogModel();
        AsyncProcessManager asyncManager = new AsyncProcessManager();
        String domainUser = systemUserModel.getDomainName() + "." + systemUserModel.getUserId();
        try {
            logger.debug("deleteUser(systemUserModel) begin");
            // Log user deletion in the ASYNCPROCESSINGLOG table
            asyncLogModel.init(credentials.getUserId(), credentials.getDomainName(), "ADMIN", "SECURITY", "In process deletion of user " + domainUser, credentials.getIpAddress());
            asyncLogModel = asyncManager.createAsyncProcessLog(asyncLogModel);

            deleteUserRoles(systemUserModel);
            deleteSystemUser(systemUserModel);
            collectionManager.reset();

            asyncManager.logResult(asyncLogModel, true, "Successful deletion of user " + domainUser, "deleteUser");
        } catch (Exception e) {
            logger.error("Exception in deleteUser(systemUserModel)", e);
            asyncManager.logResult(asyncLogModel, false, "Failed deletion of user " + domainUser, "Exception");
            throw new EJBException(e);
        }
    }

    private void deleteUserRoles(SystemUserModel systemUserModel) {
        logger.debug("deleteUserRoles(" + systemUserModel.getSystemUserId() + "): begin");
        String query = "DELETE FROM USERSYSTEMROLE WHERE SYSTEMUSERID= ? ";
        Connection connection = null;
        PreparedStatement pstmt = null;
        try {
            connection = getConnection();
            pstmt = connection.prepareStatement(query);
            pstmt.setLong(1, systemUserModel.getSystemUserId());
            pstmt.executeUpdate();
        } catch (Exception e) {
            logger.error("Error occurred during deleteUserRoles(systemUserModel)", e);
            throw new EJBException(e);
        } finally {
            ConnectionUtil.closeResources(connection, pstmt, null);
        }
    }

    private void deleteSystemUser(SystemUserModel systemUserModel) {
        logger.info("deleteSystemUser (" + systemUserModel.getSystemUserId() + "): begin");
        String query = "DELETE FROM SYSTEMUSER WHERE SYSTEMUSERID = ? ";
        Connection connection = null;
        PreparedStatement pstmt = null;
        try {
            connection = getConnection();
            pstmt = connection.prepareStatement(query);
            pstmt.setLong(1, systemUserModel.getSystemUserId());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            logger.error("Error occurred during deleteSystemUser(systemUserModel)", e);
            throw new EJBException(e);
        } finally {
            ConnectionUtil.closeResources(connection, pstmt, null);
        }
    }

    /**
     * Gets the details of a user.
     */
    public SystemUserModel getUserDetails(SystemUserModel systemUserModel) {

        StringBuffer query = new StringBuffer("SELECT P.ORGNAME, C.CONTACTFIRSTNAME, NVL(C.CONTACTLASTNAME,C.ORGNAME) CONTACTLASTNAME, ");
        query.append("U.ORGID,U.SYSTEMUSERID, USERID, U.PASSWORDEXPIRATIONDATE,  U.ISPASSWORDAUTOEXPIRE, U.AUTOEXPIREDAYS, U.DOMAINNAME, U.UOMCODE, ");
        query.append("U.CREATETIMESTAMP,U.CREATEUSERID,U.LASTUPDATETIMESTAMP,U.LASTUPDATEUSERID, U.NUMFAILEDLOGIN, ");
        query.append("U.CURRENCYCODE, U.DATEFORMAT,U.LASTLOGINTIMESTAMP,U.ISACTIVE,U.SYSTEMROLECODE,U.PASSPHRASEHASH,C.EMAIL ");
        query.append("FROM ORGHIERARCHY P,ORGHIERARCHY C,SYSTEMUSER U ");
        query.append("WHERE C.ORGID = ? AND U.SYSTEMUSERID=? ");
        query.append("AND C.PARENTORGID = P.ORGID(+) ");

        logger.debug("[query] " + query);

        Connection connection = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            connection = getConnection();
            pstmt = connection.prepareStatement(query.toString());
            pstmt.setLong(1, systemUserModel.getOrgId());
            pstmt.setLong(2, systemUserModel.getSystemUserId());
            rs = pstmt.executeQuery();
            while (rs.next()) {
                systemUserModel = new SystemUserModel();
                
                systemUserModel.setOrgName(rs.getString("ORGNAME"));
                systemUserModel.setContactFirstName(rs.getString("CONTACTFIRSTNAME"));
                systemUserModel.setContactLastName(rs.getString("CONTACTLASTNAME"));
                systemUserModel.setOrgId(rs.getLong("ORGID"));
                systemUserModel.setSystemUserId(rs.getLong("SYSTEMUSERID"));
                systemUserModel.setUserId(rs.getString("USERID"));
                systemUserModel.setPasswordExpirationDate(rs.getTimestamp("PASSWORDEXPIRATIONDATE"));
                systemUserModel.setIsPasswordAutoExpire(rs.getLong("ISPASSWORDAUTOEXPIRE"));
                systemUserModel.setAutoExpireDays(rs.getLong("AUTOEXPIREDAYS"));
                systemUserModel.setDomainName(rs.getString("DOMAINNAME"));
                systemUserModel.setUomCode(rs.getString("UOMCODE"));
                systemUserModel.setCurrencyCode(rs.getString("CURRENCYCODE"));
                systemUserModel.setDateFormat(rs.getString("DATEFORMAT"));
                systemUserModel.setLastLoginTimestamp(rs.getTimestamp("LASTLOGINTIMESTAMP"));
                systemUserModel.setIsActive(rs.getString("ISACTIVE"));
                systemUserModel.setPassphraseHash(rs.getString("PASSPHRASEHASH"));
                systemUserModel.setSystemRoleCode(rs.getString("SYSTEMROLECODE"));
                systemUserModel.setEmail(rs.getString("EMAIL"));
                systemUserModel.setCreateTimestamp(rs.getTimestamp("CREATETIMESTAMP"));
                systemUserModel.setLastUpdateTimestamp(rs.getTimestamp("LASTUPDATETIMESTAMP"));
                systemUserModel.setCreateUserId(rs.getString("CREATEUSERID"));
                systemUserModel.setLastUpdateUserId(rs.getString("LASTUPDATEUSERID"));
                systemUserModel.setNumFailedLogin(rs.getInt("NUMFAILEDLOGIN"));
            }
        } catch (Exception e) {
            logger.error("Exception in getUserDetails(systemUserModel)", e);
            throw new EJBException(e);
        } finally {
            ConnectionUtil.closeResources(connection, pstmt, rs);
        }
        return systemUserModel;
    }

    /**
     * Fetches the preferences for the user.
     *
     * @param systemUserId
     * @return SystemUserModel
     */
    public SystemUserModel getUserPreferenceDetails(long systemUserId) {
        SystemUserModel systemUserModel;
        try {
            logger.info("getUserPreferenceDetails(systemUserId) begin");
            systemUserModel = userAccessDAO.getUserPreferenceDetails(systemUserId);
        } catch (Exception e) {
            logger.error("Error occurred during getUserPreferenceDetails(systemUserId)", e);
            throw new EJBException();
        }
        return systemUserModel;
    }

    /**
     * Updates the preferences for the user.
     *
     * @param SystemUserModel
     */
    public void updateUserPreferences(SystemUserModel systemUserModel) {
        logger.info("updateUserPreferences(systemUserModel): begin");
        try {
            userAccessDAO.updateUserPreferences(systemUserModel);
        } catch (Exception e) {
            logger.error("Error occurred during  updateUserPreferences(systemUserModel)", e);
            throw new EJBException();
        }
    }

    public ArrayList getAllSystemRoles(String domain) {
        StringBuffer query = new StringBuffer("SELECT DISTINCT SYSTEMROLENAME,SYSTEMROLECODE FROM SYSTEMROLE WHERE DOMAINNAME IN (?,'PUBLIC')");
        Connection connection = null;
        PreparedStatement pstmt = null;
        logger.debug("getAllSystemRoles(domain) begin. \n [DQL]" + query);
        ArrayList aList = new ArrayList();
        ResultSet rs = null;
        try {
            connection = getConnection();
            pstmt = connection.prepareStatement(query.toString());
            pstmt.setString(1, domain);
            rs = pstmt.executeQuery();
            while (rs.next()) {
                OptionBean optionBean = new OptionBean(rs.getString(1), rs.getString(2));
                aList.add(optionBean);
            }
        } catch (Exception e) {
            logger.error("Error occurred during getAllSystemRoles(domain)", e);
            throw new EJBException(e);
        } finally {
            ConnectionUtil.closeResources(connection, pstmt, rs);
        }
        return aList;
    }

    public ArrayList getAllCurrencyCodes(String domain) {
        StringBuffer query = new StringBuffer("SELECT DISTINCT CURRENCYNAME,CURRENCYCODE FROM CURRENCY WHERE DOMAINNAME IN (?,'PUBLIC')");
        Connection connection = null;
        PreparedStatement pstmt = null;
        logger.debug("getAllCurrencyCodes(domain) begin. \n [DQL] " + query.toString());
        ArrayList aList = new ArrayList();
        ResultSet rs = null;
        try {
            connection = getConnection();
            pstmt = connection.prepareStatement(query.toString());
            pstmt.setString(1, domain);
            rs = pstmt.executeQuery();
            while (rs.next()) {
                OptionBean optionBean = new OptionBean(rs.getString(1), rs.getString(2));
                aList.add(optionBean);
            }
        } catch (Exception e) {
            logger.error("Error occurred during getAllCurrencyCodes(domain)", e);
            throw new EJBException(e);
        } finally {
            ConnectionUtil.closeResources(connection, pstmt, rs);
        }
        return aList;
    }

    public ArrayList<OptionBean> getAllUnitSystem(String domain) {
        StringBuffer query = new StringBuffer("SELECT DISTINCT UNITSYSTEMNAME,UNITSYSTEMCODE FROM UNITSYSTEM WHERE DOMAINNAME IN (?,'PUBLIC')");
        Connection connection = null;
        PreparedStatement pstmt = null;
        logger.debug("getAllUnitSystem(domain) begin. \n[DQL] " + query.toString());
        ArrayList<OptionBean> aList = new ArrayList<OptionBean>();
        ResultSet rs = null;
        try {
            connection = getConnection();
            pstmt = connection.prepareStatement(query.toString());
            pstmt.setString(1, domain);
            rs = pstmt.executeQuery();
            while (rs.next()) {
                OptionBean optionBean = new OptionBean(rs.getString(1), rs.getString(2));
                aList.add(optionBean);
            }
        } catch (Exception e) {
            logger.error("Error occurred during getAllUnitSystem(domain)", e);
            throw new EJBException(e);
        } finally {
            ConnectionUtil.closeResources(connection, pstmt, rs);
        }
        return aList;
    }

    /**
     * @deprecated Use getTimeZoneOBs() method.
     */
    public ArrayList getAllTimeZones(String domain)
            throws SQLException {
        StringBuffer query = new StringBuffer("SELECT DISTINCT TIMEZONECODE TIMEZONE, TIMEZONECODE  FROM TIMEZONE WHERE DOMAINNAME IN (?,'PUBLIC')");
        Connection connection = null;
        PreparedStatement pstmt = null;
        logger.debug("getAllTimeZones(domain) begin. \n [DQL] " + query.toString());
        ArrayList aList = new ArrayList();
        ResultSet rs = null;
        try {
            connection = getConnection();
            pstmt = connection.prepareStatement(query.toString());
            pstmt.setString(1, domain);
            rs = pstmt.executeQuery();
            while (rs.next()) {
                OptionBean optionBean = new OptionBean(rs.getString(1), rs.getString(2));
                aList.add(optionBean);
            }
        } catch (SQLException e) {
            logger.error("Error occurred during getAllTimeZones(domain)", e);
            throw e;
        } finally {
            ConnectionUtil.closeResources(connection, pstmt, rs);
        }
        return aList;
    }

    private boolean validateUser(ResultSet rs)
            throws InvalidUserException, UserNotActiveException, PasswordExpiredException {
        logger.debug("validateUser(ResultSet): begin");
        try {
            if (rs.next()) {
                Timestamp passwordExpirationDate = rs.getTimestamp("PASSWORDEXPIRATIONDATE");
                int isPasswordAutoExpire = rs.getInt("ISPASSWORDAUTOEXPIRE");
                String isActive = rs.getString("ISACTIVE");
                Timestamp currentDate = new Timestamp(System.currentTimeMillis());
                Timestamp addDate = rs.getTimestamp("add_date");
                logger.debug("IsActive: " + isActive);

                if (isActive.equalsIgnoreCase("Y") || isActive.equalsIgnoreCase("C") || isActive.equalsIgnoreCase("S")) {
                    if (passwordExpirationDate != null) {
                        logger.debug("currentDate " + currentDate + " passwordExpirationDate " + passwordExpirationDate);
                        if (!currentDate.before(passwordExpirationDate)) {
                            throw new PasswordExpiredException();
                        }
                    }
                    if (isPasswordAutoExpire > 0) {
                        logger.debug("currentDate " + currentDate + " addDate " + addDate);
                        if (addDate != null && !currentDate.before(addDate)) {
                            throw new PasswordExpiredException();
                        }
                    }
                } else {
                    throw new UserNotActiveException();
                }
            } else {
                throw new InvalidUserException("User not found");
            }
        } catch (SQLException sqex) {
            logger.error("SQLException in validateUser (ResultSet)", sqex);
            throw new EJBException(sqex);
        }
        return true;
    }

    public ArrayList getAllSystemFunction()
            throws SQLException {
        Connection connection = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            connection = getConnection();
            stmt = connection.createStatement();
            String timeZoneQuery = "SELECT SYSTEMFUNCTIONCODE, SYSTEMFUNCTIONNAME FROM SYSTEMFUNCTION ORDER BY SYSTEMFUNCTIONNAME";

            rs = stmt.executeQuery(timeZoneQuery);
            ArrayList aList = new ArrayList();
            while (rs.next()) {
                String sysFuncCode = rs.getString(1);
                String sysFuncName = rs.getString(2);
                OptionBean sysFunc = new OptionBean(sysFuncCode, sysFuncName);
                aList.add(sysFunc);
            }
            return aList;
        } catch (SQLException sqEx) {
            logger.error("SQL Error occurred during getAllSystemFunction()", sqEx);
            throw sqEx;
        } finally {
            ConnectionUtil.closeResources(connection, stmt, rs);
        }
    }

    /**
     * Deletes all system function role for the specified rolename.
     */
    public void deleteSystemRoleFunction(String roleName) throws SQLException {
        logger.debug("deleteSystemRoleFunction begin:");
        
        Connection connection = null;
        PreparedStatement pStmt = null;
        String deleteQuery = "DELETE FROM SYSTEMROLEFUNCTION WHERE SYSTEMROLECODE = ?";
        logger.info("DELETE FROM SYSTEMROLEFUNCTION WHERE SYSTEMROLECODE = ?" + roleName);
        try {
            connection = getConnection();
            pStmt = connection.prepareStatement(deleteQuery);
            pStmt.setString(1, roleName);
            int i = pStmt.executeUpdate();
            logger.debug("deleteSystemRoleFunction records Deleted" + i);
            
        } catch (SQLException e) {
            logger.error("Error occurred during deleteSystemRoleFunction(): ", e);
            if (connection != null) {
               connection.rollback();
			}
            throw e;
        } finally {
            ConnectionUtil.closeResources(connection, pStmt, null);
        }
    }

    public void createSystemRoleFunction(String[] systemFunctionCodes, String roleName, String createdBy)
            throws SQLException {
        logger.debug("createSystemRoleFunction(): begin");
        
        Connection connection = null;
        PreparedStatement pStmt = null;
        String insertQuery = "INSERT INTO SYSTEMROLEFUNCTION (SYSTEMFUNCTIONCODE, SYSTEMROLECODE, CREATEUSERID, DOMAINNAME) VALUES (?,?,?,?)";
        try {
            connection = getConnection();
            logger.debug("systemFunctionCodes.length" + systemFunctionCodes.length);
            
            pStmt = connection.prepareStatement(insertQuery);
            for (int i = 0; i < systemFunctionCodes.length; i++) {
                logger.debug("Inserting code " + systemFunctionCodes[i] + " for role " + roleName);
                pStmt.clearParameters();
                pStmt.setString(1, systemFunctionCodes[i]);
                pStmt.setString(2, roleName);
                pStmt.setString(3, createdBy);
                pStmt.setString(4, "PUBLIC");
                pStmt.executeUpdate();
            }
            pStmt.close();
            connection.close();
        } catch (SQLException e) {
            logger.error("Error occurred during deleteSystemRoleFunction(): ", e);
            if (connection != null) {
               connection.rollback();
			}
            throw e;
        } finally {
            ConnectionUtil.closeResources(connection, pStmt, null);
        }
    }
}
