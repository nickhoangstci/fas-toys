/** 
 * 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolio/communication/ejb/CommMethodSLSBean.java,v 1.8.4.1 2010/08/22 23:08:35 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: CommMethodSLSBean.java,v $
 *  Revision 1.8.4.1  2010/08/22 23:08:35  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.8  2006/03/28 21:23:01  aarora
 *  Repackaging of fdcommons
 *
 *  Revision 1.7  2005/08/20 12:35:36  pjain
 *  DAO movement impact
 *
 *  Revision 1.6  2005/03/10 19:18:46  agarg
 *  Changed return type of Create method from void to CommunicationModel
 *
 *  Revision 1.5  2005/02/16 21:52:14  amrinder
 *  Removed unnecessary imports
 *
 *  Revision 1.4  2004/11/29 12:46:53  biju
 *  DAO/EJB changes for UM
 *
 *  Revision 1.3  2004/09/15 13:06:03  ranand
 *  2.6 Baseline
 *
 * 
 */



package com.freightdesk.fdfolio.communication.ejb;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.freightdesk.fdfolio.dao.CommunicationMethodDAO;
import com.freightdesk.fdcommons.BaseSLSBean;
import com.freightdesk.fdcommons.ConnectionUtil;

public class CommMethodSLSBean extends BaseSLSBean {
	
	protected CommunicationMethodDAO communicationMethodDAO = new CommunicationMethodDAO();

    public ArrayList getCommMethodTypeCodeName(String domainName)
        throws SQLException
    {
        Connection connection = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        String qStr = null;
        ArrayList aList = new ArrayList();
        String results[] = null;
        qStr = "SELECT COMMUNICATIONMETHODTYPECODE, COMMUNICATIONMETHODTYPENAME FROM COMMUNICATIONMETHODTYPE WHERE DOMAINNAME IN(?,'PUBLIC') ORDER BY COMMUNICATIONMETHODTYPENAME";
        try
        {
            connection = getConnection();
            pStmt = connection.prepareStatement(qStr);
            pStmt.clearParameters();
            pStmt.setString(1, domainName);
            aList = new ArrayList();
            for(rs = pStmt.executeQuery(); rs.next(); aList.add(results))
            {
                results = new String[2];
                results[0] = rs.getString(1);
                results[1] = rs.getString(2);
            }

        }
        catch(SQLException sqEx)
        {
            logger.error("SQLException in CommunicationMethodDAO[getCommMethodTypeCodeName(domainName)] -> " + sqEx.toString());
            throw sqEx;
        }
        finally
        {
            ConnectionUtil.closeResources(connection, pStmt, rs);
        }
        return aList;
    }

}
