/** 
 * 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolio/shipmentinspection/mappings/ImageBodyObjectMapping.java,v 1.1.10.1 2010/08/22 23:08:24 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: ImageBodyObjectMapping.java,v $
 *  Revision 1.1.10.1  2010/08/22 23:08:24  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.1  2004/09/15 13:13:41  ranand
 *  2.6 Baseline
 *
 * 
 */

package com.freightdesk.fdfolio.shipmentinspection.mappings;


public class ImageBodyObjectMapping {
    private ImageReportObjectMapping imageReportObjectMapping;
    
    /**
     * @return imageReportObjectMapping
     */
    public ImageReportObjectMapping getImageReportObjectMapping() {
        return imageReportObjectMapping;
    }

    /**
     * @param imageReportObjectMapping
     */
    public void setImageReportObjectMapping(ImageReportObjectMapping imageReportObjectMapping) {
        this.imageReportObjectMapping = imageReportObjectMapping;
    }

}
