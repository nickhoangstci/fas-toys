/** 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolio/search/SearchManager.java,v 1.16.4.8 2010/09/23 19:35:24 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: SearchManager.java,v $
 *  Revision 1.16.4.8  2010/09/23 19:35:24  mechevarria
 *  remove ejb layer for instantiating objects.  direct calls to bean class now made
 *
 *  Revision 1.16.4.7  2010/08/22 23:08:45  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.16.4.6  2010/08/05 20:34:41  mechevarria
 *  fix lookup bug for locs
 *
 *  Revision 1.16.4.5  2010/02/11 22:12:44  mechevarria
 *  moved systemusermodel to commons
 *
 *  Revision 1.16.4.4  2008/06/03 12:39:05  mechevarria
 *  gov_solutions merge updates
 *
 *  Revision 1.16.4.3  2007/03/21 18:13:50  mechevarria
 *  remove old change of consignee to agent.
 *
 *  Revision 1.16.4.2  2007/02/26 22:09:24  mechevarria
 *  Updated to edit layout of portal and undo generic consignee generation.
 *
 *  Revision 1.16.4.1  2007/02/21 17:40:48  mechevarria
 *  TSA FAS initial branch
 *
 *  Revision 1.16  2006/07/11 14:09:59  dkumar
 *  used ShipmentChargesModel in place of LegChargeModel
 *
 *  Revision 1.15  2006/06/27 10:25:16  ranand
 *  removed redudant code
 *
 *  Revision 1.14  2006/05/11 16:55:28  aarora
 *  Many changes as the SessionKey class has been added to com.freightdesk.fdfolio.commons
 *
 *  Revision 1.13  2006/04/12 04:58:01  aarora
 *  Removed redundant code
 *
 *  Revision 1.12  2006/03/28 21:23:06  aarora
 *  Repackaging of fdcommons
 *
 *  Revision 1.11  2006/02/28 11:01:03  nsehra
 *  copying organization ref to involved part ref
 *
 *  Revision 1.10  2006/02/16 08:41:09  pjain
 *  declared instance variable
 *
 *  Revision 1.9  2006/02/16 08:28:32  pjain
 *  fixed 1392 bug
 *
 *  Revision 1.8  2005/09/28 08:35:54  ranand
 *  Code clean up of Address Module
 *
 *  Revision 1.7  2005/09/16 16:32:19  ranand
 *  code clean up
 *
 *  Revision 1.6  2005/08/29 08:00:42  ranand
 *  added leg stops in Routing template leg
 *
 *  Revision 1.5  2005/04/08 12:47:27  nsehra
 *  paging enhancement
 *
 *  Revision 1.4  2005/01/20 23:38:08  amrinder
 *  Changes due to removal of duplicate list in LegModel
 *
 *  Revision 1.3  2004/11/19 09:47:38  ranand
 *  no message
 *
 *  Revision 1.2  2004/09/23 13:44:28  ranand
 *  Dao's  and model's  moved from Settlement to Invoice
 *
 *  Revision 1.1  2004/09/21 08:42:29  ranand
 *  package changed from folioweb to folio
 *
 *  Revision 1.2  2004/09/16 07:25:20  ranand
 *  package name changed from organization to orghierarchy in fdfolio
 *
 *  Revision 1.1  2004/09/15 13:36:28  asingh
 *  2.6 Baseline
 * 
 */

package com.freightdesk.fdfolio.search;

import java.math.BigInteger;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Vector;

import javax.naming.InitialContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
//import org.apache.struts.action.ActionForward;
//import org.apache.struts.action.ActionMapping;

import com.freightdesk.fdfolio.dao.OrghierarchyDAO;
import com.freightdesk.fdfolio.orghierarchy.ejb.OrganizationSLSBean;
import com.freightdesk.fdfolio.orghierarchy.model.OrghierarchyModel;
import com.freightdesk.fdfolio.search.ejb.SearchBean;
//import com.freightdesk.fdfolioweb.search.form.SearchForm;
import com.freightdesk.fdcommons.Credentials;
import com.freightdesk.fdcommons.SessionKey;
import com.freightdesk.fdcommons.SessionStore;
import com.freightdesk.fdcommons.StackManager;
import com.freightdesk.fdfolio.useraccess.model.SystemUserModel;

/**
 * The business logic facade for the Search Manager.
 * 
 * This class contains methods to search organization, item, shipment, order, tariff, rate, 
 * address, and location.
 *
 * @author Biju Joseph
 * @author Amrinder Arora
 * @author Manan Gupta
 */
public final class SearchManager
{

    Logger logger = Logger.getLogger(getClass());

    OrghierarchyDAO orgDAO = new OrghierarchyDAO();

    
    
    /**
     * ??????? 
     *
     * @param request                The HTTP request being processed.
     * @param credentials            User information.
     *
     * @return java.lang.List        Returns the shipment list.
     */
    public ArrayList eventShipSearch(HttpServletRequest request, Credentials credentials)
    {
        String domain = credentials.getDomainName();
        String referenceQualifier[] = request.getParameterValues("referenceQualifier");
        String filter[] = request.getParameterValues("filter");
        String identifier[] = request.getParameterValues("identifier");
        String additionalQualifier[] = request.getParameterValues("additionalQualifier");
        String srSql = "";
        if (identifier != null)
        {
            for (int i = 0; i < identifier.length; i++)
            {
                String additionalQualifierFinal = "";
                if (additionalQualifier[i].equalsIgnoreCase("None"))
                    additionalQualifier[i] = "UNION";
                additionalQualifierFinal = additionalQualifier[i];
                if (i + 1 == identifier.length)
                    additionalQualifierFinal = "";
                if (filter[i].equals("1"))
                    srSql = srSql + " SELECT DISTINCT SR.SHIPMENTID FROM SHIPMENTREFERENCE SR WHERE   SR.SHIPMENTREFERENCETYPECODE= '" + referenceQualifier[i] + "' AND SR.SHIPMENTREFERENCEVALUE LIKE '" + identifier[i] + "%' " + additionalQualifierFinal;
                else
                    if (filter[i].equals("2"))
                        srSql = srSql + " SELECT DISTINCT SR.SHIPMENTID FROM SHIPMENTREFERENCE SR WHERE  SR.SHIPMENTREFERENCETYPECODE= '" + referenceQualifier[i] + "' AND SR.SHIPMENTREFERENCEVALUE  LIKE '%" + identifier[i] + "%' " + additionalQualifierFinal;
                    else
                        if (filter[i].equals("3"))
                            srSql = srSql + " SELECT DISTINCT SR.SHIPMENTID FROM SHIPMENTREFERENCE SR WHERE   SR.SHIPMENTREFERENCETYPECODE= '" + referenceQualifier[i] + "' AND SR.SHIPMENTREFERENCEVALUE  LIKE '%" + identifier[i] + "' " + additionalQualifierFinal;
                        else
                            if (filter[i].equals("4"))
                                srSql = srSql + " SELECT DISTINCT SR.SHIPMENTID FROM SHIPMENTREFERENCE SR WHERE   SR.SHIPMENTREFERENCETYPECODE= '" + referenceQualifier[i] + "' AND SR.SHIPMENTREFERENCEVALUE  ='" + identifier[i] + "' " + additionalQualifierFinal;
            }

        }
        ArrayList shipList = null;
        try
        {
            InitialContext ic = new InitialContext();
            SearchBean remote = new SearchBean();
            
            HttpSession session = request.getSession();
            session.setAttribute("shipments", shipList);
        }
        catch(Exception _ex)
        {
            logger.error("Exception in Search Manager   searchShipments()  method ");
        }
        return shipList;
    }

}



