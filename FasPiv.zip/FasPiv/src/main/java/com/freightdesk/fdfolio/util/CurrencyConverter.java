/** 
 * 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolio/util/CurrencyConverter.java,v 1.1.10.1 2010/08/22 23:08:34 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: CurrencyConverter.java,v $
 *  Revision 1.1.10.1  2010/08/22 23:08:34  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.1  2004/09/15 13:05:24  ranand
 *  2.6 Baseline
 *
 * 
 */



package com.freightdesk.fdfolio.util;

import java.io.Serializable;
import java.util.Hashtable;
import java.util.Map;

import org.apache.log4j.Logger;

public class CurrencyConverter
    implements Serializable
{

    private static Map currencyTable = new Hashtable();

    static {
		currencyTable.put("USD",new Double(1.4));
		currencyTable.put("INR",new Double(64.4));
		currencyTable.put("KWD",new Double(0.4));
		currencyTable.put("AUD",new Double(2.1));
		currencyTable.put("SGD",new Double(2.4));
		currencyTable.put("JPY",new Double(163.1));
		currencyTable.put("PD",new Double(0.87));
		currencyTable.put("EUR",new Double(1.27175));
		currencyTable.put("GBP",new Double(0.87686));
	}
     /**
	 * a logger
	 */
	public static Logger logger = Logger.getLogger("com.freightdesk.fdfolio.util.CurrencyConverter");


    private CurrencyConverter()
    {
		// load currency conversion table
		/*try {
			ServiceLocator serviceLocator = ServiceLocator.getInstance();
			RateSLSHome rateSLSHome = (RateSLSHome) (serviceLocator.getRemoteHome("RateSLSBean", RateSLSHome.class));
			RateSLS rateSLS = rateSLSHome.create();
			rateSLS.getCurrencyValues();
			logger.debug("CurrencyConverter :  currencyConversionTable loaded");
		}
		catch (Throwable t) {
			logger.error("CurrencyConverter() : constructor ", t);
			throw new RuntimeException("loading of currency conversion table did not complete successfully");
		}*/
    }

    public static double convertToBaseCurrency(String currencyCode, double aValue)
    {
        if(currencyCode == null)
            return 0.0D;
        Double conversionFactor = null;
        double convertedValue = 0.0D;
        conversionFactor = (Double)currencyTable.get(currencyCode);
        if(conversionFactor != null)
            convertedValue = aValue / conversionFactor.doubleValue();
        return convertedValue;
    }

    public static double convertToCurrency(String fromCurrencyCode, String toCurrencyCode, double aValue)
    {
        if(fromCurrencyCode == null || toCurrencyCode == null)
            return 0.0D;
        else if (fromCurrencyCode.equalsIgnoreCase(toCurrencyCode))
        return aValue;

        Double conversionFactor = null;
        double convertedValue = 0.0D;
        conversionFactor = (Double)currencyTable.get(fromCurrencyCode);
        if(conversionFactor != null)
        {
            aValue /= conversionFactor.doubleValue();
            conversionFactor = (Double)currencyTable.get(toCurrencyCode);
            if(conversionFactor != null)
                convertedValue = conversionFactor.doubleValue() * aValue;
        }
        return convertedValue;
    }

    public static Double getCurrencyFactor(String currencyCode)
    {
        if(currencyCode != null)
            return (Double)currencyTable.get(currencyCode);
        else
            return new Double(0.0D);
    }

    public static void loadCurrencies(Hashtable newCurrencyTable)
    {
        currencyTable = newCurrencyTable;
    }

    /*public static CurrencyConverter getCurrencyConverter() {

	}*/
}

