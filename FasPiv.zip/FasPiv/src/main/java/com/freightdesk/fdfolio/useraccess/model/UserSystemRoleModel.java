/** 
 * 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolio/useraccess/model/UserSystemRoleModel.java,v 1.3.4.1 2010/08/22 23:08:31 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: UserSystemRoleModel.java,v $
 *  Revision 1.3.4.1  2010/08/22 23:08:31  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.3  2006/03/28 21:23:07  aarora
 *  Repackaging of fdcommons
 *
 *  Revision 1.2  2005/08/01 09:41:08  pjain
 *  refactored UserModel to BaseModel
 *
 *  Revision 1.1  2004/09/15 13:07:11  ranand
 *  2.6 Baseline
 *
 * 
 */



package com.freightdesk.fdfolio.useraccess.model;

import java.io.Serializable;
import java.sql.Timestamp;

import com.freightdesk.fdcommons.BaseModel;

public class UserSystemRoleModel extends BaseModel
    implements Serializable
{

    private long userSystemRoleId;
    private String systemRoleName;
    private String systemRoleCode;
    private long systemUserId;
    private String userSystemRoleStatus;
    private String lastStatusUpdateUserId;
    private Timestamp lastStatusUpdateTimestamp;


    public UserSystemRoleModel()
    {
    }

    public UserSystemRoleModel(String systemRoleCode, long userSystemRoleId, long systemUserId, String userSystemRoleStatus, String lastStatusUpdateUserId, 
            Timestamp lastStatusUpdateTimestamp, String createUserId, Timestamp createTimestamp, String domainName)
    {
        this.systemRoleCode = systemRoleCode;
        this.userSystemRoleId = userSystemRoleId;
        this.userSystemRoleStatus = userSystemRoleStatus;
        this.lastStatusUpdateUserId = lastStatusUpdateUserId;
        this.lastStatusUpdateTimestamp = lastStatusUpdateTimestamp;
        this.systemUserId = systemUserId;
        super.createUserId = createUserId;
        super.createTimestamp = createTimestamp;
        super.domainName = domainName;
    }

    public UserSystemRoleModel(String systemRoleCode, long userSystemRoleId, String systemRoleName, long systemUserId, String userSystemRoleStatus, 
            String lastStatusUpdateUserId, Timestamp lastStatusUpdateTimestamp, String createUserId, Timestamp createTimestamp, String domainName)
    {
        this.systemRoleCode = systemRoleCode;
        this.userSystemRoleId = userSystemRoleId;
        this.systemRoleName = systemRoleName;
        this.userSystemRoleStatus = userSystemRoleStatus;
        this.lastStatusUpdateUserId = lastStatusUpdateUserId;
        this.lastStatusUpdateTimestamp = lastStatusUpdateTimestamp;
        this.systemUserId = systemUserId;
        super.createUserId = createUserId;
        super.createTimestamp = createTimestamp;
        super.domainName = domainName;
    }

	/**
	 * Implements the abstract method defined by BaseModel.
	 * @return primaryKey  the unique id key for this model object.
	 */
	public long getPrimaryKey(){
		return this.userSystemRoleId;
	}  

    public Timestamp getLastStatusUpdateTimestamp()
    {
        return lastStatusUpdateTimestamp;
    }

    public String getLastStatusUpdateUserId()
    {
        if(lastStatusUpdateUserId == null)
            lastStatusUpdateUserId = "";
        return lastStatusUpdateUserId;
    }

    public String getUserSystemRoleStatus()
    {
        if(userSystemRoleStatus == null)
            userSystemRoleStatus = "";
        return userSystemRoleStatus;
    }

    public String getSystemRoleCode()
    {
        if(systemRoleCode == null)
            systemRoleCode = "";
        return systemRoleCode;
    }

    public String getSystemRoleName()
    {
        return systemRoleName;
    }

    public long getSystemUserId()
    {
        return systemUserId;
    }

    public long getUserSystemRoleId()
    {
        return userSystemRoleId;
    }

    public void setLastStatusUpdateTimestamp(Timestamp lastStatusUpdateTimestamp)
    {
        this.lastStatusUpdateTimestamp = lastStatusUpdateTimestamp;
    }

    public void setLastStatusUpdateUserId(String lastStatusUpdateUserId)
    {
        this.lastStatusUpdateUserId = lastStatusUpdateUserId;
    }

    public void setUserSystemRoleStatus(String userSystemRoleStatus)
    {
        this.userSystemRoleStatus = userSystemRoleStatus;
    }

    public void setSystemRoleCode(String systemRoleCode)
    {
        this.systemRoleCode = systemRoleCode;
    }

    public void setSystemRoleName(String systemRoleName)
    {
        this.systemRoleName = systemRoleName;
    }

    public void setSystemUserId(long systemUserId)
    {
        this.systemUserId = systemUserId;
    }

    public void setUserSystemRoleId(long userSystemRoleId)
    {
        this.userSystemRoleId = userSystemRoleId;
    }
}

