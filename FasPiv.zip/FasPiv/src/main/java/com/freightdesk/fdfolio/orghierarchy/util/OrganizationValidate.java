/** 
 * 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolio/orghierarchy/util/OrganizationValidate.java,v 1.3.4.1 2010/08/22 23:08:48 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: OrganizationValidate.java,v $
 *  Revision 1.3.4.1  2010/08/22 23:08:48  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.3  2006/04/12 23:44:31  aarora
 *  Removed extra code
 *
 *  Revision 1.2  2006/03/28 21:23:06  aarora
 *  Repackaging of fdcommons
 *
 *  Revision 1.1  2004/09/16 07:22:24  ranand
 *  moved from organization package
 *
 *  Revision 1.1  2004/09/15 13:24:34  ranand
 *  2.6 Baseline
 *
 * 
 */



package com.freightdesk.fdfolio.orghierarchy.util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Hashtable;

import javax.ejb.EJBException;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import org.apache.log4j.Logger;

import com.freightdesk.fdcommons.ConnectionUtil;

public class OrganizationValidate
{
    private long orgId;
    public Hashtable errors;
    protected Logger logger = Logger.getLogger (getClass());

    public OrganizationValidate()
    {
        errors = new Hashtable();
        errors = new Hashtable();
    }

    public OrganizationValidate(long orgId)
    {
        errors = new Hashtable();
        this.orgId = orgId;
    }

    public OrganizationValidate(String organizationName, String locationName, String contactName, String countryCode, String domainName)
    {
        errors = new Hashtable();
        errors = new Hashtable();
    }

    public OrganizationValidate(ArrayList validationList)
    {
        errors = new Hashtable();
    }

    private Connection getConnection()
        throws SQLException
    {
        InitialContext ictx = null;
        DataSource dataSource = null;
        try
        {
            if(dataSource == null)
            {
                ictx = new InitialContext();
                dataSource = (DataSource)ictx.lookup("java:comp/env/oraclePool");
            }
        }
        catch(Exception ex)
        {
            logger.error ("OrganizationValidate[getConnection()]-> ", ex);
            throw new EJBException(ex);
        }
        return dataSource.getConnection();
    }

    public long getOrgId()
    {
        return orgId;
    }

    public boolean isOrgIdValidationForDeletion()
        throws SQLException
    {
        boolean isValid = true;
        String dAddressIdQueryForShipment = "SELECT DESTINATIONADDRESSID FROM SHIPMENT WHERE DESTINATIONADDRESSID IN (SELECT ADDRESSID FROM ORGHIERARCHY WHERE ORGID=" + orgId + ")";
        String oAddressIdQueryForShipment = "SELECT ORIGINADDRESSID FROM SHIPMENT WHERE ORIGINADDRESSID IN (SELECT ADDRESSID FROM ORGHIERARCHY WHERE ORGID=" + orgId + ")";
        String dAddressIdQueryForLeg = "SELECT DESTINATIONADDRESSID FROM LEG WHERE DESTINATIONADDRESSID IN (SELECT ADDRESSID FROM ORGHIERARCHY WHERE ORGID=" + orgId + ")";
        String oAddressIdQueryForLeg = "SELECT ORIGINADDRESSID FROM LEG WHERE ORIGINADDRESSID IN (SELECT ADDRESSID FROM ORGHIERARCHY WHERE ORGID=" + orgId + ")";
        String involvedPartyQuery = "SELECT ORGID FROM INVOLVEDPARTY WHERE ORGID=" + orgId;
        String legStopQuery = "SELECT ADDRESSID FROM LEGSTOP WHERE ADDRESSID IN (SELECT ADDRESSID FROM ORGHIERARCHY WHERE ORGID=" + orgId + ")";
        try
        {
            if(isValidForDeletion(dAddressIdQueryForShipment))
                return false;
            if(isValidForDeletion(oAddressIdQueryForShipment))
                return false;
            if(isValidForDeletion(dAddressIdQueryForLeg))
                return false;
            if(isValidForDeletion(oAddressIdQueryForLeg))
                return false;
            if(isValidForDeletion(involvedPartyQuery))
                return false;
            if(isValidForDeletion(legStopQuery))
                return false;
        }
        catch (SQLException sqEx)
        {
            logger.error("isOrgIdValidationForDeletion: exception ", sqEx);
            throw sqEx;
        }
        return isValid;
    }

    public boolean isValidCountryCode(String countryCode)
    {
        boolean flag = false;
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try
        {
            String sqlStr = "SELECT COUNTRYCODE FROM COUNTRY WHERE COUNTRYCODE=?";
            conn = getConnection();
            pstmt = conn.prepareStatement(sqlStr);
            pstmt.setString(1, countryCode);
            rs = pstmt.executeQuery();
            if (rs.next())
                flag = true;
            pstmt.close();
            rs.close();
            conn.close();
        }
        catch (Exception e)
        {
            logger.error("isValidCountryCode(): exception ", e);
        }
        finally 
        {
            ConnectionUtil.closeResources(conn, pstmt, rs);
        }
        return flag;
    }

    private boolean isValidForDeletion(String query)
        throws SQLException
    {
        boolean flag = false;
        Connection connection = null;
        Statement stmt = null;
        ResultSet rs = null;
        try
        {
            connection = getConnection();
            stmt = connection.createStatement();
            rs = stmt.executeQuery(query); 
            if (rs.next())
                flag = true;
        }
        catch (SQLException sqEx)
        {
            logger.error ("OrganizationValidate[isValidForDeletion(query)] -> ", sqEx);
            throw sqEx;
        }
        finally
        {
            ConnectionUtil.closeResources(connection, stmt, rs);
        }
        return flag;
    }
}
