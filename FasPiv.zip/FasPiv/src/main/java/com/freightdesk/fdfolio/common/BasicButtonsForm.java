/** 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolio/common/BasicButtonsForm.java,v 1.4.6.3 2010/08/22 23:08:26 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: BasicButtonsForm.java,v $
 *  Revision 1.4.6.3  2010/08/22 23:08:26  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.4.6.2  2009/09/23 18:02:18  mechevarria
 *  import clean via eclipse
 *
 *  Revision 1.4.6.1  2009/09/22 19:32:42  mechevarria
 *  updated user management
 *
 *  Revision 1.4  2005/03/01 23:22:54  amrinder
 *  Formatting changes
 *
 *  Revision 1.3  2004/09/15 13:03:45  ranand
 *  2.6 Baseline
 */

package com.freightdesk.fdfolio.common;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
//import org.apache.struts.action.ActionMapping;
//import org.apache.struts.validator.ValidatorForm;

/**
 * A form bean to map the common buttons on pages of the
 * FreightDesk LCP Application.
 *
 * It holds the basicBtnClicked, and constant values to help decode
 * which buttons was clicked on the corresponding JSP.
 *
 * @author Amrinder Arora
 * @see com.freightdesk.common.BasicButtonsAction
 */
//public class BasicButtonsForm extends ValidatorForm {
public class BasicButtonsForm {

    protected static Logger logger = Logger.getLogger ("com.freightdesk.common.BasicButtonsForm");

    /** The instance variable to hold the value corresponding to the button
     * that was clicked. */
    private String basicBtnClicked;
    private List operationLevelKeys;

    /** Gets the value of basicBtnClicked attribute */
    public String getBasicBtnClicked() {
        logger.debug ("getBasicBtnClicked: " + basicBtnClicked);
        return basicBtnClicked;
    }
    /** Sets the value of basicBtnClicked attribute */
    public void setBasicBtnClicked (String newBasicBtnClicked) {
        logger.debug ("setBasicBtnClicked: " + newBasicBtnClicked);
        basicBtnClicked = newBasicBtnClicked;
    }
 
    // constant values
    public static String SAVE = "SAVE";
    public static String SAVE_RETURN = "SAVE_RETURN";
	public static String SAVE_ALL = "SAVE_ALL";	
    public static String SAVE_NEW = "SAVE_NEW";
    public static String CANCEL = "CANCEL";

//    public void reset (ActionMapping mapping, HttpServletRequest request)
//    {
//        basicBtnClicked = null;
//    }
    /**
     * @return operationLevel
     */
    public List getOperationLevelKeys()
    {
        return operationLevelKeys;
    }

    /**
     * @param argOperationLevel
     */
    public void setOperationLevelKeys(List argOperationLevelKeys)
    {
        operationLevelKeys = argOperationLevelKeys;
    }
}
