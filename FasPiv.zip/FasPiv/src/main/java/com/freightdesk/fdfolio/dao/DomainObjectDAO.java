
/** 
 * 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolio/dao/DomainObjectDAO.java,v 1.2.6.1 2010/08/22 23:08:30 mechevarria Exp $
 * 
 */


package com.freightdesk.fdfolio.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

import com.freightdesk.fdcommons.BaseDao;
import com.freightdesk.fdcommons.ConnectionUtil;
import com.freightdesk.fdcommons.DomainObjectModel;


/** 
*  This class defines the methods for performing insert, update, delete, Read operations on DOMAINOBJECT table.
*
*  @author Biju Joseph
*/
public class DomainObjectDAO extends BaseDao {

	/**
	* Creates the domainObject model in the database.
	*/
	public void create(DomainObjectModel domainObjectModel)
		throws SQLException
	{
		Connection connection = null;
		PreparedStatement pStmt = null;
		try	{
			String DML = "INSERT INTO DOMAINOBJECT (DOMAINOBJECTID, DOMAINOBJECTCODE, DOMAINNAME, STATUS, CREATEUSERID, CREATETIMESTAMP, LASTUPDATEUSERID, LASTUPDATETIMESTAMP) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
			connection = getConnection();
			pStmt = connection.prepareStatement(DML);
			if (domainObjectModel.getDomainObjectId() == 0)	{
				domainObjectModel.setDomainObjectId(getNextID("DOMAINOBJECTID"));
			}
			pStmt.setLong(1, domainObjectModel.getDomainObjectId());
			pStmt.setString(2, domainObjectModel.getDomainObjectCode());
			pStmt.setString(3, domainObjectModel.getDomainName());
			pStmt.setString(4, domainObjectModel.getStatus());
			pStmt.setString(5, domainObjectModel.getCreateUserId());
			pStmt.setTimestamp(6, domainObjectModel.getCreateTimestamp());			
			if(domainObjectModel.getLastUpdateUserId() != null) {
				pStmt.setString(7, domainObjectModel.getLastUpdateUserId());
			} else {
				pStmt.setNull(7, Types.VARCHAR);
			}			
			if(domainObjectModel.getLastUpdateTimestamp() != null) {			
				pStmt.setTimestamp(8, domainObjectModel.getLastUpdateTimestamp());
			} else {
				pStmt.setNull(8, Types.TIMESTAMP);
			}

			pStmt.executeUpdate();
			
		} catch(SQLException sqle)	{
			logger.error("create : ", sqle);
			throw sqle;
		} finally {
			ConnectionUtil.closeResources(connection, pStmt, null);
		}
	}
	
	/**
	* Updates the domainObject model in the database.
	*/
	public void update(DomainObjectModel domainObjectModel) throws SQLException
	{
		Connection connection = null;
		PreparedStatement pStmt = null;        
		try	{
			String DML = "UPDATE DOMAINOBJECT SET  DOMAINOBJECTCODE=?, DOMAINNAME=?, STATUS=?, CREATEUSERID=?, CREATETIMESTAMP=?, LASTUPDATEUSERID=?, LASTUPDATETIMESTAMP=? WHERE DETERMINANTID = ?";
			connection = getConnection();
			pStmt = connection.prepareStatement(DML);

			pStmt.setString(1, domainObjectModel.getDomainObjectCode());
			pStmt.setString(2, domainObjectModel.getDomainName());
			pStmt.setString(3, domainObjectModel.getStatus());
			pStmt.setString(4, domainObjectModel.getCreateUserId());
			pStmt.setTimestamp(5, domainObjectModel.getCreateTimestamp());
			pStmt.setString(6, domainObjectModel.getLastUpdateUserId());
			pStmt.setTimestamp(7, domainObjectModel.getLastUpdateTimestamp());
			pStmt.setLong(8, domainObjectModel.getDomainObjectId());

			pStmt.executeUpdate();
			
		} catch(SQLException sqle)	{
			logger.error("update: ", sqle);
			throw sqle;
		} finally {
			ConnectionUtil.closeResources(connection, pStmt, null);
		}		
	}


   /**
	* Retrieves the domainObject model from the database.
	*/
	public DomainObjectModel retrieve(long domainObjectId) throws SQLException
	{
		Connection connection = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String query = "SELECT DOMAINOBJECTID, DOMAINOBJECTCODE, DOMAINNAME, STATUS, CREATEUSERID, CREATETIMESTAMP, LASTUPDATEUSERID, LASTUPDATETIMESTAMP FROM DOMAINOBJECT WHERE DOMAINOBJECTID = ?";
		DomainObjectModel domainObjectModel = null;
		try {
		  connection = getConnection();
		  pstmt = connection.prepareStatement(query);
		  pstmt.setLong (1,domainObjectId);
		  logger.debug ("domainObjectId: " + domainObjectId);
		  rs = pstmt.executeQuery();
		  while (rs.next()) {
			  domainObjectModel = new DomainObjectModel ();
			  domainObjectModel.setDomainObjectId(domainObjectId);
			  domainObjectModel.setDomainObjectCode(rs.getString("DOMAINOBJECTCODE"));			  
			  domainObjectModel.setDomainName(rs.getString ("DOMAINNAME"));
			  domainObjectModel.setCreateUserId(rs.getString ("CREATEUSERID"));
			  domainObjectModel.setCreateTimestamp(rs.getTimestamp ("CREATETIMESTAMP"));
			  domainObjectModel.setLastUpdateUserId(rs.getString ("LASTUPDATEUSERID"));
			  domainObjectModel.setLastUpdateTimestamp(rs.getTimestamp ("LASTUPDATETIMESTAMP"));			  
		  }
	  	} catch(SQLException sqle) {
			logger.error("retrieve ", sqle);
			throw sqle;
		} finally {
		    ConnectionUtil.closeResources(connection, pstmt, rs);
		}

		return domainObjectModel;
	}	
	
	//deletes the domainObject model
	public void delete(long domainObjectId) throws SQLException
	{
		PreparedStatement pStmt = null;
		Connection connection = null;
		String DML = "DELETE DOMAINOBJECT WHERE DOMAINOBJECTID = ?";

		try	{
			connection = getConnection();
			pStmt = connection.prepareStatement(DML);
			pStmt.setLong(1, domainObjectId);
			pStmt.executeUpdate();
		} catch(SQLException sqle)	{
			logger.error("delete: ", sqle);
			throw sqle;
		} finally {
			ConnectionUtil.closeResources(connection, pStmt, null);
		}
	}
}