/** 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolio/useraccess/ejb/DirectoryManager.java,v 1.3.2.3 2010/09/23 19:35:23 mechevarria Exp $ 
 * 
 *  Modification History:
 *  $Log: DirectoryManager.java,v $
 *  Revision 1.3.2.3  2010/09/23 19:35:23  mechevarria
 *  remove ejb layer for instantiating objects.  direct calls to bean class now made
 *
 *  Revision 1.3.2.2  2010/08/22 23:08:44  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.3.2.1  2009/09/23 18:04:14  mechevarria
 *  import cleanup via eclipse
 *
 *  Revision 1.3  2006/10/09 12:14:22  dkumar
 *  created seperate FDSuite properties
 *
 *  Revision 1.2  2006/03/28 21:23:02  aarora
 *  Repackaging of fdcommons
 *
 *  Revision 1.1  2005/08/11 11:00:23  pjain
 *  BaseLine
 *
 */
package com.freightdesk.fdfolio.useraccess.ejb;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.naming.AuthenticationException;
import javax.naming.Context;
import javax.naming.NameAlreadyBoundException;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.BasicAttribute;
import javax.naming.directory.BasicAttributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;

import com.freightdesk.fdcommons.FDSuiteProperties;
import org.apache.log4j.Logger;

/**
 * @author Pankaj Jain
 * This class manages all Directory operations. 
 */
public class DirectoryManager  {

  protected static Logger logger = Logger.getLogger("com.freightdesk.fdfolio.useraccess.ejb.DirectoryManager");
  private DirContext dirctx = null;
  
  /** LDAP host */
  private static String LDAP_HOST = FDSuiteProperties.getProperty("LDAP_HOST");
  
  /** OID Context */
  private static String OID_CONTEXT = FDSuiteProperties.getProperty("OID_CONTEXT");
  
  /** User Context */
  private static String USER_CONTEXT = FDSuiteProperties.getProperty("USER_CONTEXT");

  /**
   * Empty default Constructor.
   */
  public DirectoryManager() {
  }

  /**
   * Checks if the specified uname is a member of the specified group.
   * 
   * @param uname  Relative Distinguished name of the user
   * @param groupDN Distingushed name of the group
   * @return  true - if the user belongs to the group, else false
   * @exception NamingException if any directory operation fails
   */
  public boolean isUserInGroup(String uname,String groupDN) 
    throws NamingException {
    
    boolean ingroup = false;

    // Get the Distinguished Name of the user
    String userDN = this.getUserDN(uname);    
    
    // Filter to check if the user DN is a member
    // A user is a member of a group if the uniqueMember attribute of that group entry
    // has the user DN value.
    String filter = "(uniqueMember="+userDN+")";

    // Initialize search controls to search with scope as sub tree
    SearchControls searchControls = new SearchControls();
    searchControls.setSearchScope(SearchControls.SUBTREE_SCOPE) ;
    // Set the attributes to be returned 
    searchControls.setReturningAttributes(new String[]{"cn"});

    // Search under the specified group
    NamingEnumeration  results = dirctx.search(groupDN, filter, searchControls);

    // If the search has results, then the user is a member    
     if (results.hasMore()) { 
         ingroup = true;
     }  // else user not present, i.e defaulted

     return ingroup;
  }

  /**
   *  Authenticates the user credentials with Directory.
   *  
   * @param username  User Name of the user
   * @param passwd Password of the user
   * @return  true - if the credentials are valid
   * 
   * @exception AuthenticationException If credentials are invalid
   * @exception NamingException if any directory operation fails
   */
  public Attributes authenticateUser(String username, String passwd) 
    throws AuthenticationException,NamingException {

      Attributes attributes = null;
          
      // Get the Distinguished Name
      
      String dn = this.getUserDN(username);
      logger.info("User DN is "+dn);
      try {
        // Authenticate with Directory
        dirctx = this.getDirectoryContext(dn,passwd);
        
        attributes = dirctx.getAttributes(dn);
        
      } catch(AuthenticationException authEx)   {
      
        throw new AuthenticationException(" Invalid Password ");
      }
        
      return attributes;
  }

  /**
   * Retrieves the Distinguished name of them of the specified RDN.
   * 
   * @param uname  Relative Distinguished name.
   * @return  Distinguished name of the user
   * @exception NamingException if directory operation fails
   */
  public String getUserDN(String uname) 
    throws NamingException {
  
    DirContext dCtx = null;
    
    // if Grocery context is available, use it, else create one as application entity
    if(dirctx==null) {
      dCtx = this.getDirectoryContext(OID_CONTEXT,"");
    }   else {
      dCtx = dirctx;
    }  
      
      SearchResult searchResult = null;
      NamingEnumeration results = null;
     String userDN = null;
     String filter="(uid="+uname+")";
    
        // To set search controls to search with subtree scope
        SearchControls searchControls = new SearchControls();
       searchControls.setSearchScope(SearchControls.SUBTREE_SCOPE);

        // Search the directory based on the SearchBean string from the specified context
        results = dCtx.search(USER_CONTEXT+","+OID_CONTEXT, filter, searchControls);

        // If matching record found
        if (results.hasMore()) { 
            
            searchResult = (SearchResult)results.next();            
            // Build the User DN
            userDN = searchResult.getName() + ","+USER_CONTEXT+","+OID_CONTEXT;

        } else {
          // User not found
          throw new NamingException(" Invalid Username ");
        }
     return userDN;
  }

  /**
   *  Initializes a Directory Context with the specified credentials and return it.
   *  If the password is blank(null), it binds as anonymous user and returns the
   *  context.
   *  
   * @param username Directory user name
   * @param password Directory user password
   * @return  valid directory context, if credentials are valid
   * @exception AuthenticationException  if credentails are invalid
   * @exception NamingException if directory operation fails
   */
  public DirContext getDirectoryContext(String username,String password) 
       throws AuthenticationException,NamingException {

     DirContext dCtx = null;
     
      //Build the LDAP url 
      String ldapurl = LDAP_HOST;

      Hashtable env = new Hashtable();
      env.put(Context.INITIAL_CONTEXT_FACTORY,
          "com.sun.jndi.ldap.LdapCtxFactory");
      env.put(Context.PROVIDER_URL, ldapurl);
      
      // if password is specified, set the credentials
      if( password != null ) {
        env.put(Context.SECURITY_AUTHENTICATION, "simple");
        env.put(Context.SECURITY_PRINCIPAL,username);
        env.put(Context.SECURITY_CREDENTIALS, password);
      } 

      // Bind and initialize the Directory context
      dCtx = new InitialDirContext(env);

      return dCtx;
  }

  /**
   * Searchs the directory under the specified context with specified filter 
   * and returns the search results.
   * The scope is set to one-level.
   * 
   * @param ctxname Context under which seach has to be done.
   * @param filter Search filter
   * @return  Attributes matching the SearchBean specification
   * @exception NamingException if directory search fails
   */
   public Collection search( String ctxname, String filter)
     throws NamingException {

      SearchResult searchResult = null;
      NamingEnumeration results = null;
      Collection retColl = new ArrayList();
      Attributes attrs = null;
  
        // Initialize SearchBean search controls with one-level scope
        SearchControls searchControls = new SearchControls();
       searchControls.setSearchScope(SearchControls.ONELEVEL_SCOPE);

        // Search the directory based on the SearchBean string under the specified context
        results = dirctx.search(ctxname, filter, searchControls);

        // Check if any matching results were found in Directory
        if (results.hasMore()) { 
  
          // Iterate through the results and populate the return collection
          do { 
          
            searchResult = (SearchResult)results.next();
            // Get the attributes 
            attrs = searchResult.getAttributes();

            retColl.add(attrs);
            
          }while(results.hasMore()); 
        }
        return retColl;
     } 
      

  /**
   * Creates an entry in Directory with the specified attributes and objectclass,  
   * with the specified Distingushed Name.
   * 
   * @param dn Distinguished name of the entry to be created
   * @param objCls Object classes that the entry must use
   * @param map Attribute,value mappings of the entry
   * @exception NamingException if adding entry fails
   * @exception NameAlreadyBoundException if user already exists
   */
   public void addDirectoryEntry(String dn, List objCls, Map map)
     throws NamingException,NameAlreadyBoundException {

      // Create attribute list, ignore case of attribute names
      Attributes attrs = new BasicAttributes(true);

      if( !objCls.isEmpty()) {
        Attribute objclass = new BasicAttribute("objectclass");
        // Iterate thriough the collection and add the object classes to the attribute
        Iterator objclsIter = objCls.iterator();        
        while(objclsIter.hasNext()) {
          // Add the object classes        
          objclass.add(objclsIter.next());  
        }             
        // Add the object class attribute to list
        attrs.put(objclass);
      }

      // Iterate through other attributes and add to attributes list
      Iterator attrsIter = map.entrySet().iterator();

      while( attrsIter.hasNext() ) {
        Map.Entry attr = (Map.Entry)attrsIter.next();
        attrs.put(new BasicAttribute((String)attr.getKey(),attr.getValue()));
      }
      
      // add the directory entry to the directory with the attributes
      dirctx.createSubcontext(dn, attrs);
     
   }


  /**
   * Replaces the specified attributes of an entry.
   * 
   * @param dn The distinguished name of the entry whose attributes have to be modified
   * @param map Attribute,Value pair to be replaced
   * @exception NamingException if directory operation fails, or attribute is not present
   */
  public void modifyDirectoryEntry(String dn, Map map) 
    throws NamingException  {

      // Get the attribute,newvalue mapping
      Iterator attrsIter = map.entrySet().iterator();

      // Construct the attributes list
      Attributes attrs = new BasicAttributes(true); // case-ignore

      while( attrsIter.hasNext() ) {
        Map.Entry attr = (Map.Entry)attrsIter.next();
        attrs.put(new BasicAttribute((String)attr.getKey(),attr.getValue()));
      }

      // Replace the existing attribute values with the specified new values
      dirctx.modifyAttributes(dn,DirContext.REPLACE_ATTRIBUTE, attrs);
    
  }

  /**
   *  Adds the specified user to the group.
   *  
   * @param uid Relative distinguished name of the entry 
   * @param groupdn Group to which the user has to be added
   * @exception NamingException if adding to group fails, or user is already a member
   */
  public void addToGroup(String uid,String groupdn) 
    throws NamingException  {
      // Build the distinguished name of the entry
      String userdn = this.getUserDN(uid);
      
      Attributes attrs = new BasicAttributes(true); 

      //The DN of the user  has to be added to the uniqueMember attribute of the group 
      // to become a member
      attrs.put(new BasicAttribute("uniqueMember", userdn));

      // Add the user as member
      dirctx.modifyAttributes(groupdn,DirContext.ADD_ATTRIBUTE,attrs);
  }

  /**
   * Removes the specified user from the group.
   * 
   * @param uid  User to be removed from group
   * @param groupdn Group from which the user has to be removed
   * @exception NamingException if directory opertaion fails, or the user is not a memeber of this group
   */
  public void removeFromGroup(String uid,String groupdn) 
    throws NamingException  {
      // Build the user distinguished name
      String userdn = this.getUserDN(uid);
      
      Attributes attrs = new BasicAttributes(true); // case-ignore

      // Remove the user dn from the uniqueMember attribute
      attrs.put(new BasicAttribute("uniqueMember", userdn));

      // Modify the attributes in Directory
      dirctx.modifyAttributes(groupdn,DirContext.REMOVE_ATTRIBUTE,attrs);
  }


  /**
   *  Delete the specified entry from Directory.
   *  
   * @param dn The distinguished name of the entry to be removed
   * @exception NamingException if entry not found
   */
  public void deleteDirectoryEntry(String dn)
    throws NamingException  {
      // delete the entry with this DN
      dirctx.destroySubcontext(dn);
  }

  

}