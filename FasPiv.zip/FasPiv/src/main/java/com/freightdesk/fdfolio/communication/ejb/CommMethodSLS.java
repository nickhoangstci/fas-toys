/** 
 * 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolio/communication/ejb/CommMethodSLS.java,v 1.5.6.1 2010/08/22 23:08:35 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: CommMethodSLS.java,v $
 *  Revision 1.5.6.1  2010/08/22 23:08:35  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.5  2005/03/10 19:33:25  agarg
 *  Changed return type of Create method from void to CommunicationModel
 *
 *  Revision 1.4  2004/11/29 12:46:53  biju
 *  DAO/EJB changes for UM
 *
 *  Revision 1.3  2004/09/15 13:06:03  ranand
 *  2.6 Baseline
 *
 * 
 */



package com.freightdesk.fdfolio.communication.ejb;

import java.rmi.RemoteException;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.ejb.EJBObject;

import com.freightdesk.fdfolio.communication.model.CommunicationModel;

public interface CommMethodSLS
    extends EJBObject
{
    public abstract ArrayList getCommMethodTypeCodeName(String domainName)
        throws RemoteException, SQLException;
        
	public CommunicationModel createCommunicationMethod(CommunicationModel communicationModel) throws RemoteException;
		
	public void updateCommunicationMethod(CommunicationModel communicationModel) throws RemoteException;

}

