/** 
 * 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolio/communication/ejb/CommMethodSLSHome.java,v 1.3.10.1 2010/08/22 23:08:35 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: CommMethodSLSHome.java,v $
 *  Revision 1.3.10.1  2010/08/22 23:08:35  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.3  2004/09/15 13:06:03  ranand
 *  2.6 Baseline
 *
 * 
 */



package com.freightdesk.fdfolio.communication.ejb;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.ejb.EJBHome;


public interface CommMethodSLSHome
    extends EJBHome
{

    public abstract CommMethodSLS create()
        throws CreateException, RemoteException;
}

