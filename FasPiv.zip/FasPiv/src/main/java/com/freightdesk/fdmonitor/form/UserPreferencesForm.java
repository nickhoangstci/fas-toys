/** 
 * 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolioweb/setup/form/Attic/UserPreferencesForm.java,v 1.6.4.2 2010/08/22 23:08:39 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: UserPreferencesForm.java,v $
 *  Revision 1.6.4.2  2010/08/22 23:08:39  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.6.4.1  2010/02/03 20:33:44  mechevarria
 *  re-write for FAS
 *
 *  Revision 1.6  2006/07/19 14:26:31  dkumar
 *  change due to removal of related_product_label and related_product_value
 *
 *  Revision 1.5  2006/05/24 14:09:59  dkumar
 *  added field skinCode and skinList
 *
 *  Revision 1.4  2006/04/07 16:12:03  ranand
 *  make the  Dashboard cofigurable
 *
 *  Revision 1.3  2006/03/28 21:23:07  aarora
 *  Repackaging of fdcommons
 *
 *  Revision 1.2  2005/08/31 11:05:14  ranand
 *  changes for customization of Dashboard
 *
 *  Revision 1.1  2004/09/15 13:36:28  asingh
 *  2.6 Baseline
 *
 * 
 */

package com.freightdesk.fdmonitor.form;

import java.util.List;

import com.freightdesk.fdcommons.OptionBean;
import com.freightdesk.fdfolio.common.BasicButtonsForm;

/**
 * The UserPreferenceForm is associated with UserPreferences.jsp and the
 * UserPreferenceAction.
 * 
 * @author Mike Echevarria
 */

public class UserPreferencesForm {

	private static final long serialVersionUID = 1L;
	private long systemUserId;
	private String uomCode;
	private List<OptionBean> uomList;

	
	public long getSystemUserId() {
		return systemUserId;
	}

	public void setSystemUserId(long systemUserId) {
		this.systemUserId = systemUserId;
	}

	public UserPreferencesForm() {
	}

	public String getUomCode() {
		return uomCode;
	}

	public void setUomCode(String uomCode) {
		this.uomCode = uomCode;
	}

	public List<OptionBean> getUomList() {
		return uomList;
	}

	public void setUomList(List<OptionBean> uomList) {
		this.uomList = uomList;
	}

}
