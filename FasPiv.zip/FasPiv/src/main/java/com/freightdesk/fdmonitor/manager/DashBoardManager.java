/** 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolio/dashboard/Attic/DashBoardManager.java,v 1.5.4.2 2010/08/22 23:08:47 mechevarria Exp $ 
 * 
 *  Modification History:
 *  $Log: DashBoardManager.java,v $
 *  Revision 1.5.4.2  2010/08/22 23:08:47  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.5.4.1  2009/09/23 18:04:15  mechevarria
 *  import cleanup via eclipse
 *
 *  Revision 1.5  2006/06/08 21:06:05  aarora
 *  Formatted
 *
 *  Revision 1.4  2006/03/28 21:28:06  aarora
 *  Repackaging of fdcommons
 *
 *  Revision 1.3  2006/03/28 21:23:01  aarora
 *  Repackaging of fdcommons
 *
 *  Revision 1.2  2005/10/11 05:59:40  nsehra
 *  new method getDefualtPreferancs added
 *
 *  Revision 1.1  2005/10/05 12:04:13  nsehra
 *  first version
 *
 */
package com.freightdesk.fdmonitor.manager;

import crt.com.freightdesk.fdfolio.dashboard.DashBoardTile;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import org.apache.log4j.Logger;

import com.freightdesk.fdcommons.ApplicationProperties;
import com.freightdesk.fdcommons.LcpConstants;
import com.freightdesk.fdcommons.UserPreferenceModel;


/**
 * @author Nitin Sehra
 */
public class DashBoardManager
{
    public static transient Logger logger = Logger.getLogger("com.freightdesk.fdfolio.dashboard.DashBoard");

    Map dashBoardTile = new HashMap();

    /**
     * @return
     */
    public Map getAllDashBoardTile()
    {
        String prefValue = null;
        prefValue = ApplicationProperties.getProperty("dashboard.all.preferances");
        List prefValueList = new ArrayList();
        if (prefValue != null) {
            StringTokenizer referenceTokens = new StringTokenizer(prefValue, ",");
            while (referenceTokens.hasMoreTokens()) {
                String token = referenceTokens.nextToken();
                prefValueList.add(token);
            }
        }
        for (int l = 0; l < prefValueList.size(); l++) {
            DashBoardTile tile = new DashBoardTile((String) prefValueList.get(l));
            dashBoardTile.put((String) prefValueList.get(l), tile);
        }
        return dashBoardTile;
    }

    /**
     * Gets default preferences.
     * 
     * @return Map of default preferences
     */
    public Map getDefaultPreferances(List roleList)
    {
        Map preferences = new HashMap();
        List prefValueLeftTileList = new ArrayList();
        List prefValueRightTileList = new ArrayList();
        logger.debug("getDefaultPreferances() :begin");
        //default left side tiles
        if (roleList != null) {
            int j = 1;
            for (int i = 0; i < roleList.size(); i++) {
                List valueList = new ArrayList();
                logger.debug("Role Value i" + roleList.get(i) + i);
                String prefValue = ApplicationProperties.getProperty("preferances." + roleList.get(i).toString().toLowerCase() + ".value");
                if (prefValue != null) {
                    StringTokenizer referenceTokens = new StringTokenizer(prefValue, ",");
                    while (referenceTokens.hasMoreTokens()) {
                        UserPreferenceModel userPreferenceModel = new UserPreferenceModel();
                        String token = referenceTokens.nextToken();
                        userPreferenceModel.setPrefValue("LH." + j + "." + token);
                        logger.debug("getDefaultPreferances() :prefValue" + userPreferenceModel.getPrefValue());
                        valueList.add(userPreferenceModel);
                        j++;
                    }
                    prefValueLeftTileList.addAll(valueList);
                }
            }
        }
        preferences.put("LHTILES", prefValueLeftTileList);
        //default right side tiles
        UserPreferenceModel userPreferenceModel = null;
        prefValueRightTileList.add(userPreferenceModel);
        preferences.put("RHTILES", prefValueRightTileList);
        return preferences;
    }
}