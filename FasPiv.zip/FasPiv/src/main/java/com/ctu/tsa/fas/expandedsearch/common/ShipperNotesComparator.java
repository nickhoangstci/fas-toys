/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ctu.tsa.fas.expandedsearch.common;
import java.io.Serializable;
import java.util.Comparator;

import org.apache.log4j.Logger;
import com.ctu.tsa.fas.expandedsearch.model.ShipperNotesModel;

/**
 *
 * @author Binh.Nguyen
 */
public class ShipperNotesComparator implements Comparator<ShipperNotesModel>, Serializable{
    private static final long serialVersionUID = 11L;

    private Logger logger = Logger.getLogger(ShipperNotesComparator.class);
    private boolean ascendingNotes;
    private String colName;
    
    public ShipperNotesComparator(String colName, boolean ascendingNotes) {
	this.ascendingNotes = ascendingNotes;
	this.colName = colName;
    }
    
    @SuppressWarnings("unchecked")
    public int compare(ShipperNotesModel o1, ShipperNotesModel o2) {
        int result = 0;
        
      try {
            Object value1 = null;
            Object value2 = null;
            
        if (colName.equalsIgnoreCase("notes")) {
		value1 = o1.getNotes();
		value2 = o2.getNotes();
        } else if (colName.equalsIgnoreCase("dateEntered")) {
		value1 = o1.getDateEntered();
		value2 = o2.getDateEntered();
        } else if (colName.equalsIgnoreCase("email")) {
		value1 = o1.getEmail();
		value2 = o2.getEmail();
        } else if (colName.equalsIgnoreCase("createdByProcess")) {
		value1 = o1.getCreatedByProcess();
		value2 = o2.getCreatedByProcess();	
        } else if (colName.equalsIgnoreCase("previousStatus")) {
		value1 = o1.getPreviousStatus();
		value2 = o2.getPreviousStatus();	   
  		} else if (colName.equalsIgnoreCase("shipperStatus")) {
		value1 = o1.getShipperStatus();
		value2 = o2.getShipperStatus();	
		} else if (colName.equalsIgnoreCase("noteType")) {
		value1 = o1.getNoteType();
		value2 = o2.getNoteType();	
        } else {
		logger.warn("Could not map " + colName + " to class attribute");
        }
            
        // Null is lesser than anything else.
        if ((value1 == null) && (value2 == null)) {
		       result = 0;
        } else if ((value1 == null) && (value2 != null)) {
		       result = -1;
        } else if ((value1 != null) && (value2 == null)) {
		       result = 1;           
        } else if (value1 instanceof Comparable) {
		    // the attribute values are Comparable, we have hit the JackPot.  We have absolutely nothing intelligent to do
		      @SuppressWarnings("rawtypes")
		      Comparable comp1 = (Comparable) value1;
		      @SuppressWarnings("rawtypes")
		      Comparable comp2 = (Comparable) value2;
		      result = comp1.compareTo(comp2);
        } else {
		       logger.warn("Dont know how to sort by " + colName);
        }

        if (!ascendingNotes) {
		result = 0 - result;
        }
      }
      catch (Exception ex) {
            //ex.printStackTrace();
            logger.error("Exception : " + ex.getMessage());
	 }
        return result;
    }
}
