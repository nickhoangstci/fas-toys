/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ctu.tsa.fas.expandedsearch.dao;

import java.sql.Connection;
import java.util.Collections;
import java.util.ArrayList;
import org.apache.log4j.Logger;
import java.util.List;
import java.util.Date;
import java.util.*;
import java.text.SimpleDateFormat;
import org.hibernate.Session;
import java.sql.*;
import java.sql.DriverManager;
import java.util.Map;
import oracle.jdbc.OracleTypes;
import oracle.jdbc.pool.OracleDataSource;

/*
 * @author Binh.Nguyen
 */
public class ExpandedSearchSubjectCompanyDAO {
    /** Target database driver */                                                                                                  
    
    private static ExpandedSearchSubjectCompanyDAO instance = null;
	
    protected Logger logger = Logger.getLogger(getClass());    

        Connection connection = null;
        String queryStr;
        String searchString = null;
        ResultSet sResultSet = null;
        

    public ExpandedSearchSubjectCompanyDAO() {

    }

    public static ExpandedSearchSubjectCompanyDAO getInstance() {
        if (instance == null) {
            instance = new ExpandedSearchSubjectCompanyDAO();
        }
        return instance;
    }
    
	public List<Map> getSubjectCompanyByName(String subjectCompanyName) throws Exception {

		logger.info("---------------:getSubjectCompanyByName:"+subjectCompanyName.toUpperCase());
       
        try {
	        connection = com.freightdesk.fdcommons.ConnectionUtil.getConnectionIacms();
        } catch (Exception ex) {
            logger.error("ods.getConnection() failed");
            throw (ex);
        }
        
        Session session = null;
        
		String stProcName = "EGOV_IAC.FAS_SUBJECT_COMPANY.SEL_REC_BY_NAME_SUMMARY_PAGE";		
        String tCallableStmtStr = "{call " + stProcName + "(?,?)}";
        
        logger.info(tCallableStmtStr);
        
        CallableStatement eStatement = null;
		boolean eReturnCode;
		List<Map> esListMap = null;
        try {
            eStatement = connection.prepareCall (tCallableStmtStr);
			eStatement.setString(1, subjectCompanyName.toUpperCase());		
            eStatement.registerOutParameter(2, OracleTypes.CURSOR);
			logger.info("After prepareCall");
			eReturnCode = eStatement.execute();
			logger.info("After execute");
			sResultSet = (ResultSet) eStatement.getObject(2);
			esListMap = convertSummaryResultSetToListMap (sResultSet);
        } catch (Exception ex) {
            logger.error("getSubjectCompanyConnection failed" + ex.getMessage());
            throw (ex);
        } finally {
            com.freightdesk.fdcommons.ConnectionUtil.closeResources(connection,	eStatement, sResultSet);                       
        }              	    						
		
        return esListMap;
    }
	
    
	public List<Map> getSubjectCompanyByName1234(String subjectCompanyName, String stProcName) throws Exception {

		logger.info(stProcName + "----------getSubjectCompanyByName1234-----:"+subjectCompanyName.toUpperCase());
        Connection connection = null;
        String queryStr;
        String searchString = null;
        ResultSet sResultSet = null;
		String tCallableStmtStr = null;
       
        try {
	        connection = com.freightdesk.fdcommons.ConnectionUtil.getConnectionIacms();
        } catch (Exception ex) {
            logger.error("ods.getConnection() failed");
            throw (ex);
        }
              		
        tCallableStmtStr = "{call " + stProcName + "(?,?)}";
        
        logger.info(tCallableStmtStr);
        
        CallableStatement eStatement = null;
		List<Map> esListMap = null;
        try {
            eStatement = connection.prepareCall (tCallableStmtStr);
			eStatement.setString(1, subjectCompanyName.toUpperCase());		
            eStatement.registerOutParameter(2, OracleTypes.CURSOR);
			eStatement.execute();
			sResultSet = (ResultSet) eStatement.getObject(2);
			esListMap = convertSummaryResultSetToListMap (sResultSet);
        } catch (Exception ex) {
            logger.error("getSubjectCompanyConnection failed" + ex.getMessage());
            throw (ex);
        } finally {
		   com.freightdesk.fdcommons.ConnectionUtil.closeResources(connection,	eStatement, sResultSet);       
        }
		
		
        return esListMap;
    }
	
	
	public List<Map> getSubjectCompanyByNameDetails(String type, String subjectCompanyId) throws Exception {
		    
		logger.info(type + ":getSubjectCompanyByNameDetails:"+subjectCompanyId);
		           
		ResultSet sResultSet = null;
               
        try {
	        connection = com.freightdesk.fdcommons.ConnectionUtil.getConnectionIacms();
        } catch (Exception ex) {
            logger.error("ods.getConnection() failed");
            throw (ex);
        }
        
        Session session = null;
        
        String tCallableStmtStr = null;
        
        String stProcName = null;
       	if (type.equals("AC")) {
        	logger.info("CALL SEL_REC_BY_SC_AC_DET" );
		    stProcName = "EGOV_IAC.FAS_SUBJECT_COMPANY.SEL_REC_BY_SC_AC_DET";		
            tCallableStmtStr = "{call " + stProcName + "(?,?)}";
        }
        
        else  {
        	logger.info("CALL SEL_REC_BY_SC_AGT_DET" );
 		   stProcName = "EGOV_IAC.FAS_SUBJECT_COMPANY.SEL_REC_BY_SC_AGT_DET";		
            tCallableStmtStr = "{call " + stProcName + "(?,?)}";
		}
        logger.info(tCallableStmtStr);
        
        CallableStatement eStatement = null;
		boolean eReturnCode;
		List<Map> esListMap = null;
        try {
            eStatement = connection.prepareCall (tCallableStmtStr);
			logger.info("subjectCompanyId:" + subjectCompanyId);
			eStatement.setString(1, subjectCompanyId); 
			
			if (type.equals("STA")) {
				
				eStatement.registerOutParameter(2, OracleTypes.CURSOR);
				eStatement.registerOutParameter(3, OracleTypes.CURSOR);
				eStatement.registerOutParameter(4, OracleTypes.CURSOR);
			}
			else {
				eStatement.registerOutParameter(2, OracleTypes.CURSOR);
			}
			
			eReturnCode = eStatement.execute();
			sResultSet = (ResultSet) eStatement.getObject(2);
			
			if (type.equals("AC")) {
				esListMap = convertAcDetailsResultSetToListMap (sResultSet);
				logger.info("after converting AC details");
			}	
			else {   // type.equals("AGT") or "Agent"
				esListMap = convertAgtDetailsResultSetToListMap (sResultSet);
				logger.info("after converting Agent details");
			}
        } catch (Exception ex) {
            logger.error("getSubjectCompanyConnection failed" + ex.getMessage());
            throw (ex);
        } finally {
		    com.freightdesk.fdcommons.ConnectionUtil.closeResources(connection,	eStatement, sResultSet);
        }
        	
		
        return esListMap;
    }
	
	
	public List<Map> getSecurityContacts(String partyId) throws Exception {
		    
		logger.info( ":getSecurityContactsByPartyId:"+partyId);
		    
        OracleDataSource ods = null;
        Connection connection = null;
        String queryStr;
        String searchString = null;
        ResultSet sResultSet = null;
        
        try {
	        connection = com.freightdesk.fdcommons.ConnectionUtil.getConnectionIacms();
        } catch (Exception ex) {
            logger.error("ods.getConnection() failed");
            throw (ex);
        }
        
        Session session = null;
        
  	    String stProcName = "EGOV_IAC.FAS_SUBJECT_COMPANY.SEL_CONTACTS_BY_PARTY_ID";
  	    
        String tCallableStmtStr = "{call " + stProcName + "(?,?)}";
        logger.info(tCallableStmtStr);
        
        CallableStatement eStatement = null;
		boolean eReturnCode;
		List<Map> esListMap = null;
        try {
            eStatement = connection.prepareCall (tCallableStmtStr);
			eStatement.setString(1, partyId);		
            eStatement.registerOutParameter(2, OracleTypes.CURSOR);
			eReturnCode = eStatement.execute();
			sResultSet = (ResultSet) eStatement.getObject(2);
			esListMap = convertSecurityContactResultSetToListMap (sResultSet);
        } catch (Exception ex) {
            logger.error("getSecurityContacts failed:" + ex.getMessage());
            throw (ex);
        } finally {
 		    com.freightdesk.fdcommons.ConnectionUtil.closeResources(connection,	eStatement, sResultSet);                  
        }
   
		
        return esListMap;
    }
	
	
	public List<Map> getAcStaList(String partyId) throws Exception {
		    
		logger.info( ":getAcStaList:"+partyId);
		    
        OracleDataSource ods = null;
        Connection connection = null;
        String queryStr;
        String searchString = null;
        ResultSet sResultSet = null;
        
        try {
	        connection = com.freightdesk.fdcommons.ConnectionUtil.getConnectionIacms();
        } catch (Exception ex) {
            logger.error("ods.getConnection() failed");
            throw (ex);
        }
        
        Session session = null;
        
  	    String stProcName = "EGOV_IAC.FAS_SUBJECT_COMPANY.SEL_STAs_BY_PARTY_ID";
  	    
        String tCallableStmtStr = "{call " + stProcName + "(?,?)}";
        logger.info(tCallableStmtStr);
        
        CallableStatement eStatement = null;
		boolean eReturnCode;
		List<Map> esListMap = null;
        try {
            eStatement = connection.prepareCall (tCallableStmtStr);
			eStatement.setString(1, partyId);		
            eStatement.registerOutParameter(2, OracleTypes.CURSOR);		
            logger.info(eStatement);
			eReturnCode = eStatement.execute();
			sResultSet = (ResultSet) eStatement.getObject(2);		
            logger.info(sResultSet);
		    esListMap = convertResultSetToStaMap (sResultSet);
            logger.info("after convertResultSetToStaMap");
        } catch (Exception ex) {
            logger.error("getSubjectCompanyConnection failed" + ex.getMessage());
            throw (ex);
        } finally {
		   com.freightdesk.fdcommons.ConnectionUtil.closeResources(connection,	eStatement, sResultSet);
        }
               			
		
        return esListMap;
    }
	
	
	public List<Map> getAgentStaList(String partyId) throws Exception {
		    
		logger.info( ":getAgentStaList:"+partyId);
		    
        OracleDataSource ods = null;
        Connection connection = null;
        String queryStr;
        String searchString = null;
        ResultSet sResultSet = null;
        
        try {
	        connection = com.freightdesk.fdcommons.ConnectionUtil.getConnectionIacms();
        } catch (Exception ex) {
            logger.error("ods.getConnection() failed");
            throw (ex);
        }
        
        Session session = null;
        
  	    String stProcName = "EGOV_IAC.FAS_SUBJECT_COMPANY.SEL_REC_FOR_SC_AGT_STA";
  	    
        String tCallableStmtStr = "{call " + stProcName + "(?,?)}";
        logger.info(tCallableStmtStr);
        
        CallableStatement eStatement = null;
		boolean eReturnCode;
		List<Map> esListMap = null;
        try {
            eStatement = connection.prepareCall (tCallableStmtStr);
			eStatement.setString(1, partyId);		
            eStatement.registerOutParameter(2, OracleTypes.CURSOR);
		    eReturnCode = eStatement.execute();
			sResultSet = (ResultSet) eStatement.getObject(2);
			logger.info(sResultSet);			
			esListMap = convertResultSetToStaMap (sResultSet);
			logger.info("after convertResultSetToStaMap");		
        } catch (Exception ex) {
            logger.error("getSubjectCompanyConnection failed" + ex.getMessage());
            throw (ex);
        } finally {
  		   com.freightdesk.fdcommons.ConnectionUtil.closeResources(connection,	eStatement, sResultSet);
        }
                 
		
        return esListMap;
    }
	
	
	public List<Map> getIacList(String partyId) throws Exception {
		    
		logger.info( ":getIacList:"+partyId);
		    
        OracleDataSource ods = null;
        Connection connection = null;
        String queryStr;
        String searchString = null;
        ResultSet sResultSet = null;
        
        try {
	        connection = com.freightdesk.fdcommons.ConnectionUtil.getConnectionIacms();
        } catch (Exception ex) {
            logger.error("ods.getConnection() failed");
            throw (ex);
        }
        
        Session session = null;
        
  	    String stProcName = "EGOV_IAC.FAS_SUBJECT_COMPANY.SEL_REC_FOR_SC_AGT_ASSOC_IAC";
  	    
        String tCallableStmtStr = "{call " + stProcName + "(?,?)}";
        logger.info(tCallableStmtStr);
        
        CallableStatement eStatement = null;
		boolean eReturnCode;
		List<Map> esListMap;
        try {
            eStatement = connection.prepareCall (tCallableStmtStr);
			eStatement.setString(1, partyId);		
			eStatement.registerOutParameter(2, OracleTypes.CURSOR);		
			logger.info(eStatement);
			eReturnCode = eStatement.execute();
			sResultSet = (ResultSet) eStatement.getObject(2);		
            logger.info(sResultSet);
			esListMap = convertResultSetToIacMap(sResultSet);
            logger.info("after convertResultSetToStaMap");
        } catch (Exception ex) {
            logger.error("getSubjectCompanyConnection failed" + ex.getMessage());
            throw (ex);
        } finally {
		   com.freightdesk.fdcommons.ConnectionUtil.closeResources(connection,	eStatement, sResultSet);
        }
		
		
        return esListMap;
    }		

    private List<Map> convertResultSetToStaMap (ResultSet searchResultSet) throws Exception{
    	
        logger.info("convertResultSetToStaMap");
    	
        List<Map> listMap = new ArrayList();
        Map  <String, String> map = null;
        
      
        while (searchResultSet.next()){
            map = new HashMap <String, String> ();
            			
            if (searchResultSet.getString("STA_ID") == null){  			    
				map.put("staId", "");
            } else {
                map.put("staId", searchResultSet.getString("STA_ID"));
			}
            if (searchResultSet.getString("APPLICATION_STATUS") == null){  			    
				map.put("staStatus", "");
            } else {
                if (searchResultSet.getString("APPLICATION_STATUS").equalsIgnoreCase("ACTIVE")){
                    map.put("staStatus", "ACTIVE");
                    map.put("issuedOnDate", "");
                } else if (searchResultSet.getString("APPLICATION_STATUS").equalsIgnoreCase("INACTIVE")){
                    map.put("staStatus", "INACTIVE");               
                } else if (searchResultSet.getString("APPLICATION_STATUS").equalsIgnoreCase("STAAWAITINGPAYMNT")){
                    map.put("staStatus", "Awaiting Payment");
                    map.put("issuedOnDate", "");
                } else if (searchResultSet.getString("APPLICATION_STATUS").equalsIgnoreCase("STAERRORTTAC")){
                    map.put("staStatus", "STA ErrorTTAC");     
                    map.put("issuedOnDate", "");
                } else if (searchResultSet.getString("APPLICATION_STATUS").equalsIgnoreCase("STAINCOMPL")){
                    map.put("staStatus", "STA Incomplete"); 
                    map.put("issuedOnDate", "");
                } else if (searchResultSet.getString("APPLICATION_STATUS").equalsIgnoreCase("STAEXPIRED")){
                    map.put("staStatus", "STA Expired"); 
                    map.put("issuedOnDate", "");
                } else if (searchResultSet.getString("APPLICATION_STATUS").equalsIgnoreCase("STADENIED")){
                    map.put("staStatus", "STA Denied"); 
                    map.put("issuedOnDate", "");
                } else if (searchResultSet.getString("APPLICATION_STATUS").equalsIgnoreCase("STAINPROGRESS")){
                    map.put("staStatus", "STA In Progress");   
                    map.put("issuedOnDate", "");
                } else if (searchResultSet.getString("APPLICATION_STATUS").equalsIgnoreCase("STAPASSED")){
                    map.put("staStatus", "Passed"); 					
                    if (searchResultSet.getString("ISSUED_ON_DATE") == null){  			    
                        map.put("issuedOnDate", "");
                    } else {                        
                        map.put("issuedOnDate", searchResultSet.getString("ISSUED_ON_DATE").split(" ")[0]);
                    }					
                } else {
                    map.put("staStatus", searchResultSet.getString("APPLICATION_STATUS"));
                    map.put("issuedOnDate", "");
                }
            }
			     
            if (searchResultSet.getString("STATUS") == null){  			    
				map.put("status", "");
            } else {
                if (searchResultSet.getString("STATUS").equalsIgnoreCase("A")){
                    map.put("status", "ACTIVE");									
                } else if (searchResultSet.getString("STATUS").equalsIgnoreCase("I")){
                    map.put("status", "INACTIVE");               
				} else {
                    map.put("status", searchResultSet.getString("STATUS").toUpperCase()); 
                }
            }	
            
            if (searchResultSet.getString("CREATION_DATE") == null){  			    
				map.put("creationDate", "");
            } else {
                map.put("creationDate", searchResultSet.getString("CREATION_DATE").split(" ")[0]);	
            }
            
            if (searchResultSet.getString("EXPIRES_ON_DATE") == null){  			    
				map.put("expiresOnDate", "");
            } else {
                if (searchResultSet.getString("APPLICATION_STATUS").equalsIgnoreCase("STAERRORTTAC")){
                    map.put("expiresOnDate", "");
                } else {
                    map.put("expiresOnDate", searchResultSet.getString("EXPIRES_ON_DATE").split(" ")[0]);
                }
            }
            
		    if (searchResultSet.getString("FIRST_NAME") == null){  			    
					map.put("firstName", "");
	            } else {
	                map.put("firstName", searchResultSet.getString("FIRST_NAME"));
				}
	
		    if (searchResultSet.getString("LAST_NAME") == null){  			    
					map.put("lastName", "");
	            } else {
	                map.put("lastName", searchResultSet.getString("LAST_NAME"));
				}	            

            listMap.add(map);
        }
        
        return listMap;
    }	
    

    private List<Map> convertResultSetToIacMap (ResultSet searchResultSet) throws Exception{
    	
        logger.info("convertResultSetToIacMap");
        
    	
        List<Map> listMap = new ArrayList();
        Map  <String, String> map = null;
        
        Date today = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
      
        while (searchResultSet.next()){
            map = new HashMap <String, String> ();
            			
            if (searchResultSet.getString("IAC_NUMBER") == null){  			    
				map.put("iacId", "");
            } else {
                map.put("iacId", searchResultSet.getString("IAC_NUMBER"));
			}

            if (searchResultSet.getString("IAC_NAME") == null){  			    
				map.put("iacName", "");
            } else {
                map.put("iacName", searchResultSet.getString("IAC_NAME"));
			}

            if (searchResultSet.getString("CITY") == null){  			    
				map.put("city", "");
            } else {
                map.put("city", searchResultSet.getString("CITY"));
			}

            if (searchResultSet.getString("STATE") == null){  			    
				map.put("state", "");
            } else {
                map.put("state", searchResultSet.getString("STATE"));
			}
			
			// compare expired date with current date
            if (searchResultSet.getString("EXPIRED_DATE") == null){  			    
                map.put("expired", "");   
            } else {               	
            	Date expiredDate = sdf.parse(searchResultSet.getString("EXPIRED_DATE").split(" ")[0]);
            	
            	logger.info(today + ":date:" + expiredDate);
            	if (expiredDate.compareTo(today) < 0) {
                	map.put("expired", "Y");	            		
            	}
            	else {
                	map.put("expired", "N");	            		
            	}
            }
                      
            if (searchResultSet.getString("STATUS") == null){  			    
				map.put("status", "");
            } else {
                if (searchResultSet.getString("STATUS").equalsIgnoreCase("A")){
                    map.put("status", "ACTIVE");									
                } else if (searchResultSet.getString("STATUS").equalsIgnoreCase("I")){
                    map.put("status", "INACTIVE");               
				} else {
                    map.put("status", searchResultSet.getString("STATUS").toUpperCase()); 
                }
            }	
                       

            listMap.add(map);
        }
        
        return listMap;
    }    
	
    
    private List<Map> convertSummaryResultSetToListMap (ResultSet searchResultSet) throws Exception{			 

	List<Map> listMap = new ArrayList();
        Map map = null;
        
        int debugInt = 0;
          while (searchResultSet.next()){
          	
            map = new HashMap();		  
            			
		if (null != searchResultSet.getString("NAME")){  			    
                map.put("subjectCompanyName", searchResultSet.getString("NAME"));			    
			}
			else {
				map.put("subjectCompanyName", "");
			}			
                
		if (null != searchResultSet.getString("PARTY_ID")){  			    
                map.put("partyId", searchResultSet.getString("PARTY_ID"));			    
			}
			else {
				map.put("partyId", "");
			}			
                
		if (null != searchResultSet.getString("ID")){  			    
                map.put("subjectCompanyId", searchResultSet.getString("ID"));				
			}
			else {
				map.put("subjectCompanyId", "");
			}			
			
		if (null != searchResultSet.getString("TYPE")){  			    
                map.put("subjectCompanyType", searchResultSet.getString("TYPE"));
			}			
			else {
				map.put("subjectCompanyType", "");
			}			
			
		if (null != searchResultSet.getString("STATE")){
                map.put("subjectCompanyState", searchResultSet.getString("STATE"));	
            }
			else {
				map.put("subjectCompanyState", "");
			}			
					
		if (null != searchResultSet.getString("OBJECT_ID")){
                map.put("objectId", searchResultSet.getString("OBJECT_ID"));				    
            }
			else {
				map.put("objectId", "");
			}			
			
		if (null != searchResultSet.getString("STATUS")){  			    
                if (searchResultSet.getString("STATUS").equalsIgnoreCase("Y")){
                    map.put("subjectCompanyStatus", "ACTIVE");	
                }								
                else if (searchResultSet.getString("STATUS").equalsIgnoreCase("N")){
                    map.put("subjectCompanyStatus", "INACTIVE");               
                } else {
                    map.put("subjectCompanyStatus", searchResultSet.getString("STATUS").toUpperCase());
                }
            }											
			else {
				map.put("subjectCompanyStatus", "");
			}			
			
            listMap.add(map);
		  } 		 

        return listMap;
    }	
	
    private List<Map> convertSecurityContactResultSetToListMap (ResultSet contactRS) throws Exception{
	
	    logger.info("convertSecurityContactResultSetToListMap");
		List<Map> listMap = new ArrayList();
        Map  <String, String> map = null;
		
		String firstName = null; 
		String lastName = null;
		String phoneNumber = ""; 
		String userName = "";
		String firstName0 = null; 
		String lastName0 = null;	

        while (contactRS.next()){
        	
			firstName = contactRS.getString("PERSON_FIRST_NAME"); 			    
			lastName = contactRS.getString("PERSON_LAST_NAME");
			userName = contactRS.getString("USER_NAME");			    
			 			    
			if ((null != firstName && !firstName.equals(firstName0)) || 
			    (null != lastName && !lastName.equals(lastName0))) { 
	            map = new HashMap <String, String> ();
                map.put("firstName", firstName);
                map.put("lastName", lastName);
   		        listMap.add(map);

                firstName0 = firstName;
                lastName0 = lastName;
                
			}
			else if ((null == firstName && !firstName.equals(firstName0)) || 
			    (null == lastName && !lastName.equals(lastName0))) {
			     map.put("firstName", "");
                 map.put("lastName", "");
			}
			
			if (null != userName) {  			    
                map.put("userName", userName);
			}
			else if (null == userName) {
			    map.put("userName", "");
			}
						
			if (null != contactRS.getString("PHONE_AREA_CODE")) {  			    
                phoneNumber = contactRS.getString("PHONE_AREA_CODE");				
                if (null != contactRS.getString("PHONE_NUMBER")) {
                	phoneNumber += "-" + contactRS.getString("PHONE_NUMBER");	              													  
				  
				   if (null != contactRS.getString("PHONE_LINE_TYPE")) {
					  if (contactRS.getString("PHONE_LINE_TYPE").equals("WORK")) {					      
					      map.put("phone", phoneNumber);						  
					  }
					  
					  else if (contactRS.getString("PHONE_LINE_TYPE").equals("FAX")) {					     					      
					      map.put("fax", phoneNumber);						  
					  }
					  				
					  else if (contactRS.getString("PHONE_LINE_TYPE").equals("24_HOUR_PHONE")) {					      					      
					      map.put("h24HourPhone", phoneNumber);						  
					  }					  					 
				  }	
                }								
			}
						
			if (map.get("phone") == null) {
				map.put("phone", "");
			}

			if (map.get("fax") == null){
				map.put("fax", "");
			}

			if (map.get("h24HourPhone") == null){
				map.put("h24HourPhone", "");
			}
						
			if (null != contactRS.getString("CONTACT_POINT_TYPE")){ 			    
                if (contactRS.getString("CONTACT_POINT_TYPE").equals("EMAIL")) {				    
	                map.put("email", contactRS.getString("EMAIL_ADDRESS"));
                }				
			}
			else if (null == contactRS.getString("CONTACT_POINT_TYPE")){ 
				 map.put("email", "");
	        }
		  }
		  
        return listMap;
    }	
	
	private List<Map> convertDetailsResultSetToListMap (ResultSet searchResultSet) throws Exception{
	
		logger.info("convertDetailsResultSetToListMap:");
	
		List<Map> listMap = new ArrayList();
        Map map = null;
        try {
       
        int counter = 0;
        
          while (searchResultSet.next()){
            map = new HashMap();	                   		  
            			
			if (searchResultSet.getString("PARTY_NAME") == null){  			    
				map.put("subjectCompanyName", "");
            } else {
                map.put("subjectCompanyName", searchResultSet.getString("PARTY_NAME"));
			}			
			
			if (searchResultSet.getString("AGENT_ID") == null){  			    
				map.put("subjectCompanyId", "");
            } else {
                map.put("subjectCompanyId", searchResultSet.getString("AGENT_ID"));	
			}						
			
			if (searchResultSet.getString("ACTIVE_FLAG") == null){  			    
				map.put("subjectCompanyStatus", "");
            } else {
                if (searchResultSet.getString("ACTIVE_FLAG").equalsIgnoreCase("Y")){
                    map.put("subjectCompanyStatus", "ACTIVE");									
                } else if (searchResultSet.getString("ACTIVE_FLAG").equalsIgnoreCase("N")){
                    map.put("subjectCompanyStatus", "INACTIVE");               
				} else {
                    map.put("subjectCompanyStatus", searchResultSet.getString("ACTIVE_FLAG")); 
                }
            }		
						
			if (searchResultSet.getString("EIN_NBR") == null){  			    
				map.put("subjectCompanyEinNumber", "");
            } else {
                map.put("subjectCompanyEinNumber", searchResultSet.getString("EIN_NBR"));                 
			}
			
			if (searchResultSet.getString("ADDRESS1") == null){
                map.put("subjectCompanyAddress1", "");
            } else {
                map.put("subjectCompanyAddress1", searchResultSet.getString("ADDRESS1"));
			}
            
			if (searchResultSet.getString("ADDRESS2") == null){
                map.put("subjectCompanyAddress2", "");
            } else {
                map.put("subjectCompanyAddress2", searchResultSet.getString("ADDRESS2"));		
			}
			
            if (searchResultSet.getString("CITY") == null){
                map.put("subjectCompanyCity", "");
            } else {
                map.put("subjectCompanyCity", searchResultSet.getString("CITY"));
			}
			
			if (searchResultSet.getString("STATE") == null){
                map.put("subjectCompanyState", "");
            } else {
                map.put("subjectCompanyState", searchResultSet.getString("STATE"));	
            }
			
			if (searchResultSet.getString("POSTAL_CODE") == null){
                map.put("subjectCompanyZipPostalCode", "");
            } else {
                map.put("subjectCompanyZipPostalCode", searchResultSet.getString("POSTAL_CODE"));
			}
			
			if (searchResultSet.getString("SIC_CODE") == null){
                map.put("subjectCompanySicCode", "");
            } else {
                map.put("subjectCompanySicCode", searchResultSet.getString("SIC_CODE"));	
            }						
			
			if (searchResultSet.getString("PHONE_NUMBER") == null){
                map.put("subjectCompanyPhone", "");
            } else {
                map.put("subjectCompanyPhone", searchResultSet.getString("PHONE_NUMBER"));
			}	
			
			if (searchResultSet.getString("KNOWN_AS") == null){
                map.put("subjectCompanyKnownAs1", "");
            } else {
                if (searchResultSet.getString("KNOWN_AS").equalsIgnoreCase(";;;")) {
					map.put("subjectCompanyKnownAs1", "");	    				
				} else {				
				    map.put("subjectCompanyKnownAs1", searchResultSet.getString("KNOWN_AS"));
				}
			}
			
			if (searchResultSet.getString("KNOWN_AS2") == null){
                map.put("subjectCompanyKnownAs2", "");
            } else {
                if (searchResultSet.getString("KNOWN_AS2").equalsIgnoreCase(";;;")) {
					map.put("subjectCompanyKnownAs2", "");	    				
				} else {				
				    map.put("subjectCompanyKnownAs2", searchResultSet.getString("KNOWN_AS2"));
				}
			}
			
			if (searchResultSet.getString("KNOWN_AS3") == null){
                map.put("subjectCompanyKnownAs3", "");
            } else {
                if (searchResultSet.getString("KNOWN_AS3").equalsIgnoreCase(";;;")) {
					map.put("subjectCompanyKnownAs3", "");	    				
				} else {				
				    map.put("subjectCompanyKnownAs3", searchResultSet.getString("KNOWN_AS3"));
				}
			}
			
			if (searchResultSet.getString("FIRST_NAME") == null){
                map.put("subjectCompanyFirstName", "");				
            } else {
                map.put("subjectCompanyFirstName", searchResultSet.getString("FIRST_NAME"));		
			}
			
			if (searchResultSet.getString("LAST_NAME") == null){
                map.put("subjectCompanyLastName", "");
            } else {
                map.put("subjectCompanyLastName", searchResultSet.getString("LAST_NAME"));
			}
			
			if (searchResultSet.getString("EMAIL_ADDRESS") == null){
                map.put("subjectCompanyEmail", "");
            } else {
                map.put("subjectCompanyEmail", searchResultSet.getString("EMAIL_ADDRESS"));
			}
			
			if (searchResultSet.getString("DESIGNATION") == null){
                map.put("subjectCompanyDesignation", "");
            } else {
                map.put("subjectCompanyDesignation", searchResultSet.getString("DESIGNATION"));
                logger.info("subjectCompanyDesignation:" + map.get("subjectCompanyDesignation"));
			}
			
			if (searchResultSet.getString("TITLE") == null){
                map.put("subjectCompanyTitle", "");
            } else {
                map.put("subjectCompanyTitle", searchResultSet.getString("TITLE"));
			}

			if (searchResultSet.getLong("COORDINATOR_ID") == 0){
                map.put("subjectCompanyCredential", "");				
            } else {
                map.put("subjectCompanyCredential", searchResultSet.getLong("COORDINATOR_ID"));		
			}
			
			if (searchResultSet.getString("APPROVAL_DT") == null){
                map.put("subjectCompanyInitialApprovalDate", "");
            } else {
                map.put("subjectCompanyInitialApprovalDate", searchResultSet.getString("APPROVAL_DT"));
			}
			
			if (searchResultSet.getString("APPROVING_AGT") == null){
                map.put("subjectCompanyApprovingAgent", "");
            } else {
                map.put("subjectCompanyApprovingAgent", searchResultSet.getString("APPROVING_AGT"));
			}
			
			if (searchResultSet.getString("LAST_RENEWAL_DT") == null){
                map.put("subjectCompanyLastApprovalDate", "");
            } else {
                map.put("subjectCompanyLastApprovalDate", searchResultSet.getString("LAST_RENEWAL_DT"));
			}
			
			if (searchResultSet.getString("NEXT_EXPIRATION_DT") == null){
                map.put("subjectCompanyExpirationDate", "");
            } else {
                map.put("subjectCompanyExpirationDate", searchResultSet.getString("NEXT_EXPIRATION_DT"));
			}
			
			if (searchResultSet.getString("COMMENTS") == null){
                map.put("subjectCompanyComments", "");
            } else {
                map.put("subjectCompanyComments", searchResultSet.getString("COMMENTS"));
			}
			
            listMap.add(map);
		  }
		}
		catch (Exception e) {
			logger.error (e.getMessage ());
		}
		  
        return listMap;
    }
    	
	private List<Map> convertAgtDetailsResultSetToListMap (ResultSet searchResultSet) throws Exception{
	
		logger.info("convertAgtDetailsResultSetToListMap:");
	
		List<Map> listMap = new ArrayList();
        Map map = null;
	try {
        
        int debugInt = 0;
        
          while (searchResultSet.next()){
			logger.info("-------------:convertAgtDetailsResultSetToListMap:" + debugInt++);
             map = new HashMap();	            	   
             			
			if (searchResultSet.getString("PARTY_NAME") == null){  			    
				map.put("subjectCompanyName", "");
            } else {
                map.put("subjectCompanyName", searchResultSet.getString("PARTY_NAME"));
			}			
			
			if (searchResultSet.getString("AGENT_ID") == null){  			    
				map.put("subjectCompanyId", "");
            } else {
                map.put("subjectCompanyId", searchResultSet.getString("AGENT_ID"));	
			}						
			
			if (searchResultSet.getString("STATUS") == null){  			    
				map.put("subjectCompanyStatus", "");
            } else {
                if (searchResultSet.getString("STATUS").equalsIgnoreCase("Y")){
                    map.put("subjectCompanyStatus", "ACTIVE");									
                } else if (searchResultSet.getString("STATUS").equalsIgnoreCase("N")){
                    map.put("subjectCompanyStatus", "INACTIVE");               
				} else {
                    map.put("subjectCompanyStatus", searchResultSet.getString("STATUS")); 
                }
            }		
						
			if (searchResultSet.getString("ADDRESS1") == null){
                map.put("subjectCompanyAddress1", "");
            } else {
                map.put("subjectCompanyAddress1", searchResultSet.getString("ADDRESS1"));
			}
            
			if (searchResultSet.getString("ADDRESS2") == null){
                map.put("subjectCompanyAddress2", "");
            } else {
                map.put("subjectCompanyAddress2", searchResultSet.getString("ADDRESS2"));		
			}
			
            if (searchResultSet.getString("CITY") == null){
                map.put("subjectCompanyCity", "");
            } else {
                map.put("subjectCompanyCity", searchResultSet.getString("CITY"));
			}
			
			if (searchResultSet.getString("STATE") == null){
                map.put("subjectCompanyState", "");
            } else {
                map.put("subjectCompanyState", searchResultSet.getString("STATE"));	
            }
			
			if (searchResultSet.getString("POSTAL_CODE") == null){
                map.put("subjectCompanyZipPostalCode", "");
            } else {
                map.put("subjectCompanyZipPostalCode", searchResultSet.getString("POSTAL_CODE"));
			}
			
			
			
            listMap.add(map);
		  }
		  
		}
		catch (Exception e) {
			logger.error (e.getMessage ());
		}
        return listMap;
    }
  
	private List<Map> convertAgentContactResultSetToListMap (ResultSet searchResultSet) throws Exception{
	
		logger.info("convertAgentContactResultSetToListMap:");
	
		List<Map> listMap = new ArrayList();
        Map map = null;
	try {
        
        int debugInt = 0;
        
          while (searchResultSet.next()){
			logger.info("-------------:convertAgentContactResultSetToListMap:" + debugInt++);
             map = new HashMap();	
            	
			if (searchResultSet.getString("FIRST_NAME") == null){  			    
				map.put("subjectCompanyFirstName", "");
            } else {
                map.put("subjectCompanyFirstName", searchResultSet.getString("FIRST_NAME"));
				logger.info("-------------:subjectCompanyFirstName:" + map.get("subjectCompanyFirstName"));
			}			
			
			
			if (searchResultSet.getString("LAST_NAME") == null){
                map.put("subjectCompanyLastName", "");
            } else {
                map.put("subjectCompanyLastName", searchResultSet.getString("LAST_NAME"));
			}
            
			if (searchResultSet.getString("EMAIL") == null){
                map.put("subjectCompanyEmail", "");
            } else {
                map.put("subjectCompanyEmail", searchResultSet.getString("EMAIL"));		
				logger.info("-------------:subjectCompanyEmail:" + map.get("subjectCompanyEmail"));
			}
			
            if (searchResultSet.getString("PHONE") == null){
                map.put("subjectCompanyPhone", "");
            } else {
                map.put("subjectCompanyPhone", searchResultSet.getString("PHONE"));
				logger.info("-------------:subjectCompanyPhone:" + map.get("subjectCompanyPhone"));
			}
			
			
            listMap.add(map);
		  }
		  
		}
		catch (Exception e) {
			logger.error (e.getMessage ());
		}
        return listMap;
    }
    
    	
	private List<Map> convertAcDetailsResultSetToListMap (ResultSet searchResultSet) throws Exception{
	
		logger.info("convertAcDetailsResultSetToListMap 1:");
		String partyId = "";
	
		List<Map> listMap = new ArrayList();
        Map map = null;	

         
        if (null == searchResultSet ) {
			logger.info("listMap is null" );
        	return Collections.emptyList();
        }
         
          while (searchResultSet.next()){
            map = new HashMap();		  
            			
			if (searchResultSet.getString("PARTY_NAME") == null){  			    
				map.put("subjectCompanyName", "");
            } else {
                map.put("subjectCompanyName", searchResultSet.getString("PARTY_NAME"));
			}			

			if (searchResultSet.getString("PARTY_ID") == null){  			    
				map.put("subjectCompanyId", "");
            } else {
                map.put("subjectCompanyId", searchResultSet.getString("PARTY_ID"));
                logger.info("Party ID:" + searchResultSet.getString("PARTY_ID"));
			}	
										
			if (searchResultSet.getString("ADDRESS1") == null){
                map.put("subjectCompanyAddress1", "");
            } else {
				logger.info("subjectCompanyAddress1:" + searchResultSet.getString("ADDRESS1"));	
                map.put("subjectCompanyAddress1", searchResultSet.getString("ADDRESS1"));		
			}
            
			if (searchResultSet.getString("ADDRESS2") == null){
                map.put("subjectCompanyAddress2", "");
            } else {
                map.put("subjectCompanyAddress2", searchResultSet.getString("ADDRESS2"));		
			}
			
            if (searchResultSet.getString("CITY") == null){
                map.put("subjectCompanyCity", "");
            } else {
                map.put("subjectCompanyCity", searchResultSet.getString("CITY"));
			}
			
			if (searchResultSet.getString("STATE") == null){
                map.put("subjectCompanyState", "");
            } else {
                map.put("subjectCompanyState", searchResultSet.getString("STATE"));	
            }
			
			if (searchResultSet.getString("POSTAL_CODE") == null){
                map.put("subjectCompanyZipPostalCode", "");
            } else {
                map.put("subjectCompanyZipPostalCode", searchResultSet.getString("POSTAL_CODE"));
			}
			
			
			if (searchResultSet.getString("PHONE_NUMBER") == null){
                map.put("subjectCompanyPhone", "");
            } else {
                map.put("subjectCompanyPhone", searchResultSet.getString("PHONE_NUMBER"));
			}	

			if (searchResultSet.getString("DESIGNATION") == null){
                map.put("subjectCompanyDesignation", "");
            } else {
                map.put("subjectCompanyDesignation", searchResultSet.getString("DESIGNATION"));
			}
			
			if (searchResultSet.getString("FIRST_NAME") == null){
                map.put("subjectCompanyFirstName", "");				
            } else {
                map.put("subjectCompanyFirstName", searchResultSet.getString("FIRST_NAME"));		
			}
			
			if (searchResultSet.getString("LAST_NAME") == null){
                map.put("subjectCompanyLastName", "");
            } else {
                map.put("subjectCompanyLastName", searchResultSet.getString("LAST_NAME"));
			}
			
            listMap.add(map);
		  }
		  
        return listMap;
    }
}
