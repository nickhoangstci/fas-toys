/*
 * Any changes to this class must be in sync with CtuRequet.hbm.xml and CtuRequest table.
 */

package com.ctu.tsa.fas.requesttracker.data;

import java.util.Date;

/**
 *
 * @author STCI
 */
public class Cturequest {
 private int requestID;
 private String requestNumber;
 private String requestStatus;
 private String requestType;
 private int cargoIncidentID;
 private int ctuCCSFApproval;
 private int psiID;
 private int staRequestID;
 private int ogaReferralID;
 private int requesterAgencyID;
 private Date requestDate;
 private String requester;
 private String requestorName;
 private int airportID;
 private String subjectIndividual;
 private String subjectCompany;
 private int subjectReqionID;
 private String results;
 private String recommendation;
 private String comments;
 private String derog;
 private String derogLevel;
 private String createUserName;
 private Date createTimeStamp;
 private String lastUpdateUserName;
 private Date lastUpdateTimestamp;
 private String leadTargeter;
 private String coTargeter;
 private String staInformation;
 private String inLieuAirport;
 
 // constructors
	public Cturequest() {
	}
    public int getRequestID() {
        return requestID;
    }

    public void setRequestID(int requestID) {
        this.requestID = requestID;
    }

    public String getRequestNumber() {
        return requestNumber;
    }

    public void setRequestNumber(String requestNumber) {
        this.requestNumber = requestNumber;
    }

    public String getRequestStatus() {
        return requestStatus;
    }

    public void setRequestStatus(String requestStatus) {
        this.requestStatus = requestStatus;
    }

    public String getRequestType() {
        return requestType;
    }

    public void setRequestType(String requestType) {
        this.requestType = requestType;
    }

    public int getCargoIncidentID() {
        return cargoIncidentID;
    }

    public void setCargoIncidentID(int cargoIncidentID) {
        this.cargoIncidentID = cargoIncidentID;
    }

    public int getCtuCCSFApproval() {
        return ctuCCSFApproval;
    }

    public void setCtuCCSFApproval(int ctuCCSFApproval) {
        this.ctuCCSFApproval = ctuCCSFApproval;
    }

    public int getPsiID() {
        return psiID;
    }

    public void setPsiID(int psiID) {
        this.psiID = psiID;
    }

    public int getStaRequestID() {
        return staRequestID;
    }

    public void setStaRequestID(int staRequestID) {
        this.staRequestID = staRequestID;
    }

    public int getOgaReferralID() {
        return ogaReferralID;
    }

    public void setOgaReferralID(int ogaReferralID) {
        this.ogaReferralID = ogaReferralID;
    }

    public int getRequesterAgencyID() {
        return requesterAgencyID;
    }

    public void setRequesterAgencyID(int requesterAgencyID) {
        this.requesterAgencyID = requesterAgencyID;
    }

    public Date getRequestDate() {
        return requestDate;
    }

    public void setRequestDate(Date requestDate) {
        this.requestDate = requestDate;
    }

    public String getRequester() {
        return requester;
    }

    public void setRequester(String requester) {
        this.requester = requester;
    }

    public String getRequestorName() {
        return requestorName;
    }

    public void setRequestorName(String requestorName) {
        this.requestorName = requestorName;
    }
    
    public int getAirportID() {
        return airportID;
    }

    public void setAirportID(int airportID) {
        this.airportID = airportID;
    }

    public String getSubjectIndividual() {
        return subjectIndividual;
    }

    public void setSubjectIndividual(String subjectIndividueal) {
        this.subjectIndividual = subjectIndividueal;
    }

    public String getSubjectCompany() {
        return subjectCompany;
    }

    public void setSubjectCompany(String subjectCompany) {
        this.subjectCompany = subjectCompany;
    }

    public int getSubjectReqionID() {
        return subjectReqionID;
    }

    public void setSubjectReqionID(int subjectReqionID) {
        this.subjectReqionID = subjectReqionID;
    }

    public String getResults() {
        return results;
    }

    public void setResults(String results) {
        this.results = results;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public String getDerog() {
        return derog;
    }

    public void setDerog(String derog) {
        this.derog = derog;
    }

    public String getDerogLevel() {
        return derogLevel;
    }

    public void setDerogLevel(String derogLevel) {
        this.derogLevel = derogLevel;
    }

    public String getCreateUserName() {
        return createUserName;
    }

    public void setCreateUserName(String createUserName) {
        this.createUserName = createUserName;
    }

    public Date getCreateTimeStamp() {
        return createTimeStamp;
    }

    public void setCreateTimeStamp(Date createTimeStamp) {
        this.createTimeStamp = createTimeStamp;
    }

    public String getLastUpdateUserName() {
        return lastUpdateUserName;
    }

    public void setLastUpdateUserName(String lastUpdateUserName) {
        this.lastUpdateUserName = lastUpdateUserName;
    }

    public Date getLastUpdateTimestamp() {
        return lastUpdateTimestamp;
    }

    public void setLastUpdateTimestamp(Date lastUpdateTimestamp) {
        this.lastUpdateTimestamp = lastUpdateTimestamp;
    }

    public String getLeadTargeter() {
        return leadTargeter;
    }

    public void setLeadTargeter(String leadTargeter) {
        this.leadTargeter = leadTargeter;
    }

    public String getCoTargeter() {
        return coTargeter;
    }

    public void setCoTargeter(String coTargeter) {
        this.coTargeter = coTargeter;
    }

    public String getRecommendation() {
        return recommendation;
    }

    public void setRecommendation(String recommendation) {
        this.recommendation = recommendation;
    }

    public String getStaInformation() {
        return staInformation;
    }

    public void setStaInformation(String staInformation) {
        this.staInformation = staInformation;
    }

    public String getInLieuAirport() {
        return inLieuAirport;
    }

    public void setInLieuAirport(String inLieuAirport) {
        this.inLieuAirport = inLieuAirport;
    }
	
    @Override
    public String toString() {
        return "Cturequest{" + "requestID=" + requestID + ", requestNumber=" + requestNumber + ", requestStatus=" + requestStatus + ", requestType=" + requestType + ", cargoIncidentID=" + cargoIncidentID + ", ctuCCSFApproval=" + ctuCCSFApproval + ", psiID=" + psiID + ", staRequestID=" + staRequestID + ", ogaReferralID=" + ogaReferralID + ", requesterAgencyID=" + requesterAgencyID + ", requestDate=" + requestDate + ", requester=" + requester + ", requestorName=" + requestorName + ", airportID=" + airportID + ", subjectIndividual=" + subjectIndividual + ", subjectCompany=" + subjectCompany + ", subjectReqionID=" + subjectReqionID + ", results=" + results + ", recommendation=" + recommendation + ", comments=" + comments + ", derog=" + derog + ", derogLevel=" + derogLevel + ", createUserName=" + createUserName + ", createTimeStamp=" + createTimeStamp + ", lastUpdateUserName=" + lastUpdateUserName + ", lastUpdateTimestamp=" + lastUpdateTimestamp + ", leadTargeter=" + leadTargeter + ", coTargeter=" + coTargeter + ", staInformation=" + staInformation + ", inLieuAirport=" + inLieuAirport + '}';
    }


}
       

        
 
 