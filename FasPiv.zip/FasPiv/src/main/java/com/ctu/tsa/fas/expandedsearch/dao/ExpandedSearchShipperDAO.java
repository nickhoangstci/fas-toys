/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ctu.tsa.fas.expandedsearch.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import oracle.jdbc.OracleTypes;

import org.apache.log4j.Logger;
import org.hibernate.Session;

import com.ctu.tsa.fas.expandedsearch.model.ShipperDetails;

/*
 * @author Binh.Nguyen
 */
public class ExpandedSearchShipperDAO {
    
    private static ExpandedSearchShipperDAO instance = null;
    private static int fetchSize = 5000;
    private long[] elapsedTime = new long[4];
    protected Logger logger = Logger.getLogger(getClass());    
    
    Connection connection = null;
    String queryStr;
    String searchString = null;
    ResultSet sResultSet = null;

    public ExpandedSearchShipperDAO() {

    }

    public static ExpandedSearchShipperDAO getInstance() {
        if (instance == null) {
            instance = new ExpandedSearchShipperDAO();
        }
        return instance;
    }
    
    public class MyShipperSqlResults {
	List<Map> sListMap;
	long totalCount;
        long count1;
        long count2;

	public List<Map> getSListMap() {
            return sListMap;
	}

	public void setSListMap(List<Map> sListMap) {
            this.sListMap = sListMap;
	}

	public long getTotalCount() {
            return totalCount;
	}

	public void setTotalCount(long totalCount) {
            this.totalCount = totalCount;
	}
        
        public long getCount1() {
            return count1;
	}

	public void setCount1(long count1) {
            this.count1 = count1;
	}
        
        public long getCount2() {
            return count2;
	}

	public void setCount2(long count2) {
            this.count2 = count2;
	}
    }
    
    
    public List<Map> getShipperInfo(String shipperId, String iacNumber, String shipperName, 
    	String iacAcCompany, String stateCode) throws Exception {
        
        elapsedTime[0] = System.currentTimeMillis();
        
        try {
	        connection = com.freightdesk.fdcommons.ConnectionUtil.getConnectionKsms();
        } catch (Exception ex) {
            logger.error("getShipperInfo.getConnectionKsms() failed");
            throw (ex);
        }
        
        logger.info("------getShipperInfo:" + shipperName);
        Session session = null;
        CallableStatement eStatement = null;
        boolean eReturnCode;
		List<Map> esListMap = null;
        try {

		String stProcName = "apps.FAS_SHIPPER_SEARCH.SEL_REC_BY_ANY";
	        String tCallableStmtStr = "{call " + stProcName + "(?,?,?,?,?,?)}";
	
		    eStatement = connection.prepareCall (tCallableStmtStr);
             
			eStatement.setString(1, shipperId);
			eStatement.setString(2, iacNumber);
			eStatement.setString(3, shipperName);
			eStatement.setString(4, iacAcCompany);
			eStatement.setString(5, stateCode);
	        eStatement.registerOutParameter(6, OracleTypes.CURSOR);

		    eStatement.setFetchSize(fetchSize);
        
            eReturnCode = eStatement.execute();
        
	        sResultSet = (ResultSet) eStatement.getObject(6);
			elapsedTime[1] = System.currentTimeMillis();
            esListMap = convertResultSetToListMapForSummaryPage (sResultSet);
        } catch (Exception ex) {
            logger.error("ExpandedSearchShipperDAO - after eStatement.execute failed:" + ex.getMessage());
            throw (ex);
        } finally {
            com.freightdesk.fdcommons.ConnectionUtil.closeResources(connection, eStatement, sResultSet);		
        }
			  		
        elapsedTime[2] = System.currentTimeMillis();
        logger.info("Elapsed Time :" + (elapsedTime[1] - elapsedTime[0]) + " --- " + (elapsedTime[2] - elapsedTime[1]));
        
        return esListMap;
    }    
    
    public MyShipperSqlResults getShipperInfoByShipperId(String shipperId) throws Exception {
        
        MyShipperSqlResults myShipperSqlResults = new MyShipperSqlResults();
        
        try {
	        connection = com.freightdesk.fdcommons.ConnectionUtil.getConnectionKsms();
        } catch (Exception ex) {
            logger.error("getShipperInfoByShipperId.getConnectionKsms() failed");
            throw (ex);
        }
        
        logger.info("getShipperInfoByShipperId:" + shipperId);
        Session session = null;
        
	String stProcName = "apps.FAS_SHIPPER_SEARCH.SEL_REC_BY_SHIPPER_ID";
        String tCallableStmtStr = "{call " + stProcName + "(?,?,?,?,?)}";
        
        CallableStatement eStatement = null;
		boolean eReturnCode;
        try {
            eStatement = connection.prepareCall (tCallableStmtStr);
			eStatement.setString(1, shipperId.toUpperCase());
			eStatement.registerOutParameter(2, OracleTypes.CURSOR);
			eStatement.registerOutParameter(3, OracleTypes.INTEGER);
			eStatement.registerOutParameter(4, OracleTypes.INTEGER);
			eStatement.registerOutParameter(5, OracleTypes.INTEGER);
	        eStatement.setFetchSize(fetchSize);
			eReturnCode = eStatement.execute();
			sResultSet = (ResultSet) eStatement.getObject(2);
			myShipperSqlResults.setTotalCount ((int) eStatement.getObject(3));
			myShipperSqlResults.setCount1 ((int) eStatement.getObject(4));
			myShipperSqlResults.setCount2 ((int) eStatement.getObject(5));
			myShipperSqlResults.setSListMap (convertResultSetToListMapForSummaryPage (sResultSet));
        } catch (Exception ex) {
            logger.error("getShipperConnection failed" + ex.getMessage());
            throw (ex);
        } finally {
            com.freightdesk.fdcommons.ConnectionUtil.closeResources(connection, eStatement, sResultSet);                       
        }
		        
        return myShipperSqlResults;
    }
    
    public List<Map> getShipperInfoByStateCode(String stateCode) throws Exception {
        
        
        try {
	        connection = com.freightdesk.fdcommons.ConnectionUtil.getConnectionKsms();
        } catch (Exception ex) {
            logger.error("getShipperInfoByStateCode.getConnectionKsms() failed");
            throw (ex);
        }
        
        logger.info("getShipperInfoByStateCode:" + stateCode);
        List<ShipperDetails> shipperDetails = new ArrayList<ShipperDetails>();
        Session session = null;
        
		String stProcName = "apps.FAS_SHIPPER_SEARCH.SEL_REC_BY_STATE_CODE";
        String tCallableStmtStr = "{call " + stProcName + "(?,?)}";
        
        CallableStatement eStatement = null;
		boolean eReturnCode;
		List<Map> esListMap = null;
        try {
            eStatement = connection.prepareCall (tCallableStmtStr);
			eStatement.setString(1, stateCode);
            eStatement.registerOutParameter(2, OracleTypes.CURSOR);
			eReturnCode = eStatement.execute();
			sResultSet = (ResultSet) eStatement.getObject(2);
			esListMap = convertResultSetToListMapForSummaryPage (sResultSet);
        } catch (Exception ex) {
            logger.error("getShipperConnection failed" + ex.getMessage());
            throw (ex);
        } finally {
            com.freightdesk.fdcommons.ConnectionUtil.closeResources(connection, eStatement, sResultSet);                       
        }
		       
        return esListMap;
    }
    
    
    public MyShipperSqlResults getShipperInfoByShipperName(String shipperName) throws Exception {
        MyShipperSqlResults myShipperSqlResults = new MyShipperSqlResults();
        
        try {
	    connection = com.freightdesk.fdcommons.ConnectionUtil.getConnectionKsms();
        } catch (Exception ex) {
            logger.error("getShipperInfoByShipperName.getConnectionKsms() failed");
            throw (ex);
        }
        
        logger.info("getShipperInfoByShipperName:" + shipperName);
        List<ShipperDetails> shipperDetails = new ArrayList<ShipperDetails>();
        Session session = null;
        
	String stProcName = "apps.FAS_SHIPPER_SEARCH.SEL_REC_BY_SHIPPER_NAME";
        String tCallableStmtStr = "{call " + stProcName + "(?,?,?,?,?)}";
        
        CallableStatement eStatement = null;
		boolean eReturnCode;
        try {
            eStatement = connection.prepareCall (tCallableStmtStr);
			eStatement.setString(1, shipperName.toUpperCase());
			eStatement.registerOutParameter(2, OracleTypes.CURSOR);
			eStatement.registerOutParameter(3, OracleTypes.INTEGER);
			eStatement.registerOutParameter(4, OracleTypes.INTEGER);
			eStatement.registerOutParameter(5, OracleTypes.INTEGER);
	        eStatement.setFetchSize(fetchSize);
			eReturnCode = eStatement.execute();
			sResultSet = (ResultSet) eStatement.getObject(2);
			myShipperSqlResults.setTotalCount ((int) eStatement.getObject(3));
			myShipperSqlResults.setCount1 ((int) eStatement.getObject(4));
			myShipperSqlResults.setCount2 ((int) eStatement.getObject(5));
			myShipperSqlResults.setSListMap (convertResultSetToListMapForSummaryPage (sResultSet));
        } catch (Exception ex) {
            logger.error("getShipperConnection failed" + ex.getMessage());
            throw (ex);
        } finally {
            com.freightdesk.fdcommons.ConnectionUtil.closeResources(connection, eStatement, sResultSet);                       
        }            		
        
        return myShipperSqlResults;
    }
    
    
    public MyShipperSqlResults getShipperInfoByShipperNameIacNumber(String shipperName, String iacNumber) throws Exception {
        MyShipperSqlResults myShipperSqlResults = new MyShipperSqlResults();
        
        try {
	    connection = com.freightdesk.fdcommons.ConnectionUtil.getConnectionKsms();
        } catch (Exception ex) {
            logger.error("getShipperInfoByShipperName.getConnectionKsms() failed");
            throw (ex);
        }
        
        logger.info("getShipperInfoByShipperName:" + shipperName);
        List<ShipperDetails> shipperDetails = new ArrayList<ShipperDetails>();
        Session session = null;
        
	String stProcName = "apps.FAS_SHIPPER_SEARCH.SEL_REC_BY_SHIPPER_NAME_IAC";
        String tCallableStmtStr = "{call " + stProcName + "(?,?,?,?,?,?)}";
        
        CallableStatement eStatement = null;
		boolean eReturnCode;
        try {
            eStatement = connection.prepareCall (tCallableStmtStr);
			eStatement.setString(1, shipperName.toUpperCase());
			eStatement.setString(2, iacNumber.toUpperCase());
			eStatement.registerOutParameter(3, OracleTypes.CURSOR);
			eStatement.registerOutParameter(4, OracleTypes.INTEGER);
			eStatement.registerOutParameter(5, OracleTypes.INTEGER);
			eStatement.registerOutParameter(6, OracleTypes.INTEGER);
			eStatement.setFetchSize(fetchSize);
		    eReturnCode = eStatement.execute();
			sResultSet = (ResultSet) eStatement.getObject(3);
			myShipperSqlResults.setTotalCount ((int) eStatement.getObject(4));
			myShipperSqlResults.setCount1 ((int) eStatement.getObject(5));
			myShipperSqlResults.setCount2 ((int) eStatement.getObject(6));
			myShipperSqlResults.setSListMap (convertResultSetToListMapForSummaryPage (sResultSet));
        } catch (Exception ex) {
            logger.error("getShipperConnection failed" + ex.getMessage());
            throw (ex);
        } finally {
            com.freightdesk.fdcommons.ConnectionUtil.closeResources(connection, eStatement, sResultSet);                       
        }			
        
        return myShipperSqlResults;
    }
        
    
    public MyShipperSqlResults getShipperInfoByIacNumber(String iacNumber) throws Exception {
        MyShipperSqlResults myShipperSqlResults = new MyShipperSqlResults();
        
        try {
	        connection = com.freightdesk.fdcommons.ConnectionUtil.getConnectionKsms();
        } catch (Exception ex) {
            logger.error("getShipperInfoByIacNumber.getConnectionKsms() failed");
            throw (ex);
        }
        
        logger.info("getShipperInfoByiacNumber:" + iacNumber);
        List<ShipperDetails> shipperDetails = new ArrayList<ShipperDetails>();
        Session session = null;
        
        String stProcName = "apps.FAS_SHIPPER_SEARCH.SEL_REC_BY_IAC_NUMBER";
        String tCallableStmtStr = "{call " + stProcName + "(?,?,?,?,?)}";
        
        CallableStatement eStatement = null;
		boolean eReturnCode;
        try {
            eStatement = connection.prepareCall (tCallableStmtStr);
			eStatement.setString(1, iacNumber.toUpperCase());
			eStatement.registerOutParameter(2, OracleTypes.CURSOR);
			eStatement.registerOutParameter(3, OracleTypes.INTEGER);
			eStatement.registerOutParameter(4, OracleTypes.INTEGER);
			eStatement.registerOutParameter(5, OracleTypes.INTEGER);       
			eStatement.setFetchSize(fetchSize);
			eReturnCode = eStatement.execute();
			sResultSet = (ResultSet) eStatement.getObject(2);
			myShipperSqlResults.setTotalCount ((int) eStatement.getObject(3));
			myShipperSqlResults.setCount1 ((int) eStatement.getObject(4));
			myShipperSqlResults.setCount2 ((int) eStatement.getObject(5));
			myShipperSqlResults.setSListMap (convertResultSetToListMapForSummaryPage (sResultSet));
        } catch (Exception ex) {
            logger.error("getShipperConnection failed" + ex.getMessage());
            throw (ex);
        } finally {
            com.freightdesk.fdcommons.ConnectionUtil.closeResources(connection, eStatement, sResultSet);                      
        }			
        
        return myShipperSqlResults;
    }   
    
    public MyShipperSqlResults getShipperInfoByIacNumberShipperId(String iacNumber, String shipperId) throws Exception {
        MyShipperSqlResults myShipperSqlResults = new MyShipperSqlResults();
        
        try {
	        connection = com.freightdesk.fdcommons.ConnectionUtil.getConnectionKsms();
        } catch (Exception ex) {
            logger.error("getShipperInfoByIacNumberShipperId.getConnectionKsms() failed");
            throw (ex);
        }
        
        logger.info("getShipperInfoByIacNumberShipperId:" + iacNumber);
        List<ShipperDetails> shipperDetails = new ArrayList<ShipperDetails>();
        Session session = null;
        
        String stProcName = "apps.FAS_SHIPPER_SEARCH.SEL_REC_BY_IAC_SHIPPER_ID";
        String tCallableStmtStr = "{call " + stProcName + "(?,?,?,?,?,?)}";
        
        CallableStatement eStatement = null;
		boolean eReturnCode;
        try {
            eStatement = connection.prepareCall (tCallableStmtStr);
			eStatement.setString(1, iacNumber.toUpperCase());
			eStatement.setString(2, shipperId);
			eStatement.registerOutParameter(3, OracleTypes.CURSOR);
			eStatement.registerOutParameter(4, OracleTypes.INTEGER);
			eStatement.registerOutParameter(5, OracleTypes.INTEGER);
			eStatement.registerOutParameter(6, OracleTypes.INTEGER);        
			eStatement.setFetchSize(fetchSize);
			eReturnCode = eStatement.execute();
			sResultSet = (ResultSet) eStatement.getObject(3);
			myShipperSqlResults.setTotalCount ((int) eStatement.getObject(4));
			myShipperSqlResults.setCount1 ((int) eStatement.getObject(5));
			myShipperSqlResults.setCount2 ((int) eStatement.getObject(6));
			myShipperSqlResults.setSListMap (convertResultSetToListMapForSummaryPage (sResultSet));
        } catch (Exception ex) {
            logger.error("getShipperConnection failed" + ex.getMessage());
            throw (ex);
        } finally {
            com.freightdesk.fdcommons.ConnectionUtil.closeResources(connection, eStatement, sResultSet);                       
        }
                     	       
        return myShipperSqlResults;
    }   
    
    public MyShipperSqlResults getShipperInfoByIacAcCompanyName(String compName) throws Exception {
        MyShipperSqlResults myShipperSqlResults = new MyShipperSqlResults();
        
        elapsedTime[0] = System.currentTimeMillis();
        try {
	        connection = com.freightdesk.fdcommons.ConnectionUtil.getConnectionKsms();
        } catch (Exception ex) {
            logger.error("getShipperInfoByIacAcCompanyName.getConnectionKsms() failed");
            throw (ex);
        }
        
        logger.info("BEGIN ***** getShipperInfoByCompName:" + compName + " fetchSize:" + fetchSize);
        List<ShipperDetails> shipperDetails = new ArrayList<ShipperDetails>();
        Session session = null;
        
		String stProcName = "apps.FAS_SHIPPER_SEARCH.SEL_REC_BY_ORGANIZATION_NAME";
        String tCallableStmtStr = "{call " + stProcName + "(?,?,?,?,?)}";
        
        CallableStatement eStatement = null;
		boolean eReturnCode;
        try {
            eStatement = connection.prepareCall (tCallableStmtStr);
			eStatement.setString(1, compName.toUpperCase());
			eStatement.registerOutParameter(2, OracleTypes.CURSOR);
			eStatement.registerOutParameter(3, OracleTypes.INTEGER);
			eStatement.registerOutParameter(4, OracleTypes.INTEGER);
			eStatement.registerOutParameter(5, OracleTypes.INTEGER);        
			eStatement.setFetchSize(fetchSize);
			eReturnCode = eStatement.execute();
			sResultSet = (ResultSet) eStatement.getObject(2);	
			myShipperSqlResults.setTotalCount ((int) eStatement.getObject(3));
			myShipperSqlResults.setCount1 ((int) eStatement.getObject(4));
			myShipperSqlResults.setCount2 ((int) eStatement.getObject(5));        
			myShipperSqlResults.setSListMap ((convertResultSetToListMapForSummaryPage (sResultSet)));       
			logger.info("END ***** getShipperInfoByCompName:" + compName);
			elapsedTime[1] = System.currentTimeMillis();
        } catch (Exception ex) {
            logger.error("getShipperConnection failed" + ex.getMessage());
            throw (ex);
        } finally {
            com.freightdesk.fdcommons.ConnectionUtil.closeResources(connection, eStatement, sResultSet);                       
        }            			
        
        elapsedTime[2] = System.currentTimeMillis();
        logger.info("*** Elapsed Time :" + (elapsedTime[1] - elapsedTime[0]) + " --- " + (elapsedTime[2] - elapsedTime[1]));
           
        return myShipperSqlResults;
    }
           
    
    public MyShipperSqlResults getShipperInfoByIacAcCompanyNameShipperId(String compName, String shipperId) throws Exception {
        MyShipperSqlResults myShipperSqlResults = new MyShipperSqlResults();
        
        elapsedTime[0] = System.currentTimeMillis();
        try {
	        connection = com.freightdesk.fdcommons.ConnectionUtil.getConnectionKsms();
        } catch (Exception ex) {
            logger.error("getShipperInfoByIacAcCompanyNameShipperId.getConnectionKsms() failed");
            throw (ex);
        }
        
        logger.info("BEGIN ***** getShipperInfoByIacAcCompanyNameShipperId:" + compName + " fetchSize:" + fetchSize);
        List<ShipperDetails> shipperDetails = new ArrayList<ShipperDetails>();
        Session session = null;
        
		String stProcName = "apps.FAS_SHIPPER_SEARCH.SEL_REC_BY_ORG_NAME_SHIPPER_ID";
        String tCallableStmtStr = "{call " + stProcName + "(?,?,?,?,?,?)}";
        
        CallableStatement eStatement = null;
		boolean eReturnCode;
        try {
            eStatement = connection.prepareCall (tCallableStmtStr);
			eStatement.setString(1, compName.toUpperCase());
			eStatement.setString(2, shipperId);
			eStatement.registerOutParameter(3, OracleTypes.CURSOR);
			eStatement.registerOutParameter(4, OracleTypes.INTEGER);
			eStatement.registerOutParameter(5, OracleTypes.INTEGER);
			eStatement.registerOutParameter(6, OracleTypes.INTEGER);        
			eStatement.setFetchSize(fetchSize);
			eReturnCode = eStatement.execute();
			sResultSet = (ResultSet) eStatement.getObject(3);	
			myShipperSqlResults.setTotalCount ((int) eStatement.getObject(4));
			myShipperSqlResults.setCount1 ((int) eStatement.getObject(5));
			myShipperSqlResults.setCount2 ((int) eStatement.getObject(6));        
			myShipperSqlResults.setSListMap ((convertResultSetToListMapForSummaryPage (sResultSet)));        
			logger.info("END ***** getShipperInfoByIacAcCompanyNameShipperId:" + compName);
			elapsedTime[1] = System.currentTimeMillis();
        } catch (Exception ex) {
            logger.error("getShipperConnection failed" + ex.getMessage());
            throw (ex);
        } finally {
            com.freightdesk.fdcommons.ConnectionUtil.closeResources(connection, eStatement, sResultSet);                       
        }            		
        
        elapsedTime[2] = System.currentTimeMillis();
        logger.info("*** Elapsed Time :" + (elapsedTime[1] - elapsedTime[0]) + " --- " + (elapsedTime[2] - elapsedTime[1]));
           
        return myShipperSqlResults;
    }
       
    
    public List<Map> getShipperDetails(String shipperId, String iacNumber) throws Exception {
        
        try {
	        connection = com.freightdesk.fdcommons.ConnectionUtil.getConnectionKsms();
        } catch (Exception ex) {
            logger.error("getShipperDetails.getConnectionKsms() failed");
            throw (ex);
        }
        
        logger.info("getShipperDetails:" + shipperId + ":" + iacNumber);
        List<ShipperDetails> shipperDetails = new ArrayList<ShipperDetails>();
        Session session = null;
        
	String stProcName = "apps.FAS_SHIPPER_SEARCH.SEL_SHIPPER_DETAILS_BY_ID_IAC";
        String tCallableStmtStr ="";
        
        if ((iacNumber != null) && (iacNumber.length() > 0)) {
            stProcName = "apps.FAS_SHIPPER_SEARCH.SEL_SHIPPER_DETAILS_BY_ID_IAC";
            logger.info("SHIPPER iacNumber.length():" + iacNumber.length());
        } else {
            stProcName = "apps.FAS_SHIPPER_SEARCH.SEL_SHIPPER_AC_DET_BY_ID_IAC";            
        }
        
        tCallableStmtStr = "{call " + stProcName + "(?,?,?)}";
        
        CallableStatement eStatement = null;
	    boolean eReturnCode;
		List<Map> esListMap = null;
        try {
            eStatement = connection.prepareCall (tCallableStmtStr);
			eStatement.setString(1, shipperId);
			eStatement.setString(2, iacNumber);
			eStatement.registerOutParameter(3, OracleTypes.CURSOR);
		    eReturnCode = eStatement.execute();
			sResultSet = (ResultSet) eStatement.getObject(3);
			esListMap = convertResultSetToListMapForDetailPage (sResultSet);
        } catch (Exception ex) {
            logger.error("getShipperConnection failed" + ex.getMessage());
            throw (ex);
        } finally {
            com.freightdesk.fdcommons.ConnectionUtil.closeResources(connection, eStatement, sResultSet);                      
        }
           		       
        return esListMap;
    }  
    
    public List<Map> getDispCodeByShipperId(String shipperId) throws Exception {
        
        try {
	        connection = com.freightdesk.fdcommons.ConnectionUtil.getConnectionKsms();
        } catch (Exception ex) {
            logger.error("getDispCodeByShipperId.getConnectionKsms() failed");
            throw (ex);
        }
        
        logger.info("getShipperInfoByShipperId:" + shipperId);
        List<ShipperDetails> shipperDetails = new ArrayList<ShipperDetails>();
        Session session = null;
        
		String stProcName = "apps.FAS_SHIPPER_SEARCH.SEL_DISP_CODE_BY_PARTY_ID";
        String tCallableStmtStr = "{call " + stProcName + "(?,?)}";
        
        CallableStatement eStatement = null;
		boolean eReturnCode;
		List<Map> esListMap = null;
        try {
            eStatement = connection.prepareCall (tCallableStmtStr);
			eStatement.setString(1, shipperId);
            eStatement.registerOutParameter(2, OracleTypes.CURSOR);
			eReturnCode = eStatement.execute();
			sResultSet = (ResultSet) eStatement.getObject(2);
			esListMap = convertResultSetToOrgProfMap (sResultSet);
        } catch (Exception ex) {
            logger.error("getShipperConnection failed" + ex.getMessage());
            throw (ex);
        } finally {
            com.freightdesk.fdcommons.ConnectionUtil.closeResources(connection, eStatement, sResultSet);                       
        }				
        
        return esListMap;
    }
    

    public List<Map> getDispCodeByPartyId(long partyId) throws Exception {
        
        try {
	        connection = com.freightdesk.fdcommons.ConnectionUtil.getConnectionKsms();
        } catch (Exception ex) {
            logger.error("getDispCodeByPartyId.getConnectionKsms() failed");
            throw (ex);
        }
        
        logger.info("getDispCodeByPartyId:" + partyId);
        Session session = null;
        
		String stProcName = "apps.FAS_SHIPPER_SEARCH.SEL_DISP_CODE_BY_PARTY_ID";
        String tCallableStmtStr = "{call " + stProcName + "(?,?)}";
        
        CallableStatement eStatement = null;
		boolean eReturnCode;
		List<Map> esListMap = null;
        try {
            eStatement = connection.prepareCall (tCallableStmtStr);
			eStatement.setLong(1, partyId);
            eStatement.registerOutParameter(2, OracleTypes.CURSOR);
			eReturnCode = eStatement.execute();
			sResultSet = (ResultSet) eStatement.getObject(2);
			esListMap = convertResultSetToOrgProfMap (sResultSet);
        } catch (Exception ex) {
            logger.error("getShipperConnection failed" + ex.getMessage());
            throw (ex);
        } finally {
            com.freightdesk.fdcommons.ConnectionUtil.closeResources(connection, eStatement, sResultSet);                       
        }             	    				
        
        return esListMap;
    }
    
    
    public List<Map> getNotesByPartyId(long partyId) throws Exception {
        
        try {
	        connection = com.freightdesk.fdcommons.ConnectionUtil.getConnectionKsms();
        } catch (Exception ex) {
            logger.error("getNotesByPartyId.getConnectionKsms() failed");
            throw (ex);
        }
        
        logger.info("----getNotesByPartyId:" + partyId);
        Session session = null;
        
		String stProcName = "apps.FAS_SHIPPER_SEARCH.SEL_NOTES_BY_PARTY_ID";
        String tCallableStmtStr = "{call " + stProcName + "(?,?)}";
        
        CallableStatement eStatement = null;
		boolean eReturnCode;
		List<Map> esListMap = null;
        try {
            eStatement = connection.prepareCall (tCallableStmtStr);
			eStatement.setLong(1, partyId);
            eStatement.registerOutParameter(2, OracleTypes.CURSOR);
			eReturnCode = eStatement.execute();
			sResultSet = (ResultSet) eStatement.getObject(2);
			esListMap = convertResultSetToNotesMap (sResultSet);
        } catch (Exception ex) {
            logger.error("getNotesByPartyId failed" + ex.getMessage());
            throw (ex);
        } finally {
            com.freightdesk.fdcommons.ConnectionUtil.closeResources(connection, eStatement, sResultSet);                       
        }             				
        
        return esListMap;
    }    
	
    private List<Map> convertResultSetToListMapForDetailPage (ResultSet searchResultSet) throws Exception{
		List<Map> listMap = new ArrayList();
        Map map = null;
        
        try {
        
          while (searchResultSet.next()){
            map = new HashMap();

            if (searchResultSet.getString("PARTY_ID") == null){
                map.put("partyId", "");
            } else {
                map.put("partyId", searchResultSet.getLong("PARTY_ID"));
            }
            
            if (searchResultSet.getString("APPROVAL_NBR") == null){
                map.put("iacNumber", "");
            } else {
                map.put("iacNumber", searchResultSet.getString("APPROVAL_NBR"));
            }

            if (searchResultSet.getString("IAC_NAME") == null){
                map.put("iacAcCompanyName", "");
            } else {
                map.put("iacAcCompanyName", searchResultSet.getString("IAC_NAME"));
            }
            
            if (searchResultSet.getString("SHIPPER_ID") == null){
				map.put("shipperId", "");
            } else {
                map.put("shipperId", searchResultSet.getString("SHIPPER_ID"));				
            }
            
            if (searchResultSet.getString("SHIPPER_NAME") == null){
                map.put("shipperName", "");
            } else {
                map.put("shipperName", searchResultSet.getString("SHIPPER_NAME"));				
            }
            
            
            if (searchResultSet.getString("PARTY_TYPE") == null){
                map.put("shipperType", "");
            } else {
                map.put("shipperType", searchResultSet.getString("PARTY_TYPE"));
            }
            
            if (searchResultSet.getString("ATTRIBUTE15") == null){
                map.put("shipperStatus", "");
            } else {
                map.put("shipperStatus", searchResultSet.getString("ATTRIBUTE15"));				
            }
            
            if (searchResultSet.getString("ATTRIBUTE5") == null){
                map.put("reasonForStatus", "");
            } else {
                map.put("reasonForStatus", searchResultSet.getString("ATTRIBUTE5"));				
            }
            
            if (searchResultSet.getString("CREATION_DATE") == null){
                map.put("creationDate", "");
            } else {
                map.put("creationDate", searchResultSet.getString("CREATION_DATE"));				
            }
            
            if (searchResultSet.getString("ADDRESS1") == null){
                map.put("address1", "");
            } else {
                map.put("address1", searchResultSet.getString("ADDRESS1"));
            }
            
            if (searchResultSet.getString("ADDRESS2") == null){
                map.put("address2", "");
            } else {
                map.put("address2", searchResultSet.getString("ADDRESS2"));
            }
            
            if (searchResultSet.getString("CITY") == null){
                map.put("city", "");
            } else {
                map.put("city", searchResultSet.getString("CITY"));
            }
            
           
            if (searchResultSet.getString("POSTAL_CODE") == null){
                map.put("zipPostalCode", "");
            } else {
                map.put("zipPostalCode", searchResultSet.getString("POSTAL_CODE"));
            }
            
            if (searchResultSet.getString("STATE") == null){
                map.put("state", "");
            } else {
                map.put("state", searchResultSet.getString("STATE"));				
            }
            
            if (searchResultSet.getString("COUNTRY") == null){
                map.put("country", "");
            } else {
                map.put("country", searchResultSet.getString("COUNTRY"));				
            }
            
            if (searchResultSet.getString("PRIMARY_PHONE_NUMBER") == null){
                map.put("phone", "");
            } else {
                map.put("phone", searchResultSet.getString("PRIMARY_PHONE_NUMBER"));				
            }
            
            listMap.add(map);
            return listMap;   // only one for ID search
            
  		  }
		}  catch (Exception e)             {
          	logger.error ("Exception in shipper convertResultSetToListMapForDetailPage" + e.getMessage ());
          	return listMap;
        }
		
		  
        return listMap;
    }   
    
    private List<Map> convertResultSetToListMapForSummaryPage (ResultSet searchResultSet) throws Exception{
		List<Map> listMap = new ArrayList();
        Map map = null;
        
        String shipperId = "";
        int count = 0;        
        
        try {
        
          while (searchResultSet.next()) {
        	  
            map = new HashMap  ();
            if (searchResultSet.getString("SHIPPER_ID") == null){
				map.put("shipperId", "");
            } else {
                shipperId = searchResultSet.getString("SHIPPER_ID");	
                map.put("shipperId", shipperId);
            }
            
            if (searchResultSet.getString("INTERNAL_APPROVAL_NBR") == null){
                map.put("internalIacNumber", "");
            } else {
                map.put("internalIacNumber", searchResultSet.getString("INTERNAL_APPROVAL_NBR"));
            }
            
            if (searchResultSet.getString("APPROVAL_NBR") == null){
                map.put("iacNumber", "");
            } else {
                map.put("iacNumber", searchResultSet.getString("APPROVAL_NBR"));
            }
            
            if (searchResultSet.getString("IAC_NAME") == null){
                map.put("iacAcCompanyName", "");
            } else {
                map.put("iacAcCompanyName", searchResultSet.getString("IAC_NAME"));
            }
            
            
            if (searchResultSet.getString("SHIPPER_NAME") == null){
                map.put("shipperName", "");
            } else {
                map.put("shipperName", searchResultSet.getString("SHIPPER_NAME"));				
            }
            
            if (searchResultSet.getString("PARTY_TYPE") == null){
                map.put("shipperType", "");
            } else {
                map.put("shipperType", searchResultSet.getString("PARTY_TYPE"));
            }
            
            if (searchResultSet.getString("ATTRIBUTE15") == null){
                map.put("shipperStatus", "");
            } else {
                map.put("shipperStatus", searchResultSet.getString("ATTRIBUTE15"));				
            }
            
            listMap.add(map);
          }
		}  catch (Exception e)             {
          	logger.error ("Exception in shipper summary" + e.getMessage ());
          	return listMap;
        }
		
        return listMap;
    }       
    
    private List<Map> convertResultSetToOrgProfMap (ResultSet searchResultSet) throws Exception{
	List<Map> listMap = new ArrayList();
        Map map = new HashMap();
        
          while (searchResultSet.next()){
            map = new HashMap();
            if (searchResultSet.getString("ORGANIZATION_NAME") == null){
                map.put("organizationName", "");
            } else {
                map.put("organizationName", searchResultSet.getString("ORGANIZATION_NAME"));
            }
            
            if (searchResultSet.getLong("ORGANIZATION_PROFILE_ID") == 0){
                map.put("organizationProfileId", 0);
            } else {
                map.put("organizationProfileId", searchResultSet.getLong("ORGANIZATION_PROFILE_ID"));
            }
            
            if (searchResultSet.getString("C_EXT_ATTR4") == null){
				map.put("dispositionCode", "");
            } else {
                map.put("dispositionCode", searchResultSet.getString("C_EXT_ATTR4"));				
            }
            
            if (searchResultSet.getString("C_EXT_ATTR10") == null){
                map.put("virtualShipper", "");
            } else {
                map.put("virtualShipper", searchResultSet.getString("C_EXT_ATTR10"));				
            }
            
            listMap.add(map);
	}
		  
        return listMap;
    }
   
    
    private List<Map> convertResultSetToNotesMap (ResultSet searchResultSet) throws Exception{

	List<Map> listMap = new ArrayList();
        Map map = null;
        
          while (searchResultSet.next()){
            map = new HashMap();
            if (searchResultSet.getString("NOTES") == null){
                map.put("notes", "");
            } else {
                map.put("notes", searchResultSet.getString("NOTES"));
            }           
            
            if (searchResultSet.getString("EMAIL_ADDRESS") == null){
                map.put("email", "");
            } else {
                map.put("email", searchResultSet.getString("EMAIL_ADDRESS"));
            }
			
            if (searchResultSet.getString("LAST_UPDATE_DATE") == null){
                map.put("dateEntered", "");
            } else {			                   
				map.put("dateEntered", ((String)searchResultSet.getString("LAST_UPDATE_DATE")).substring(0, 16));
            }
            
            if (searchResultSet.getString("ATTRIBUTE4") == null){
				map.put("createdByProcess", "");
            } else {
                map.put("createdByProcess", searchResultSet.getString("ATTRIBUTE4"));				
            }
            
            if (searchResultSet.getString("ATTRIBUTE2") == null){
				map.put("previousStatus", "");
            } else {
                map.put("previousStatus", searchResultSet.getString("ATTRIBUTE2"));				
            }
            
            if (searchResultSet.getString("ATTRIBUTE3") == null){
                map.put("shipperStatus", "");
            } else {
                map.put("shipperStatus", searchResultSet.getString("ATTRIBUTE3"));				
            }
            
             
             if (searchResultSet.getString("NOTE_TYPE") == null){
                map.put("noteType", "");
            } else {
                map.put("noteType", searchResultSet.getString("NOTE_TYPE"));				
            }
             
            listMap.add(map);
		}
		  
        return listMap;
    }
}
