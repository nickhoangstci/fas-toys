/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ctu.tsa.fas.requesttracker.action;

import com.ctu.tsa.fas.delegation.RequestTrackerDelegation;
import com.ctu.tsa.fas.requesttracker.dao.RequestTrackerDAO;
import com.ctu.tsa.fas.requesttracker.data.RequestReferenceData;
import com.opensymphony.xwork2.Action;
import java.util.Map;
import java.util.Iterator;
import org.apache.log4j.Logger;
import com.freightdesk.fdcommons.ApplicationTabs;
import com.freightdesk.fdcommons.Credentials;
import com.freightdesk.fdcommons.SessionKey;
import com.freightdesk.fdcommons.SessionStore;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.apache.struts2.ServletActionContext;

public class RequestTrackerAction implements Action {

    private static Map<String, String> subjectRegionLinkedMap = null;
    private static Map<String, String> ogaReferralLinkedMap = null;
    private static Map<String, String> jointOperationsLinkedMap = null;
    private static Map<String, String> fieldCallStaRequestLinkedMap = null;
    private static Map<String, String> staInLieuOfLinkedMap = null;
    private static Map<String, String> cargoIncidentLinkedMap = null;
    private  Map<String, String> ccsfApprovalLinkedMap = null;
    private Map<String, String> targeterLinkedMap = null;
    private static Map<String, String> airportNamesLinkedMap = null;
    private static Map<String, String> requestTypeLinkedMap = null;
    protected Logger logger = Logger.getLogger(getClass());
    
    HttpServletRequest request = ServletActionContext.getRequest();
	
    public static boolean resetRequestTrackerParams = false;   // should be set by other pages when needed.

    public String execute() {

        if (resetRequestTrackerParams) {
            logger.debug("All lists are initialized");
            return SUCCESS;
        }
        
        request = ServletActionContext.getRequest();
        HttpSession session = request.getSession();
        SessionStore sessionStore = SessionStore.getInstance(session);
        Credentials credentials = (Credentials) sessionStore.get(SessionKey.CREDENTIALS);

        logger.info("Initialize all lists SHOULD BE ONLY FOR FIRST TIME or REFRESH");
        sessionStore.put(SessionKey.CURRENT_TAB, ApplicationTabs.REQUESTTRACKER);

        RequestTrackerDelegation delegate = new RequestTrackerDelegation();
        try {

            subjectRegionLinkedMap = delegate.getSubjectRegionList();
            ogaReferralLinkedMap = delegate.getOgaReferralList();
            jointOperationsLinkedMap = delegate.getJointOperationsList();
            fieldCallStaRequestLinkedMap = delegate.getFieldCallStaRequestList();
            staInLieuOfLinkedMap = delegate.getStaInLieuOfList();
            cargoIncidentLinkedMap = delegate.getCargoIncidentList();
            ccsfApprovalLinkedMap = delegate.getCCSFApprovalList();
            targeterLinkedMap = delegate.getTargeterList();
            airportNamesLinkedMap = delegate.getAirportList();
            requestTypeLinkedMap = delegate.getRequestTypeList();

            RequestReferenceData requestReferenceData = RequestReferenceData.getInstance();
            requestReferenceData.setTargeterLinkedMap(targeterLinkedMap);
            requestReferenceData.setAirportNamesLinkedMap(airportNamesLinkedMap);
            requestReferenceData.setCcsfApprovalLinkedMap(ccsfApprovalLinkedMap);
            requestReferenceData.setOgaReferralLinkedMap(ogaReferralLinkedMap);
            requestReferenceData.setSubjectRegionLinkedMap(subjectRegionLinkedMap);
            requestReferenceData.setRequestTypeLinkedMap(requestTypeLinkedMap);
            requestReferenceData.setJointOperationsLinkedMap(jointOperationsLinkedMap);
            requestReferenceData.setFieldCallStaRequestLinkedMap(fieldCallStaRequestLinkedMap);
            requestReferenceData.setStaInLieuOfLinkedMap(staInLieuOfLinkedMap);
            requestReferenceData.setCargoIncidentLinkedMap(cargoIncidentLinkedMap);

            resetRequestTrackerParams = true;
        } catch (Exception e) {
            logger.error ("RequestTrackerAction EXCEPTION : = "+e.getMessage());
        }
        return SUCCESS;
    }

    public String getAllPsiTargetters() {
    	
        logger.info("getAllPsiTargetters----------------------");		

        RequestTrackerDAO dao = RequestTrackerDAO.getInstance();
        try {
            ccsfApprovalLinkedMap = dao.getCCSFApprovalList();            

            targeterLinkedMap = dao.getTargeterList();           
			
            RequestReferenceData requestReferenceData = RequestReferenceData.getInstance();
            requestReferenceData.setTargeterLinkedMap(dao.getTargeterList());
            requestReferenceData.setCcsfApprovalLinkedMap(dao.getCCSFApprovalList());
			
            ccsfApprovalLinkedMap.clear();
            ccsfApprovalLinkedMap.put("0", "Select PSI");
            ccsfApprovalLinkedMap.putAll(requestReferenceData.getCcsfApprovalLinkedMap());
			
            targeterLinkedMap.clear();
            targeterLinkedMap.put("0", "Select Targeter");
            targeterLinkedMap.putAll(requestReferenceData.getTargeterLinkedMap());			

        } catch (Exception e) {
            logger.error("getAllPsiTargetters EXCEPTION : = "+e.getMessage());
        }
        return SUCCESS;
	
    }
    public Map<String, String> getRequestTypeLinkedMap() {
        return requestTypeLinkedMap;
    }

    public void setRequestTypeLinkedMap(Map<String, String> requestTypeLinkedMap) {
        this.requestTypeLinkedMap = requestTypeLinkedMap;
    }

    public Map<String, String> getAirportNamesLinkedMap() {
        return airportNamesLinkedMap;
    }

    public void setAirportNamesLinkedMap(Map<String, String> airportNamesLinkedMap) {
        this.airportNamesLinkedMap = airportNamesLinkedMap;
    }

    public Map<String, String> getSubjectRegionLinkedMap() {
        return subjectRegionLinkedMap;
    }

    public Map<String, String> getOgaReferralLinkedMap() {
        return ogaReferralLinkedMap;
    }

    public Map<String, String> getJointOperationsLinkedMap() {
        return jointOperationsLinkedMap;
    }

    public Map<String, String> getFieldCallStaRequestLinkedMap() {
        return fieldCallStaRequestLinkedMap;
    }

    public Map<String, String> getCargoIncidentLinkedMap() {
        return cargoIncidentLinkedMap;
    }

    public Map<String, String> getCcsfApprovalLinkedMap() {
        return ccsfApprovalLinkedMap;
    }

    public void setOgaReferralLinkedMap(Map<String, String> ogaReferralLinkedMap) {
        this.ogaReferralLinkedMap = ogaReferralLinkedMap;
    }

    public void setJointOperationsLinkedMap(Map<String, String> jointOperationsLinkedMap) {
        this.jointOperationsLinkedMap = jointOperationsLinkedMap;
    }

    public void setFieldCallStaRequestLinkedMap(Map<String, String> fieldCallStaRequestLinkedMap) {
        this.fieldCallStaRequestLinkedMap = fieldCallStaRequestLinkedMap;
    }

    public void setCargoIncidentLinkedMap(Map<String, String> cargoIncidentLinkedMap) {
        this.cargoIncidentLinkedMap = cargoIncidentLinkedMap;
    }

    public void setCcsfApprovalLinkedMap(Map<String, String> ccsfApprovalLinkedMap) {
        this.ccsfApprovalLinkedMap = ccsfApprovalLinkedMap;
    }

    public void setSubjectRegionLinkedMap(Map<String, String> subjectRegionLinkedMap) {
        this.subjectRegionLinkedMap = subjectRegionLinkedMap;
    }

    public Map<String, String> getTargeterLinkedMap() {
        return targeterLinkedMap;
    }

    public void setTargeterLinkedMap(Map<String, String> targeterLinkedMap) {
        this.targeterLinkedMap = targeterLinkedMap;
    }

    public Map<String, String> getStaInLieuOfLinkedMap() {
        return staInLieuOfLinkedMap;
    }

    public void setStaInLieuOfLinkedMap(Map<String, String> staInLieuOfLinkedMap) {
        this.staInLieuOfLinkedMap = staInLieuOfLinkedMap;
    }

}
