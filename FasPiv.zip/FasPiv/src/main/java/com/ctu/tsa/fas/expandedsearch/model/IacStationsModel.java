/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ctu.tsa.fas.expandedsearch.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

/**
 *
 * @author Binh.Nguyen
 */
public class IacStationsModel implements Serializable{
    private static final long serialVersionUID = -8767337899673261248L;
    private String partyName;
	private String city;
	private String state;
	private String active;
	private int partyId;
	private int objectId;
		
    public IacStationsModel() {
    }
        
    public IacStationsModel(String partyName, String city, String state, String active) {
		this.partyName = partyName;        
		this.city = city;       
		this.state = state;
		this.active = active;
    }
    
    public void setPartyName (String partyName) {
		this.partyName = partyName; 
    }	
	
	public void setCity (String city) {
		this.city = city; 
    }
	
    public void setState(String state) {
    	this.state = state; 
    }
	
	public void setActive (String active) {
		this.active = active; 
    }
	
	public String getPartyName () {
		return (this.partyName); 
    }	
	
	public String getCity () {
		return (this.city); 
    }
	
	public String getState () {
		return (this.state); 
    }
	
	public String getActive () {
		return (this.active); 
    }
	
    public String toString () {

	String sep = System.getProperty("line.separator");

	StringBuffer buffer = new StringBuffer();
	buffer.append(sep);		
	buffer.append("partyName = ");
	buffer.append(partyName);
	buffer.append(sep);	
	buffer.append("city = ");
	buffer.append(city);
	buffer.append(sep);
	buffer.append("state = ");
	buffer.append(state);
	buffer.append(sep);
	buffer.append("active = ");
	buffer.append(active);
	buffer.append(sep);     		
	
	return buffer.toString();
    }
	
	public IacStationsModel (IacStationsModel other) {
		if (this != other) {
			this.partyName = other.partyName;			
			this.city = other.city;
			this.state = other.state;
			this.active = other.active;
			this.partyId = other.partyId;
			this.objectId = other.objectId;
		}
	}
	
	public void setPartyId (int partyId) {	    
		this.partyId = partyId; 
	}
	
	public int getPartyId () {
		return (this.partyId); 
	}
	
	public void setObjectId (int objectId) {
		this.objectId = objectId; 
	}
	
	public int getObjectId () {
		return (this.objectId); 
	}
}
