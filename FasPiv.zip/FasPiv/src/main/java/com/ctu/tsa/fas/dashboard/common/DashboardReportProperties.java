/** 
 * 
 * Copyright (c) 2000-2002 NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/reporting/ReportPropertiesReader.java,v 1.1.4.3 2010/12/01 21:57:17 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: ReportPropertiesReader.java,v $
 *  Revision 1.1.4.3  2010/12/01 21:57:17  mechevarria
 *  use runtime only
 
 * 
 */

package com.ctu.tsa.fas.dashboard.common;

import com.freightdesk.fdcommons.reporting.ReportsXML;
import java.io.File;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;

import org.apache.log4j.Logger;

/**
 * Responsible for analyzing Report Properties xml document and prepare
 * corresponding model.
 * 
 * @author Mike Echevarria
 */
public class DashboardReportProperties {
	private static Logger logger = Logger.getLogger(Class.class);
	
	private static ReportsXML reportsXML = null;
	
	protected static DashboardReportProperties _instance = null;
	

	public static DashboardReportProperties getInstance() {
		if (_instance == null) {
			_instance = new DashboardReportProperties();
		}
		return _instance;
	}

	public static void reset() {
		reportsXML = null;
		load();
	}

	private DashboardReportProperties() {
		load();
	}

	/**
	 * Prepare Reports XML Model from xml.
	 * 
	 * @throws Exception
	 *             if No properties file exist for domain passed as an argument.
	 * @return ReportsXML
	 */
	private static void load() {
		logger.info("Loading ReportProperties to ReportsXML");
		Unmarshaller u = null;
		
		String filePath = System.getProperty("RUNTIME_HOME") + File.separator + "FASReportProperties.xml";

		try {
			JAXBContext ctx = JAXBContext.newInstance(ReportsXML.class);
			u = ctx.createUnmarshaller();
			reportsXML = (ReportsXML) u.unmarshal(new File(filePath));
		} catch (Exception e) {			
			logger.error("Exception - Error occured during ReportProperties unmarshall: " + e.getMessage());
		}
		logger.debug("Loaded " + reportsXML.getReportXML().size() + " from " + filePath);
	}
	
	public ReportsXML getReportsXML() {
		return reportsXML;
	}
}
