/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ctu.tsa.fas.expandedsearch.action;

import javax.servlet.http.HttpServletRequest;
import com.freightdesk.fdcommons.Credentials;
import com.freightdesk.fdcommons.SessionKey;
import com.freightdesk.fdcommons.SessionStore;
import javax.servlet.http.HttpSession;
import com.opensymphony.xwork2.ActionSupport;
import org.apache.log4j.Logger;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.ServletActionContext;
import crt.com.freightdesk.fdfolio.common.IncludesUtil;
import java.util.List;
import java.util.ArrayList;
import com.ctu.tsa.fas.expandedsearch.dao.ExpandedSearchCcsfDAO;
import com.ctu.tsa.fas.expandedsearch.model.CcsfFacility; 
import java.util.Map;
import java.util.HashMap;
import java.sql.*;
import java.util.Iterator;
import org.json.JSONArray;
import org.json.JSONObject;
import com.freightdesk.fdcommons.ApplicationTabs;

/**
 *
 * @author Kevin.Tsou
 */
public class CcsfSearchAction extends ActionSupport implements ServletRequestAware{
    protected Logger logger = Logger.getLogger(getClass());
    HttpServletRequest request = ServletActionContext.getRequest();    
    private String loginTimeRoleMsg;
    private String expandedSearchType = "";
    private String basicBtnClicked = "";
    private List<String> searchTypeList = new ArrayList<>();
    private String certNumber = "";
    private String companyName = "";
    private List<Map> ccsfListMap;
    private List<Map> ccsfList;
    private long recordCount=0;
    private String pagerOffset;
    private int noOfCcsfRecordsToLoad = 5000;
    private String noOfCcsfRecordsToLoadStr = "";
    
    private String process;
    private String hdnProcess;	
    
    private int pageSize = 25;

    private long startTime = 0;
    private Runtime runtime = Runtime.getRuntime();
    private String debugMsg = null;
    private String ccsfJsonStr = null;
    	
    
    @Override
    public String execute()throws Exception {
    	
    	startTime = System.currentTimeMillis();
    	
        request = ServletActionContext.getRequest();
        HttpSession session = request.getSession(false);
        SessionStore store = SessionStore.getInstance(session);
        Credentials credentials = (Credentials) store.get(SessionKey.CREDENTIALS);
        ExpandedSearchCcsfDAO dao = new ExpandedSearchCcsfDAO();
        List<CcsfFacility> CcsfFacilities = new ArrayList<CcsfFacility>();
        ResultSet searchResultSet;
        
        logger.info("------execute CCSF: begin");
        loginTimeRoleMsg = IncludesUtil.getWelcomeMsg(credentials)+ "<br>" + IncludesUtil.getExpireMsg(credentials);              

        SessionStore sessionStore = SessionStore.getInstance (request.getSession());
        sessionStore.put(SessionKey.CURRENT_TAB, ApplicationTabs.EXPANDEDSEARCH);
        
        noOfCcsfRecordsToLoad = 100;
        noOfCcsfRecordsToLoadStr = Integer.toString(noOfCcsfRecordsToLoad);            
        
        setNoOfCcsfRecordsToLoad(getNoOfCcsfRecordsToLoad());
        
        
        searchTypeList = initSearchTypeList (searchTypeList);
        try {
            setHdnProcess (request.getParameter("hdnProcess"));               
                
            if ((hdnProcess != null) && (hdnProcess.equalsIgnoreCase("searchResults"))){
                setProcess(hdnProcess);                
                ccsfList = (List<Map>)store.get(SessionKey.CCSF_LIST);
                ccsfListMap = convertToCcsfListMap(ccsfList);
                setRecordCount ( ccsfList.size());
                sessionStore.put (SessionKey.CCSF_LIST, ccsfList);    
                return "displayCcsf";
                
            } 				
        } catch (Exception ex) {
            logger.error("Unexpected exception in execute(): ", ex);
            throw ex;
        }
        
        ccsfList = new ArrayList<Map>();
        sessionStore.put(SessionKey.CCSF_LIST, ccsfList); 
        
        if ((getCertNumber().length() < 3) && (getCompanyName().length() < 3)){
            sessionStore.put (SessionKey.TOTAL_COUNT, new Long(0) );
            addFieldError("userDetailsErrorsHeader", getText("errors.header"));
            addActionError("Minimum of 3 alphanumeric characters must be entered in the search field");
            return "displayCcsf";
        }
        
        setCertNumber(getCertNumber().toUpperCase().replaceAll("<", "&lt").replaceAll(">", "&gt"));
        setCompanyName(getCompanyName().toUpperCase().replaceAll("<", "&lt").replaceAll(">", "&gt"));
            
        if (! getCertNumber().trim().equals("")){
            logger.info("before NOT NULL certNumber: " + getCertNumber());
            setCcsfList(dao.getCcsfInfoByCertNum(getCertNumber()));
        } else if (! getCompanyName().trim().equals("")){
            logger.info("before NOT NULL companyName: " + getCompanyName());
            setCcsfList(dao.getCcsfInfoByFacilityName(getCompanyName()));
        } else {
            logger.info("NULL certNumber: ");
            setCcsfList(dao.getCcsfInfoByFacilityName("%"));
        }
        
        ccsfJsonStr = convertMapListToJsonString(ccsfList);
        sessionStore.put (SessionKey.CCSF_LIST_JSON_STR, ccsfJsonStr);
        
        ccsfListMap = convertToCcsfListMap(ccsfList);
        setRecordCount ( ccsfList.size());
        sessionStore.put (SessionKey.CCSF_LIST, ccsfList);
        sessionStore.put (SessionKey.TOTAL_COUNT, new Long(getRecordCount()));        
        
        logger.info(" :TOTAL COUNT: " + ccsfList.size());
	debugMsg = "CCSF **** Memory: " + runtime.totalMemory()/1000 + ", Used: " + (runtime.totalMemory() - runtime.freeMemory())/1000 + " Elapsed Time :" + (System.currentTimeMillis() - startTime);
	logger.info(debugMsg);
        session.setAttribute("DEBUG_MSG", debugMsg);

	return "displayCcsf";
        
    }
    
    public String respondBtnSearchTypeReturn() throws java.lang.Exception {
        request = ServletActionContext.getRequest();
        HttpSession session = request.getSession(false);
        SessionStore store = SessionStore.getInstance(session);
        Credentials credentials = (Credentials) store.get(SessionKey.CREDENTIALS);
        loginTimeRoleMsg = IncludesUtil.getWelcomeMsg(credentials) + "<br>" + IncludesUtil.getExpireMsg(credentials);

        logger.info("Starting respondBtnSearchTypeReturn ");
        SessionStore sessionStore = SessionStore.getInstance(request.getSession());
        
        
        return "display";
    }         
    
    public String getExpandedSearchType() {
	return expandedSearchType;
    }
        
    public void setExpandedSearchType(String expandedSearchType) {
	this.expandedSearchType = expandedSearchType; 
    }
    
    public String getCertNumber() {
	return certNumber.toUpperCase();
    }
        
    public void setCertNumber(String certNumber) {
	this.certNumber = certNumber; 
    }
    
    public String getCompanyName() {
	return companyName.toUpperCase();
    }
        
    public void setCompanyName(String companyName) {
	this.companyName = companyName; 
    }
    
    public List<String> getSearchTypeList() {
	return searchTypeList;
    }
        
    public void setSearchTypeList(List<String> searchTypeList) {
	this.searchTypeList = searchTypeList; 
    }
    
    public String getLoginTimeRoleMsg() {
        return loginTimeRoleMsg;
    }

    public void setLoginTimeRoleMsg(String loginTimeRoleMsg) {
        this.loginTimeRoleMsg = loginTimeRoleMsg;
    }

    @Override
    public void setServletRequest(HttpServletRequest request) {
        this.request = request;
    }

    public HttpServletRequest getServletRequest() {
        return this.request;
    }
    
    public String getBasicBtnClicked() {
        return basicBtnClicked;
    }

    public void setBasicBtnClicked(String basicBtnClicked) {
        this.basicBtnClicked = basicBtnClicked;
    }
    
    public long getRecordCount() {
	return recordCount;
    }
        
    public void setRecordCount(long recordCount) {
	this.recordCount = recordCount; 
    }
    
    private List<String> initSearchTypeList (List<String> inSearchTypeList){
        inSearchTypeList = new ArrayList<>();        
        inSearchTypeList.add("CCSF");
        inSearchTypeList.add("IAC");
        inSearchTypeList.add("Shipper");
        inSearchTypeList.add("Subject Company");
        inSearchTypeList.add("Subject Individual");
        
        return inSearchTypeList;
    }
    
    public List<Map> getCcsfListMap() {
        return ccsfListMap;
    }

    public void setCcsfListMap(List<Map> ccsfListMap) {
        this.ccsfListMap = ccsfListMap;
    }
    
    public List<Map> getCcsfList() {
        return ccsfList;
    }

    public void setCcsfList(List<Map> ccsfList) {
        this.ccsfList = ccsfList;
    }
    
    public String getPagerOffset() {
        return pagerOffset;
    }

    public void setPagerOffset(String pagerOffset) {
        this.pagerOffset = pagerOffset;
    }       
    
    
    List<Map> convertToCcsfListMap(List<Map> theCcsfList){
        int starting_idx=0;

        if (request.getParameter("pager.offset") != null) {
            starting_idx = Integer.parseInt((String)request.getParameter("pager.offset"));
        }
        
        logger.info(starting_idx + ":-----starting_idx - pageSize---:" + pageSize + " listSize:" + theCcsfList.size());

        return theCcsfList.subList(starting_idx, Math.min(starting_idx + pageSize, theCcsfList.size()));
    }
    
    
    public void setNoOfCcsfRecordsToLoad(int noOfCcsfRecordsToLoad){
        this.noOfCcsfRecordsToLoad = noOfCcsfRecordsToLoad;
    }

    public int getNoOfCcsfRecordsToLoad() {
        return noOfCcsfRecordsToLoad;
    }       
    
	public void setNoOfCcsfRecordsToLoadStr(String noOfCcsfRecordsToLoadStr){
        this.noOfCcsfRecordsToLoadStr = noOfCcsfRecordsToLoadStr;
    }

    public String getNoOfCcsfRecordsToLoadStr() {
        return noOfCcsfRecordsToLoadStr;
    } 
	
    public String getProcess() {
        return process;
    }

    public void setProcess(String process) {
        this.process = process;
    }
    
    public void setHdnProcess(String hdnProcess) {
        this.hdnProcess = hdnProcess;
    }

    public String getHdnProcess() {
        if (hdnProcess != null) return hdnProcess.trim();
            return hdnProcess;
    }
    	
	
		
    public List<Map> removeBadCcsfRec(List<Map> ccsfListMap) {
        List<Map> newCcsfListMap = new ArrayList();
        Map ccsfMap = new HashMap();
        Map map = new HashMap();
        int counter=0;
        
        Iterator<Map>  itrList = ccsfListMap.iterator();
        while (itrList.hasNext()) {
            ccsfMap = (Map)itrList.next();            
			if ((ccsfMap.get("iacNumber").equals("") || ccsfMap.get("iacNumber")== null) && 
                    (ccsfMap.get("staAuthorizationKey").equals("") || ccsfMap.get("staAuthorizationKey") == null)){		
                counter = counter + 1;
            }
            else {
                map = new HashMap();
                map.put("facilityName", ccsfMap.get("facilityName"));
                map.put("type", ccsfMap.get("type"));
                map.put("iacNumber", ccsfMap.get("iacNumber"));
                map.put("ccsfStatus", ccsfMap.get("ccsfStatus"));
                map.put("certificationNumber", ccsfMap.get("certificationNumber"));
                map.put("staAuthorizationKey", ccsfMap.get("staAuthorizationKey"));
                newCcsfListMap.add(map);
            }  
        }
        
        return newCcsfListMap;
    }
    
    private String convertMapListToJsonString(List<Map> list) {

	JSONArray ja = new JSONArray();
        JSONObject jo = null;
	String dataStr = null;
        dataStr = new JSONArray().toString();
	
        try {
            if (null != list && !list.isEmpty()) {

                for (Map<String, String> map : list) {
                    jo = new JSONObject();
                    for (Map.Entry<String, String> entry : map.entrySet()) {
                        jo.put(entry.getKey(), entry.getValue());
                    }
                    ja.put (jo);
                }
                dataStr = ja.toString();                
            }
        } catch(Exception e) {
          logger.error ("Exception JSON conversion" + e);
        }
        return dataStr;

    }
}
