/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ctu.tsa.fas.expandedsearch.common;
import java.io.Serializable;
import java.util.Comparator;

import org.apache.log4j.Logger;
import com.ctu.tsa.fas.expandedsearch.model.CcsfDirEmpModel;

/**
 *
 * @author Binh.Nguyen
 */
public class CcsfDirEmpComparator implements Comparator<CcsfDirEmpModel>, Serializable{
    private static final long serialVersionUID = 11L;

    private Logger logger = Logger.getLogger(CcsfDirEmpComparator.class);
    private boolean ascendingDirEmp;
    private String colName;
    
    public CcsfDirEmpComparator(String colName, boolean ascendingDirEmp) {
	this.ascendingDirEmp = ascendingDirEmp;
	this.colName = colName;
    }
    
    @SuppressWarnings("unchecked")
    public int compare(CcsfDirEmpModel o1, CcsfDirEmpModel o2) {
        int result = 0;
        
      try {
            Object value1 = null;
            Object value2 = null;
            
        if (colName.equalsIgnoreCase("staId")) {
		value1 = o1.getStaId();
		value2 = o2.getStaId();
        } else if (colName.equalsIgnoreCase("firstName")) {
		value1 = o1.getFirstName();
		value2 = o2.getFirstName();
        } else if (colName.equalsIgnoreCase("lastName")) {
		value1 = o1.getLastName();
		value2 = o2.getLastName();
        } else if (colName.equalsIgnoreCase("creationDate")) {
		value1 = o1.getCreationDate();
		value2 = o2.getCreationDate();	
        } else if (colName.equalsIgnoreCase("issuedOnDate")) {
		value1 = o1.getIssuedOnDate();
		value2 = o2.getIssuedOnDate();	   
  		} else if (colName.equalsIgnoreCase("expiresOnDate")) {
		value1 = o1.getExpiresOnDate();
		value2 = o2.getExpiresOnDate();	
		} else if (colName.equalsIgnoreCase("status")) {
		value1 = o1.getStatus();
		value2 = o2.getStatus();	
		} else if (colName.equalsIgnoreCase("staStatus")) {		
		value1 = o1.getStaStatus();
		value2 = o2.getStaStatus();	
        } else {
		logger.warn("Could not map " + colName + " to class attribute");
        }
            
        // Null is lesser than anything else.
        if ((value1 == null) && (value2 == null)) {
		       result = 0;
        } else if ((value1 == null) && (value2 != null)) {
		       result = -1;
        } else if ((value1 != null) && (value2 == null)) {
		       result = 1;           
        } else if (value1 instanceof Comparable) {
		    // the attribute values are Comparable, we have hit the JackPot.  We have absolutely nothing intelligent to do
		      @SuppressWarnings("rawtypes")
		      Comparable comp1 = (Comparable) value1;
		      @SuppressWarnings("rawtypes")
		      Comparable comp2 = (Comparable) value2;
		      result = comp1.compareTo(comp2);
        } else {
		       logger.warn("Dont know how to sort by " + colName);
        }

        if (!ascendingDirEmp) {
		result = 0 - result;
        }
      }
      catch (Exception ex) {
            //ex.printStackTrace();
            logger.error("Exception : " + ex.getMessage());
	 }
        return result;
    }
}
