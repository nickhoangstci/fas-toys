/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ctu.tsa.fas.expandedsearch.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

/**
 *
 * @author Binh.Nguyen
 */
public class SubjectCompanyStationsModel implements Serializable{
    private static final long serialVersionUID = -8767337899673261248L;
    private String firstName;
	private String middleName;
	private String lastName;
	private String emailAddress;
	private String workPhoneNumber;
	private String h24HourPhoneNumber;
		
    public SubjectCompanyStationsModel() {
    }
        
    public SubjectCompanyStationsModel(String firstName, String middleName, String lastName, String emailAddress, String workPhoneNumber, String h24HourPhoneNumber) {
		this.firstName = firstName;        
		this.middleName = middleName;       
		this.lastName = lastName;
		this.emailAddress = emailAddress;
		this.workPhoneNumber = workPhoneNumber;
		this.h24HourPhoneNumber = h24HourPhoneNumber;
    }
    
    public void setFirstName (String firstName) {
		this.firstName = firstName; 
    }	
	
	public void setMiddleName (String middleName) {
		this.middleName = middleName; 
    }
	
	public void setLastName (String lastName) {
		this.lastName = lastName; 
    }
	
	public void setEmailAddress (String emailAddress) {
		this.emailAddress = emailAddress; 
    }
	
    public void setWorkPhoneNumber(String workPhoneNumber) {
    	this.workPhoneNumber = workPhoneNumber; 
    }
	
	public void setH24HourPhoneNumber (String h24HourPhoneNumber) {
		this.h24HourPhoneNumber = h24HourPhoneNumber; 
    }
	
	public String getFirstName () {
		return (this.firstName); 
    }	
	
	public String getMiddleName () {
		return (this.middleName); 
    }
	
	public String getLastName () {
		return (this.lastName); 
    }
	
	public String getEmailAddress () {
		return (this.emailAddress); 
    }
	
	public String getWorkPhoneNumber () {
		return (this.workPhoneNumber); 
    }
	
	public String getH24HourPhoneNumber () {
		return (this.h24HourPhoneNumber); 
    }
	
    public String toString () {

	String sep = System.getProperty("line.separator");

	StringBuffer buffer = new StringBuffer();
	buffer.append(sep);		
	buffer.append("firstName = ");
	buffer.append(firstName);
	buffer.append(sep);	
	buffer.append("middleName = ");
	buffer.append(middleName);
	buffer.append(sep);
	buffer.append("lastName = ");
	buffer.append(lastName);
	buffer.append(sep);
	buffer.append("emailAddress = ");
	buffer.append(emailAddress);
	buffer.append(sep); 
	buffer.append("workPhoneNumber = ");
	buffer.append(workPhoneNumber);
	buffer.append(sep); 
	buffer.append("h24HourPhoneNumber = ");
	buffer.append(h24HourPhoneNumber);
	buffer.append(sep); 
	
	return buffer.toString();
    }
}
