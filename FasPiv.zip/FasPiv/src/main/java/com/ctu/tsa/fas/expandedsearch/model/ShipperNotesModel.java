/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ctu.tsa.fas.expandedsearch.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

/**
 *
 * @author Binh.Nguyen
 */
public class ShipperNotesModel implements Serializable{
    private static final long serialVersionUID = -8767337899673261248L;
    private String notes;
	private String dateEntered;
	private String email;
	private String createdByProcess;
	private String previousStatus;
	private String shipperStatus;
	private String noteType;	
		
    public ShipperNotesModel() {
    }
        
    public ShipperNotesModel(String notes, String dateEntered, String email, String createdByProcess,
	     String previousStatus, String shipperStatus, String noteType) {
		this.notes = notes;        
		this.dateEntered = dateEntered;       
		this.email = email;
		this.createdByProcess = createdByProcess;
		this.previousStatus = previousStatus;
		this.shipperStatus = shipperStatus;
		this.noteType = noteType;		
    }
    
    public void setNotes (String notes) {
		this.notes = notes; 
    }
	
	public void setDateEntered (String dateEntered) {
		this.dateEntered = dateEntered; 
    }
	
    public void setEmail(String email) {
		this.email = email; 
    }
	
	public void setCreatedByProcess (String createdByProcess) {
		this.createdByProcess = createdByProcess; 
    }
	
	public void setPreviousStatus (String previousStatus) {
		this.previousStatus = previousStatus; 
    }
	
	public void setShipperStatus (String shipperStatus) {
		this.shipperStatus = shipperStatus; 
    }
	
    public void setNoteType (String noteType) {
		this.noteType = noteType; 
    }	
	
	public String getNotes () {
		return (this.notes); 
    }
	
	public String getDateEntered () {
    	return (this.dateEntered); 
    }

    public String getEmail () {
        return (this.email); 
    }
	
	public String getCreatedByProcess () {
		return (this.createdByProcess); 
    }
	
	public String getPreviousStatus () {
		return (this.previousStatus); 
    }
	
	public String getShipperStatus () {
		return (this.shipperStatus); 
    }
	
	public String getNoteType () {
		return (this.noteType); 
    }
		
    public String toString () {

	String sep = System.getProperty("line.separator");

	StringBuffer buffer = new StringBuffer();
	buffer.append(sep);	
    buffer.append("notes= ");
	buffer.append(notes);
	buffer.append(sep);
	buffer.append("dateEntered= ");
	buffer.append(dateEntered);
	buffer.append(sep);
	buffer.append("email= ");
	buffer.append(email);
	buffer.append(sep);
	buffer.append("createdByProcess= ");
	buffer.append(createdByProcess);
	buffer.append(sep);
	buffer.append("previousStatus= ");
	buffer.append(previousStatus);
	buffer.append(sep);
	buffer.append("shipperStatus= ");
	buffer.append(shipperStatus);
	buffer.append(sep);
	buffer.append("noteType= ");
	buffer.append(noteType);
	buffer.append(sep);	
	return buffer.toString();
    }
}
