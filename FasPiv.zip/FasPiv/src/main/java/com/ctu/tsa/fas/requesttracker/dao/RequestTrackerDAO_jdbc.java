/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.ctu.tsa.fas.requesttracker.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.ctu.tsa.fas.requesttracker.data.SubjectRegion;
import com.freightdesk.fdcommons.ConnectionUtil;

import java.util.List;
import java.util.ArrayList;
import org.apache.log4j.Logger;
/**
 *
 * @author Eswara.Somu
 */
public class RequestTrackerDAO_jdbc {
    
     
    protected Logger logger = Logger.getLogger(getClass());
    
    public List<SubjectRegion> getSubjectRegionList() throws SQLException
	{
		String query = "select SUBJECTREGIONID, REGIONNAME, DESCRIPTION, CREATEUSERID, \n"
                               +" LASTUPDATEUSERID, CREATETIMESTAMP, LASTUPDATETIMESTAMP "
                               + "from FD.ctusubjectregion  ORDER BY SUBJECTREGIONID";
                
		Connection        connection   = null;
		PreparedStatement pStmt        = null;
		ResultSet         rs           = null;
		List<SubjectRegion> regionList = new ArrayList<SubjectRegion>();
		
		try {
			
			connection = getConnection();
			pStmt = connection.prepareStatement(query);
			for (rs = pStmt.executeQuery(); 
                                rs.next();) {
								logger.debug(rs.getInt(1)+ " :dao subject region  :  "+ rs.getString(2));                               			
			}
		} catch (SQLException sqEx) {
			
			throw sqEx;
		} finally {
			ConnectionUtil.closeResources(connection, pStmt, rs);
		}
		return regionList;
	}
    
     /**
     * Gets a connection to the database.
     *
     * If the dataSource is null, it looks up the dataSource 
     * again, otherwise it gets a connection from the dataSource.
     *
     * @return Connection
     */
    protected Connection getConnection()
        throws SQLException
    {        
		return ConnectionUtil.getConnection();		
    }
}
