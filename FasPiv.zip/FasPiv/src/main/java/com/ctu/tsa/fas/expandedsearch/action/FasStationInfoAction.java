/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ctu.tsa.fas.expandedsearch.action;

/**
 *
 * @author kevin.tsou
 */

import javax.servlet.http.HttpServletRequest;
import com.freightdesk.fdcommons.Credentials;
import com.freightdesk.fdcommons.SessionKey;
import com.freightdesk.fdcommons.SessionStore;
import javax.servlet.http.HttpSession;
import com.opensymphony.xwork2.ActionSupport;
import org.apache.log4j.Logger;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.ServletActionContext;
import crt.com.freightdesk.fdfolio.common.IncludesUtil;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import com.ctu.tsa.fas.expandedsearch.dao.ExpandedSearchStationDAO;
import com.ctu.tsa.fas.expandedsearch.model.StationDetails; 
import java.util.Map;
import java.util.HashMap;
import org.apache.commons.lang3.StringEscapeUtils;


public class FasStationInfoAction extends ActionSupport implements ServletRequestAware{
    
    protected Logger logger = Logger.getLogger(getClass());
    HttpServletRequest request = ServletActionContext.getRequest();    
    private String loginTimeRoleMsg;
    private String iacName;
    private String stationName;
    private String iacId;
    private String airportName;
    private String isActive;
    private String address1;
    private String address2;
    private String city;
    private String state;
    private String zipPostalCode;
    private String country;
    private String comments;
    private String partyId;
    private String objectId;
    private List<Map> stationList;
    private List<Map> airportList;
    private String status;
    private List<Map> contactsListMap;
    private Map contactsMap;
    private List<Map> namesListMap;
    private Map namesMap;
	
	ExpandedSearchStationDAO dao = new ExpandedSearchStationDAO();
    List<StationDetails> stationDetails = new ArrayList<StationDetails>();
	List<Map> stationMap = new ArrayList();
	Map theStationMap = new HashMap();
    Map theAirportMap = new HashMap();
    private int listSize = 0;
    private int airportListSize = 0;
    private String airportNameStr = "";
    private String airportAbbrStr = "";   
    private String processStations;
    private String hdnProcessStations = "";	
    
    @Override
    public String execute()throws Exception {
        request = ServletActionContext.getRequest();
        HttpSession session = request.getSession(false);
        SessionStore store = SessionStore.getInstance(session);
        Credentials credentials = (Credentials) store.get(SessionKey.CREDENTIALS);
        
        logger.info("execute(): begin");
        loginTimeRoleMsg = IncludesUtil.getWelcomeMsg(credentials)+ "<br>" + IncludesUtil.getExpireMsg(credentials);              
        		        
        setStationList(dao.getStationInfoByPartyId(Long.parseLong(getPartyId()), Long.parseLong(getObjectId())));        
        
        if ((stationList == null) || (stationList.isEmpty())){
            listSize = 0;
        } else {
            listSize = stationList.size();
        }                     			
        
        if (listSize > 0) {	            
            theStationMap = stationList.get(0);
            
            setPartyId((String)theStationMap.get("partyId"));
            setStationName((String)theStationMap.get("partyName"));
            setIsActive((String)theStationMap.get("activeFlag"));
            setComments((String)theStationMap.get("comments"));
            setAddress1((String)theStationMap.get("address1"));
            setAddress2((String)theStationMap.get("address2"));
            setCity((String)theStationMap.get("city"));
            setState((String)theStationMap.get("state"));
            setZipPostalCode((String)theStationMap.get("postalCode"));
            setCountry((String)theStationMap.get("country"));
            setIacName((String)theStationMap.get("iacName"));
            setIacId((String)theStationMap.get("approvalNbr"));
            setStatus((String)theStationMap.get("status"));
        }
               
        setAirportList(dao.getAirportInfoByPartyId(Long.parseLong(getPartyId())));       
        
        if ((airportList == null) || (airportList.isEmpty())){
            airportListSize = 0;
        } else {
            airportListSize = airportList.size();
        }
        
        if (airportListSize > 0) {	            
            theAirportMap = airportList.get(0);
            
            airportNameStr = ((String)theAirportMap.get("airportName"));
            airportAbbrStr = ((String)theAirportMap.get("airportAbbr"));
            setAirportName (airportAbbrStr + " - " + airportNameStr);
        }
        
        setContactsListMap(dao.getContactsByPartyId(Long.parseLong(getPartyId())));
        setContactsMap(contactsListMap.get(0));
        
        setNamesListMap(dao.getNamesByPartyId(Long.parseLong(getPartyId())));
        setNamesMap(namesListMap.get(0));
        
        contactsMap.put("firstName", namesMap.get("firstName"));
        contactsMap.put("middleName", namesMap.get("middleName"));
        contactsMap.put("lastName", namesMap.get("lastName"));
        
        contactsListMap = new ArrayList();
        contactsListMap.add(contactsMap);
        session.setAttribute("STA_CONTACT_LIST", IncludesUtil.convertMapListToJsonString(contactsListMap));        							        			
        
        return "displayStationInfo";
    }    	   	
	
    @Override
    public void setServletRequest(HttpServletRequest request) {
        this.request = request;
    }

    public HttpServletRequest getServletRequest() {
        return this.request;
    }
    
    public String getIacId() {
        if (iacId == null){
            this.iacId = "";
	}	
	return StringEscapeUtils.unescapeHtml4(iacId);
    }
    
    public void setIacId(String iacId) {
	this.iacId = iacId;
    }  
    
    public String getObjectId() {
        if (objectId == null){
            this.objectId = "";
	}	
	return StringEscapeUtils.unescapeHtml4(objectId);
    }
    
    public void setObjectId(String objectId) {
	this.objectId = objectId;
    }  
    
    public String getIacName() {
        if (iacName == null){
            this.iacName = "";
	    }
        return (iacName);
    }
    
    public void setIacName(String  iacName) {
	this.iacName =  iacName;
    }     
    
    public String getStationName() {
        if (stationName == null){
            this.stationName = "";
	}
		
	return StringEscapeUtils.unescapeHtml4(stationName);
    }
    
    public void setStationName(String  stationName) {
	this.stationName =  stationName;
    }  
    
    public String getAirportName() {
        if (airportName == null){
            this.airportName = "";
	}
		
	return StringEscapeUtils.unescapeHtml4(airportName);
    }
    
    public void setAirportName(String  airportName) {
	this.airportName =  airportName;
    }
    
    public String getIsActive() {
        if (isActive == null){
            this.isActive = "";
	}
		
	return StringEscapeUtils.unescapeHtml4(isActive);
    }
    
    public void setIsActive(String  isActive) {
	this.isActive =  isActive;
    }
    
    public String getAddress1() {
        if (address1 == null){
            this.address1 = "";
	}
	
        return StringEscapeUtils.unescapeHtml4(address1);	
    }

    public void setAddress1(String address1) {
        this.address1 = address1;
    } 
    
    public String getAddress2() {
        if (address2 == null){
            this.address2 = "";
	}
	
        return StringEscapeUtils.unescapeHtml4(address2);	
    }

    public void setAddress2(String address2) {
        this.address2 = address2;
    } 
    
    public String getCity() {
        if (city == null){
            this.city = "";
	}
	
        return StringEscapeUtils.unescapeHtml4(city);	
    }
    
    public void setCity(String city) {
        this.city = city;
    } 
    
    public String getState() {
        if (state == null){
            this.state = "";
	}
	
        return StringEscapeUtils.unescapeHtml4(state);	
    }
    
    public void setState(String state) {
        this.state = state;
    } 
    
    public String getZipPostalCode() {
        if (zipPostalCode == null){
            this.zipPostalCode = "";
	}
	
        return StringEscapeUtils.unescapeHtml4(zipPostalCode);	
    }
    
    public void setZipPostalCode(String zipPostalCode) {
        this.zipPostalCode = zipPostalCode;
    } 
    
    public String getCountry() {
        if (country == null){
            this.country = "";
	}
	
        return StringEscapeUtils.unescapeHtml4(country);	
    }
    
    public void setCountry(String country) {
        this.country = country;
    } 
    
    public String getComments() {
        if (comments == null){
            this.comments = "";
	}
	
        return StringEscapeUtils.unescapeHtml4(comments);	
    }
    
    public void setComments(String comments) {
        this.comments = comments;
    } 
    
    public String getPartyId() {
        if (partyId == null){
            this.partyId = "";
	}
	
        return StringEscapeUtils.unescapeHtml4(partyId);	
    }
    
    public void setPartyId(String partyId) {
        this.partyId = partyId;
    } 
    
    public String getStatus() {
        if (status == null){
            this.status = "";
	}
	
        return StringEscapeUtils.unescapeHtml4(status);	
    }
    
    public void setStatus(String status) {
        this.status = status;
    } 
    
    public void setStationList(List<Map> stationList) {
        this.stationList = stationList;
    }
    
    public List<Map> getStationList() {
        return stationList;
    } 
    
    public void setAirportList(List<Map> airportList) {
        this.airportList = airportList;
    }
    
    public List<Map> getAirportList() {
        return airportList;
    } 
    
    public void setContactsListMap(List<Map> contactsListMap) {
        this.contactsListMap = contactsListMap;
    }
    
    public List<Map> getContactsListMap() {
        return contactsListMap;
    } 
    
    public void setNamesListMap(List<Map> namesListMap) {
        this.namesListMap = namesListMap;
    }
    
    public List<Map> getNamesListMap() {
        return namesListMap;
    } 
    
    public void setContactsMap(Map contactsMap) {
        this.contactsMap = contactsMap;
    }
    
    public Map getContactsMap() {
        return contactsMap;
    } 
    
    public void setNamesMap(Map namesMap) {
        this.namesMap = namesMap;
    }
    
    public Map getNamesMap() {
        return namesMap;
    } 
    
    public String getLoginTimeRoleMsg() {
        return loginTimeRoleMsg;
    }

    public void setLoginTimeRoleMsg(String loginTimeRoleMsg) {
        this.loginTimeRoleMsg = loginTimeRoleMsg;
    }
		
	
	public void setHdnProcessStations(String hdnProcessStations) {
        this.hdnProcessStations = hdnProcessStations;
    }

    public String getHdnProcessStations() {	    
        if (hdnProcessStations == null) {		    
		    this.hdnProcessStations = "";
	    }
		return hdnProcessStations.trim();
    }
	
	public void setProcessStations(String processStations) {
        this.processStations = processStations;
    }
    
	public String getProcessStations() { 
    if (processStations == null){
            this.processStations = "";
	}
	
    return StringEscapeUtils.unescapeHtml4(processStations);		
    }
	
	public List<Map> getStationMap() {
        return stationMap;
    }
	
	public void setStationMap(List<Map> stationMap) {
        this.stationMap = stationMap;
    }	
}
