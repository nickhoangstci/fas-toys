/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ctu.tsa.fas.requesttracker.action;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.ctu.tsa.fas.delegation.RequestTrackerDelegation;
import com.ctu.tsa.fas.requesttracker.dao.RequestTrackerDAO;
import com.ctu.tsa.fas.requesttracker.data.RequestTrackerData;
import com.ctu.tsa.fas.requesttracker.model.Request;

import org.json.JSONObject;
import org.json.JSONArray;

import com.opensymphony.xwork2.Action;

import org.apache.log4j.Logger;
import org.apache.struts2.ServletActionContext;

public class ExportAction implements Action {


    private String message = "";
    private String exportTypeValue;
    private String exportType;

	protected Logger logger = Logger.getLogger(getClass());

    public String execute() {
	    logger.info(exportTypeValue + "****** ExportAction  execute  Request Type:  "+ exportType);
        
        if (null == exportType) {
            return null;
        } else {
            String params[] = exportType.split("&");
            String fieldNames = "";
            
            for (int i=0; i<params.length; i++) {
            	if (i == 0) {  
            		exportType = params[0].split("=")[1];
            	}
            	else {
            		fieldNames += params[i].split("=")[0] + ",";   
            	}
            }
            
            if (!fieldNames.isEmpty()) {
            	fieldNames = fieldNames.substring(0, fieldNames.length()-1);    // remove the last comma
            	logger.info (exportType + ":" + fieldNames);
            }
            
            HttpSession session = ServletActionContext.getRequest().getSession();
            
            // get stored search parameters for export
            String searchStatus = (String) session.getAttribute("SV_searchStatus");
            String searchData = (String) session.getAttribute("SV_searchData");

            logger.info(fieldNames + ":" +searchStatus+ ":" + searchData);  // pass these to DAO
            
            RequestTrackerDAO dao = RequestTrackerDAO.getInstance();
            String requestList;
            try {
				if ("csv".equals(exportType)) {
                    requestList = dao.getCsvRequestsByFields(fieldNames, searchStatus, searchData);
				}
				else {
                    requestList = dao.getXmlRequestsByFields(fieldNames, searchStatus, searchData);
				}

                if (null != requestList && requestList.length () > 0) {
                     message = requestList ;                     
                }
            } catch (Exception e) {
                logger.error("*** Export Action EXCEPTION:  "+ e.getMessage());               
            }
        }       
        
        return SUCCESS;
    }


    public String getExportTypeValue() {
        return exportTypeValue;
    }

    public void setExportTypeValue(String exportTypeValue) {
        this.exportTypeValue = exportTypeValue;
    }


    public String getExportType() {
        return exportType;
    }

    public void setExportType(String exportType) {
        this.exportType = exportType;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
    
    
    
}
