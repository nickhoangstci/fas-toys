/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ctu.tsa.fas.expandedsearch.dao;

import com.ctu.tsa.fas.expandedsearch.model.SubjectIndividualDetails;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import oracle.jdbc.OracleTypes;
import oracle.jdbc.pool.OracleDataSource;

import org.apache.log4j.Logger;
import org.hibernate.Session;

/*
 * @author Binh.Nguyen
 */
public class ExpandedSearchStatSubjectIndividualDAO {

	private static ExpandedSearchStatSubjectIndividualDAO instance = null;

	protected Logger logger = Logger.getLogger(getClass());

	public ExpandedSearchStatSubjectIndividualDAO() {

	}

	public static ExpandedSearchStatSubjectIndividualDAO getInstance() {
		if (instance == null) {
			instance = new ExpandedSearchStatSubjectIndividualDAO();
		}
		return instance;
	}

	public class MyStatSqlResults {
		List<Map> sListMap;
		long totalCount;

		public List<Map> getSListMap() {
			return sListMap;
		}

		public void setSListMap(List<Map> sListMap) {
			this.sListMap = sListMap;
		}

		public long getTotalCount() {
			return totalCount;
		}

		public void setTotalCount(long totalCount) {
			this.totalCount = totalCount;
		}
	}
        
        public ExpandedSearchStatSubjectIndividualDAO.MyStatSqlResults getPartyNameByAuthKey(String authKey) throws Exception {

		logger.info("ExpandedSujectIndividualSearchDAO - authKey: " + authKey);
		OracleDataSource ods = null;
		Connection connection = null;
		String queryStr;
		String searchString = null;
		ResultSet sResultSet = null;

		ExpandedSearchStatSubjectIndividualDAO.MyStatSqlResults sqlResults = new ExpandedSearchStatSubjectIndividualDAO.MyStatSqlResults();
		int count;

		try {
			connection = com.freightdesk.fdcommons.ConnectionUtil.getConnectionStat();
		} catch (Exception ex) {
			logger.error("ods.getConnection() failed");
			throw (ex);
		}

		List<SubjectIndividualDetails> subjectIndividualDetails = new ArrayList<SubjectIndividualDetails>();
		Session session = null;

		String stProcName = "xxtsa.FAS_STAT_SUBJECT_INDIVIDUAL.SEL_PARTY_NAME_BY_AUTH_KEY";
		String tCallableStmtStr = "{call " + stProcName + "(?,?)}";

		CallableStatement eStatement = null;
        boolean eReturnCode;
		List<Map> esListMap = null;
		try {
			eStatement = connection.prepareCall(tCallableStmtStr);
			eStatement.setString(1, authKey);
		    eStatement.registerOutParameter(2, OracleTypes.CURSOR);
			eReturnCode = eStatement.execute();
			sResultSet = (ResultSet) eStatement.getObject(2);
			esListMap = convertResultSetToListMapForAuthKeySearch(sResultSet);
			sqlResults.sListMap = esListMap;
			sqlResults.totalCount = 0;
		} catch (Exception ex) {
			logger.error("getSubjectCompanyConnection failed" + ex.getMessage());
			throw (ex);
		} finally {
            com.freightdesk.fdcommons.ConnectionUtil.closeResources(connection,	eStatement, sResultSet);                       
        }
		
		return sqlResults;
	}

	private List<Map> convertResultSetToListMapForAuthKeySearch(
			ResultSet searchResultSet) throws Exception {

		List<Map> listMap = new ArrayList();
		Map map = new HashMap();

		while (searchResultSet.next()) {

			map = new HashMap();
			if (searchResultSet.getString("PARTY_NAME") == null) {
				map.put("partyName", "");
			} else {
				map.put("partyName", searchResultSet.getString("PARTY_NAME"));
			}

			if (searchResultSet.getString("STAAUTHORIZATIONKEY") == null) {
				map.put("staAuthorizationKey", "");
			} else {
				map.put("staAuthorizationKey",
						searchResultSet.getString("STAAUTHORIZATIONKEY"));
			}

			if (searchResultSet.getString("PARTY_ID") == null) {
				map.put("partyId", "");
			} else {
				map.put("partyId", searchResultSet.getString("PARTY_ID"));
			}

			listMap.add(map);
		}
		return listMap;
	}

	private List<Map> convertResultSetToListMapForSummaryPage(
			ResultSet searchResultSet) throws Exception {

		List<Map> listMap = new ArrayList();
		Map map = new HashMap();
		String str = "";

		while (searchResultSet.next()) {

			map = new HashMap();
			if (searchResultSet.getString("STA_ID") == null) {
				map.put("subjectIndividualStaId", "");
			} else {
				map.put("subjectIndividualStaId",
						searchResultSet.getString("STA_ID"));
			}

			if (searchResultSet.getString("LAST_NAME") == null) {
				map.put("subjectIndividualLastName", "");
			} else {
				map.put("subjectIndividualLastName",
						searchResultSet.getString("LAST_NAME"));
			}

			if (searchResultSet.getString("FIRST_NAME") == null) {
				map.put("subjectIndividualFirstName", "");
			} else {
				map.put("subjectIndividualFirstName",
						searchResultSet.getString("FIRST_NAME"));
			}
			
			if (searchResultSet.getString("CREATION_DATE") == null) {
				map.put("subjectIndividualCreationDate", "");
			} else {
				str = searchResultSet.getString("CREATION_DATE");
				map.put("subjectIndividualCreationDate", str.substring(0, str.indexOf(' ')));
			}
			
			if (searchResultSet.getString("EXPIRATION_DATE") == null) {
				map.put("subjectIndividualExpirationDate", "");
			} else {
				str = searchResultSet.getString("EXPIRATION_DATE");
				map.put("subjectIndividualExpirationDate", str.substring(0, str.indexOf(' ')));
			}

			if (searchResultSet.getString("RECORD_STATUS") == null) {
				map.put("subjectIndividualRecordStatus", "");
			} else {
				if (searchResultSet.getString("RECORD_STATUS")
						.equalsIgnoreCase("A")) {
					map.put("subjectIndividualRecordStatus", "Active");
				} else if (searchResultSet.getString("RECORD_STATUS")
						.equalsIgnoreCase("I")) {
					map.put("subjectIndividualRecordStatus", "Inactive");
				}
			}

			if (searchResultSet.getString("STA_STATUS") == null) {
				map.put("subjectIndividualStaStatus", "");
				map.put("subjectIndividualIssuedDate", "");
			} else {
				if (searchResultSet.getString("STA_STATUS").equalsIgnoreCase(
						"STAAWAITINGPAYMNT")) {
                                        map.put("subjectIndividualStaStatus", "Awaiting Payment");
					map.put("subjectIndividualIssuedDate", "");
				} else if (searchResultSet.getString("STA_STATUS")
						.equalsIgnoreCase("STAERROR")) {
                                        map.put("subjectIndividualStaStatus", "STA Error");   
					map.put("subjectIndividualIssuedDate", "");
				} else if (searchResultSet.getString("STA_STATUS")
						.equalsIgnoreCase("STAERRORTTAC")) {
                                        map.put("subjectIndividualStaStatus", "STA Error"); 
					map.put("subjectIndividualIssuedDate", "");
				} else if (searchResultSet.getString("STA_STATUS")
						.equalsIgnoreCase("STADENIED")) {
                                        map.put("subjectIndividualStaStatus", "STA Denied"); 
					map.put("subjectIndividualIssuedDate", "");
				} else if (searchResultSet.getString("STA_STATUS")
						.equalsIgnoreCase("STAINPROGRESS")) {
                                        map.put("subjectIndividualStaStatus", "STA In Progress"); 
					map.put("subjectIndividualIssuedDate", "");
				} else if (searchResultSet.getString("STA_STATUS")
						.equalsIgnoreCase("STAPASSED")) {
                                        map.put("subjectIndividualStaStatus", "Passed");   										
					if (searchResultSet.getString("ISSUED_DATE") == null) {
				       map.put("subjectIndividualIssuedDate", "");
			        } else {
				        str = searchResultSet.getString("ISSUED_DATE");
				        map.put("subjectIndividualIssuedDate", str.substring(0, str.indexOf(' ')));
			        }
				} else if (searchResultSet.getString("STA_STATUS")
						.equalsIgnoreCase("PAYCNFRMD")) {
                                        map.put("subjectIndividualStaStatus", "Payment Confirmed");  
					map.put("subjectIndividualIssuedDate", "");
				} else if (searchResultSet.getString("STA_STATUS")
						.equalsIgnoreCase("STAINCOMPL")) {
                                        map.put("subjectIndividualStaStatus", "STA Incomplete"); 
					map.put("subjectIndividualIssuedDate", "");
                                }else if (searchResultSet.getString("STA_STATUS")
						.equalsIgnoreCase("STAEXPIRED")) {
                                        map.put("subjectIndividualStaStatus", "STA Expired"); 
					map.put("subjectIndividualIssuedDate", "");
                                } else if (searchResultSet.getString("STA_STATUS").equalsIgnoreCase("STAPENDINGAPPRVL")){
                                        map.put("subjectIndividualStaStatus", "STA Pending Approval"); 
					map.put("subjectIndividualIssuedDate", "");
				} else {
                                        map.put("subjectIndividualStaStatus", searchResultSet.getString("STA_STATUS")); 
					map.put("subjectIndividualIssuedDate", "");
                                }
			}

			listMap.add(map);

		}

		return listMap;
	}

    private List<Map> convertResultSetToListMapForDetailPage (ResultSet searchResultSet) throws Exception{

		List<Map> listMap = new ArrayList();
		Map map = new HashMap();

		while (searchResultSet.next()) {

			map = new HashMap();

			if (searchResultSet.getString("STA_ID") == null) {
				map.put("subjectIndividualStaId", "");
			} else {
				map.put("subjectIndividualStaId",
						searchResultSet.getString("STA_ID"));				
			}

			if (searchResultSet.getString("LAST_NAME") == null) {
				map.put("subjectIndividualLastName", "");
			} else {
                                map.put("subjectIndividualLastName", searchResultSet.getString("LAST_NAME"));				
			}

			if (searchResultSet.getString("FIRST_NAME") == null) {
				map.put("subjectIndividualFirstName", "");
			} else {
                                map.put("subjectIndividualFirstName", searchResultSet.getString("FIRST_NAME"));				
			}

			if (searchResultSet.getString("PERSON_MIDDLE_NAME") == null) {
				map.put("subjectIndividualMiddleName", "");
			} else {
                                map.put("subjectIndividualMiddleName", searchResultSet.getString("PERSON_MIDDLE_NAME"));				
			}

			if (searchResultSet.getString("PERSON_NAME_SUFFIX") == null) {
				map.put("subjectIndividualSuffix", "");
			} else {
                                map.put("subjectIndividualSuffix", searchResultSet.getString("PERSON_NAME_SUFFIX"));				
			}

			if (searchResultSet.getString("CREATION_DATE") == null) {
				map.put("subjectIndividualCreationDate", "");
			} else {
                                map.put("subjectIndividualCreationDate", searchResultSet.getString("CREATION_DATE"));				
			}

			if (searchResultSet.getString("EXPIRES_ON_DATE") == null) {
				map.put("subjectIndividualExpirationDate", "");
			} else {
                                map.put("subjectIndividualExpirationDate", searchResultSet.getString("EXPIRES_ON_DATE"));				
			}

			if (searchResultSet.getString("STATUS") == null) {
				map.put("subjectIndividualRecordStatus", "");
			} else {
				if (searchResultSet.getString("STATUS").equalsIgnoreCase("A")) {
					map.put("subjectIndividualRecordStatus", "Active");
                                } else if (searchResultSet.getString("STATUS").equalsIgnoreCase("I")){
					map.put("subjectIndividualRecordStatus", "Inactive");
				}
			}

			if (searchResultSet.getString("CURRENT_STATUS") == null) {
				map.put("subjectIndividualStaStatus", "");
				map.put("subjectIndividualIssuedDate", "");
			} else {
                if (searchResultSet.getString("CURRENT_STATUS").equalsIgnoreCase("STAAWAITINGPAYMNT")){
                                        map.put("subjectIndividualStaStatus", "Awaiting Payment");
					map.put("subjectIndividualIssuedDate", "");
                } else if (searchResultSet.getString("CURRENT_STATUS").equalsIgnoreCase("STAERROR")){
                                        map.put("subjectIndividualStaStatus", "STA Error");   
					map.put("subjectIndividualIssuedDate", "");
		        }  else if (searchResultSet.getString("CURRENT_STATUS").equalsIgnoreCase("STAERRORTTAC")){
                                        map.put("subjectIndividualStaStatus", "STA Error"); 
					map.put("subjectIndividualIssuedDate", "");
		        }  else if (searchResultSet.getString("CURRENT_STATUS").equalsIgnoreCase("STAINPROGRESS")){
                                        map.put("subjectIndividualStaStatus", "STA In Progress"); 
					map.put("subjectIndividualIssuedDate", "");
		        }  else if (searchResultSet.getString("CURRENT_STATUS").equalsIgnoreCase("STADENIED")){
                                        map.put("subjectIndividualStaStatus", "STA Denied"); 
					map.put("subjectIndividualIssuedDate", "");
		        } else if (searchResultSet.getString("CURRENT_STATUS").equalsIgnoreCase("STAPASSED")){
                                        map.put("subjectIndividualStaStatus", "Passed");   
					if (searchResultSet.getString("ISSUED_ON_DATE") == null) {
						map.put("subjectIndividualIssuedDate", "");
					} else {
                                                map.put("subjectIndividualIssuedDate", searchResultSet.getString("ISSUED_ON_DATE"));				
					}
		        }  else if (searchResultSet.getString("CURRENT_STATUS").equalsIgnoreCase("PAYCNFRMD")){
                                        map.put("subjectIndividualStaStatus", "Payment Confirmed");  
					map.put("subjectIndividualIssuedDate", "");
		        } else if (searchResultSet.getString("CURRENT_STATUS").equalsIgnoreCase("STAINCOMPL")){
                                        map.put("subjectIndividualStaStatus", "STA Incomplete"); 
					map.put("subjectIndividualIssuedDate", "");
		        } else if (searchResultSet.getString("CURRENT_STATUS").equalsIgnoreCase("STAEXPIRED")){
                                        map.put("subjectIndividualStaStatus", "STA Expired"); 
					map.put("subjectIndividualIssuedDate", "");
		        } else if (searchResultSet.getString("CURRENT_STATUS").equalsIgnoreCase("STAPENDINGAPPRVL")){
                                        map.put("subjectIndividualStaStatus", "STA Pending Approval"); 
					map.put("subjectIndividualIssuedDate", "");
			} else {
                                        map.put("subjectIndividualStaStatus", searchResultSet.getString("CURRENT_STATUS")); 
					map.put("subjectIndividualIssuedDate", "");
                        }
                            
		}

			if (searchResultSet.getString("KNOWN_AS") == null) {
				map.put("subjectIndividualAlias1", "");
			} else {
                map.put("subjectIndividualAlias1", searchResultSet.getString("KNOWN_AS"));				
			}

			if (searchResultSet.getString("KNOWN_AS2") == null) {
				map.put("subjectIndividualAlias2", "");
			} else {
                map.put("subjectIndividualAlias2", searchResultSet.getString("KNOWN_AS2"));				
			}

			if (searchResultSet.getString("KNOWN_AS3") == null) {
				map.put("subjectIndividualAlias3", "");
			} else {
                map.put("subjectIndividualAlias3", searchResultSet.getString("KNOWN_AS3"));				
			}

			if (searchResultSet.getString("STA_ADDRESS") == null) {
				map.put("subjectIndividualAddress1", "");
			} else {
                map.put("subjectIndividualAddress1", searchResultSet.getString("STA_ADDRESS"));				
			}

			if (searchResultSet.getString("ADDRESS2") == null) {
				map.put("subjectIndividualAddress2", "");
			} else {
                map.put("subjectIndividualAddress2", searchResultSet.getString("ADDRESS2"));				
			}

			if (searchResultSet.getString("STA_CITY") == null) {
				map.put("subjectIndividualCity", "");
			} else {
                map.put("subjectIndividualCity", searchResultSet.getString("STA_CITY"));				
			}

			if (searchResultSet.getString("STA_STATE") == null) {
				map.put("subjectIndividualState", "");
			} else {
                map.put("subjectIndividualState", searchResultSet.getString("STA_STATE"));				
			}

			if (searchResultSet.getString("STA_POSTAL_CODE") == null) {
				map.put("subjectIndividualZipPostalCode", "");
			} else {
                map.put("subjectIndividualZipPostalCode", searchResultSet.getString("STA_POSTAL_CODE"));				
			}

			if (searchResultSet.getString("COUNTRY") == null) {
				map.put("subjectIndividualCountry", "");
			} else {
                map.put("subjectIndividualCountry", searchResultSet.getString("COUNTRY"));				
			}

			listMap.add(map);

		}

		return listMap;
	}
}
