/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ctu.tsa.fas.expandedsearch.common;
import java.io.Serializable;
import java.util.Comparator;

import org.apache.log4j.Logger;
import com.ctu.tsa.fas.expandedsearch.model.IacModel;

/**
 *
 * @author Kevin.Tsou
 */
public class IacComparator implements Comparator<IacModel>, Serializable{
    private static final long serialVersionUID = 11L;

    private Logger logger = Logger.getLogger(IacComparator.class);
    private boolean ascending;
    private String colName;
    
    public IacComparator(String colName, boolean ascending) {
	this.ascending = ascending;
	this.colName = colName;
    }
    
    @SuppressWarnings("unchecked")
    public int compare(IacModel o1, IacModel o2) {
        int result = 0;
        
        try {
            String value1 = null;
            String value2 = null;
            
            if (colName.equalsIgnoreCase("iacName")) {
				value1 = o1.getIacName();
				value2 = o2.getIacName();
            } else if (colName.equalsIgnoreCase("iacType")) {
				value1 = o1.getIacType();
                value2 = o2.getIacType();
            } else if (colName.equalsIgnoreCase("iacId")) {
				value1 = o1.getIacId();
				value2 = o2.getIacId();
            } else if (colName.equalsIgnoreCase("iacStatus")) {
				value1 = o1.getIacStatus();
				value2 = o2.getIacStatus();
            } else {
				logger.warn("Could not map " + colName + " to class attribute");
            }
            
            // Null is lesser than anything else.
            if (value1 == null && value2 == null) {
				result = 0;
            } else if (value1 == null && value2 != null) {
				result = -1;
            } else if (value1 != null && value2 == null) {
				result = 1;

            } else if (value1 instanceof Comparable) {
				// the attribute values are Comparable, we have hit the JackPot.  We have absolutely nothing intelligent to do
				@SuppressWarnings("rawtypes")
				Comparable comp1 = (Comparable) value1;
				@SuppressWarnings("rawtypes")
				Comparable comp2 = (Comparable) value2;
				result = comp1.compareTo(comp2);
            } else {
				logger.warn("Dont know how to sort by " + colName);
            }

            if (result == 0) {
				result = -1; // to help in table sort
            }

            if (!ascending) {
				result = 0 - result;
            }
        }
        catch (Exception ex) {
            //ex.printStackTrace();
            logger.error("Exception : " + ex.getMessage());
		}
        
        return result;
    }
}
