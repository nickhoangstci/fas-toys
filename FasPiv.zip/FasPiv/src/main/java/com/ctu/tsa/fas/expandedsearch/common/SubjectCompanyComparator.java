/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ctu.tsa.fas.expandedsearch.common;
import java.io.Serializable;
import java.util.Comparator;

import org.apache.log4j.Logger;
import com.ctu.tsa.fas.expandedsearch.model.SubjectCompanyModel;

/**
 *
 * @author Kevin.Tsou
 */
public class SubjectCompanyComparator implements Comparator<SubjectCompanyModel>, Serializable{
    private static final long serialVersionUID = 1L;

    private Logger logger = Logger.getLogger(SubjectCompanyComparator.class);
    private boolean ascending;
    private String colName;
    
    public SubjectCompanyComparator(String colName, boolean ascending) {
	this.ascending = ascending;
	this.colName = colName;
    }
    
    @SuppressWarnings("unchecked")
    public int compare(SubjectCompanyModel o1, SubjectCompanyModel o2) {
        int result = 0;
        
        try {
            Object value1 = null;
            Object value2 = null;
            
            if (colName.equalsIgnoreCase("subjectCompanyName")) {
		      value1 = o1.getSubjectCompanyName();
		      value2 = o2.getSubjectCompanyName();
            } else if (colName.equalsIgnoreCase("subjectCompanyType")) {
		      value1 = o1.getSubjectCompanyType();
                      value2 = o2.getSubjectCompanyType();
            } else if (colName.equalsIgnoreCase("subjectCompanyId")) {
		      value1 = o1.getSubjectCompanyId();
                      value2 = o2.getSubjectCompanyId();
            } else if (colName.equalsIgnoreCase("subjectCompanyState")) {
		      value1 = o1.getSubjectCompanyState();
		      value2 = o2.getSubjectCompanyState();
			} else if (colName.equalsIgnoreCase("subjectCompanyStatus")) {
		      value1 = o1.getSubjectCompanyStatus();
		      value2 = o2.getSubjectCompanyStatus();	           
            } else {
		      logger.warn("Could not map " + colName + " to class attribute");
            }
            
            // Null is lesser than anything else.
            if ((value1 == null) && (value2 == null)) {
		       result = 0;            
            } else if (value1 instanceof Comparable) {
		    // the attribute values are Comparable, we have hit the JackPot.  We have absolutely nothing intelligent to do
		      @SuppressWarnings("rawtypes")
		      Comparable comp1 = (Comparable) value1;
		      @SuppressWarnings("rawtypes")
		      Comparable comp2 = (Comparable) value2;
		      result = comp1.compareTo(comp2);
            } else {
		       logger.warn("Dont know how to sort by " + colName);
            }

            if (!ascending) {
		     result = 0 - result;
            }
        }
        catch (Exception ex) {
            logger.error("Exception : " + ex.getMessage());
	} 
	
    return result;
	
    }
}
