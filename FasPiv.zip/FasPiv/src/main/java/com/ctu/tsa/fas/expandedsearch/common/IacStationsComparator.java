/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ctu.tsa.fas.expandedsearch.common;
import java.io.Serializable;
import java.util.Comparator;

import org.apache.log4j.Logger;
import com.ctu.tsa.fas.expandedsearch.model.IacStationsModel;

/**
 *
 * @author Binh.Nguyen
 */
public class IacStationsComparator implements Comparator<IacStationsModel>, Serializable{
    private static final long serialVersionUID = 11L;

    private Logger logger = Logger.getLogger(IacStationsComparator.class);
    private boolean ascendingStations;
    private String colName;
    
    public IacStationsComparator(String colName, boolean ascendingStations) {
	this.ascendingStations = ascendingStations;
	this.colName = colName;
    }
    
    @SuppressWarnings("unchecked")
    public int compare(IacStationsModel o1, IacStationsModel o2) {
        int result = 0;
        
      try {
            Object value1 = null;
            Object value2 = null;
            
        if (colName.equalsIgnoreCase("partyName")) {
		value1 = o1.getPartyName();
		value2 = o2.getPartyName();
        } else if (colName.equalsIgnoreCase("city")) {
		value1 = o1.getCity();
		value2 = o2.getCity();
        } else if (colName.equalsIgnoreCase("state")) {
		value1 = o1.getState();
		value2 = o2.getState();
        } else if (colName.equalsIgnoreCase("active")) {
		value1 = o1.getActive();
		value2 = o2.getActive();		
        } else {
		logger.warn("Could not map " + colName + " to class attribute");
        }
            
        // Null is lesser than anything else.
        if ((value1 == null) && (value2 == null)) {
		result = 0;
        } else if ((value1 == null) && (value2 != null)) {
		result = -1;
        } else if ((value1 != null) && (value2 == null)) {
		result = 1;
        } else if (value1 instanceof Comparable) {
		// the attribute values are Comparable, we have hit the JackPot.  We have absolutely nothing intelligent to do
		@SuppressWarnings("rawtypes")
		Comparable comp1 = (Comparable) value1;
		@SuppressWarnings("rawtypes")
		Comparable comp2 = (Comparable) value2;
		result = comp1.compareTo(comp2);
        } else {
		logger.warn("Dont know how to sort by " + colName);
        }

        if (result == 0) {
		result = -1; // to help in table sort
        }

        if (!ascendingStations) {
		result = 0 - result;
        }
      }
      catch (Exception ex) {
            //ex.printStackTrace();
            logger.error("Exception : " + ex.getMessage());
	 }
        return result;
    }
}
