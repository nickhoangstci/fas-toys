/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ctu.tsa.fas.expandedsearch.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

/**
 *
 * @author Kevin.Tsou
 */
public class CcsfFacility implements Serializable{
    private static final long serialVersionUID = -8767337899673261247L;

    private String ccsfCertificationNum;
    private long facilityId;
    private String facilityName;
    private String iacNum;
    private String certificationStatus;
    private String iataCode;
    private String companyName;

	
	public void setCcsfCertificationNum (String ccsfCertificationNum) {
		this.ccsfCertificationNum = ccsfCertificationNum; 
	}

	public void setFacilityId (long facilityId) {
		this.facilityId = facilityId; 
	}

	public void setFacilityName (String facilityName) {
		this.facilityName = facilityName; 
	}

	public void setIacNum (String iacNum) {
		this.iacNum = iacNum; 
	}

	public void setCertificationStatus (String certificationStatus) {
		this.certificationStatus = certificationStatus; 
	}
        
        public void setIataCode (String iataCode) {
		this.iataCode = iataCode; 
	}
        
        public void setCompanyName (String companyName) {
		this.companyName = companyName; 
	}

	public String getCcsfCertificationNum () {
		return (this.ccsfCertificationNum); 
	}

	public long getFacilityId () {
		return (this.facilityId); 
	}

	public String getFacilityName () {
		return (this.facilityName); 
	}

	public String getIacNum () {
		return (this.iacNum); 
	}

	public String getCertificationStatus () {
		return (this.certificationStatus); 
	}
        
        public String getIataCode () {
		return (this.iataCode); 
	}
        
        public String getCompanyName () {
		return (this.companyName); 
	}

	public String toString () {

		String sep = System.getProperty("line.separator");

		StringBuffer buffer = new StringBuffer();
		buffer.append(sep);
		buffer.append("ccsfCertificationNum = ");
		buffer.append(ccsfCertificationNum);
		buffer.append(sep);
		buffer.append("facilityId = ");
		buffer.append(facilityId);
		buffer.append(sep);
		buffer.append("facilityName = ");
		buffer.append(facilityName);
		buffer.append(sep);
		buffer.append("iacNum = ");
		buffer.append(iacNum);
		buffer.append(sep);
		buffer.append("certificationStatus = ");
		buffer.append(certificationStatus);
		buffer.append(sep);
                buffer.append("iataCode = ");
		buffer.append(iataCode);
		buffer.append(sep);
                buffer.append("companyName = ");
		buffer.append(companyName);
		buffer.append(sep);
		
		return buffer.toString();
	}
}
