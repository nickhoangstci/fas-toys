/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ctu.tsa.fas.expandedsearch.action;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.log4j.Logger;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.json.JSONArray;
import org.json.JSONObject;

import com.ctu.tsa.fas.expandedsearch.dao.ExpandedSearchShipperDAO;
import com.ctu.tsa.fas.expandedsearch.model.ShipperDetails;
import com.freightdesk.fdcommons.Credentials;
import com.freightdesk.fdcommons.SessionKey;
import com.freightdesk.fdcommons.SessionStore;
import com.opensymphony.xwork2.ActionSupport;

import crt.com.freightdesk.fdfolio.common.IncludesUtil;

/**
 *
 * @author Binh.Nguyen
 */
public class FasShipperInfoAction extends ActionSupport implements ServletRequestAware{
    protected Logger logger = Logger.getLogger(getClass());
    HttpServletRequest request = ServletActionContext.getRequest();   
    private String loginTimeRoleMsg;
    private String shipperName = "";
    private String shipperType = "";
    private String shipperId = "";
    private String shipperStatus = "";
    private String shipperNumber = "";
    private String iacAcCompanyName = "";
    private String organizationName = "";
    private long organizationProfileId = 0;
    private long partyId = 0;
    private String reasonForStatus = "";
    private String iacNumber = "";
    private String creationDate = "";
    private List<Map> shipperList;
    private List<Map> detailRecShipperList;
    private List<Map> orgProfList;        
    private String phone = "";
    private String address1 = "";
    private String address2 = "";
    private String city = "";
    private String state = "";
    private String zipPostalCode = "";
    private String country = "";
    private String notes = "";
	private String email = "";	
    private String dispositionCode = "";
    private String virtualShipper = "";	    
	private int detListSize = 0;
    private int orgProfListSize = 0;    	     
  	List<Map> notesList = new ArrayList();
    
    @Override
    public String execute()throws Exception {
        request = ServletActionContext.getRequest();
        HttpSession session = request.getSession(false);
        SessionStore store = SessionStore.getInstance(session);
        Credentials credentials = (Credentials) store.get(SessionKey.CREDENTIALS);
        ExpandedSearchShipperDAO dao = new ExpandedSearchShipperDAO();
        List<ShipperDetails> shipperDetailsList = new ArrayList<ShipperDetails>();
        Map theShipperMap = new HashMap();
        Map theOrgProfMap = new HashMap();            
        		
        loginTimeRoleMsg = IncludesUtil.getWelcomeMsg(credentials)+ "<br>" + IncludesUtil.getExpireMsg(credentials);               
				
        SessionStore sessionStore = SessionStore.getInstance (request.getSession());		 
        
	    setDetailRecShipperList(dao.getShipperDetails(getShipperId(), getIacNumber()));
        
        if ((detailRecShipperList == null) || (detailRecShipperList.isEmpty())){
            detListSize = 0;
        } else {
            detListSize = detailRecShipperList.size();
        }
        
        if (detListSize > 0) {	
            theShipperMap = detailRecShipperList.get(0);	
            
            setIacNumber((String)theShipperMap.get("iacNumber"));
            setIacAcCompanyName((String)theShipperMap.get("iacAcCompanyName"));
            setPartyId((long)theShipperMap.get("partyId"));
            setShipperId((String)theShipperMap.get("shipperId"));
            setShipperName((String)theShipperMap.get("shipperName"));
            setShipperType((String)theShipperMap.get("shipperType"));
            setReasonForStatus((String)theShipperMap.get("reasonForStatus"));
            setShipperStatus((String)theShipperMap.get("shipperStatus"));
            setCreationDate(((String)theShipperMap.get("creationDate")).substring(0, 11));
            			
            setPhone((String)theShipperMap.get("phone"));
            setAddress1((String)theShipperMap.get("address1"));
            setAddress2((String)theShipperMap.get("address2"));
            setCity((String)theShipperMap.get("city"));
            setZipPostalCode((String)theShipperMap.get("zipPostalCode"));
            setState((String)theShipperMap.get("state"));
	    	setCountry((String)theShipperMap.get("country"));
        }
        
        setOrgProfList(dao.getDispCodeByPartyId(getPartyId()));
        
        if ((orgProfList == null) || (orgProfList.isEmpty())){
            orgProfListSize = 0;
        } else {
            orgProfListSize = orgProfList.size();
        }
        
        if (orgProfListSize > 0) {
            theOrgProfMap = orgProfList.get(0);	
		
            setOrganizationName((String)theOrgProfMap.get("organizationName"));
            setOrganizationProfileId((long)theOrgProfMap.get("organizationProfileId"));
            setVirtualShipper((String)theOrgProfMap.get("virtualShipper"));
            setDispositionCode((String)theOrgProfMap.get("dispositionCode") + " " +
            getDispositionCodeDesc((String)theOrgProfMap.get("dispositionCode")));
        }
        
        setNotesList(dao.getNotesByPartyId(getPartyId()));		
		
	store.put (SessionKey.SHIPPER_DET_MAP, detailRecShipperList);
	store.put (SessionKey.SHIPPER_ORG_MAP, orgProfList);
	store.put (SessionKey.SHIPPER_NOTES_MAP, notesList);				
        session.setAttribute("SHIPPER_NOTES_MAP", convertMapListToJsonString(notesList));
        
        return "displayIacShipperInfo";
    }			
    
    private String convertMapListToJsonString(List<Map> list) {

		JSONArray ja = new JSONArray();
	    JSONObject jo = null;
		String dataStr = null;
	
	    try {
	        if (null != list && !list.isEmpty()) {
	
				for (Map<String, String> map : list) {
			      jo = new JSONObject();
			      for (Map.Entry<String, String> entry : map.entrySet()) {
			    	  jo.put(entry.getKey(), entry.getValue());
			      }
			      ja.put (jo);
	           }
				dataStr = ja.toString ();				
	        }
	    } catch(Exception e) {
	      logger.error ("Exception JSON conversion" + e);
	    }
	    return dataStr;
    
    }        
    
    public String getLoginTimeRoleMsg() {
        return loginTimeRoleMsg;
    }

    public void setLoginTimeRoleMsg(String loginTimeRoleMsg) {
        this.loginTimeRoleMsg = loginTimeRoleMsg;
    }
    
    @Override
    public void setServletRequest(HttpServletRequest request) {
        this.request = request;
    }

    public HttpServletRequest getServletRequest() {
        return this.request;
    }
    
    public String getShipperName() {
        if (shipperName == null){
            this.shipperName = "";
        }
        return StringEscapeUtils.unescapeHtml4(shipperName);
    }
    
    public String getIacNumber() {
        if (iacNumber == null){
            this.iacNumber = "";
	}
        return StringEscapeUtils.unescapeHtml4(iacNumber);
    }
    
    public String getShipperType() {
        if (shipperType == null){
            this.shipperType = "";
	    }
	    return StringEscapeUtils.unescapeHtml4(shipperType);
    }
    
    public String getIacAcCompanyName() {
        if (iacAcCompanyName == null){
            this.iacAcCompanyName = "";
	    }
	    return StringEscapeUtils.unescapeHtml4(iacAcCompanyName);
    }
    
    public void setIacAcCompanyName(String iacAcCompanyName) {
	   this.iacAcCompanyName = iacAcCompanyName;
    }
    
    public String getOrganizationName() {
        if (organizationName == null){
            this.organizationName = "";
	    }
	    return StringEscapeUtils.unescapeHtml4(organizationName);
    }
    
    public void setOrganizationName(String organizationName) {
	   this.organizationName = organizationName;
    }
    
    public long getOrganizationProfileId() {
        return organizationProfileId;
    }
    
    public void setOrganizationProfileId(long organizationProfileId) {
	   this.organizationProfileId = organizationProfileId;
    }
    
    public String getReasonForStatus() {
        if (reasonForStatus == null){
            this.reasonForStatus = "";
	    }
	    return StringEscapeUtils.unescapeHtml4(reasonForStatus);
    }
    
    public void setReasonForStatus(String reasonForStatus) {
	   this.reasonForStatus = reasonForStatus;
    }
    
    public void setShipperName(String shipperName) {
	       this.shipperName = shipperName;
    } 
    
    public void setIacNumber(String iacNumber) {
	       this.iacNumber = iacNumber;
    } 
    
	public void setShipperType(String shipperType) {
	       this.shipperType = shipperType;
    } 
        
    public String getShipperNumber() {
        if (shipperNumber == null){
            this.shipperNumber = "";
	    }	
	    return StringEscapeUtils.unescapeHtml4(shipperNumber);
    }
    
    public void setShipperNumber(String shipperNumber) {
	   this.shipperNumber = shipperNumber;
    }  
    
    public String getDispositionCode() {
        if (dispositionCode == null){
            this.dispositionCode = "";
	}
	return StringEscapeUtils.unescapeHtml4(dispositionCode);
    }

    public void setDispositionCode(String dispositionCode) {
        this.dispositionCode = dispositionCode;
    }
	
    public String getVirtualShipper() {
        if (virtualShipper == null){
            this.virtualShipper = "";
	}
	return StringEscapeUtils.unescapeHtml4(virtualShipper);
    }

    public void setVirtualShipper(String virtualShipper) {
        this.virtualShipper = virtualShipper;
    }

    public List<Map> getShipperList() {
        return shipperList;
    }

    public void setShipperList(List<Map> shipperList) {
        this.shipperList = shipperList;
    }
    
    public List<Map> getDetailRecShipperList() {
        return detailRecShipperList;
    }

    public void setDetailRecShipperList(List<Map> detailRecShipperList) {
        this.detailRecShipperList = detailRecShipperList;
    }
    
    public List<Map> getOrgProfList() {
        return orgProfList;
    }

    public void setOrgProfList(List<Map> orgProfList) {
        this.orgProfList = orgProfList;
    }
    
    public List<Map> getNotesList() {
        return notesList;
    }

    public void setNotesList(List<Map> notesList) {
        this.notesList = notesList;
    }
   
    public String getShipperStatus() {
        if (shipperStatus == null){
            this.shipperStatus = "";
	    }	
	    return StringEscapeUtils.unescapeHtml4(shipperStatus);
    }
    
    public void setShipperStatus(String shipperStatus) {
	      this.shipperStatus = shipperStatus;
    }  
    
    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
            
    public String getAddress1() {
        return address1;
    }

    public void setAddress1(String address1) {
        this.address1 = address1;
    }        
        
    public String getAddress2() {
        return address2;
    }

    public void setAddress2(String address2) {
        this.address2 = address2;
    }    
    
    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }
    
    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }
    
    public String getZipPostalCode() {
        return zipPostalCode;
    }

    public void setZipPostalCode(String zipPostalCode) {
        this.zipPostalCode = zipPostalCode;
    }
    
    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }
    
    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }
    
    public String getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(String creationDate) {
        this.creationDate = creationDate;
    }

	
	public void setShipperId (String shipperId) {
		this.shipperId = shipperId; 
	}

	public String getShipperId () {
		return StringEscapeUtils.unescapeHtml4(this.shipperId);
	}
	
	public void setEmail (String email) {
		this.email = email; 
	}

	public String getEmail() {
		return (this.email); 
	}
	
	public void setPartyId (long partyId) {
		this.partyId = partyId; 
	}

	public long getPartyId () {
		return (this.partyId); 
	}				       
         
    public String getDispositionCodeDesc (String dispCodeStr){
            String descStr = "";
            switch (dispCodeStr) {
                case "100":
                    descStr = "New Record or branch created";
                    break;
                case "110":
                    descStr = "Updated out of Biz indicator";
                    break;
                case "120":
                    descStr = "Updated name or tradestyle";
                    break;
                case "130":
                    descStr = "Updated address";
                    break;
                case "140":
                    descStr = "Updated phone number";
                    break;
                case "150":
                    descStr = "Updated linkage";
                    break;
                case "189":
                    descStr = "Updated multiple fields of different types";
                    break;
                case "199":
                    descStr = "Other-See comments";
                    break;
                case "200":
                    descStr = "No updates made, exact match found";
                    break;
                case "297":
                    descStr = "No updates made, contact declined";
                    break;
                case "298":
                    descStr = "Maximum Attempts";
                    break;
                case "299":
                    descStr = "No updates made, investigation denied";
                    break;
                case "997":
                    descStr = "No DUNS# existing, or created, contact declined";
                    break;
                case "998":
                    descStr = "Maximum call attempts without business contact";
                    break;
                case "999":
                    descStr = "No DUNS existed, or created";
                    break;
                default:
                    descStr = "";
                    break;
            }
            
            return descStr;
        }	

}
