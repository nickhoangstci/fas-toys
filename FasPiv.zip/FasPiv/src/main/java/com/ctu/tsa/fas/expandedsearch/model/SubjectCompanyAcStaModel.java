/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ctu.tsa.fas.expandedsearch.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

/**
 *
 * @author Binh.Nguyen
 */
public class SubjectCompanyAcStaModel implements Serializable{
    private static final long serialVersionUID = -8767337899673261248L;
    private String staId;
	private String firstName;	
	private String lastName;
	private String creationDate;
	private String issuedOnDate;
	private String expiresOnDate;
	private String status;
	private String staStatus;
		
    public SubjectCompanyAcStaModel() {
    }
        
    public SubjectCompanyAcStaModel(String staId, String firstName, String lastName, String creationDate, String issuedOnDate, String expiresOnDate, String status, String staStatus) {
		this.staId = staId;
		this.firstName = firstName;        		      
		this.lastName = lastName;
		this.creationDate = creationDate;
		this.issuedOnDate = issuedOnDate;
		this.expiresOnDate = expiresOnDate;
		this.status = status;
		this.staStatus = staStatus;
    }
    
    public void setStaId (String staId) {
		this.staId = staId; 
    }
	
	public void setFirstName (String firstName) {
		this.firstName = firstName; 
    }			
	
	public void setLastName (String lastName) {
		this.lastName = lastName; 
    }
	
	public void setCreationDate (String creationDate) {
		this.creationDate = creationDate; 
    }
	
    public void setIssuedOnDate(String issuedOnDate) {
    	this.issuedOnDate = issuedOnDate; 
    }
	
	public void setExpiresOnDate (String expiresOnDate) {
		this.expiresOnDate = expiresOnDate; 
    }
	
	public void setStatus (String status) {
		this.status = status; 
    }
	
	public void setStaStatus (String staStatus) {
		this.staStatus = staStatus; 
    }
	
	public String getStaId () {
		return (this.staId); 
    }
	
	public String getFirstName () {
		return (this.firstName); 
    }			
	
	public String getLastName () {
		return (this.lastName); 
    }
	
	public String getCreationDate () {
		return (this.creationDate); 
    }
	
	public String getIssuedOnDate () {
		return (this.issuedOnDate);
    }
	
	public String getExpiresOnDate () {
		return (this.expiresOnDate); 
    }
	
	public String getStatus () {
		return (this.status); 
    }
	
	public String getStaStatus () {
		return (this.staStatus); 
    }
	
    public String toString () {

	String sep = System.getProperty("line.separator");

	StringBuffer buffer = new StringBuffer();
	buffer.append(sep);	
	buffer.append("staId = ");
	buffer.append(staId);
	buffer.append(sep);	
	buffer.append("firstName = ");
	buffer.append(firstName);
	buffer.append(sep);	
	buffer.append("lastName = ");
	buffer.append(lastName);
	buffer.append(sep);
	buffer.append("creationDate = ");
	buffer.append(creationDate);
	buffer.append(sep); 
	buffer.append("issuedOnDate = ");
	buffer.append(issuedOnDate);
	buffer.append(sep); 
	buffer.append("expiresOnDate = ");
	buffer.append(expiresOnDate);
	buffer.append(sep);
	buffer.append("status = ");
	buffer.append(status);
	buffer.append(sep);
	buffer.append("staStatus = ");
	buffer.append(staStatus);
	buffer.append(sep);
	
	return buffer.toString();
    }
}
