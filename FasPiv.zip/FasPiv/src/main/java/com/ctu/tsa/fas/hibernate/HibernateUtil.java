/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.ctu.tsa.fas.hibernate;

/**
 *
 * @author Eswara.Somu
 */
import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.apache.log4j.Logger;
 
public class HibernateUtil {
 
	protected static Logger logger = Logger.getLogger("com.ctu.tsa.fas.hibernate.HibernateUtil");
	private static final SessionFactory sessionFactory = buildSessionFactory();
 private static Configuration configuration = null;
	public  static SessionFactory buildSessionFactory() {
		try {
                    logger.debug("begin buildSessionFactory  1 ");
			// Create the SessionFactory from hibernate.cfg.xml
                    configuration = new Configuration();
                    logger.info("configuration " + configuration);
                    configuration.configure("hibernate.cfg.xml");
             
                    logger.info("   after load the cfg fiile 1111: "  +configuration.toString());
			return configuration.buildSessionFactory();
		} catch (Exception ex) {
			// Make sure you log the exception, as it might be swallowed
			logger.error("Initial SessionFactory creation failed." + ex);
			throw new ExceptionInInitializerError(ex);
		}
	}
    public static Configuration getConfiguration()
        throws HibernateException
    {
         logger.debug("begin getConfiguration   ");
        if (configuration==null)
        {
             logger.debug(" inside configuration==null   ");
            configuration = new Configuration().configure("hibernate.cfg.xml");
            logger.info(" after nside configuration==null   " + configuration);
         
        }

        return configuration;
    }
	public static SessionFactory getSessionFactory() {
             logger.info(" begin getSessionFactory   " + sessionFactory);
		return sessionFactory;
	}
 
	public static void shutdown() {
		// Close caches and connection pools
		getSessionFactory().close();
	}
 
}