/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ctu.tsa.fas.expandedsearch.action;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.log4j.Logger;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.interceptor.ServletRequestAware;

import com.ctu.tsa.fas.expandedsearch.dao.ExpandedSearchSubjectIndividualDAO;
import com.ctu.tsa.fas.expandedsearch.model.SubjectIndividualDetails;
import com.freightdesk.fdcommons.Credentials;
import com.freightdesk.fdcommons.SessionKey;
import com.freightdesk.fdcommons.SessionStore;
import com.opensymphony.xwork2.ActionSupport;

import crt.com.freightdesk.fdfolio.common.IncludesUtil;

/**
 *
 * @author STCI
 */
public class FasSubjectIndividualInfoAction extends ActionSupport implements ServletRequestAware{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * 
	 */
	protected Logger logger = Logger.getLogger(getClass());
    HttpServletRequest request = ServletActionContext.getRequest();
    private String debugMsg;
    private String loginTimeRoleMsg;	
    private String subjectIndividualStaId;
    private String subjectIndividualFirstName;
    private String subjectIndividualLastName;
    private String subjectIndividualCreationDate;
    private String subjectIndividualIssuedDate;
    private String subjectIndividualExpirationDate;
    private String subjectIndividualRecordStatus; 
    private String subjectIndividualStaStatus;
    private String subjectIndividualMiddleName;
    private String subjectIndividualSuffix;
    private String subjectIndividualAlias1;
    private String subjectIndividualAlias2;
    private String subjectIndividualAlias3;	
    private String subjectIndividualAddress1;
    private String subjectIndividualAddress2;
    private String subjectIndividualCity;
    private String subjectIndividualState;    
    private String subjectIndividualZipPostalCode;		
    private String subjectIndividualCountry;
    private String subjectIndividualPersonName;	   
    private String subjectIndividualResidentialPhysicalAddress;	
    private String subjectIndividualResidentialPhysicalCity;
    private String subjectIndividualResidentialPhysicalState;
    private String subjectIndividualResidentialPhysicalZipPostalCode;	
    private String subjectIndividualResidentialPhysicalCountry;
    private String subjectIndividualResidentialPhysicalStartDate;
    private String subjectIndividualResidentialPhysicalEndDate;		
    private String subjectIndividualGender;
    private String subjectIndividualSsn;
    private String subjectIndividualSsnLastFour;
    private String subjectIndividualDateOfBirth;
    private String subjectIndividualBirthCity;
    private String subjectIndividualBirthState;
    private String subjectIndividualBirthCountry;	
    private String subjectIndividualCountryOfCitizenship;
    private String subjectIndividualAlienNumber;
    private String subjectIndividualNaturalizationDate;
    private String subjectIndividualNaturalizationNumber;
    private String subjectIndividualUsPassportNumber;
    private String subjectIndividualBirthAbroadCertificationNumber;	
    private String subjectIndividualIacNumber;
    private String subjectIndividualIacName;
    private String subjectIndividualIacCity;
    private String subjectIndividualIacState;
    private String subjectIndividualIacStartDate;
    private String subjectIndividualIacEndDate;	
    private String subjectIndividualAgentName;
    private String subjectIndividualAgentId;
    private String subjectIndividualPartyId;
    private String subjectIndividualAgentCity;
    private String subjectIndividualAgentState;
    private String subjectIndividualAgentAssociatedIac;
    private String subjectIndividualAgentStartDate;
    private String subjectIndividualAgentEndDate;	
    private String subjectIndividualAcName;
    private String subjectIndividualAcCity;
    private String subjectIndividualAcState;
    private String subjectIndividualAcStartDate;
    private String subjectIndividualAcEndtDate;	
    private List<Map> subjectIndividualList;    	
    private List<Map> cznInforList;
    private List<Map> staIdMap;
    private List<Map> firstNameMap;
    private List<Map> lastNameMap;		
    Map thePersonalInforMap ;
    List<Map> personalInforList ;
    List<Map> residentialPhysicalMap;
    List<Map> iacMap;
    List<Map> agentMap;
    List<Map> acMap;	
    List<Map> personalMap ;
    List<Map> citizenshipMap;   
    private List<Map> subjectIndividualRePhyList;   	
    private List<Map> subjectIndividualIacList;    
    private List<Map> subjectIndividualAgentsList;
    private List<Map> subjectIndividualAcList;  
    
    private int personalInforListSize = 0;	
    private long[] debugTime = new long[8];
    
    @Override
    public String execute()throws Exception {
        request = ServletActionContext.getRequest();
        final HttpSession session = request.getSession(false);
        SessionStore store = SessionStore.getInstance(session);
        Credentials credentials = (Credentials) store.get(SessionKey.CREDENTIALS);
        final ExpandedSearchSubjectIndividualDAO dao = new ExpandedSearchSubjectIndividualDAO();
        
        debugTime[0] = System.currentTimeMillis();
        
        List<SubjectIndividualDetails> subjectIndividualDetails = new ArrayList<SubjectIndividualDetails>();
        logger.info("execute(): begin");
        loginTimeRoleMsg = IncludesUtil.getWelcomeMsg(credentials)+ "<br>" + IncludesUtil.getExpireMsg(credentials);                             
        
        SessionStore sessionStore = SessionStore.getInstance (request.getSession());	         
	
        try {
            debugTime[1] = System.currentTimeMillis();

            setSubjectIndividualList(dao.getSubjectIndividualDetailsByStatIdLastNameFirstName(getSubjectIndividualStaId(),
            getSubjectIndividualLastName(), getSubjectIndividualFirstName()));            

            if ((subjectIndividualList == null) || (subjectIndividualList.isEmpty())) {
                Thread.currentThread().interrupt();
                return "subjectIndividualList is empty";
            }

            Map theSubjectIndividualMap = null;				
            String temp;

            theSubjectIndividualMap = subjectIndividualList.get(0);			
            setSubjectIndividualStaId((String)theSubjectIndividualMap.get("subjectIndividualStaId"));
            setSubjectIndividualLastName((String)theSubjectIndividualMap.get("subjectIndividualLastName"));
            setSubjectIndividualFirstName((String)theSubjectIndividualMap.get("subjectIndividualFirstName"));	
            setSubjectIndividualMiddleName((String)theSubjectIndividualMap.get("subjectIndividualMiddleName"));
            setSubjectIndividualSuffix((String)theSubjectIndividualMap.get("subjectIndividualSuffix"));                       
            setSubjectIndividualAlias1((String)theSubjectIndividualMap.get("subjectIndividualAlias1"));
            setSubjectIndividualAlias2((String)theSubjectIndividualMap.get("subjectIndividualAlias2"));
            setSubjectIndividualAlias3((String)theSubjectIndividualMap.get("subjectIndividualAlias3"));			

            if ((String)theSubjectIndividualMap.get("subjectIndividualCreationDate") != null && 
                !(theSubjectIndividualMap.get("subjectIndividualCreationDate").equals(""))){
                    temp = (String)theSubjectIndividualMap.get("subjectIndividualCreationDate");
                    setSubjectIndividualCreationDate(temp.substring(0, (temp).indexOf(' ')));
            }
            else {
                    setSubjectIndividualCreationDate ("");
            }

            if ((String)theSubjectIndividualMap.get("subjectIndividualIssuedDate") != null && 
                !(theSubjectIndividualMap.get("subjectIndividualIssuedDate").equals(""))){
                    temp = (String)theSubjectIndividualMap.get("subjectIndividualIssuedDate");
                    setSubjectIndividualIssuedDate(temp.substring(0, (temp).indexOf(' ')));
            }
            else {
                    setSubjectIndividualIssuedDate ("");
            }

            if ((String)theSubjectIndividualMap.get("subjectIndividualExpirationDate") != null && 
                !(theSubjectIndividualMap.get("subjectIndividualExpirationDate").equals(""))){
                    temp = (String)theSubjectIndividualMap.get("subjectIndividualExpirationDate");
                    setSubjectIndividualExpirationDate(temp.substring(0, (temp).indexOf(' ')));
            }
            else {
                    setSubjectIndividualExpirationDate ("");
            }

            setSubjectIndividualStaStatus((String)theSubjectIndividualMap.get("subjectIndividualStaStatus"));
            setSubjectIndividualRecordStatus((String)theSubjectIndividualMap.get("subjectIndividualRecordStatus"));
            setSubjectIndividualAddress1((String)theSubjectIndividualMap.get("subjectIndividualAddress1"));
            setSubjectIndividualAddress2((String)theSubjectIndividualMap.get("subjectIndividualAddress2"));
            setSubjectIndividualCity((String)theSubjectIndividualMap.get("subjectIndividualCity"));
            setSubjectIndividualZipPostalCode((String)theSubjectIndividualMap.get("subjectIndividualZipPostalCode"));
            setSubjectIndividualState((String)theSubjectIndividualMap.get("subjectIndividualState"));

            if (theSubjectIndividualMap.get("subjectIndividualState") != null && theSubjectIndividualMap.get("subjectIndividualState") != ""){
                setSubjectIndividualCountry("UNITED STATES");
            }

            setSubjectIndividualResidentialPhysicalAddress((String)theSubjectIndividualMap.get("subjectIndividualResidentialPhysicalAddress"));
            setSubjectIndividualResidentialPhysicalCity((String)theSubjectIndividualMap.get("subjectIndividualResidentialPhysicalCity"));
            setSubjectIndividualResidentialPhysicalState((String)theSubjectIndividualMap.get("subjectIndividualResidentialPhysicalState"));
            setSubjectIndividualResidentialPhysicalZipPostalCode((String)theSubjectIndividualMap.get("subjectIndividualResidentialPhysicalZipPostalCode"));
            setSubjectIndividualResidentialPhysicalCountry((String)theSubjectIndividualMap.get("subjectIndividualResidentialPhysicalCountry"));
            setSubjectIndividualResidentialPhysicalStartDate((String)theSubjectIndividualMap.get("subjectIndividualResidentialPhysicalStartDate"));
            setSubjectIndividualResidentialPhysicalEndDate((String)theSubjectIndividualMap.get("subjectIndividualResidentialPhysicalEndDate"));

            setSubjectIndividualIacNumber((String)theSubjectIndividualMap.get("subjectIndividualIacNumber"));
            setSubjectIndividualIacName((String)theSubjectIndividualMap.get("subjectIndividualIacName"));
            setSubjectIndividualIacCity((String)theSubjectIndividualMap.get("subjectIndividualIacCity"));
            setSubjectIndividualIacState((String)theSubjectIndividualMap.get("subjectIndividualIacState"));
            setSubjectIndividualIacStartDate((String)theSubjectIndividualMap.get("subjectIndividualIacStartDate"));
            setSubjectIndividualIacEndDate((String)theSubjectIndividualMap.get("subjectIndividualIacEndDate"));

            setSubjectIndividualAgentName((String)theSubjectIndividualMap.get("subjectIndividualAgentName"));
            setSubjectIndividualAgentId((String)theSubjectIndividualMap.get("subjectIndividualAgentId"));
            setSubjectIndividualPartyId((String)theSubjectIndividualMap.get("subjectIndividualPartyId"));
            setSubjectIndividualAgentCity((String)theSubjectIndividualMap.get("subjectIndividualAgentCity"));
            setSubjectIndividualAgentState((String)theSubjectIndividualMap.get("subjectIndividualAgentState"));
            setSubjectIndividualAgentAssociatedIac((String)theSubjectIndividualMap.get("subjectIndividualAgentAssociatedIac"));
            setSubjectIndividualAgentStartDate((String)theSubjectIndividualMap.get("subjectIndividualAgentStartDate"));
            setSubjectIndividualAgentEndDate((String)theSubjectIndividualMap.get("subjectIndividualAgentEndDate"));

            setSubjectIndividualAcName((String)theSubjectIndividualMap.get("subjectIndividualAcName"));
            setSubjectIndividualPartyId((String)theSubjectIndividualMap.get("subjectIndividualPartyId"));
            setSubjectIndividualAcCity((String)theSubjectIndividualMap.get("subjectIndividualAcCity"));
            setSubjectIndividualAcState((String)theSubjectIndividualMap.get("subjectIndividualAcState"));
            setSubjectIndividualAcStartDate((String)theSubjectIndividualMap.get("subjectIndividualAcStartDate"));
            setSubjectIndividualAcEndtDate((String)theSubjectIndividualMap.get("subjectIndividualAcEndtDate"));			

            debugTime[1] = System.currentTimeMillis() - debugTime[1];
        }
        catch (Exception e) {
            logger.error("t1:" + e.getMessage());
        }

        try {
            debugTime[2] = System.currentTimeMillis();

            setResidentialPhysicalMap(convertResidentialPhysicalToResidentialPhysicalMap(dao.getSubjectIndividualByResidentialPhysical(getSubjectIndividualStaId(),
                    getSubjectIndividualLastName(), getSubjectIndividualFirstName())));
            session.setAttribute("ADDRESS_LIST",IncludesUtil.convertMapListToJsonString(residentialPhysicalMap));
                  debugTime[2] = System.currentTimeMillis() - debugTime[2];
        }
        catch (Exception e) {
            logger.error("t2:" + e.getMessage());
        }

        try {
            debugTime[3] = System.currentTimeMillis();

            setIacMap(convertIacToIacMap(dao.getSubjectIndividualByIac(getSubjectIndividualStaId(), getSubjectIndividualLastName(), getSubjectIndividualFirstName())));
            session.setAttribute("IAC_LIST",IncludesUtil.convertMapListToJsonString(iacMap));
            debugTime[3] = System.currentTimeMillis() - debugTime[3];
        }
        catch (Exception e) {
            logger.error("t3:" + e.getMessage());
        }

        try {
            debugTime[4] = System.currentTimeMillis();

            setAgentMap(convertAgentToAgentMap(dao.getSubjectIndividualByAgent(getSubjectIndividualStaId(),getSubjectIndividualLastName(), getSubjectIndividualFirstName())));
            session.setAttribute("AGENT_LIST",IncludesUtil.convertMapListToJsonString(agentMap));
            debugTime[4] = System.currentTimeMillis() - debugTime[4];           
        }
        catch (Exception e) {
            logger.error("t4:"+ e.getMessage());
        }

        try {
            debugTime[5] = System.currentTimeMillis();

            setAcMap(convertAcToAcMap(dao.getSubjectIndividualByAc(getSubjectIndividualStaId(),getSubjectIndividualLastName(), getSubjectIndividualFirstName())));
            session.setAttribute("AC_LIST",IncludesUtil.convertMapListToJsonString(acMap));
            debugTime[5] = System.currentTimeMillis() - debugTime[5];
        }    	                    	
        catch (Exception e) {
            logger.error("t5:" + e.getMessage());
        }

        try {
            debugTime[6] = System.currentTimeMillis();

            setPersonalInforList(convertPersonalInforToPersonalInfoMap(dao.getSubjectIndividualByPersonalInfor(getSubjectIndividualStaId(), getSubjectIndividualLastName(), getSubjectIndividualFirstName())));			           

            if ((personalInforList == null) || (personalInforList.isEmpty())){
                personalInforListSize = 0;
            } else {
                personalInforListSize = personalInforList.size();
            }
            if (personalInforListSize > 0) {			  		  
                thePersonalInforMap = personalInforList.get(0);

                setSubjectIndividualGender((String)thePersonalInforMap.get("subjectIndividualGender"));                        						  
                setSubjectIndividualSsn((String)thePersonalInforMap.get("subjectIndividualSsn"));
                setSubjectIndividualDateOfBirth((String)thePersonalInforMap.get("subjectIndividualDateOfBirth"));		  
                setSubjectIndividualBirthCity((String)thePersonalInforMap.get("subjectIndividualBirthCity"));		  
                setSubjectIndividualBirthState((String)thePersonalInforMap.get("subjectIndividualBirthState"));		  
                setSubjectIndividualBirthCountry((String)thePersonalInforMap.get("subjectIndividualBirthCountry"));		  
            }
            session.setAttribute("PER_LIST",IncludesUtil.convertMapListToJsonString(personalInforList));              
            debugTime[6] = System.currentTimeMillis() - debugTime[6];
        }
        catch (Exception e) {
            logger.error("t6:"+ e.getMessage());
        }

        try {
                debugTime[7] = System.currentTimeMillis();

                setCitizenshipMap(convertCznInforToCznInfoMap(dao.getSubjectIndividualByCznInfor(getSubjectIndividualStaId(), getSubjectIndividualLastName(), getSubjectIndividualFirstName())));
                session.setAttribute("CITIZ_LIST",IncludesUtil.convertMapListToJsonString(citizenshipMap));
                debugTime[7] = System.currentTimeMillis() - debugTime[7]; 
        }
        catch (Exception e) {
            logger.error("t7:" + e.getMessage());
        }  
		
        debugTime[0] = System.currentTimeMillis() - debugTime[0];
        int processors = Runtime.getRuntime().availableProcessors();
        logger.info(processors +" Elapsed Time = " + java.util.Arrays.toString(debugTime));
        debugMsg = " # CPUs: " + processors +" Elapsed Time = " + java.util.Arrays.toString(debugTime);
        logger.info(debugMsg);
        session.setAttribute("DEBUG_MSG", debugMsg);
        return "displaySubjectIndividualInfo";
    }    		
	
    public List<Map> convertCznInforToCznInfoMap(List<Map> list) {
        List<Map> theCznInforMap = new ArrayList();
        Map map = new HashMap();
        Iterator<Map>  itrList = list.iterator();
        Map cznInforMap = new HashMap();
        String temp3;

        while (itrList.hasNext()) {
            cznInforMap = (Map)itrList.next();
            map = new HashMap();

            map.put("subjectIndividualCountryOfCitizenship", cznInforMap.get("subjectIndividualCountryOfCitizenship"));
            map.put("subjectIndividualAlienNumber", cznInforMap.get("subjectIndividualAlienNumber"));
            if ((String)cznInforMap.get("subjectIndividualNaturalizationDate") != null && !(cznInforMap.get("subjectIndividualNaturalizationDate").equals(""))){
               temp3 = (String)cznInforMap.get("subjectIndividualNaturalizationDate");				   
               map.put("subjectIndividualNaturalizationDate", temp3.substring(0, (temp3).indexOf(' ')));				   
            }
            else {
               map.put("subjectIndividualNaturalizationDate", "");
            }            
            map.put("subjectIndividualNaturalizationNumber", cznInforMap.get("subjectIndividualNaturalizationNumber"));
            map.put("subjectIndividualUsPassportNumber", cznInforMap.get("subjectIndividualUsPassportNumber"));
            map.put("subjectIndividualBirthAbroadCertificationNumber", cznInforMap.get("subjectIndividualBirthAbroadCertificationNumber"));						

            theCznInforMap.add(map);
        }
		
        return (theCznInforMap);
    }
   
    public List<Map> convertPersonalInforToPersonalInfoMap(List<Map> list) {
        List<Map> thePersonalInformationMap = new ArrayList();
        Map map = new HashMap();
        Iterator<Map>  itrList = list.iterator();
        Map personalInforMap = new HashMap();
        String temp1;

        while (itrList.hasNext()) {
            personalInforMap = (Map)itrList.next();
            map = new HashMap();

            map.put("subjectIndividualGender", personalInforMap.get("subjectIndividualGender"));
            map.put("subjectIndividualSsn", personalInforMap.get("subjectIndividualSsn"));			
            subjectIndividualSsnLastFour = convertToSsnLastFour((String)personalInforMap.get("subjectIndividualSsn"));
            map.put("subjectIndividualSsnLastFour", subjectIndividualSsnLastFour);

            if ((String)personalInforMap.get("subjectIndividualDateOfBirth") != null && !(personalInforMap.get("subjectIndividualDateOfBirth").equals(""))){
                temp1 = (String)personalInforMap.get("subjectIndividualDateOfBirth");				   
                map.put("subjectIndividualDateOfBirth", temp1.substring(0, (temp1).indexOf(' ')));				   
            }
            else {
                map.put("subjectIndividualDateOfBirth", "");
            }           
            map.put("subjectIndividualBirthCity", personalInforMap.get("subjectIndividualBirthCity"));
            map.put("subjectIndividualBirthState", personalInforMap.get("subjectIndividualBirthState"));
            map.put("subjectIndividualBirthCountry", personalInforMap.get("subjectIndividualBirthCountry"));						

            thePersonalInformationMap.add(map);
        }

        return (thePersonalInformationMap);
    }
   
	public List<Map> convertResidentialPhysicalToResidentialPhysicalMap(List<Map> list) {
        List<Map> theResidentialPhysicalMap = new ArrayList();
        Map map = new HashMap();
        Iterator<Map>  itrList = list.iterator();
        Map residentialPhysicalMap = new HashMap();
		String temp2;
        
        while (itrList.hasNext()) {
            residentialPhysicalMap = (Map)itrList.next();
            map = new HashMap();
            map.put("subjectIndividualResidentialPhysicalAddress", residentialPhysicalMap.get("subjectIndividualResidentialPhysicalAddress"));
            map.put("subjectIndividualResidentialPhysicalCity", residentialPhysicalMap.get("subjectIndividualResidentialPhysicalCity"));
            map.put("subjectIndividualResidentialPhysicalState", residentialPhysicalMap.get("subjectIndividualResidentialPhysicalState"));
            map.put("subjectIndividualResidentialPhysicalZipPostalCode", residentialPhysicalMap.get("subjectIndividualResidentialPhysicalZipPostalCode"));
            map.put("subjectIndividualResidentialPhysicalCountry", residentialPhysicalMap.get("subjectIndividualResidentialPhysicalCountry"));
            						
            if ((String)residentialPhysicalMap.get("subjectIndividualResidentialPhysicalStartDate") != null && !(residentialPhysicalMap.get("subjectIndividualResidentialPhysicalStartDate").equals(""))){
                       temp2 = (String)residentialPhysicalMap.get("subjectIndividualResidentialPhysicalStartDate");				   
                       map.put("subjectIndividualResidentialPhysicalStartDate", temp2.substring(0, (temp2).indexOf(' ')));				   
            }
            else {
                       map.put("subjectIndividualResidentialPhysicalStartDate", "");
            }			

            if ((String)residentialPhysicalMap.get("subjectIndividualResidentialPhysicalEndDate") != null && !(residentialPhysicalMap.get("subjectIndividualResidentialPhysicalEndDate").equals(""))){
                       temp2 = (String)residentialPhysicalMap.get("subjectIndividualResidentialPhysicalEndDate");				   
                       map.put("subjectIndividualResidentialPhysicalEndDate", temp2.substring(0, (temp2).indexOf(' ')));				   
            }
            else {
                       map.put("subjectIndividualResidentialPhysicalEndDate", "");
            }

            theResidentialPhysicalMap.add(map);
        }
        return (theResidentialPhysicalMap);
    }	
	
	public List<Map> convertLastNameToLastNameMap(List<Map> list) {
        List<Map> theLastNameMap = new ArrayList();
        Map map = new HashMap();
        Iterator<Map>  itrList = list.iterator();
        Map lastNameMap = new HashMap();
		String temp;
        
        while (itrList.hasNext()) {
            lastNameMap = (Map)itrList.next();
            map = new HashMap();
            map.put("subjectIndividualStaId", lastNameMap.get("subjectIndividualStaId"));
            map.put("subjectIndividualLastName", lastNameMap.get("subjectIndividualLastName"));
            map.put("subjectIndividualFirstName", lastNameMap.get("subjectIndividualFirstName"));
            map.put("subjectIndividualMiddleName", lastNameMap.get("subjectIndividualMiddleName"));
            map.put("subjectIndividualSuffix", lastNameMap.get("subjectIndividualSuffix"));
            
            if ((String)lastNameMap.get("subjectIndividualCreationDate") != null && !(lastNameMap.get("subjectIndividualCreationDate").equals(""))){
                       temp = (String)lastNameMap.get("subjectIndividualCreationDate");				   
                       map.put("subjectIndividualCreationDate", temp.substring(0, (temp).indexOf(' ')));				   
            }
            else {
                       map.put("subjectIndividualCreationDate", "");
            }           

            if ((String)lastNameMap.get("subjectIndividualIssuedDate") != null && !(lastNameMap.get("subjectIndividualIssuedDate").equals(""))){
                       temp = (String)lastNameMap.get("subjectIndividualIssuedDate");				   
                       map.put("subjectIndividualIssuedDate", temp.substring(0, (temp).indexOf(' ')));				   
            }
            else {
                       map.put("subjectIndividualIssuedDate", "");
            }            

            if ((String)lastNameMap.get("subjectIndividualExpirationDate") != null && !(lastNameMap.get("subjectIndividualExpirationDate").equals(""))){
                       temp = (String)lastNameMap.get("subjectIndividualExpirationDate");				   
                       map.put("subjectIndividualExpirationDate", temp.substring(0, (temp).indexOf(' ')));				   
            }
            else {
                       map.put("subjectIndividualExpirationDate", "");
            }					         

            map.put("subjectIndividualRecordStatus", lastNameMap.get("subjectIndividualRecordStatus"));
            map.put("subjectIndividualStaStatus", lastNameMap.get("subjectIndividualStaStatus"));
            map.put("subjectIndividualAlias1", lastNameMap.get("subjectIndividualAlias1"));
            map.put("subjectIndividualAlias2", lastNameMap.get("subjectIndividualAlias2"));
            map.put("subjectIndividualAlias3", lastNameMap.get("subjectIndividualAlias3"));
            map.put("subjectIndividualAddress1", lastNameMap.get("subjectIndividualAddress1"));
            map.put("subjectIndividualAddress2", lastNameMap.get("subjectIndividualAddress2"));            
            map.put("subjectIndividualCity", lastNameMap.get("subjectIndividualCity"));
            map.put("subjectIndividualState", lastNameMap.get("subjectIndividualState"));
            map.put("subjectIndividualZipPostalCode", lastNameMap.get("subjectIndividualZipPostalCode"));
            map.put("subjectIndividualCountry", lastNameMap.get("subjectIndividualCountry"));

            theLastNameMap.add(map);
        }
        
        return (theLastNameMap);
    }
	
	public List<Map> convertFirstNameToFirstNameMap(List<Map> list) {
        List<Map> theFirstNameMap = new ArrayList();
        Map map = new HashMap();
        Iterator<Map>  itrList = list.iterator();
        Map firstNameMap = new HashMap();
		String temp;
        
        while (itrList.hasNext()) {
            firstNameMap = (Map)itrList.next();
            map = new HashMap();
            map.put("subjectIndividualStaId", firstNameMap.get("subjectIndividualStaId"));
            map.put("subjectIndividualLastName", firstNameMap.get("subjectIndividualLastName"));
            map.put("subjectIndividualFirstName", firstNameMap.get("subjectIndividualFirstName"));
            map.put("subjectIndividualMiddleName", firstNameMap.get("subjectIndividualMiddleName"));
            map.put("subjectIndividualSuffix", firstNameMap.get("subjectIndividualSuffix"));
            
            if ((String)firstNameMap.get("subjectIndividualCreationDate") != null && !(firstNameMap.get("subjectIndividualCreationDate").equals(""))){
                       temp = (String)firstNameMap.get("subjectIndividualCreationDate");				   
                       map.put("subjectIndividualCreationDate", temp.substring(0, (temp).indexOf(' ')));				   
            }
            else {
                       map.put("subjectIndividualCreationDate", "");
            }           

            if ((String)firstNameMap.get("subjectIndividualIssuedDate") != null && !(firstNameMap.get("subjectIndividualIssuedDate").equals(""))){
                       temp = (String)firstNameMap.get("subjectIndividualIssuedDate");				   
                       map.put("subjectIndividualIssuedDate", temp.substring(0, (temp).indexOf(' ')));				   
            }
            else {
                       map.put("subjectIndividualIssuedDate", "");
            }           

            if ((String)firstNameMap.get("subjectIndividualExpirationDate") != null && !(firstNameMap.get("subjectIndividualExpirationDate").equals(""))){
                       temp = (String)firstNameMap.get("subjectIndividualExpirationDate");				   
                       map.put("subjectIndividualExpirationDate", temp.substring(0, (temp).indexOf(' ')));				   
            }
            else {
                       map.put("subjectIndividualExpirationDate", "");
            }

            map.put("subjectIndividualRecordStatus", firstNameMap.get("subjectIndividualRecordStatus"));
            map.put("subjectIndividualStaStatus", firstNameMap.get("subjectIndividualStaStatus"));
            map.put("subjectIndividualAlias1", firstNameMap.get("subjectIndividualAlias1"));
            map.put("subjectIndividualAlias2", firstNameMap.get("subjectIndividualAlias2"));
            map.put("subjectIndividualAlias3", firstNameMap.get("subjectIndividualAlias3"));
            map.put("subjectIndividualAddress1", firstNameMap.get("subjectIndividualAddress1"));
            map.put("subjectIndividualAddress2", firstNameMap.get("subjectIndividualAddress2"));
            map.put("subjectIndividualCity", firstNameMap.get("subjectIndividualCity"));
            map.put("subjectIndividualState", firstNameMap.get("subjectIndividualState"));
            map.put("subjectIndividualZipPostalCode", firstNameMap.get("subjectIndividualZipPostalCode"));
            map.put("subjectIndividualCountry", firstNameMap.get("subjectIndividualCountry"));

            theFirstNameMap.add(map);
        }
        
        return (theFirstNameMap);
    }		
   
    public List<Map> convertIacToIacMap(List<Map> list) {
        List<Map> theIacMap = new ArrayList();
        Map map = new HashMap();
        Iterator<Map>  itrList = list.iterator();
        Map iacMap = new HashMap();
		String temp4;
        
        while (itrList.hasNext()) {
            iacMap = (Map)itrList.next();
            map = new HashMap();
						
            map.put("subjectIndividualIacNumber", iacMap.get("subjectIndividualIacNumber"));
            map.put("subjectIndividualIacName", iacMap.get("subjectIndividualIacName"));			            
            map.put("subjectIndividualIacCity", iacMap.get("subjectIndividualIacCity"));
            map.put("subjectIndividualIacState", iacMap.get("subjectIndividualIacState"));

            if ((String)iacMap.get("subjectIndividualIacStartDate") != null && !(iacMap.get("subjectIndividualIacStartDate").equals(""))){
                       temp4 = (String)iacMap.get("subjectIndividualIacStartDate");				   
                       map.put("subjectIndividualIacStartDate", temp4.substring(0, (temp4).indexOf(' ')));				   
            }
            else {
                       map.put("subjectIndividualIacStartDate", "");
            }

            if ((String)iacMap.get("subjectIndividualIacEndDate") != null && !(iacMap.get("subjectIndividualIacEndDate").equals(""))){
                       temp4 = (String)iacMap.get("subjectIndividualIacEndDate");				   
                       map.put("subjectIndividualIacEndDate", temp4.substring(0, (temp4).indexOf(' ')));				   
            }
            else {
                       map.put("subjectIndividualIacEndDate", "");
            }
            theIacMap.add(map);
        }
	return (theIacMap);
    }
	
	public List<Map> convertAgentToAgentMap(List<Map> list) {
        List<Map> theAgentMap = new ArrayList();
        Map map = new HashMap();
        Iterator<Map>  itrList = list.iterator();
        Map agentMap = new HashMap();
		String temp5;
        
        while (itrList.hasNext()) {
            agentMap = (Map)itrList.next();
            map = new HashMap();
						
            map.put("subjectIndividualAgentName", agentMap.get("subjectIndividualAgentName"));
            map.put("subjectIndividualAgentId", agentMap.get("subjectIndividualAgentId"));
            map.put("subjectIndividualPartyId", agentMap.get("subjectIndividualPartyId"));
            map.put("subjectIndividualAgentCity", agentMap.get("subjectIndividualAgentCity"));
			map.put("subjectIndividualAgentState", agentMap.get("subjectIndividualAgentState"));
            map.put("subjectIndividualAgentAssociatedIac", agentMap.get("subjectIndividualAgentAssociatedIac"));
			if ((String)agentMap.get("subjectIndividualAgentStartDate") != null && !(agentMap.get("subjectIndividualAgentStartDate").equals(""))){
				   temp5 = (String)agentMap.get("subjectIndividualAgentStartDate");				   
				   map.put("subjectIndividualAgentStartDate", temp5.substring(0, (temp5).indexOf(' ')));				   
			}
			else {
				   map.put("subjectIndividualAgentStartDate", "");
			}
			
			if ((String)agentMap.get("subjectIndividualAgentEndDate") != null && !(agentMap.get("subjectIndividualAgentEndDate").equals(""))){
				   temp5 = (String)agentMap.get("subjectIndividualAgentEndDate");				   
				   map.put("subjectIndividualAgentEndDate", temp5.substring(0, (temp5).indexOf(' ')));				   
			}
			else {
				   map.put("subjectIndividualAgentEndDate", "");
			}
			
			theAgentMap.add(map);
        }
		
        return (theAgentMap);
    }
	
	public List<Map> convertAcToAcMap(List<Map> list) {
        List<Map> theAcMap = new ArrayList();
        Map map = new HashMap();
        Iterator<Map>  itrList = list.iterator();
        Map acMap = new HashMap();
		String temp6;
        
        while (itrList.hasNext()) {
            acMap = (Map)itrList.next();
            map = new HashMap();
						
            map.put("subjectIndividualAcName", acMap.get("subjectIndividualAcName"));
            map.put("subjectIndividualPartyId", acMap.get("subjectIndividualPartyId"));
            map.put("subjectIndividualAcCity", acMap.get("subjectIndividualAcCity"));			            
            map.put("subjectIndividualAcState", acMap.get("subjectIndividualAcState"));			
			if ((String)acMap.get("subjectIndividualAcStartDate") != null && !(acMap.get("subjectIndividualAcStartDate").equals(""))){
				   temp6 = (String)acMap.get("subjectIndividualAcStartDate");				   
				   map.put("subjectIndividualAcStartDate", temp6.substring(0, (temp6).indexOf(' ')));				   
			}
			else {
				   map.put("subjectIndividualAcStartDate", "");
			}
			
			if ((String)acMap.get("subjectIndividualAcEndtDate") != null && !(acMap.get("subjectIndividualAcEndtDate").equals(""))){
				   temp6 = (String)acMap.get("subjectIndividualAcEndtDate");				   
				   map.put("subjectIndividualAcEndtDate", temp6.substring(0, (temp6).indexOf(' ')));				   
			}
			else {
				   map.put("subjectIndividualAcEndtDate", "");
			}
			
			theAcMap.add(map);
        }
		
        return (theAcMap);
    }
  
    public String getLoginTimeRoleMsg() {
        return loginTimeRoleMsg;
    }

    public void setLoginTimeRoleMsg(String loginTimeRoleMsg) {
        this.loginTimeRoleMsg = loginTimeRoleMsg;
    }
    
    @Override
    public void setServletRequest(HttpServletRequest request) {
        this.request = request;
    }

    public HttpServletRequest getServletRequest() {
        return this.request;
    }
    
	public void setStaIdMap(List<Map> staIdMap) {
        this.staIdMap = staIdMap;
    }
	
	public void setLastNameMap(List<Map> lastNameMap) {
        this.lastNameMap = lastNameMap;
    }
	
	public void setFirstNameMap(List<Map> firstNameMap) {
        this.firstNameMap = firstNameMap;
    }
	
    public void setSubjectIndividualList(List<Map> subjectIndividualList) {
        this.subjectIndividualList = subjectIndividualList;
    }    	
	
	public void setResidentialPhysicalMap(List<Map> residentialPhysicalMap) {
        this.residentialPhysicalMap = residentialPhysicalMap;
    }
	
	public void setPersonalInforList(List<Map> personalInforList) {
        this.personalInforList = personalInforList;
    }
	
	public void setCznInforList(List<Map> cznInforList) {
        this.cznInforList = cznInforList;
    }
		
	public void setIacMap(List<Map> iacMap) {
        this.iacMap = iacMap;
    }
	
	public void setAgentMap(List<Map> agentMap) {
        this.agentMap = agentMap;
    }
	
    public void setAcMap(List<Map> acMap) {
        this.acMap = acMap;
    }
	
	public void setPersonalMap(List<Map> personalMap) {
        this.personalMap = personalMap;
    }
	
	public void setCitizenshipMap(List<Map> citizenshipMap) {
        this.citizenshipMap = citizenshipMap;
    }
	
	public List<Map> getPersonalMap() {
        return personalMap;
    }
	
	public List<Map> getCitizenshipMap() {
        return citizenshipMap;
    }
	
	public String getSubjectIndividualStaId() {
        if (subjectIndividualStaId == null){
            this.subjectIndividualStaId = "";
	}
		
	return StringEscapeUtils.unescapeHtml4(subjectIndividualStaId);
    }
	
	public String getSubjectIndividualPersonName() {
        if (subjectIndividualPersonName == null){
            this.subjectIndividualPersonName = "";
	}
		
	return StringEscapeUtils.unescapeHtml4(subjectIndividualPersonName);
    }
	
	public void setSubjectIndividualStaId(String subjectIndividualStaId) {
	this.subjectIndividualStaId = subjectIndividualStaId;
    } 
	
	public void setSubjectIndividualPersonName(String subjectIndividualPersonName) {
	this.subjectIndividualPersonName = subjectIndividualPersonName;
    }
	
    public String getSubjectIndividualRecordStatus() {
        if (subjectIndividualRecordStatus == null){
            this.subjectIndividualRecordStatus = "";
	}
		
	return StringEscapeUtils.unescapeHtml4(subjectIndividualRecordStatus);
    }
    
    public void setSubjectIndividualRecordStatus(String subjectIndividualRecordStatus) {
	this.subjectIndividualRecordStatus = subjectIndividualRecordStatus;
    }  
    
	public List<Map> getStaIdMap() {
        return staIdMap;
    }
	
	public List<Map> getLastNameMap() {
        return lastNameMap;
    }
	
	public List<Map> getFirstNameMap() {
        return firstNameMap;
    }
	
	public String getSubjectIndividualStaStatus() {
        if (subjectIndividualStaStatus == null){
            this.subjectIndividualStaStatus = "";
	}
		
	return StringEscapeUtils.unescapeHtml4(subjectIndividualStaStatus);
    }
    
    public void setSubjectIndividualStaStatus(String subjectIndividualStaStatus) {
	this.subjectIndividualStaStatus = subjectIndividualStaStatus;
    } 		  
	
	public String getSubjectIndividualResidentialPhysicalCountry() {
        if (subjectIndividualResidentialPhysicalCountry == null){
            this.subjectIndividualResidentialPhysicalCountry = "";
	}
		
	return StringEscapeUtils.unescapeHtml4(subjectIndividualResidentialPhysicalCountry);
    }
    
    public void setSubjectIndividualResidentialPhysicalCountry(String subjectIndividualResidentialPhysicalCountry){
	this.subjectIndividualResidentialPhysicalCountry = subjectIndividualResidentialPhysicalCountry;
    }
	
	public String getSubjectIndividualResidentialPhysicalStartDate() {
        if (subjectIndividualResidentialPhysicalStartDate == null){
            this.subjectIndividualResidentialPhysicalStartDate = "";
	}
		
	return StringEscapeUtils.unescapeHtml4(subjectIndividualResidentialPhysicalStartDate);
    }
    
    public void setSubjectIndividualResidentialPhysicalStartDate(String subjectIndividualResidentialPhysicalStartDate) {
	this.subjectIndividualResidentialPhysicalStartDate = subjectIndividualResidentialPhysicalStartDate;
    }
	
	public String getSubjectIndividualExpirationDate() {
        if (subjectIndividualExpirationDate == null){
            this.subjectIndividualExpirationDate = "";
	}
		
	return StringEscapeUtils.unescapeHtml4(subjectIndividualExpirationDate);
    }
    
    public void setSubjectIndividualExpirationDate(String subjectIndividualExpirationDate) {
	this.subjectIndividualExpirationDate = subjectIndividualExpirationDate;
    }
	
	public String getSubjectIndividualResidentialPhysicalEndDate() {
        if (subjectIndividualResidentialPhysicalEndDate == null){
            this.subjectIndividualResidentialPhysicalEndDate = "";
	}
		
	return StringEscapeUtils.unescapeHtml4(subjectIndividualResidentialPhysicalEndDate);
    }
    
    public void setSubjectIndividualResidentialPhysicalEndDate(String subjectIndividualResidentialPhysicalEndDate) {
	this.subjectIndividualResidentialPhysicalEndDate = subjectIndividualResidentialPhysicalEndDate;
    }  
       
	public void setSubjectIndividualRephyList(List<Map> subjectIndividualRePhyList) {
        this.subjectIndividualRePhyList = subjectIndividualRePhyList;
    }
	
	public List<Map> getSubjectIndividualRePhyList() {
        return subjectIndividualRePhyList;
    }
	
	public void setSubjectIndividualIacList(List<Map> subjectIndividualIacList) {
        this.subjectIndividualIacList = subjectIndividualIacList;
    }
	
	public List<Map> getSubjectIndividualIacList() {
        return subjectIndividualIacList;
    }
			
	
	public void setSubjectIndividualAgentsList(List<Map> subjectIndividualAgentsList) {
        this.subjectIndividualAgentsList = subjectIndividualAgentsList;
    }
	
	public List<Map> getSubjectIndividualAgentsList() {
        return subjectIndividualAgentsList;
    }		
		
	public void setSubjectIndividualAcList(List<Map> subjectIndividualAcList) {
        this.subjectIndividualAcList = subjectIndividualAcList;
    }
	
	public List<Map> getSubjectIndividualAcList() {
        return subjectIndividualAcList;
    }	
	
    public List<Map> getSubjectIndividualList() {
        return subjectIndividualList;
    }
	
	public List<Map> getResidentialPhysicalMap() {
        return residentialPhysicalMap;
    }

	public List<Map> getPersonalInforList() {
        return personalInforList;
    }
	
	public List<Map> getCznInforList() {
        return cznInforList;
    }
		
	public List<Map> getIacMap() {
        return iacMap;
    }
	
	public List<Map> getAgentMap() {
        return agentMap;
    }
	
	public List<Map> getAcMap() {
        return acMap;
    }
	
    public String getSubjectIndividualCreationDate() {
        if (subjectIndividualCreationDate == null){
            this.subjectIndividualCreationDate = "";
	}
		
	return StringEscapeUtils.unescapeHtml4(subjectIndividualCreationDate);
    }
    
    public void setSubjectIndividualCreationDate(String  subjectIndividualCreationDate) {
	this.subjectIndividualCreationDate =  subjectIndividualCreationDate;
    }     
    
    public String getSubjectIndividualIssuedDate() {
        if (subjectIndividualIssuedDate == null){
            this.subjectIndividualIssuedDate = "";
	}
		
	return StringEscapeUtils.unescapeHtml4(subjectIndividualIssuedDate);
    }
    
    public void setSubjectIndividualIssuedDate(String subjectIndividualIssuedDate) {
	this.subjectIndividualIssuedDate = subjectIndividualIssuedDate;
    }  
        
	public String getSubjectIndividualFirstName() {
        if (subjectIndividualFirstName == null){
            this.subjectIndividualFirstName = "";
	}
		
	return StringEscapeUtils.unescapeHtml4(subjectIndividualFirstName);	
    }
    
    public void setSubjectIndividualFirstName(String subjectIndividualFirstName) {
	this.subjectIndividualFirstName = subjectIndividualFirstName;
    }
	
    public String getSubjectIndividualLastName() {
        if (subjectIndividualLastName == null){
            this.subjectIndividualLastName = "";
	}
		
	return StringEscapeUtils.unescapeHtml4(subjectIndividualLastName);	
    }
    
    public void setSubjectIndividualLastName(String subjectIndividualLastName) {
	this.subjectIndividualLastName = subjectIndividualLastName;
    }	
    
	public String getSubjectIndividualResidentialPhysicalCity() {
        if (subjectIndividualResidentialPhysicalCity == null){
            this.subjectIndividualResidentialPhysicalCity = "";
	}
		
	return StringEscapeUtils.unescapeHtml4(subjectIndividualResidentialPhysicalCity);	
    }	
	
    public void setSubjectIndividualResidentialPhysicalCity(String subjectIndividualResidentialPhysicalCity) {
	this.subjectIndividualResidentialPhysicalCity = subjectIndividualResidentialPhysicalCity;
    }
	
	public String getSubjectIndividualResidentialPhysicalState() {
        if (subjectIndividualResidentialPhysicalState == null){
            this.subjectIndividualResidentialPhysicalState = "";
	}
		
	return StringEscapeUtils.unescapeHtml4(subjectIndividualResidentialPhysicalState);	
    }
    
    public void setSubjectIndividualResidentialPhysicalState(String subjectIndividualResidentialPhysicalState) {
	this.subjectIndividualResidentialPhysicalState = subjectIndividualResidentialPhysicalState;
    }
	
	public String getSubjectIndividualResidentialPhysicalZipPostalCode() {
        if (subjectIndividualResidentialPhysicalZipPostalCode == null){
            this.subjectIndividualResidentialPhysicalZipPostalCode = "";
	}
		
	return StringEscapeUtils.unescapeHtml4(subjectIndividualResidentialPhysicalZipPostalCode);	
    }
    
    public void setSubjectIndividualResidentialPhysicalZipPostalCode(String subjectIndividualResidentialPhysicalZipPostalCode) {
	this.subjectIndividualResidentialPhysicalZipPostalCode = subjectIndividualResidentialPhysicalZipPostalCode;
    }
	
    public String getSubjectIndividualSuffix() {
        if (subjectIndividualSuffix == null){
            this.subjectIndividualSuffix = "";
	}
    
	return StringEscapeUtils.unescapeHtml4(subjectIndividualSuffix);	
	}

    public void setSubjectIndividualSuffix(String subjectIndividualSuffix) {
        this.subjectIndividualSuffix = subjectIndividualSuffix;
    }
    
    public String getSubjectIndividualMiddleName() {
	    if (subjectIndividualMiddleName == null){
            this.subjectIndividualMiddleName = "";
	}
	
    return StringEscapeUtils.unescapeHtml4(subjectIndividualMiddleName);	
    }

    public void setSubjectIndividualMiddleName(String subjectIndividualMiddleName) {
        this.subjectIndividualMiddleName = subjectIndividualMiddleName;
    }
            
    public String getSubjectIndividualAddress1() {
	    if (subjectIndividualAddress1 == null){
            this.subjectIndividualAddress1 = "";
	}
	
    return StringEscapeUtils.unescapeHtml4(subjectIndividualAddress1);	
    }

    public void setSubjectIndividualAddress1(String subjectIndividualAddress1) {
        this.subjectIndividualAddress1 = subjectIndividualAddress1;
    } 
	
	public String getSubjectIndividualAddress2() {
	    if (subjectIndividualAddress2 == null){
            this.subjectIndividualAddress2 = "";
	}
	
    return StringEscapeUtils.unescapeHtml4(subjectIndividualAddress2);	
    }

    public void setSubjectIndividualAddress2(String subjectIndividualAddress2) {
        this.subjectIndividualAddress2 = subjectIndividualAddress2;
    } 

	public String getSubjectIndividualAlias1() {
	    if (subjectIndividualAlias1 == null){
            this.subjectIndividualAlias1 = "";
	}
	
    return StringEscapeUtils.unescapeHtml4(subjectIndividualAlias1);	
    }

    public void setSubjectIndividualAlias1(String subjectIndividualAlias1) {
        this.subjectIndividualAlias1 = subjectIndividualAlias1;
    } 
	
	public String getSubjectIndividualAlias2() {
	    if (subjectIndividualAlias2 == null){
            this.subjectIndividualAlias2 = "";
	}
	
    return StringEscapeUtils.unescapeHtml4(subjectIndividualAlias2);	
    }

    public void setSubjectIndividualAlias2(String subjectIndividualAlias2) {
        this.subjectIndividualAlias2 = subjectIndividualAlias2;
    } 
    
	public String getSubjectIndividualAlias3() {
	    if (subjectIndividualAlias3 == null){
            this.subjectIndividualAlias3 = "";
	}
	
    return StringEscapeUtils.unescapeHtml4(subjectIndividualAlias3);	
    }

    public void setSubjectIndividualAlias3(String subjectIndividualAlias3) {
        this.subjectIndividualAlias3 = subjectIndividualAlias3;
    } 
	
    public String getSubjectIndividualCity() {
	if (subjectIndividualCity == null){
            this.subjectIndividualCity = "";
	}
	
    return StringEscapeUtils.unescapeHtml4(subjectIndividualCity); 	
    }

    public void setSubjectIndividualCity(String subjectIndividualCity) {
        this.subjectIndividualCity = subjectIndividualCity;
    }
    
    public String getSubjectIndividualState() {
	if (subjectIndividualState == null){
            this.subjectIndividualState = "";
	}
	
    return StringEscapeUtils.unescapeHtml4(subjectIndividualState);	
    }

    public void setSubjectIndividualState(String subjectIndividualState) {
        this.subjectIndividualState = subjectIndividualState;
    }
    
    public String getSubjectIndividualZipPostalCode() {
	if (subjectIndividualZipPostalCode == null){
            this.subjectIndividualZipPostalCode = "";
	}
	
    return StringEscapeUtils.unescapeHtml4(subjectIndividualZipPostalCode);	
    }

    public void setSubjectIndividualZipPostalCode(String subjectIndividualZipPostalCode) {
        this.subjectIndividualZipPostalCode = subjectIndividualZipPostalCode;
    }
    	
    public String getSubjectIndividualResidentialPhysicalAddress() {
	if (subjectIndividualResidentialPhysicalAddress == null){
            this.subjectIndividualResidentialPhysicalAddress = "";
	}
	
    return StringEscapeUtils.unescapeHtml4(subjectIndividualResidentialPhysicalAddress);	
    }	
	
    public void setSubjectIndividualResidentialPhysicalAddress(String subjectIndividualResidentialPhysicalAddress) {
        this.subjectIndividualResidentialPhysicalAddress = subjectIndividualResidentialPhysicalAddress;
    }
	
	public String getSubjectIndividualCountry() {
	if (subjectIndividualCountry == null){
            this.subjectIndividualCountry = "";
	}
	
    return StringEscapeUtils.unescapeHtml4(subjectIndividualCountry);	
    }

    public void setSubjectIndividualCountry(String subjectIndividualCountry) {
        this.subjectIndividualCountry = subjectIndividualCountry;
    } 

	public String getSubjectIndividualGender() {
	if (subjectIndividualGender == null){
            this.subjectIndividualGender = "";
	}
	
    return StringEscapeUtils.unescapeHtml4(subjectIndividualGender);	
    }

    public void setSubjectIndividualGender(String subjectIndividualGender) {
        this.subjectIndividualGender = subjectIndividualGender;
    }
 
	public String getSubjectIndividualAgentName() {
	if (subjectIndividualAgentName == null){
            this.subjectIndividualAgentName = "";
	}
	
    return StringEscapeUtils.unescapeHtml4(subjectIndividualAgentName);	
    }

    public void setSubjectIndividualAgentName(String subjectIndividualAgentName) {
        this.subjectIndividualAgentName = subjectIndividualAgentName;
    }
	
	public String getSubjectIndividualAgentId() {
	if (subjectIndividualAgentId == null){
            this.subjectIndividualAgentId = "";
	}
	
    return StringEscapeUtils.unescapeHtml4(subjectIndividualAgentId);	
    }

    public void setSubjectIndividualAgentId(String subjectIndividualAgentId) {
        this.subjectIndividualAgentId = subjectIndividualAgentId;
    }
    
    public String getSubjectIndividualPartyId() {
	if (subjectIndividualPartyId == null){
            this.subjectIndividualPartyId = "";
	}
	
    return StringEscapeUtils.unescapeHtml4(subjectIndividualPartyId);	
    }

    public void setSubjectIndividualPartyId(String subjectIndividualPartyId) {
        this.subjectIndividualPartyId = subjectIndividualPartyId;
    }
	
	public String getSubjectIndividualAgentCity() {
	if (subjectIndividualAgentCity == null){
            this.subjectIndividualAgentCity = "";
	}
	
    return StringEscapeUtils.unescapeHtml4(subjectIndividualAgentCity);	
    }

    public void setSubjectIndividualAgentCity(String subjectIndividualAgentCity) {
        this.subjectIndividualAgentCity = subjectIndividualAgentCity;
    }			
	
	public String getSubjectIndividualAgentState() {
	if (subjectIndividualAgentState == null){
            this.subjectIndividualAgentState = "";
	}
	
    return StringEscapeUtils.unescapeHtml4(subjectIndividualAgentState);	
    }

    public void setSubjectIndividualAgentState(String subjectIndividualAgentState) {
        this.subjectIndividualAgentState = subjectIndividualAgentState;
    }
	
	public String getSubjectIndividualAgentAssociatedIac() {
	if (subjectIndividualAgentAssociatedIac == null){
            this.subjectIndividualAgentAssociatedIac = "";
	}
	
    return StringEscapeUtils.unescapeHtml4(subjectIndividualAgentAssociatedIac);	
    }

    public void setSubjectIndividualAgentAssociatedIac(String subjectIndividualAgentAssociatedIac) {
        this.subjectIndividualAgentAssociatedIac = subjectIndividualAgentAssociatedIac;
    }
	
	public String getSubjectIndividualAgentStartDate() {
	if (subjectIndividualAgentStartDate == null){
            this.subjectIndividualAgentStartDate = "";
	}
	
    return StringEscapeUtils.unescapeHtml4(subjectIndividualAgentStartDate);	
    }

    public void setSubjectIndividualAgentStartDate(String subjectIndividualAgentStartDate) {
        this.subjectIndividualAgentStartDate = subjectIndividualAgentStartDate;
    }
	
	public String getSubjectIndividualAgentEndDate() {
	if (subjectIndividualAgentEndDate == null){
            this.subjectIndividualAgentEndDate = "";
	}
	
    return StringEscapeUtils.unescapeHtml4(subjectIndividualAgentEndDate);	
    }

    public void setSubjectIndividualAgentEndDate(String subjectIndividualAgentEndDate) {
        this.subjectIndividualAgentEndDate = subjectIndividualAgentEndDate;
    }
	
	public String getSubjectIndividualAcName() {
	if (subjectIndividualAcName == null){
            this.subjectIndividualAcName = "";
	}
	
    return StringEscapeUtils.unescapeHtml4(subjectIndividualAcName);	
    }

    public void setSubjectIndividualAcName(String subjectIndividualAcName) {
        this.subjectIndividualAcName = subjectIndividualAcName;
    }
	
	public String getSubjectIndividualAcCity() {
	if (subjectIndividualAcCity == null){
            this.subjectIndividualAcCity = "";
	}
	
    return StringEscapeUtils.unescapeHtml4(subjectIndividualAcCity);	
    }

    public void setSubjectIndividualAcCity(String subjectIndividualAcCity) {
        this.subjectIndividualAcCity = subjectIndividualAcCity;
    }
	
	public String getSubjectIndividualAcState() {
	if (subjectIndividualAcState == null){
            this.subjectIndividualAcState = "";
	}
	
    return StringEscapeUtils.unescapeHtml4(subjectIndividualAcState);	
    }

    public void setSubjectIndividualAcState(String subjectIndividualAcState) {
        this.subjectIndividualAcState = subjectIndividualAcState;
    }
	
	public String getsubjectIndividualAcStartDate() {
	if (subjectIndividualAcStartDate == null){
            this.subjectIndividualAcStartDate = "";
	}
	
    return StringEscapeUtils.unescapeHtml4(subjectIndividualAcStartDate);	
    }

    public void setSubjectIndividualAcStartDate(String subjectIndividualAcStartDate) {
        this.subjectIndividualAcStartDate = subjectIndividualAcStartDate;
    }
	
	public String getSubjectIndividualAcEndtDate() {
	if (subjectIndividualAcEndtDate == null){
            this.subjectIndividualAcEndtDate = "";
	}
	
    return StringEscapeUtils.unescapeHtml4(subjectIndividualAcEndtDate);	
    }

    public void setSubjectIndividualAcEndtDate(String subjectIndividualAcEndtDate) {
        this.subjectIndividualAcEndtDate = subjectIndividualAcEndtDate;
    }
	
	public String getSubjectIndividualIacNumber() {
	if (subjectIndividualIacNumber == null){
            this.subjectIndividualIacNumber = "";
	}
	
    return StringEscapeUtils.unescapeHtml4(subjectIndividualIacNumber);	
    }

    public void setSubjectIndividualIacNumber(String subjectIndividualIacNumber) {
        this.subjectIndividualIacNumber = subjectIndividualIacNumber;
    }
	
	public String getSubjectIndividualIacName() {
	if (subjectIndividualIacName == null){
            this.subjectIndividualIacName = "";
	}
	
    return StringEscapeUtils.unescapeHtml4(subjectIndividualIacName);	
    }

    public void setSubjectIndividualIacName(String subjectIndividualIacName) {
        this.subjectIndividualIacName = subjectIndividualIacName;
    }
	
	public String getSubjectIndividualIacCity() {
	if (subjectIndividualIacCity == null){
            this.subjectIndividualIacCity = "";
	}
	
    return StringEscapeUtils.unescapeHtml4(subjectIndividualIacCity);	
    }

    public void setSubjectIndividualIacCity(String subjectIndividualIacCity) {
        this.subjectIndividualIacCity = subjectIndividualIacCity;
    }
	
	public String getSubjectIndividualIacState() {
	if (subjectIndividualIacState == null){
            this.subjectIndividualIacState = "";
	}
	
    return StringEscapeUtils.unescapeHtml4(subjectIndividualIacState);	
    }

    public void setSubjectIndividualIacState(String subjectIndividualIacState) {
        this.subjectIndividualIacState = subjectIndividualIacState;
    }
	
	public String getSubjectIndividualIacStartDate() {
	if (subjectIndividualIacStartDate == null){
            this.subjectIndividualIacStartDate = "";
	}
	
    return StringEscapeUtils.unescapeHtml4(subjectIndividualIacStartDate);	
    }

    public void setSubjectIndividualIacStartDate(String subjectIndividualIacStartDate) {
        this.subjectIndividualIacStartDate = subjectIndividualIacStartDate;
    }
	
	public String getSubjectIndividualIacEndDate() {
	if (subjectIndividualIacEndDate == null){
            this.subjectIndividualIacEndDate = "";
	}
	
    return StringEscapeUtils.unescapeHtml4(subjectIndividualIacEndDate);	
    }

    public void setSubjectIndividualIacEndDate(String subjectIndividualIacEndDate) {
        this.subjectIndividualIacEndDate = subjectIndividualIacEndDate;
    }

	public String getSubjectIndividualCountryOfCitizenship() {
	if (subjectIndividualCountryOfCitizenship == null){
            this.subjectIndividualCountryOfCitizenship = "";
	}
	
    return StringEscapeUtils.unescapeHtml4(subjectIndividualCountryOfCitizenship);	
    }

    public void setSubjectIndividualCountryOfCitizenship(String subjectIndividualCountryOfCitizenship) {
        this.subjectIndividualCountryOfCitizenship = subjectIndividualCountryOfCitizenship;
    }
	
	public String getSubjectIndividualAlienNumber() {
	if (subjectIndividualAlienNumber == null){
            this.subjectIndividualAlienNumber = "";
	}
	
    return StringEscapeUtils.unescapeHtml4(subjectIndividualAlienNumber);	
    }

    public void setSubjectIndividualAlienNumber(String subjectIndividualAlienNumber) {
        this.subjectIndividualAlienNumber = subjectIndividualAlienNumber;
    }
	
	public String getSubjectIndividualNaturalizationDate() {
	if (subjectIndividualNaturalizationDate == null){
            this.subjectIndividualNaturalizationDate = "";
	}
	
    return StringEscapeUtils.unescapeHtml4(subjectIndividualNaturalizationDate);	
    }

    public void setSubjectIndividualNaturalizationDate(String subjectIndividualNaturalizationDate) {
        this.subjectIndividualNaturalizationDate = subjectIndividualNaturalizationDate;
    }
	
	public String getSubjectIndividualNaturalizationNumber() {
	if (subjectIndividualNaturalizationNumber == null){
            this.subjectIndividualNaturalizationNumber = "";
	}
	
    return StringEscapeUtils.unescapeHtml4(subjectIndividualNaturalizationNumber);	
    }

    public void setSubjectIndividualNaturalizationNumber(String subjectIndividualNaturalizationNumber) {
        this.subjectIndividualNaturalizationNumber = subjectIndividualNaturalizationNumber;
    }
	
	public String getSubjectIndividualUsPassportNumber() {
	if (subjectIndividualUsPassportNumber == null){
            this.subjectIndividualUsPassportNumber = "";
	}
	
    return StringEscapeUtils.unescapeHtml4(subjectIndividualUsPassportNumber);	
    }

    public void setSubjectIndividualUsPassportNumber(String subjectIndividualUsPassportNumber) {
        this.subjectIndividualUsPassportNumber = subjectIndividualUsPassportNumber;
    }
	
	public String getSubjectIndividualBirthAbroadCertificationNumber() {
	if (subjectIndividualBirthAbroadCertificationNumber == null){
            this.subjectIndividualBirthAbroadCertificationNumber = "";
	}
	
    return StringEscapeUtils.unescapeHtml4(subjectIndividualBirthAbroadCertificationNumber);	
    }

    public void setSubjectIndividualBirthAbroadCertificationNumber(String subjectIndividualBirthAbroadCertificationNumber) {
        this.subjectIndividualBirthAbroadCertificationNumber = subjectIndividualBirthAbroadCertificationNumber;
    }
	
    public String getSubjectIndividualSsn() {
	if (subjectIndividualSsn == null){
            this.subjectIndividualSsn = "";
	}
	
        return StringEscapeUtils.unescapeHtml4(subjectIndividualSsn);	
    }

    public void setSubjectIndividualSsn(String subjectIndividualSsn) {
        this.subjectIndividualSsn = subjectIndividualSsn;
    }
    
    public String getSubjectIndividualSsnLastFour() {
	if (subjectIndividualSsnLastFour == null){
            this.subjectIndividualSsnLastFour = "";
	}
	
        return StringEscapeUtils.unescapeHtml4(subjectIndividualSsnLastFour);	
    }

    public void setSubjectIndividualSsnLastFour(String subjectIndividualSsnLastFour) {
        this.subjectIndividualSsnLastFour = subjectIndividualSsnLastFour;
    }
	
	public String getSubjectIndividualDateOfBirth() {
	if (subjectIndividualDateOfBirth == null){
            this.subjectIndividualDateOfBirth = "";
	}
	
    return StringEscapeUtils.unescapeHtml4(subjectIndividualDateOfBirth);	
    }

    public void setSubjectIndividualDateOfBirth(String subjectIndividualDateOfBirth) {
        this.subjectIndividualDateOfBirth = subjectIndividualDateOfBirth;
    }
	
	public String getSubjectIndividualBirthCity() {
	if (subjectIndividualBirthCity == null){
            this.subjectIndividualBirthCity = "";
	}
	
    return StringEscapeUtils.unescapeHtml4(subjectIndividualBirthCity);	
    }

    public void setSubjectIndividualBirthCity(String subjectIndividualBirthCity) {
        this.subjectIndividualBirthCity = subjectIndividualBirthCity;
    }
	
	public String getSubjectIndividualBirthState() {
	if (subjectIndividualBirthState == null){
            this.subjectIndividualBirthState = "";
	}
	
    return StringEscapeUtils.unescapeHtml4(subjectIndividualBirthState);	
    }

    public void setSubjectIndividualBirthState(String subjectIndividualBirthState) {
        this.subjectIndividualBirthState = subjectIndividualBirthState;
    }
	
	public String getSubjectIndividualBirthCountry() {
	if (subjectIndividualBirthCountry == null){
            this.subjectIndividualBirthCountry = "";
	}
	
    return StringEscapeUtils.unescapeHtml4(subjectIndividualBirthCountry);	
    }

    public void setSubjectIndividualBirthCountry(String subjectIndividualBirthCountry) {
        this.subjectIndividualBirthCountry = subjectIndividualBirthCountry;
    }
    
    private String convertToSsnLastFour (String inputStr){
        String outputStr="";
        int i;
        if (inputStr != null){
            for (i=0; i<inputStr.length(); i++){
                if ((i==3) || (i==6)){
                    outputStr = outputStr + inputStr.substring(i, (i+1));
                } else if (i<=6){
                    outputStr = outputStr + 'X';
                } else {
                    outputStr = outputStr + inputStr.substring(i, (i+1));
                }
            }
        }
        
        return (outputStr);
    }	
}
