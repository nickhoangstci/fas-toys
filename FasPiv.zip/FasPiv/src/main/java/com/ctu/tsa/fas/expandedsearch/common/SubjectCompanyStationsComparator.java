/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ctu.tsa.fas.expandedsearch.common;
import java.io.Serializable;
import java.util.Comparator;

import org.apache.log4j.Logger;
import com.ctu.tsa.fas.expandedsearch.model.SubjectCompanyStationsModel;

/**
 *
 * @author Binh.Nguyen
 */
public class SubjectCompanyStationsComparator implements Comparator<SubjectCompanyStationsModel>, Serializable{
    private static final long serialVersionUID = 1L;

    private Logger logger = Logger.getLogger(SubjectCompanyStationsComparator.class);
    private boolean isAscendingStations;
    private String colName;
    
    public SubjectCompanyStationsComparator(String colName, boolean isAscendingStations) {
	this.isAscendingStations = isAscendingStations;
	this.colName = colName;
    }
    
    @SuppressWarnings("unchecked")
    public int compare(SubjectCompanyStationsModel o1, SubjectCompanyStationsModel o2) {
        int result = 0;
        
        try {
            Object value1 = null;
            Object value2 = null;
            
            if (colName.equalsIgnoreCase("firstName")) {
		      value1 = o1.getFirstName();
		      value2 = o2.getFirstName();
            } else if (colName.equalsIgnoreCase("middleName")) {
		      value1 = o1.getMiddleName();
              value2 = o2.getMiddleName();
			} else if (colName.equalsIgnoreCase("lastName")) {
		      value1 = o1.getLastName();
              value2 = o2.getLastName();		  
            } else if (colName.equalsIgnoreCase("emailAddress")) {
		      value1 = o1.getEmailAddress();
              value2 = o2.getEmailAddress();
			} else if (colName.equalsIgnoreCase("workPhoneNumber")) {
		      value1 = o1.getWorkPhoneNumber();
              value2 = o2.getWorkPhoneNumber();			  
			} else if (colName.equalsIgnoreCase("h24HourPhoneNumber")) {
		      value1 = o1.getH24HourPhoneNumber();
              value2 = o2.getH24HourPhoneNumber();		              
            } else {
		      logger.warn("Could not map " + colName + " to class attribute");
            }
            
            // Null is lesser than anything else.
            if ((value1 == null) && (value2 == null)) {
		      result = 0;
            } else if ((value1 == null) && (value2 != null)) {
		      result = -1;
            } else if ((value1 != null) && (value2 == null)) {
		      result = 1;
            } else if (value1 instanceof Comparable) {
		    // the attribute values are Comparable, we have hit the JackPot.  We have absolutely nothing intelligent to do
		      @SuppressWarnings("rawtypes")
		      Comparable comp1 = (Comparable) value1;
		      @SuppressWarnings("rawtypes")
		      Comparable comp2 = (Comparable) value2;
		      result = comp1.compareTo(comp2);
            } else {
		       logger.warn("Dont know how to sort by " + colName);
            }
			
            if (!isAscendingStations) {
		       result = 0 - result;
            }			
        }    			
        catch (Exception ex) {
            logger.error("Exception : " + ex.getMessage());
	} 
	
    return result;
	
    }
}
