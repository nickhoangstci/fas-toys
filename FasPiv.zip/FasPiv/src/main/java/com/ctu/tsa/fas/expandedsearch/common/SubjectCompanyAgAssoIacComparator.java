/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ctu.tsa.fas.expandedsearch.common;
import java.io.Serializable;
import java.util.Comparator;

import org.apache.log4j.Logger;
import com.ctu.tsa.fas.expandedsearch.model.SubjectCompanyAgAssoIacModel;

/**
 *
 * @author Binh.Nguyen
 */
public class SubjectCompanyAgAssoIacComparator implements Comparator<SubjectCompanyAgAssoIacModel>, Serializable{
    private static final long serialVersionUID = 1L;

    private Logger logger = Logger.getLogger(SubjectCompanyAgAssoIacComparator.class);
    private boolean isAscendingAgAssoIac;
    private String colName;
    
    public SubjectCompanyAgAssoIacComparator(String colName, boolean isAscendingAgAssoIac) {
	this.isAscendingAgAssoIac = isAscendingAgAssoIac;
	this.colName = colName;
    }
    
    @SuppressWarnings("unchecked")
    public int compare(SubjectCompanyAgAssoIacModel o1, SubjectCompanyAgAssoIacModel o2) {
        int result = 0;
        
        try {
            Object value1 = null;
            Object value2 = null;
            
            if (colName.equalsIgnoreCase("iacId")) {
		      value1 = o1.getIacId();
		      value2 = o2.getIacId();            
			} else if (colName.equalsIgnoreCase("iacName")) {
		      value1 = o1.getIacName();
              value2 = o2.getIacName();		  
            } else if (colName.equalsIgnoreCase("city")) {
		      value1 = o1.getCity();
              value2 = o2.getCity();
			} else if (colName.equalsIgnoreCase("state")) {
		      value1 = o1.getState();
              value2 = o2.getState();			  
			} else if (colName.equalsIgnoreCase("status")) {
		      value1 = o1.getStatus();
              value2 = o2.getStatus();
			} else if (colName.equalsIgnoreCase("expired")) {
		      value1 = o1.getExpired();
              value2 = o2.getExpired();  
            } else {
		      logger.warn("Could not map " + colName + " to class attribute");
            }
            
            // Null is lesser than anything else.
            if ((value1 == null) && (value2 == null)) {
		      result = 0;
            } else if ((value1 == null) && (value2 != null)) {
		      result = -1;
            } else if ((value1 != null) && (value2 == null)) {
		      result = 1;
            } else if (value1 instanceof Comparable) {
		    // the attribute values are Comparable, we have hit the JackPot.  We have absolutely nothing intelligent to do
		      @SuppressWarnings("rawtypes")
		      Comparable comp1 = (Comparable) value1;
		      @SuppressWarnings("rawtypes")
		      Comparable comp2 = (Comparable) value2;
		      result = comp1.compareTo(comp2);
            } else {
		       logger.warn("Dont know how to sort by " + colName);
            }
			
            if (!isAscendingAgAssoIac) {
		       result = 0 - result;
            }			
        }    			
        catch (Exception ex) {
            logger.error("Exception : " + ex.getMessage());
	} 
	
    return result;
	
    }
}
