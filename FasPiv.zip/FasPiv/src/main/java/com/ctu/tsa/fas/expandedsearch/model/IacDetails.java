/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ctu.tsa.fas.expandedsearch.model;

import java.io.Serializable;

/**
 *
 * @author Binh.Nguyen
 */
public class IacDetails implements Serializable{
    private static final long serialVersionUID = -8767337899673261247L;

    private String iacName = "";
    private String iacType = "";
    private String iacId = "";
    private String iacState = "";
    private String iacStatus = "";
    private String iacAddress1 = "";
    private String iacAddress2 = "";
    private String iacCity = "";
    private String iacZipPostalCode = "";
    private String iacSicCode = "";
    private String iacPhone = "";
    private String iacCountry = "";
    private String iacEinNumber = "";
    private String iacKnownAs1 = "";
    private String iacKnownAs2 = "";
    private String iacKnownAs3 = "";
    private String iacFirstName = "";
    private String iacLastName= "";
    private String iacEmail = "";
    private String iacDesignation = "";
    private String iacTitle = "";
    private long iacCredential = 0;
    private String iacInitialApprovalDate = "";
    private String iacLastApprovalDate = "";
    private String iacExpirationDate = "";
    private String iacApprovingAgent = "";
    private String iacComments = "";
	
	private String credential;
    private String firstName;
    private String lastName;
    private String personTitle;
    private String phoneNumber;
    private String emailAddress;
	private String state;
	private String country;
	
	private String partyName;
	private String agentId;
	private String city;	
	private String status;

	private String active;
	
	private String staId;
	private String creationDate;
	private String issuedOnDate;
	private String expiresOnDate;
	private String staStatus;
	
	private String agentName;
	
	public void setAgentName (String agentName) {
		this.agentName = agentName; 
    }
	
	public void setStaId (String staId) {
		this.staId = staId; 
    }
	
	public void setCreationDate (String creationDate) {
		this.creationDate = creationDate; 
    }
	
	public void setIssuedOnDate (String issuedOnDate) {
		this.issuedOnDate = issuedOnDate; 
    }
	
	public void setExpiresOnDate (String expiresOnDate) {
		this.expiresOnDate = expiresOnDate; 
    }
		
	public void setStaStatus (String staStatus) {
		this.staStatus = staStatus; 
    }	
	
	public void setActive (String active) {
		this.active = active; 
    }
	
	public void setPartyName (String partyName) {
		this.partyName = partyName; 
    }
	
	public void setAgentId (String agentId) {
		this.agentId = agentId; 
    }
	
	public void setCity (String city) {
		this.city = city; 
    }
		
	public void setStatus (String status) {
		this.status = status; 
    }
	
	public void setCredential (String credential) {
		this.credential = credential; 
    }
	
	public void setFirstName (String firstName) {
		this.firstName = firstName; 
    }
	
    public void setLastName(String lastName) {
		this.lastName = lastName; 
    }
        
    public void setPersonTitle (String personTitle) {
		this.personTitle = personTitle; 
    }
    
    public void setPhoneNumber(String phoneNumber) {
    	this.phoneNumber = phoneNumber; 
    } 
	
	public void setEmailAddress(String emailAddress) {
    	this.emailAddress = emailAddress; 
    }
	
	public void setState(String state) {
    	this.state = state; 
    }
	
	public void setCountry(String country) {
    	this.country = country; 
    }
	
	public String getAgentName () {
		return (this.agentName); 
    }
	
	public String getStaId () {
		return (this.staId); 
    }
	
	public String getCreationDate () {
		return (this.creationDate); 
    }
	
	public String getIssuedOnDate () {
		return (this.issuedOnDate); 
    }
	
	public String getExpiresOnDate () {
		return (this.expiresOnDate); 
    }
	
	public String getStaStatus () {
		return (this.staStatus); 
    }	
		
	public String getActive () {
		return (this.active); 
    }
	
    public String getPartyName () {
		return (this.partyName); 
    }
	
	public String getAgentId () {
		return (this.agentId); 
    }
	
	public String getCity () {
		return (this.city); 
    }
	
	public String getStatus () {
		return (this.status); 
    }
	
	public String getCredential () {
		return (this.credential); 
    }

    public String getFirstName () {
    	return (this.firstName); 
    }

    public String getLastName () {
        return (this.lastName); 
    }
        
    public String getPersonTitle () {
		return (this.personTitle); 
    }
	
    public String getPhoneNumber () {
		return (this.phoneNumber); 
    }
	
	public String getEmailAddress () {
		return (this.emailAddress); 
    }

	public String getState () {
		return (this.state); 
    }
	
	public String getCountry () {
		return (this.country); 
    }	
	
	public String getIacType() {       	
	return iacType;
    }
    
    public void setIacType(String iacType) {
	this.iacType = iacType;
    }  
    
    public String getIacComments() {       
	return iacComments;
    }
    
    public void setIacComments(String iacComments) {
	this.iacComments = iacComments;
    }  
	
    public String getIacInitialApprovalDate() {      	
	return iacInitialApprovalDate;
    }
    
    public void setIacInitialApprovalDate(String iacInitialApprovalDate) {
	this.iacInitialApprovalDate = iacInitialApprovalDate;
    }
	
    public String getIacLastApprovalDate() {        	
	return iacLastApprovalDate;
    }
    
    public void setIacLastApprovalDate(String iacLastApprovalDate) {
	this.iacLastApprovalDate = iacLastApprovalDate;
    }
	
    public String getIacExpirationDate() {        
	return iacExpirationDate;
    }
    
    public void setIacExpirationDate(String iacExpirationDate) {
	this.iacExpirationDate = iacExpirationDate;
    }
	
    public String getIacApprovingAgent() {       
	return iacApprovingAgent;
    }
    
    public void setIacApprovingAgent(String iacApprovingAgent) {
	this.iacApprovingAgent = iacApprovingAgent;
    }
	
    public String getIacId() {        	
	return iacId;
        
    }
    
    public void setIacId(String iacId) {
	this.iacId = iacId;
    }  
        
    public String getIacName() {       
	return iacName;
    }
    
    public void setIacName(String  iacName) {
	this.iacName =  iacName;
    }     
    
    public String getIacStatus() { 
        if (iacStatus == null){
            this.iacStatus = "";
	}
	return iacStatus;
    }
    
    public void setIacStatus(String iacStatus) {
	this.iacStatus = iacStatus;
    }

    public long getIacCredential() {       
		
	return iacCredential;	
    }
    
    public void setIacCredential(long iacCredential) {
	this.iacCredential = iacCredential;
    }

	public String getIacFirstName() {        
	return iacFirstName;	
    }
    
    public void setIacFirstName(String iacFirstName) {
	this.iacFirstName = iacFirstName;
    }
	
    public String getIacLastName() {       
	return iacLastName;	
    }
    
    public void setIacLastName(String iacLastName) {
	this.iacLastName = iacLastName;
    }	
    
	public String getIacEmail() {        
	return iacEmail;	
    }
    
    public void setIacEmail(String iacEmail) {
	this.iacEmail = iacEmail;
    }
	
	public String getIacDesignation() {       
	return iacDesignation;	
    }
    
    public void setIacDesignation(String iacDesignation) {
	this.iacDesignation = iacDesignation;
    }
	
    public String getIacTitle() {       
	return iacTitle;	
    }
    
    public void setIacTitle(String iacTitle) {
	this.iacTitle = iacTitle;
    }
	
    public String getIacSicCode() {       
	return iacSicCode;	
    }

    public void setIacSicCode(String iacSicCode) {
        this.iacSicCode = iacSicCode;
    }
    
    public String getIacPhone() {	    
        return iacPhone;	
    }

    public void setIacPhone(String iacPhone) {
        this.iacPhone = iacPhone;
    }
            
    public String getIacAddress1() {	    
    return iacAddress1;	
    }

    public void setIacAddress1(String iacAddress1) {
        this.iacAddress1 = iacAddress1;
    } 
	
    public String getIacAddress2() {	    
    return iacAddress2;	
    }

    public void setIacAddress2(String iacAddress2) {
        this.iacAddress2 = iacAddress2;
    } 

    public String getIacKnownAs1() {	    
    return iacKnownAs1;	
    }

    public void setIacKnownAs1(String iacKnownAs1) {
        this.iacKnownAs1 = iacKnownAs1;
    } 
	
    public String getIacKnownAs2() {	    
    return iacKnownAs2;	
    }

    public void setIacKnownAs2(String iacKnownAs2) {
        this.iacKnownAs2 = iacKnownAs2;
    } 
    
    public String getIacKnownAs3() {	    
        return iacKnownAs3;	
    }

    public void setIacKnownAs3(String iacKnownAs3) {
        this.iacKnownAs3 = iacKnownAs3;
    } 
	
    public String getIacCity() {	
        return iacCity; 	
    }

    public void setIacCity(String iacCity) {
        this.iacCity = iacCity;
    }
    
    public String getIacState() {	
        return iacState;	
    }

    public void setIacState(String iacState) {
        this.iacState = iacState;
    }
    
    public String getIacZipPostalCode() {	
        return iacZipPostalCode;	
    }

    public void setIacZipPostalCode(String iacZipPostalCode) {
        this.iacZipPostalCode = iacZipPostalCode;
    }
    	
    public String getIacEinNumber() {	
        return iacEinNumber;	
    }

    public void setIacEinNumber(String iacEinNumber) {
        this.iacEinNumber = iacEinNumber;
    }
	
    public String getIacCountry() {	
        return iacCountry;	
    }

    public void setIacCountry(String iacCountry) {
        this.iacCountry = iacCountry;
    }    
    
    public String toString () {

	String sep = System.getProperty("line.separator");

	StringBuffer buffer = new StringBuffer();
	buffer.append(sep);       
	buffer.append("iacName = ");
	buffer.append(iacName);
	buffer.append(sep);
	buffer.append("iacType = ");
	buffer.append(iacType);
	buffer.append(sep);
	buffer.append("iacId = ");
	buffer.append(iacId);
	buffer.append(sep);
	buffer.append("iacStatus = ");
	buffer.append(iacStatus);
	buffer.append(sep);
    buffer.append("iacState = ");
	buffer.append(iacState);
	buffer.append(sep);				
	buffer.append("iacAddress1 = ");
	buffer.append(iacAddress1);
	buffer.append(sep);
	buffer.append("iacAddress2 = ");
	buffer.append(iacAddress2);
	buffer.append(sep);
	buffer.append("iacCity = ");
	buffer.append(iacCity);
	buffer.append(sep);
	buffer.append("iacZipPostalCode = ");
	buffer.append(iacZipPostalCode);
	buffer.append(sep);
	buffer.append("iacCountry = ");
	buffer.append(iacCountry);
	buffer.append(sep);
	buffer.append("iacPhone = ");
	buffer.append(iacPhone);
	buffer.append(sep);	
    buffer.append("iacEinNumber = ");
	buffer.append(iacEinNumber);
	buffer.append(sep);	
	buffer.append("iacKnownAs1= ");
	buffer.append(iacKnownAs1);
	buffer.append(sep);
	buffer.append("iacKnownAs2= ");
	buffer.append(iacKnownAs2);
	buffer.append(sep);
	buffer.append("iacKnownAs3= ");
	buffer.append(iacKnownAs3);
	buffer.append(sep);
	buffer.append("iacFirstName= ");
	buffer.append(iacFirstName);
	buffer.append(sep);
	buffer.append("iacLastName= ");
	buffer.append(iacLastName);
	buffer.append(sep);
	buffer.append("iacEmail= ");
	buffer.append(iacEmail);
	buffer.append(sep);
	buffer.append("iacDesignation= ");
	buffer.append(iacDesignation);
	buffer.append(sep);
	buffer.append("iacTitle= ");
	buffer.append(iacTitle);
	buffer.append(sep);
	buffer.append("iacCredential= ");
	buffer.append(iacCredential);
	buffer.append(sep);
	buffer.append("iacInitialApprovalDate= ");
	buffer.append(iacInitialApprovalDate);
	buffer.append(sep);
	buffer.append("iacLastApprovalDate= ");
	buffer.append(iacLastApprovalDate);
	buffer.append(sep);
	buffer.append("iacExpirationDate= ");
	buffer.append(iacExpirationDate);
	buffer.append(sep);
	buffer.append("iacApprovingAgent= ");
	buffer.append(iacApprovingAgent);
	buffer.append(sep);
	buffer.append("iacComments= ");
	buffer.append(iacComments);
	buffer.append(sep);		
	buffer.append("credential= ");
	buffer.append(credential);
	buffer.append(sep);
	buffer.append("firstName= ");
	buffer.append(firstName);
	buffer.append(sep);
	buffer.append("lastName= ");
	buffer.append(lastName);
	buffer.append(sep);
	buffer.append("personTitle= ");
	buffer.append(personTitle);
	buffer.append(sep);
	buffer.append("phoneNumber= ");
	buffer.append(phoneNumber);
	buffer.append(sep);
	buffer.append("emailAddress= ");
	buffer.append(emailAddress);
	buffer.append(sep);
	buffer.append("state= ");
	buffer.append(state);
	buffer.append(sep);
	buffer.append("country= ");
	buffer.append(country);
	buffer.append(sep);
	
	buffer.append("staId= ");
	buffer.append(staId);
	buffer.append(sep);
	buffer.append("creationDate= ");
	buffer.append(creationDate);
	buffer.append(sep);
	buffer.append("issuedOnDate= ");
	buffer.append(issuedOnDate);
	buffer.append(sep);
	buffer.append("expiresOnDate= ");
	buffer.append(expiresOnDate);
	buffer.append(sep);
	buffer.append("status= ");
	buffer.append(status);
	buffer.append(sep);
	buffer.append("staStatus= ");
	buffer.append(staStatus);
	buffer.append(sep);			
		
	return buffer.toString();
    }
}
