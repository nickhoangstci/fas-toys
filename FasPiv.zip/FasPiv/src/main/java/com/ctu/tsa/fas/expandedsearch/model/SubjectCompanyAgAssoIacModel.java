/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ctu.tsa.fas.expandedsearch.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

/**
 *
 * @author Binh.Nguyen
 */
public class SubjectCompanyAgAssoIacModel implements Serializable{
    private static final long serialVersionUID = -8767337899673261248L;
    private String iacId;	
	private String iacName;
	private String city;
	private String state;
	private String status;
	private String expired;
		
    public SubjectCompanyAgAssoIacModel() {
    }
        
    public SubjectCompanyAgAssoIacModel(String iacId, String iacName, String city, String state, String status, String expired) {
		this.iacId = iacId;        		      
		this.iacName = iacName;
		this.city = city;
		this.state = state;
		this.status = status;
		this.expired = expired;
    }
    
    public void setIacId (String iacId) {
		this.iacId = iacId; 
    }			
	
	public void setIacName (String iacName) {
		this.iacName = iacName; 
    }
	
	public void setCity (String city) {
		this.city = city; 
    }
	
    public void setState(String state) {
    	this.state = state; 
    }
	
	public void setStatus (String status) {
		this.status = status; 
    }
	
	public void setExpired (String expired) {
		this.expired = expired; 
    }			
	
	public String getIacId () {
		return (this.iacId); 
    }			
	
	public String getIacName () {
		return (this.iacName); 
    }
	
	public String getCity () {
		return (this.city); 
    }
	
	public String getState () {
		return (this.state);
    }
	
	public String getStatus () {
		return (this.status); 
    }	
	
	public String getExpired () {
		return (this.expired); 
    }
	
    public String toString () {

	String sep = System.getProperty("line.separator");

	StringBuffer buffer = new StringBuffer();
	buffer.append(sep);		
	buffer.append("iacId = ");
	buffer.append(iacId);
	buffer.append(sep);	
	buffer.append("iacName = ");
	buffer.append(iacName);
	buffer.append(sep);
	buffer.append("city = ");
	buffer.append(city);
	buffer.append(sep); 
	buffer.append("state = ");
	buffer.append(state);
	buffer.append(sep); 
	buffer.append("status = ");
	buffer.append(status);
	buffer.append(sep);
	buffer.append("expired = ");
	buffer.append(expired);
	buffer.append(sep);
	
	return buffer.toString();
    }
}
