/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ctu.tsa.fas.requesttracker.action;

import com.ctu.tsa.fas.delegation.RequestTrackerDelegation;
import com.ctu.tsa.fas.requesttracker.dao.RequestTrackerDAO;
import com.ctu.tsa.fas.requesttracker.data.RequestReferenceData;
import com.ctu.tsa.fas.requesttracker.model.Request;
import java.util.LinkedHashMap;
import java.util.Map;
import com.opensymphony.xwork2.Action;
import org.apache.log4j.Logger;
import org.apache.struts2.json.JSONResult;
import java.util.Iterator;
import java.util.List;

public class RequestTrackerJsonAction implements Action {
    
	private Map<String, String> requestorMap = new LinkedHashMap<String, String>();

    private String message = "";
    private String requestTypeValue;
    private String subjectIndividualValue;
    private String requestNumberValue;
    private RequestReferenceData rtRefData = null;
    
    protected Logger logger = Logger.getLogger(getClass());

    public String execute() {
        rtRefData = RequestReferenceData.getInstance();

        if (requestTypeValue.equals("CI")) {
            requestorMap.clear();
            requestorMap.put("0", "Select Agency");
            requestorMap.putAll(rtRefData.getCargoIncidentLinkedMap());
            message = " CI Ajax Request Type action Triggered";
        } else if (requestTypeValue.equals("JO")) {
            requestorMap.clear();
            requestorMap.put("0", "Select Agency");
            requestorMap.putAll(rtRefData.getJointOperationsLinkedMap());
            message = " JO Ajax Request Type action Triggered";
        } else if (requestTypeValue.equals("OGA")) {
            requestorMap.clear();
            requestorMap.put("0", "Select Agency");
            requestorMap.putAll(rtRefData.getOgaReferralLinkedMap());
            message = " OGA Ajax Request Type action Triggered";
        } else {
            message = " OTHER Ajax Request Type action Triggered";
            requestorMap.clear();
            requestorMap.put("0", "Select PSI");
            requestorMap.putAll(rtRefData.getCcsfApprovalLinkedMap());

        }
        return SUCCESS;
    }


    public String getRequestByRequestNumberAction() {
        RequestTrackerDAO dao = RequestTrackerDAO.getInstance();
        Request request = null;
        try {
            request = dao.getRequest(requestNumberValue);
            
            if (null != request) {
                String requestFields = request.toAjaxString().replaceAll("null", "");
                message = requestFields;
            }

        } catch (Exception e) {           
			logger.error ("EXCEPTION 1: " + e);
        }
        return SUCCESS;
    }


    public Map<String, String> getRequestorMap() {
        return requestorMap;
    }

    public void setRequestorMap(Map<String, String> requestorMap) {
        this.requestorMap = requestorMap;
    }

    public String getRequestTypeValue() {
        return requestTypeValue;
    }

    public void setRequestTypeValue(String requestTypeValue) {
        this.requestTypeValue = requestTypeValue;
    }

    public String getRequestNumberValue() {
        return requestNumberValue;
    }

    public void setRequestNumberValue(String requestNumberValue) {
        this.requestNumberValue = requestNumberValue;
    }

    public String getSubjectIndividualValue() {
        return subjectIndividualValue;
    }

    public void setSubjectIndividualValue(String subjectIndividualValue) {
        this.subjectIndividualValue = subjectIndividualValue;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
    
    
    
}
