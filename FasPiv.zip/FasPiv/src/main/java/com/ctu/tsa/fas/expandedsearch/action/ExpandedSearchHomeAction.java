/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ctu.tsa.fas.expandedsearch.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.freightdesk.fdcommons.Credentials;
import com.freightdesk.fdcommons.SessionKey;
import com.freightdesk.fdcommons.SessionStore;

import javax.servlet.http.HttpSession;

import com.opensymphony.xwork2.ActionSupport;

import org.apache.log4j.Logger;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.ServletActionContext;

import crt.com.freightdesk.fdfolio.common.IncludesUtil;

import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.Collections;

import com.freightdesk.fdcommons.ApplicationTabs;

/**
 *
 * @author Kevin.Tsou
 */
public class ExpandedSearchHomeAction extends ActionSupport implements ServletRequestAware {
    
    protected Logger logger = Logger.getLogger(getClass());
    HttpServletRequest request = ServletActionContext.getRequest();
    private String loginTimeRoleMsg;
    private String expandedSearchType = "";
    private String basicBtnClicked = "";
    private List<String> searchTypeList = new ArrayList<>();    
    private List<Map> ccsfList;
    private List<Map> shipperList;
	private List<Map> subjectCompanyList;
	private List<Map> subjectIndividualList;
	private List<Map> iacList;
    private Runtime runtime = Runtime.getRuntime();
	private String debugMsg = null;
	
	
    @Override
    public String execute()throws Exception {
        request = ServletActionContext.getRequest();
        HttpSession session = request.getSession(false);
        SessionStore store = SessionStore.getInstance(session);
        Credentials credentials = (Credentials) store.get(SessionKey.CREDENTIALS);
        
		debugMsg = "Expanded Search Home **** Memory: " + runtime.totalMemory()/1000 + " Memory used: " + (runtime.totalMemory() - runtime.freeMemory())/1000;
		logger.info(debugMsg);

        loginTimeRoleMsg = IncludesUtil.getWelcomeMsg(credentials)+ "<br>" + IncludesUtil.getExpireMsg(credentials);              

        SessionStore sessionStore = SessionStore.getInstance (request.getSession());
        sessionStore.put(SessionKey.CURRENT_TAB, ApplicationTabs.EXPANDEDSEARCH);
        
        logger.info("clear session lists");
        sessionStore.put(SessionKey.SubjectCompany_LIST, Collections.emptyList());
        sessionStore.put(SessionKey.SubjectIndividual_LIST, Collections.emptyList());
        sessionStore.put(SessionKey.Shipper_LIST, Collections.emptyList());
        sessionStore.put(SessionKey.IAC_LIST, Collections.emptyList());
        sessionStore.put(SessionKey.CCSF_LIST, Collections.emptyList());
        
        searchTypeList = initSearchTypeList (searchTypeList);
        
        // POAM HttpOnly Secure
        HttpServletResponse response = (HttpServletResponse)ServletActionContext.getResponse();
        String secure = "";
        if (request.isSecure())
        {
          secure = "; Secure";
        }
        response.setHeader("SET-COOKIE", "JSESSIONID=" + request.getSession().getId()
                         + "; Path=" + request.getContextPath() + "; HttpOnly" + secure);

        
		debugMsg = " Expanded Search Home **** Memory: " + runtime.totalMemory()/1000 + " Memory used: " + (runtime.totalMemory() - runtime.freeMemory())/1000;
		logger.info(debugMsg);
        
        if (getExpandedSearchType().equalsIgnoreCase("CCSF")){
            ccsfList = Collections.emptyList();
            setExpandedSearchType("CCSF");
            sessionStore.put (SessionKey.CCSF_LIST, ccsfList);
            sessionStore.put (SessionKey.TOTAL_COUNT, new Long(0));
			logger.info("CCSF type: " + getExpandedSearchType());            
            return "displayCcsf";
        } else if (getExpandedSearchType().equalsIgnoreCase("IAC")){
		    iacList = Collections.emptyList();
            setExpandedSearchType("IAC");
			sessionStore.put (SessionKey.IAC_LIST, iacList);
            sessionStore.put (SessionKey.TOTAL_COUNT, new Long(0));
			logger.info("IAC type: " + getExpandedSearchType());            
            return "displayIac";
        } else if (getExpandedSearchType().equalsIgnoreCase("Shipper")){
            shipperList = Collections.emptyList();
            sessionStore.put (SessionKey.Shipper_LIST, shipperList);
            sessionStore.put (SessionKey.TOTAL_COUNT, new Long(0));
			logger.info("Shipper type: " + getExpandedSearchType());            
            return "displayShipper";
		} else if (getExpandedSearchType().equalsIgnoreCase("Subject Company")){
            subjectCompanyList = Collections.emptyList();
            sessionStore.put (SessionKey.SubjectCompany_LIST, subjectCompanyList);
            sessionStore.put (SessionKey.TOTAL_COUNT, new Long(0));
			logger.info("Subject Company type: " + getExpandedSearchType());            
            return "displaySubjectCompany";
        } else if (getExpandedSearchType().equalsIgnoreCase("Subject Individual")){
            subjectIndividualList = Collections.emptyList();
            sessionStore.put (SessionKey.SubjectIndividual_LIST, subjectIndividualList);
            sessionStore.put (SessionKey.TOTAL_COUNT, new Long(0));
			logger.info("Subject Individual type: " + getExpandedSearchType());              
            return "displaySubjectIndividual";
        }
        else if ("SEARCH_TYPE_RETURN".equalsIgnoreCase(getBasicBtnClicked())) { 
		    logger.info("NOT CCSF type: " + getExpandedSearchType());            
            return respondBtnSearchTypeReturn();
        }

        return "display";
    }
    
    public String respondBtnSearchTypeReturn() throws java.lang.Exception {
        request = ServletActionContext.getRequest();
        HttpSession session = request.getSession(false);
        SessionStore store = SessionStore.getInstance(session);
        Credentials credentials = (Credentials) store.get(SessionKey.CREDENTIALS);
        loginTimeRoleMsg = IncludesUtil.getWelcomeMsg(credentials) + "<br>" + IncludesUtil.getExpireMsg(credentials);

        logger.debug("Starting respondBtnSearchTypeReturn ");        
        SessionStore sessionStore = SessionStore.getInstance(request.getSession());
        
        
        return "display";
    }        
    
    public String getExpandedSearchType() {
	return expandedSearchType;
    }
        
    public void setExpandedSearchType(String expandedSearchType) {
	this.expandedSearchType = expandedSearchType; 
    }
    
    public List<String> getSearchTypeList() {
	return searchTypeList;
    }
        
    public void setSearchTypeList(List<String> searchTypeList) {
	this.searchTypeList = searchTypeList; 
    }
    
    public String getLoginTimeRoleMsg() {
        return loginTimeRoleMsg;
    }

    public void setLoginTimeRoleMsg(String loginTimeRoleMsg) {
        this.loginTimeRoleMsg = loginTimeRoleMsg;
    }

    @Override
    public void setServletRequest(HttpServletRequest request) {
        this.request = request;
    }

    public HttpServletRequest getServletRequest() {
        return this.request;
    }
    
    public String getBasicBtnClicked() {
        return basicBtnClicked;
    }

    public void setBasicBtnClicked(String basicBtnClicked) {
        this.basicBtnClicked = basicBtnClicked;
    }
    
    private List<String> initSearchTypeList (List<String> inSearchTypeList){
        inSearchTypeList = new ArrayList<>();
        inSearchTypeList.add("---- Select ----");
        inSearchTypeList.add("CCSF");
        inSearchTypeList.add("IAC");
        inSearchTypeList.add("Shipper");
        inSearchTypeList.add("Subject Company");
        inSearchTypeList.add("Subject Individual");
        
        return inSearchTypeList;
    }
   
    public List<Map> getCcsfList() {
        return ccsfList;
    }

    public void setCcsfList(List<Map> ccsfList) {
        this.ccsfList = ccsfList;
    }
	
	public List<Map> getShipperList() {
        return shipperList;
    }

    public void setShipperList(List<Map> shipperList) {
        this.shipperList = shipperList;
    }
	
	public List<Map> getSubjectCompanyList() {
        return subjectCompanyList;
    }

    public void setSubjectCompanyList(List<Map> subjectCompanyList) {
        this.subjectCompanyList = subjectCompanyList;
    }	
		
	public List<Map> getIacList() {
        return iacList;
    }

    public void setIacList(List<Map> iacList) {
        this.iacList = iacList;
    }
}