package com.ctu.tsa.fas.requesttracker.action;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.interceptor.ServletRequestAware;

import com.ctu.tsa.fas.delegation.RequestTrackerDelegation;
import com.ctu.tsa.fas.requesttracker.data.RequestReferenceData;
import com.ctu.tsa.fas.requesttracker.data.RequestTrackerData;
import com.ctu.tsa.fas.requesttracker.model.Request;
import com.freightdesk.fdcommons.ApplicationProperties;
import com.freightdesk.fdcommons.ApplicationTabs;
import com.freightdesk.fdcommons.Credentials;
import com.freightdesk.fdcommons.SessionKey;
import com.freightdesk.fdcommons.SessionStore;
import com.freightdesk.fdcommons.asyncprocess.AsyncProcessManager;
import com.freightdesk.fdcommons.asyncprocess.AsyncProcessingLogModel;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

import crt.com.freightdesk.fdfolio.common.IncludesUtil;
import crt.com.freightdesk.fdfolio.setup.SystemMessageManager;

public class RequestTrackerDataAction extends ActionSupport implements ServletRequestAware, ModelDriven {

    protected Logger logger = Logger.getLogger(getClass());
    HttpServletRequest request = ServletActionContext.getRequest();

    private RequestTrackerDelegation delegate;

	private String  errMessage= "";
	
    RequestTrackerData requestTrackerData = new RequestTrackerData();
    List<Request> requestList = null;
    Map<String, String> requestListMap = new LinkedHashMap<String, String>();
        
    HttpSession session = request.getSession();
    SessionStore sessionStore = SessionStore.getInstance (session);
    Credentials credentials = (Credentials) (sessionStore.get (SessionKey.CREDENTIALS));
    SystemMessageManager messageManager = SystemMessageManager.getInstance();
    

    static int pageIndex = 1;
    static int startPage = 1;
    static int pageSize = 10;
    static boolean loadActionOnly = true;
    
    // Quick Search parameters
    private String searchStatus = null;
    private String searchData = null;

    // Search Results and Request Details
    private Date requestDate;
    private String requestNumber;
    private String newRequestNumber = null;
    private String requestorValue;
    private boolean derogFound;
    private boolean invComplete;
    private String requestType;
    private String requestStatus;
    private String leadtargeter;
    private String airportName;
    private String subjectRegion;
    private String requestor;
    private String requestorName;
    private String cotargeter;
    private String requiredField;
    private String derogLevel;
    private int requestCount = 0;
    private String requestAction = "NONE";
    private String loginTimeRoleMsg;
    private String userId;
    private Date createTimeStamp;
    private String staRows[];
    private String staInformation = "";
    private String inLieuAirport;
    
	// This method is called for either Create or Update request action.
    public String execute() throws Exception {
    	
    	try {
	        requestNumber = request.getParameter("requestNumber");
	        requestor = request.getParameter("requestor");
	        requestorValue = request.getParameter("requestorValue");
	        requestType = request.getParameter("requestType");
	        
	        HttpSession session = request.getSession();
	        SessionStore sessionStore = SessionStore.getInstance (session);
	        Credentials credentials = (Credentials) (sessionStore.get (SessionKey.CREDENTIALS));
	        SystemMessageManager messageManager = SystemMessageManager.getInstance();        
	
	        sessionStore.put(SessionKey.CURRENT_TAB, ApplicationTabs.REQUESTTRACKER);
	        
	        // POAM HttpOnly Secure
	        HttpServletResponse response = (HttpServletResponse)ServletActionContext.getResponse();
	        String secure = "";
	        if (request.isSecure())
	        {
	          secure = "; Secure";
	        }
	        response.setHeader("SET-COOKIE", "JSESSIONID=" + request.getSession().getId()
	                         + "; Path=" + request.getContextPath() + "; HttpOnly" + secure);
	        	
	        doStaStatus();	
	
	        if (requestNumber != null && !requestNumber.isEmpty()) {
	            requestAction = "UPDATE";   
	            request.setAttribute("RequestNumber", requestNumber);
	        }
	
	        
           
           /// SAve the request
	        requestTrackerSaveAction();
	        
	        if (requestAction.equals("OUT_OF_RANGE")) {
	        	addActionError(errMessage);
	        	return ActionSupport.INPUT;    // invalid field size
	        }
	
	        if (null != newRequestNumber && !newRequestNumber.equalsIgnoreCase(requestNumber)) {
	            requestAction = "NEW";
	        }
	        
	        // reset search status, search data and pageIndex - MAY NOT NEED THIS
	        loadActionOnly = false;
	        requestTrackerLoadAction();
	        loadActionOnly = true;
	        
	        requestCount = requestList.size();
	
	        if (requestCount == 0) {
	            return ActionSupport.SUCCESS;
	        }
	
	        // latest record information before save  MAY NOT NEED THE FOLLOWING
	        requestType = requestList.get(requestCount - 1).getRequestType();
	        requestStatus = requestList.get(requestCount - 1).getRequestStatus();
	        subjectRegion = request.getParameter("subjectRegion");
	        airportName = request.getParameter("airportName");
	        requestor = request.getParameter("requestor");
	        requestorName = request.getParameter("requestorName");
	        leadtargeter = request.getParameter("leadtargeter");
	        cotargeter = request.getParameter("cotargeter");
	
	        // will be removed
	        if (request.getParameter("invComplete") != null) {
	            invComplete = true;
	        }
	        if (request.getParameter("derogFound") != null) {
	            derogFound = true;
	        }
	
	        String derogLevelStr = request.getParameter("derogLevel");
	        if (derogLevelStr == null) {
	            derogLevel = "0";
	        } else if (derogLevelStr.equalsIgnoreCase("Low")) {
	            derogLevel = "1";
	        } else if (derogLevelStr.equalsIgnoreCase("Medium")) {
	            derogLevel = "2";
	        } else if (derogLevelStr.equalsIgnoreCase("High")) {
	            derogLevel = "3";
	        }
	        requestTrackerData.setDerogLevel(derogLevel);
	        
	        // should keep as text
	        String inLieuAirportStr = request.getParameter("inLieuAirport");
	          if (inLieuAirportStr == null) {
	                inLieuAirport = "";
	        } else if (inLieuAirportStr.equalsIgnoreCase("HQ")) {
	                inLieuAirport = "1";
	        } else if (inLieuAirportStr.equalsIgnoreCase("Other")) {
	                inLieuAirport = "2";
	        }
	        requestTrackerData.setInLieuAirport(inLieuAirport);
			
	        // set message to be set in asyncprocesssinglog
	        setAsyncMessage(credentials, requestAction);
	        
	    } catch (Exception e) {
		    logger.error("RT Data Action Execute Exception:" + e.getMessage());
	        return ActionSupport.ERROR;
	    }
        
        return ActionSupport.SUCCESS;
        
    }
    
    private void setAsyncMessage(Credentials credentials, String requestAction) 
		throws java.lang.Exception
	{
		// log attempted uploads
		AsyncProcessingLogModel asyncLogModel = new AsyncProcessingLogModel();
		AsyncProcessManager asyncRequestManager = new AsyncProcessManager();
                asyncLogModel.init(credentials.getUserId(), credentials.getDomainName(), "MANUAL", "REQUEST TRACKER", "Manual entry of request tracker data in process/not saved",credentials.getIpAddress());
		asyncLogModel = asyncRequestManager.createAsyncProcessLog(asyncLogModel);
		// end logging initialization
		
		// log successful upload
		if (requestAction.startsWith("NEW"))
		{
                    asyncRequestManager.logResult(asyncLogModel, true, "Successful create of new request tracker record.", "execute");			
		}
		else if (requestAction.equals("UPDATE")) 
		{
                    asyncRequestManager.logResult(asyncLogModel, true, "Successful update of request tracker record.", "execute");
		}
		else if (requestAction.equals("OUT_OF_RANGE")) 
		{
                    asyncRequestManager.logResult(asyncLogModel, false, "A request tracker field exceeds 4000 bytes.", "execute");
		}
    } 
        
    private void doStaStatus() {
      try {  
      	logger.info("doStaStatus");
        staInformation = "";
        String[] staSubjectIndividuals = new String[75];   // initial size
        staSubjectIndividuals = request.getParameterValues("staSubjectIndividual");

        if (null != staSubjectIndividuals) {

            int staRowCount = staSubjectIndividuals.length;
            for (int i = 0; i < staRowCount; i++) {
                // dirty check
                if (null == staSubjectIndividuals[i]) {
                    staRowCount = i+1;
                    break;
                }
            }
            String[] staStatuses = new String[staRowCount];
            String[] staInLieuOfs = new String[staRowCount];
            String[] staCredentials = new String[staRowCount];
            
            staStatuses = request.getParameterValues("staStatus");
            staInLieuOfs = request.getParameterValues("staInLieuOf");
            staCredentials = request.getParameterValues("staCredential");

            staRows = new String[staRowCount];
            staInformation = staRowCount + ";";
            
            for (int i = 0; i < staRowCount; i++) {
                if (i > 0) {
                    staInformation += ";";
                }
                staRows[i] = staSubjectIndividuals[i].toUpperCase() + ";" + staStatuses[i] + ";" + staInLieuOfs[i] + ";" + staCredentials[i].toUpperCase();
                staInformation += staRows[i];
            }
            
            // Keep only good data.
            if (staInformation.startsWith("1;;")) {
            	staInformation = "";
            }
        }
      } catch (Exception e) {
    	    logger.error("StaStatus Exception:" + e.getMessage());
            addActionError("Invalid Sta Information");
      }
    }

    private String formatOperator(final String operator) {
        if (operator.equals("NEQ")) {
            return " <> '";
        }
        else if (operator.equals("EQ")) {
            return " = '";
        }
        else if (operator.equals("GT")) {
            return " > '";
        }
        else if (operator.equals("LT")) {
            return " < '";
        }
        else if (operator.equals("LIKE")) {
            return " LIKE '%";
        }
        else if (operator.equals("BT")) {
            return " BETWEEN '";
        }
        return " NOT LIKE '%";
    }
    // Replace single quote to two single quotes for SQL search. Previously convert ' to ~ for JSP issue. 
    // Use this for advanced search in this class
    private String fixRestoreSearchText(String s) {
        
        if (null == s || s.trim().isEmpty()) {
            return s;
        }
        String s1 = "";
        int len = s.length();
        for(int i=0; i<len; i++) {
           if (s.charAt(i) == '~') {
               if (i+1 < len && s.charAt(i+1) == '~') {  // ''
                   i++;
               }
               s1 += "''";
           }
           else {
               s1 += s.charAt(i) + "";
           }
        }
        return s1.replace("<escript>", "</script>");
    }

	// convert date from dd/MM/yyyy to yyyy/MM/dd
	private String yyyyMMdd(String ddMMyyyy)    {
		try {
		
            SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
            Date date = sdf.parse(ddMMyyyy);
            sdf.applyPattern("yyyy/MM/dd");
	        return sdf.format(date);
		}
		catch (Exception e) {
			logger.error("Parse exception:" + e.getMessage ());
			return null;
		}
            
	}

    
    private void doAdvancedSearch() {
        String asNewSearch = (String)request.getParameter("AS_newSearch");    
        if (null != asNewSearch && asNewSearch.equals("false")) {
            if (null != searchData && !searchData.isEmpty()) {
                    return;
            }
        }
        

        String andOrOp = request.getParameter("andOrOp");     // by Name
        String requestNumberOp = request.getParameter("requestNumberOp");
        String requestStatusOp = request.getParameter("requestStatusOp");
        String requestDateOp = request.getParameter("requestDateOp");
        String requestTypeOp = request.getParameter("requestTypeOp");
        String requestorNameOp = request.getParameter("requestorNameOp");
        String coTargetersOp = request.getParameter("coTargetersOp");
        String airportOp = request.getParameter("airportOp");
        String commentsOp = request.getParameter("commentsOp");
        String recommendationOp = request.getParameter("recommendationOp");
        String requestorOp = request.getParameter("requestorOp");
        String subjectRegionOp = request.getParameter("subjectRegionOp");
        String subjectIndividualOp = request.getParameter("subjectIndividualOp");
        String subjectCompanyOp = request.getParameter("subjectCompanyOp");
        String leadTargeterOp = request.getParameter("leadTargeterOp");
        String inLieuAirportOp = request.getParameter("inLieuAirportOp");

        String requestNumber = request.getParameter("AS_requestNumber");
        String requestStatus = request.getParameter("AS_requestStatus");
        String requestType = request.getParameter("AS_requestType");
        String requestDate = request.getParameter("AS_requestDate");
        String requestBtDate = request.getParameter("AS_requestBtDate");
        String requestor = request.getParameter("AS_requestor");
        String requestorName = request.getParameter("AS_requestorName");
        String subjectRegion = request.getParameter("AS_subjectRegion");
        String subjectIndividual = request.getParameter("AS_subjectIndividual");
        String subjectCompany = request.getParameter("AS_subjectCompany");
        String leadtargeter = request.getParameter("AS_leadTargeter");
        String cotargeter = request.getParameter("AS_coTargeter");
        String airport = request.getParameter("AS_airport");
        String derogFound = request.getParameter("AS_derogFound");
        String staStatus = request.getParameter("AS_staStatus");
        String recommendation = request.getParameter("AS_recommendation");
        String comments = request.getParameter("AS_comments");
	String inLieuAirport = request.getParameter("AS_inLieuAirport");
        
        // store the current parameters in this session (for page navigation)
        
        session.setAttribute("SV_andOrOp", andOrOp);
        session.setAttribute("SV_requestNumberOp", requestNumberOp);
        session.setAttribute("SV_requestStatusOp", requestStatusOp);
        session.setAttribute("SV_requestDateOp", requestDateOp);
        session.setAttribute("SV_requestTypeOp", requestTypeOp);
        session.setAttribute("SV_requestorOp", requestorOp);
        session.setAttribute("SV_requestorNameOp", requestorNameOp);
        session.setAttribute("SV_subjectRegionOp", subjectRegionOp);
        session.setAttribute("SV_subjectIndividualOp", subjectIndividualOp);
        session.setAttribute("SV_subjectCompanyOp", subjectCompanyOp);
        session.setAttribute("SV_leadTargeterOp", leadTargeterOp);
        session.setAttribute("SV_coTargetersOp", coTargetersOp);
        session.setAttribute("SV_airportOp", airportOp);
        session.setAttribute("SV_recommendationOp", recommendationOp);
        session.setAttribute("SV_commentsOp", commentsOp);

        session.setAttribute("SV_requestNumber", requestNumber);
        session.setAttribute("SV_requestStatus", requestStatus);
        session.setAttribute("SV_requestType", requestType);
        session.setAttribute("SV_requestDate", requestDate);
        session.setAttribute("SV_requestBtDate", requestBtDate);
        session.setAttribute("SV_requestor", requestor);
        session.setAttribute("SV_requestorName", requestorName);
        session.setAttribute("SV_subjectRegion", subjectRegion);
        session.setAttribute("SV_subjectIndividual", subjectIndividual);
        session.setAttribute("SV_subjectCompany", subjectCompany);
        session.setAttribute("SV_leadTargeter", leadtargeter);
        session.setAttribute("SV_coTargeter", cotargeter);
        session.setAttribute("SV_airport", airport);
        session.setAttribute("SV_derogFound", derogFound);
        session.setAttribute("SV_staStatus", staStatus);
        session.setAttribute("SV_recommendation", recommendation);
        session.setAttribute("SV_comments", comments);
        session.setAttribute("SV_inLieuAirport", inLieuAirport);

        requestNumberOp = formatOperator(requestNumberOp);
        requestStatusOp = formatOperator(requestStatusOp);
        requestTypeOp = formatOperator(requestTypeOp);
        requestorOp = formatOperator(requestorOp);
        requestorNameOp = formatOperator(requestorNameOp);
        subjectRegionOp = formatOperator(subjectRegionOp);
        subjectIndividualOp = formatOperator(subjectIndividualOp);
        subjectCompanyOp = formatOperator(subjectCompanyOp);
        requestDateOp = formatOperator(requestDateOp);
        leadTargeterOp = formatOperator(leadTargeterOp);
        coTargetersOp = formatOperator(coTargetersOp);
        airportOp = formatOperator(airportOp);
        recommendationOp = formatOperator(recommendationOp);
        commentsOp = formatOperator(commentsOp);        
        inLieuAirportOp = formatOperator(inLieuAirportOp);
        
        // restore and convert the search text field to original and SQL readable format
        requestNumber = fixRestoreSearchText(requestNumber);
        requestorName = fixRestoreSearchText(requestorName);
        subjectIndividual = fixRestoreSearchText(subjectIndividual);
        subjectCompany = fixRestoreSearchText(subjectCompany);
        recommendation = fixRestoreSearchText(recommendation);
        comments = fixRestoreSearchText(comments);
        // 
        searchData = " where ";
        int queryLen = searchData.length();
        if (null != requestNumber && !requestNumber.trim().isEmpty()) {
            searchData += " upper(r.requestNumber) " + requestNumberOp +  requestNumber;
            if (requestNumberOp.contains("LIKE")) {
                searchData += "%";
            }
            searchData += "' ";
        }
        if (null != requestStatus && !requestStatus.trim().isEmpty() && !requestStatus.contains("Any")) {
            if (searchData.length() > queryLen) {
                searchData += andOrOp;
            }
            searchData += " r.requestStatus " + requestStatusOp + requestStatus + "' ";
        }

        if (null != requestDate && !requestDate.trim().isEmpty()) {
            if (searchData.length() > queryLen) {
                searchData += andOrOp;
            }
            
            searchData += "  to_char(r.requestDate, 'yyyy/mm/dd') " + requestDateOp + yyyyMMdd(requestDate) + "' ";

	        if (requestDateOp.contains("BETWEEN") && null != requestBtDate && !requestBtDate.trim().isEmpty()) {
	            searchData += " AND '" + yyyyMMdd(requestBtDate) + "' ";
	        }
        }

        if (null != requestType && !requestType.trim().isEmpty() && !requestType.contains("Any")) {
            if (searchData.length() > queryLen) {
                searchData += andOrOp;
            }
            searchData += " r.requestType " + requestTypeOp + requestType + "' ";
        }

        if (null != requestor && !requestor.trim().isEmpty() && !requestor.contains("Select") && !requestor.equals("0"))
        {    // dependent of request type
        	
            if (searchData.length() > queryLen) {
                searchData += andOrOp;
            }

            if (requestor.contains("~~")) {   // (requestType='SF' or requestType='IAC')  
                requestorValue = requestor.split("~~")[1];   // new PSI from orgHierarchy
                searchData += " r.requesterAgencyId " + requestorOp + requestorValue + "' ";
            }
            
            else { 
            	searchData += " r.requesterAgencyId " + requestorOp + requestor + "' ";
            }
            
        }    
                    
        if (null != requestorName && !requestorName.trim().isEmpty() && !requestorName.contains("Any")) {
            if (searchData.length() > queryLen) {
                searchData += andOrOp;
            }
            searchData += " r.requestorName " + requestorNameOp + requestorName + "' ";
        }    
        if (null != subjectRegion && !subjectRegion.trim().isEmpty() && !subjectRegion.contains("Any")) {
            if (searchData.length() > queryLen) {
                searchData += andOrOp;
            }
            searchData += " r.subjectRegionId " + subjectRegionOp + subjectRegion + "' ";
        }    
        if (null != subjectIndividual && !subjectIndividual.trim().isEmpty() && !subjectIndividual.contains("Any")) {
            if (searchData.length() > queryLen) {
                searchData += andOrOp;
            }
            searchData += " upper(r.subjectIndividual) " + subjectIndividualOp + subjectIndividual.toUpperCase() ;
            if (subjectIndividualOp.contains("LIKE")) {
                searchData += "%";
            }
            searchData += "' ";
        }    
        if (null != subjectCompany && !subjectCompany.trim().isEmpty()) {
            if (searchData.length() > queryLen) {
                searchData += andOrOp;
            }
            searchData += " upper(r.subjectCompany) " + subjectCompanyOp + subjectCompany.toUpperCase() ;
            if (subjectCompanyOp.contains("LIKE")) {
                searchData += "%";
            }
            searchData += "' ";
        }    
        if (null != leadtargeter && !leadtargeter.trim().isEmpty() && !leadtargeter.contains("Any") && !leadtargeter.equals("0")) {
            if (searchData.length() > queryLen) {
                searchData += andOrOp;
            }
            if (leadtargeter.contains("~~")) {
                leadtargeter = leadtargeter.split("~~")[1];   // new leadtargeter from orgHierarchy
            }
            searchData += " r.leadtargeter " + leadTargeterOp + leadtargeter + "' ";
        }    
        if (null != cotargeter && !cotargeter.trim().isEmpty() && !cotargeter.contains("Any") && !cotargeter.equals("0")) {
            if (searchData.length() > queryLen) {
                searchData += andOrOp;
            }
            if (cotargeter.contains("~~")) {
                cotargeter = cotargeter.split("~~")[1];   // new cotargeter from orgHierarchy
            }
            // convert = to LIKE and <> to NOT LIKE
            if (coTargetersOp.contains("=")) {
                searchData += " r.cotargeters LIKE '%" + cotargeter + "%' ";
            }
            else {
                searchData += " r.cotargeters NOT LIKE '%" + cotargeter + "%' ";
            }
        }    
        if (null != airport && !airport.trim().isEmpty() && !airport.contains("Any")) {
            if (searchData.length() > queryLen) {
                searchData += andOrOp;
            }
            searchData += " r.airportid " + airportOp + airport.split("~~")[1] + "' ";   // new value AirportCode~~Id
        }    
        if (null != derogFound && !derogFound.trim().isEmpty() && !derogFound.contains("Any")) {
            if (searchData.length() > queryLen) {
                searchData += andOrOp;
            }
            searchData += " r.derog IS " + (derogFound.equals("Found")? "NOT NULL " : "NULL ");
        }    
        if (null != staStatus && !staStatus.trim().isEmpty() && !staStatus.contains("Any")) {
            if (searchData.length() > queryLen) {
                searchData += andOrOp;
            }
            if (staStatus.equals("Found")) {
                searchData += " r.StaInformation NOT LIKE '%Select Status%' ";
            }
            else {
                searchData += " r.StaInformation LIKE '%Select Status%' ";
            }
        }    
        if (null != recommendation && !recommendation.trim().isEmpty()) {
            if (searchData.length() > queryLen) {
                searchData += andOrOp;
            }
            searchData += " r.recommendation " + recommendationOp + recommendation + "%' ";
        }    
        if (null != comments && !comments.trim().isEmpty()) {
            if (searchData.length() > queryLen) {
                searchData += andOrOp;
            }
            searchData += " r.comments " + commentsOp + comments + "%' ";
        }    
        
        if (null != inLieuAirport && !inLieuAirport.trim().isEmpty() && !inLieuAirport.contains("Any")) {
            if (searchData.length() > queryLen) {
                searchData += andOrOp;
            }
	       // should keep as text
            if (inLieuAirport.equals("HQ")) {
                inLieuAirport = "1";
        	}
        	else if (inLieuAirport.equals("Other")) {
                inLieuAirport = "2";
        	}
        	else {
                inLieuAirport = "";
        	}
            searchData += " r.inLieuAirport" + inLieuAirportOp + inLieuAirport + "' ";
        }
        
        if (" where ".equals(searchData)) {  // nothing selected
            searchData = "";
        }
        logger.info(searchData)    ;
    }

    public String requestTrackerLoadAction() {    
    	
    	 logger.info("==requestTrackerLoadAction==");
        if (loadActionOnly) {
            searchStatus = request.getParameter("searchStatus");
            searchData = request.getParameter("searchData");
        }
        else {
            searchStatus = "All";
            searchData = "";
            pageIndex = 1;
        }

    	 logger.info(searchStatus+"==requestTrackerLoadAction=="+searchData);

        try {
            pageIndex = Integer.parseInt(request.getParameter("pageIndex"));
        }
        catch (Exception e) {
            try {
                pageIndex = Integer.parseInt(request.getParameter("AS_pageIndex"));
            }
            catch (Exception e1) {
                logger.warn("****** pageIndex reset in  requestTrackerLoadAction  " + e1.getMessage());
                pageIndex = 1;
            }
        }
        
        session = ServletActionContext.getRequest().getSession();
        sessionStore = SessionStore.getInstance(session);
        credentials = (Credentials) (sessionStore.get(SessionKey.CREDENTIALS));
        messageManager = SystemMessageManager.getInstance();

        loginTimeRoleMsg = IncludesUtil.getWelcomeMsg(credentials) + "<br>" + IncludesUtil.getExpireMsg(credentials);
        
        userId = credentials.getUserId();

        requestTrackerData.setUserId(userId);
        

        try {
            if (null == delegate) {
                delegate = new RequestTrackerDelegation();
            }
            
            RequestReferenceData.getInstance();  // For static data only.
            
            if (null == searchData || (searchData != null && (searchData.isEmpty() || searchData.equalsIgnoreCase("Any")))) {
                searchData = null;
                request.setAttribute("SearchData", "");
            }
            else {
                request.setAttribute("SearchData", searchData);
            }

            if (null == searchStatus || (searchStatus != null && (searchStatus.isEmpty() || searchStatus.equalsIgnoreCase("All")))) {
                searchStatus = null;
                request.setAttribute("AdvancedSearchQuery", "");
                request.setAttribute("SearchStatus", "All");
            } else if (searchStatus.equalsIgnoreCase("AdvancedSearch")) {
                doAdvancedSearch();
                request.setAttribute("AdvancedSearchQuery", searchData);
                request.setAttribute("SearchStatus", "All");
                request.setAttribute("SearchData", "");
            }
            else {
                request.setAttribute("SearchStatus", searchStatus);
                request.setAttribute("AdvancedSearchQuery", "");
            }

            requestCount = delegate.getRequestCount(searchStatus, searchData);
            request.setAttribute("RequestCount", new Integer(requestCount));
            
            
            try {
                pageSize =Integer.valueOf(ApplicationProperties.getProperty("RequestTracker.paging"));
            }
            catch (Exception e) {
                pageSize = 10;
            }
            // store search parameters for export
            session.setAttribute("SV_searchStatus", searchStatus);
            session.setAttribute("SV_searchData", searchData);

            requestList = delegate.getRequestList(searchStatus, searchData, pageIndex, pageSize);

            // Reset searchData field
            
            request.setAttribute("PageIndex", new Integer(pageIndex));
            

        } catch (Exception ex) {

            logger.error(" RequestTrackerLoadAction-Exception:" + ex.getMessage());
            return ActionSupport.ERROR;
        }
        return ActionSupport.SUCCESS;
    }
    
    public String requestTrackerAdvancedSearchAction()  {
        try {
            if (null == delegate) {
                delegate = new RequestTrackerDelegation();
            }
            

            if (null == searchStatus || (searchStatus != null && (searchStatus.isEmpty() || searchStatus.equalsIgnoreCase("All")))) {
                searchStatus = null;
            }

            if (null == searchData || (searchData != null && (searchData.isEmpty() || searchData.equalsIgnoreCase("Any")))) {
                searchData = null;
            }

            requestList = delegate.getRequestList(searchStatus, searchData);

            requestCount = requestList.size();
        } catch (Exception ex) {

            logger.error ("requestTrackerAdvancedSearchAction -----Exception:" + ex.getMessage());
            return ActionSupport.ERROR;
        }
        return ActionSupport.SUCCESS;
    }

    private boolean checkField(String fieldId, String fieldLabel, String requiredField) {

        if (requiredField == null || requiredField.isEmpty() || requiredField.contains("Select")) {
            addFieldError("requiredField", fieldLabel + " is required");
            return false;
        }
        return true;
    }

    public void requestTrackerSaveAction() throws Exception {
        if (null == delegate) {
            delegate = new RequestTrackerDelegation();
        }
        if (null != requestTrackerData) {
            int requestorId = 0;
            try {
	            if (requestor.contains("~~")) {
	                requestorId = Integer.parseInt(requestor.split("~~")[1]);   // new PSI from orgHierarchy
	            }
	            else {
	                requestorId = Integer.parseInt(requestor);
	            }
            } catch (Exception e) {
                logger.warn (e.getMessage());
            }
            requestTrackerData.setRequesterAgencyID(requestorId);
            requestTrackerData.setRequestor(null);   // for editing
            requestTrackerData.setStaInformation(staInformation);
            
            if (null != requestTrackerData.getSubjectIndividual()) {
	            int subjectIndividualLength = requestTrackerData.getSubjectIndividual ().length();
	            
	            if (subjectIndividualLength > 4000) {
	            	errMessage = "SubjectIndividual field contains " + subjectIndividualLength + " bytes (4000 max)\n";
	            	requestAction = "OUT_OF_RANGE";
	            }
            }

            if (null != requestTrackerData.getStaInformation()) {
	            int staLength = requestTrackerData.getStaInformation ().length();	
	
	            if (staLength > 4000) {
	            	errMessage += "STA table contains " + staLength + " bytes (4000 max)";
	            	requestAction = "OUT_OF_RANGE";
	            }
            }
            
            userId = credentials.getUserId();
            requestTrackerData.setUserId(userId);
            try {
                newRequestNumber = delegate.saveRequestTracker(requestTrackerData);
            } catch (Exception ex) {
		        newRequestNumber = null;
                throw new Exception(ex);
            }
        }
    }

   
    public String getRequestStatus() {
        return requestStatus;
    }

    public void setRequestStatus(String requestStatus) {
        this.requestStatus = requestStatus;
    }

    public int getRequestCount() {
        return requestCount;
    }

    public void setRequestCount(int requestCount) {
        this.requestCount = requestCount;
    }

    public String getRequestType() {
        return requestType;
    }

    public void setRequestType(String requestType) {
        this.requestType = requestType;
    }

    public Date getRequestDate() {
        return requestDate;
    }

    public Date getcreateTimeStamp() {
        return createTimeStamp;
    }
    
    public String getRequestNumber() {
        return requestNumber;
    }

    public void setRequestNumber(String requestNumber) {
        this.requestNumber = requestNumber;
    }

    public void setRequestDate(Date requestDate) {
        this.requestDate = requestDate;
    }

    public boolean isDerogFound() {
        return derogFound;
    }

    public void setDerogFound(boolean derogFound) {
        this.derogFound = derogFound;
    }

    public String getLeadtargeter() {
        return leadtargeter;
    }

    public void setLeadtargeter(String leadtargeter) {
        this.leadtargeter = leadtargeter;
    }

    public String getAirportName() {
        return airportName;
    }

    public void setAirportName(String airportName) {
        this.airportName = airportName;
    }

    public String getSubjectRegion() {
        return subjectRegion;
    }

    public void setSubjectRegion(String subjectRegion) {
        this.subjectRegion = subjectRegion;
    }

    public String getRequestor() {
        return requestor;
    }

    public void setRequestor(String requestor) {
        this.requestor = requestor;
    }

    public String getRequestorName() {
        return requestorName;
    }

    public void setRequestorName(String requestorName) {
        this.requestorName = requestorName;
    }

    public String getCotargeter() {
        return cotargeter;
    }

    public void setCotargeter(String cotargeter) {
        this.cotargeter = cotargeter;

    }

    public boolean isInvComplete() {
        return invComplete;
    }

    public void setInvComplete(boolean invComplete) {
        this.invComplete = invComplete;
    }

    public String getSearchStatus() {
        return searchStatus;
    }

    public void setSearchStatus(String searchStatus) {
        this.searchStatus = searchStatus;
    }

    public String getLoginTimeRoleMsg() {
        return loginTimeRoleMsg;
    }

    public void setLoginTimeRoleMsg(String loginTimeRoleMsg) {
        this.loginTimeRoleMsg = loginTimeRoleMsg;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    
    public String getSearchData() {
        return searchData;
    }

    public void setSearchData(String searchData) {
        this.searchData = searchData;
    }

    public String getRequestAction() {
        return requestAction;
    }

    public void setRequestAction(String requestAction) {
        this.requestAction = requestAction;
    }

    public String getRequiredField() {
        return requiredField;
    }

    public void setRequiredField(String requiredField) {
        this.requiredField = requiredField;
    }

    public String getNewRequestNumber() {
        return newRequestNumber;
    }

    public void setNewRequestNumber(String newRequestNumber) {
        this.newRequestNumber = newRequestNumber;
    }

    public String getRequestorValue() {
        return requestorValue;
    }

    public void setRequestorValue(String requestorValue) {
        this.requestorValue = requestorValue;
    }

    public String getInLieuAirport() {
        return inLieuAirport;
    }

    public void setInLieuAirport(String inLieuAirport) {
        this.inLieuAirport = inLieuAirport;
    }

    public List<Request> getRequestList() {
        return requestList;
    }

    public void setRequestList(List<Request> requestList) {
        this.requestList = requestList;
    }

    public HttpServletRequest getRequest() {
        return request;
    }

    public void setRequest(HttpServletRequest request) {
        this.request = request;
    }

    public RequestTrackerData getRequestTrackerData() {
        return requestTrackerData;
    }

    public void setRequestTrackerData(RequestTrackerData requestTrackerData) {
        this.requestTrackerData = requestTrackerData;
    }

    public void setServletRequest(HttpServletRequest request) {
        this.request = request;
    }

    public HttpServletRequest getServletRequest() {
        return this.request;
    }

    public RequestTrackerData getModel() {
        return requestTrackerData;
    }

}
