/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ctu.tsa.fas.expandedsearch.model;

import org.apache.commons.lang3.StringEscapeUtils;

/**
 *
 * @author kevin.tsou
 */
public class StationDetails {
    private static final long serialVersionUID = -8767337899673261247L;
    private String stationName = "";
    private String iacName = "";
    private long iacId = 0;
    private String airportName = "";
    private String isActive = "";
    private String address1 = "";
    private String address2 = "";
    private String city = "";
    private String state = "";
    private String zipPostalCode = "";
    private String country = "";
    private String comments = "";
    
    public void setStationName (String stationName) {
	this.stationName = stationName; 
    }
    
    public String getStationName () {
	return (this.stationName); 
    }
    
    public void setIacName (String iacName) {
	this.iacName = iacName; 
    }
    
    public String getIacName () {
	return (this.iacName); 
    }
    
    public void setSIacId (long iacId) {
	this.iacId = iacId; 
    }
    
    public long getIacId () {
	return (this.iacId); 
    }
    
    public void setAirportName (String airportName) {
	this.airportName = airportName; 
    }
    
    public String getAirportName () {
	return (this.airportName); 
    }
    
    public void setIsActive (String isActive) {
	this.isActive = isActive; 
    }
    
    public String getIsActive () {
	return (this.isActive); 
    }
    
    public String getAddress1() {
        if (address1 == null){
            this.address1 = "";
	}
	
        return StringEscapeUtils.unescapeHtml4(address1);	
    }

    public void setAddress1(String address1) {
        this.address1 = address1;
    } 
    
    public String getAddress2() {
        if (address2 == null){
            this.address2 = "";
	}
	
        return StringEscapeUtils.unescapeHtml4(address2);	
    }

    public void setAddress2(String address2) {
        this.address2 = address2;
    } 
    
    public String getCity() {
        if (city == null){
            this.city = "";
	}
	
        return StringEscapeUtils.unescapeHtml4(city);	
    }
    
    public void setCity(String city) {
        this.city = city;
    } 
    
    public String getState() {
        if (state == null){
            this.state = "";
	}
	
        return StringEscapeUtils.unescapeHtml4(state);	
    }
    
    public void setState(String state) {
        this.state = state;
    } 
    
    public String getZipPostalCode() {
        if (zipPostalCode == null){
            this.zipPostalCode = "";
	}
	
        return StringEscapeUtils.unescapeHtml4(zipPostalCode);	
    }
    
    public void setZipPostalCode(String zipPostalCode) {
        this.zipPostalCode = zipPostalCode;
    } 
    
    public String getCountry() {
        if (country == null){
            this.country = "";
	}
	
        return StringEscapeUtils.unescapeHtml4(country);	
    }
    
    public void setCountry(String country) {
        this.country = country;
    } 
    
    public String getComments() {
        if (comments == null){
            this.comments = "";
	}
	
        return StringEscapeUtils.unescapeHtml4(comments);	
    }
    
    public void setComments(String comments) {
        this.comments = comments;
    } 
    
    public String toString () {

	String sep = System.getProperty("line.separator");

	StringBuffer buffer = new StringBuffer();
	buffer.append(sep);
	buffer.append("stationName  = ");
	buffer.append(stationName);
        buffer.append(sep);
	buffer.append("iacName = ");
	buffer.append(iacName);
        buffer.append(sep);
	buffer.append("iacId = ");
	buffer.append(iacId);
        buffer.append(sep);
	buffer.append("airportName = ");
	buffer.append(airportName);
        buffer.append(sep);
	buffer.append("isActive = ");
	buffer.append(isActive);
        buffer.append(sep);
	buffer.append("address1 = ");
	buffer.append(address1 );
        buffer.append(sep);
	buffer.append("address2 = ");
	buffer.append(address2 );
        buffer.append(sep);
	buffer.append("city = ");
	buffer.append(city );
        buffer.append(sep);
	buffer.append("state = ");
	buffer.append(state );
        buffer.append(sep);
	buffer.append("zipPostalCode = ");
	buffer.append(zipPostalCode );
        buffer.append(sep);
	buffer.append("country = ");
	buffer.append(country );
        buffer.append(sep);
	buffer.append("comments = ");
	buffer.append(comments );
        
        return buffer.toString();
    }
}
