/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ctu.tsa.fas.expandedsearch.model;

import java.io.Serializable;

/**
 *
 * @author Binh.Nguyen
 */
public class SubjectCompanyModel implements Serializable{
    private static final long serialVersionUID = -1106837298377580912L;
    
    private String subjectCompanyStatus;
    private String subjectCompanyId;
    private String subjectCompanyName;
    private String subjectCompanyState;
    private String subjectCompanyType;    
    private String partyId;    
    private String objectId;    
	
    public SubjectCompanyModel() {
    }
    
    public SubjectCompanyModel(String subjectCompanyName, String subjectCompanyType, String subjectCompanyId, String subjectCompanyState, String subjectCompanyStatus) {
	
    this.subjectCompanyName = subjectCompanyName;
	this.subjectCompanyType = subjectCompanyType;
    this.subjectCompanyId = subjectCompanyId;
    this.subjectCompanyState = subjectCompanyState; 
    this.subjectCompanyStatus = subjectCompanyStatus;	
    }
    
	public void setSubjectCompanyStatus (String subjectCompanyStatus) {
	this.subjectCompanyStatus = subjectCompanyStatus; 
    }

    public void setSubjectCompanyId (String subjectCompanyId) {
	this.subjectCompanyId = subjectCompanyId; 
    }

    public void setSubjectCompanyName (String subjectCompanyName) {
	this.subjectCompanyName = subjectCompanyName; 
    }
    
    public void setSubjectCompanyType (String subjectCompanyType) {
	this.subjectCompanyType = subjectCompanyType; 
    }
	
	public void setSubjectCompanyState(String subjectCompanyState) {
        this.subjectCompanyState = subjectCompanyState;
    }

    public String getSubjectCompanyStatus () {
	return (this.subjectCompanyStatus); 
    }
	
    public String getSubjectCompanyId () {
	return (this.subjectCompanyId); 
    }

    public String getSubjectCompanyName () {
	return (this.subjectCompanyName); 
    }
   
    public String getSubjectCompanyType () {
	return (this.subjectCompanyType); 
    }
   
    public String getSubjectCompanyState() {
        return subjectCompanyState;
    }
       	
    @Override
	public String toString () {

	String sep = System.getProperty("line.separator");

	StringBuffer buffer = new StringBuffer();
	buffer.append(sep);			
    buffer.append("subjectCompanyName= ");
	buffer.append(subjectCompanyName);
	buffer.append(sep);
	buffer.append("subjectCompanyType= ");
	buffer.append(subjectCompanyType);
	buffer.append(sep);
	buffer.append("subjectCompanyId= ");
	buffer.append(subjectCompanyId);
	buffer.append(sep);		
	buffer.append("subjectCompanyState= ");
	buffer.append(subjectCompanyState);
	buffer.append(sep);
	buffer.append("subjectCompanyStatus= ");
	buffer.append(subjectCompanyStatus);
	buffer.append(sep);			
	
	return buffer.toString();
    }


	public SubjectCompanyModel (SubjectCompanyModel other) {
		if (this != other) {
			this.subjectCompanyStatus = other.subjectCompanyStatus;
			this.subjectCompanyId = other.subjectCompanyId;
			this.subjectCompanyName = other.subjectCompanyName;
			this.subjectCompanyState = other.subjectCompanyState;
			this.subjectCompanyType = other.subjectCompanyType;
			this.partyId = other.partyId;
			this.objectId = other.objectId;
		}
	}

	
	public void setPartyId (String partyId) {
		this.partyId = partyId; 
	}

	public void setObjectId (String objectId) {
		this.objectId = objectId; 
	}

	public String getPartyId () {
		return (this.partyId); 
	}

	public String getObjectId () {
		return (this.objectId); 
	}
	
	
	
}
   