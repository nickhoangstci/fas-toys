/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ctu.tsa.fas.requesttracker.dao;

import com.ctu.tsa.fas.hibernate.HibernateUtil;
import com.ctu.tsa.fas.requesttracker.data.Cturequest;
import com.ctu.tsa.fas.requesttracker.data.RequestReferenceData;
import com.ctu.tsa.fas.requesttracker.data.RequestTrackerData;
import com.ctu.tsa.fas.requesttracker.model.Request;
import com.ctu.tsa.fas.requesttracker.model.Sta;
import com.freightdesk.fdcommons.ConnectionUtil;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.*;
import org.apache.log4j.Logger;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.QueryException;
import org.hibernate.ScrollableResults;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.XML;



/**
 *
 * @author STCI
 */
public class RequestTrackerDAO {

    protected Logger logger = Logger.getLogger(getClass());    

    private static RequestTrackerDAO instance = null;

    private SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
    private SimpleDateFormat timestampFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    private SimpleDateFormat timestampFormatS = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
    
    private Date date;


    // for Export
    private static String lastSearchStatus = "";
    private static String lastSearchData = "";
    private static List<Request> lastRequestList = null;   

    public RequestTrackerDAO() {

    }

    public static RequestTrackerDAO getInstance() {
        if (instance == null) {
            instance = new RequestTrackerDAO();
        }
        return instance;
    }
    
    // called from ShipperSearchAction
    public List<String> getStateCodeList() throws QueryException {

        List<String> list = new ArrayList<String>();
    
        String queryStr = "select StateProvinceCode from FD.StateLookup ORDER BY StateProvinceCode";
        Session session = null;

        try {
            session = HibernateUtil.getSessionFactory().openSession();
            Query query = session.createSQLQuery(queryStr);

            ScrollableResults resultSet = query.scroll();
            if (resultSet.first()) {
                do {
                    list.add(resultSet.get(0).toString());
                } while (resultSet.next());
            }

        } catch (HibernateException hqEx) {
            throw hqEx;
        } finally {
            if (session != null) {
            session.close(); }
        }
        return list;
    }

    public Map<String, String> getStateCodeMap() throws QueryException {
        Map<String, String> map = new LinkedHashMap<String, String>();

        String queryStr = "select StateProvinceCode from FD.StateLookup ORDER BY StateProvinceCode";
        Session session = null;

        try {
            session = HibernateUtil.getSessionFactory().openSession();
            Query query = session.createSQLQuery(queryStr);

            ScrollableResults resultSet = query.scroll();
            if (resultSet.first()) {
                do {
                    map.put(resultSet.get(0).toString(), resultSet.get(0).toString());
                } while (resultSet.next());
            }

        } catch (HibernateException hqEx) {
            throw hqEx;
        } finally {
            if (session != null) {
            session.close();}
        }
        return map;
    }

    

    public Map<String, String> getSubjectRegionList() throws QueryException {

        Map<String, String> map = new LinkedHashMap<String, String>();

        String queryStr = "select SUBJECTREGIONID, REGIONNAME from FD.ctusubjectregion ORDER BY REGIONNAME";

        Session session = null;
        try {
			session = HibernateUtil.getSessionFactory().openSession();
            Query query = session.createSQLQuery(queryStr);

            ScrollableResults resultSet = query.scroll();
            if (resultSet.first()) {
                do {
                    map.put(resultSet.get(0).toString(), resultSet.get(1).toString());
                } while (resultSet.next());
            }

        } catch (HibernateException hqEx) {
            logger.error("RequestTrackerDAO HibernateException:" + hqEx.getMessage());
            throw hqEx;
        } finally {
            if (session != null) {
            session.close(); }
        }
        return map;

    }

    public Map<String, String> getRequestTypeList() throws QueryException {
        Map<String, String> map = new LinkedHashMap<String, String>();

        String queryStr = "select REQUESTTYPE, REQUESTNAME from FD.CTUREQUESTTYPE ORDER BY REQUESTNAME";
        Session session = null;

        try {
			session = HibernateUtil.getSessionFactory().openSession();
            Query query = session.createSQLQuery(queryStr);

            ScrollableResults resultSet = query.scroll();
            if (resultSet.first()) {
                do {
                    map.put(resultSet.get(0).toString(), resultSet.get(1).toString());
                } while (resultSet.next());
            }

        } catch (HibernateException hqEx) {
            throw hqEx;
        } finally {
            if (session != null) {
            session.close(); }
        }
        return map;
    }

    public Map<String, String> getAirportList() throws QueryException {
        LinkedHashMap<String, String> map = new LinkedHashMap<String, String>();

        String queryStr = "select OrgId, PortCode, OrgName from FD.OrgHierarchy where OrgHierarchyTypeCode = 'AIRPT' ORDER BY PortCode";
        Session session = null;
        String airportCode = "???";
        String airportName = "UNDEFINED";
        try {
            session = HibernateUtil.getSessionFactory().openSession();
            Query query = session.createSQLQuery(queryStr);

            ScrollableResults resultSet = query.scroll();
            if (resultSet.first()) {
                do {
                    if (null != resultSet.get(1)) {
                        airportCode = resultSet.get(1).toString();
                    }
                    if (null != resultSet.get(2)) {
                        airportName = resultSet.get(2).toString();
                        if (airportCode.length() > 1 && !airportCode.equalsIgnoreCase(airportName.split("-")[0].trim())) {
                            airportName = airportCode + " - " + airportName;    // OrgCode-OrgName
                        }
                    }
                    
                    map.put(airportCode + "~~" + resultSet.get(0).toString(), airportName);  // order by OrgCode~~OrgId
                } while (resultSet.next());
            }

        } catch (HibernateException hqEx) {
            throw hqEx;
        } finally {
            if (session != null) {
            session.close(); }
        }
        return map;
    }

    public List<String> getSubjectIndividualList() throws QueryException {

        List<String> list = new ArrayList<String>();

        String queryStr = "select SubjectIndividual from FD.CtuRequest";
        Session session = null;
        String subjIndField = null;
        String[] subjInds = null;

        try {
            session = HibernateUtil.getSessionFactory().openSession();
            Query query = session.createSQLQuery(queryStr);

            ScrollableResults resultSet = query.scroll();

            if (resultSet.first()) {
                do {
                    if (null != resultSet.get(0)) {
                      subjIndField = resultSet.get(0).toString();
                      subjInds = subjIndField.split(";");

                      for (int i = 0; i < subjInds.length; i++) {
                        if (!subjInds[i].trim().isEmpty()) {
                            list.add(subjInds[i]);
                        }
                      }
                    }
                } while (resultSet.next());
            }

        } catch (HibernateException hqEx) {
            logger.error(" DAO exception:" + hqEx.getMessage());
            throw hqEx;
        } finally {
            if (session != null) {
            session.close(); }
        }
        return list;
    }

    
    public List<String> getRequestNumberList(String subjectIndividual) throws Exception {

        if (null == subjectIndividual || subjectIndividual.isEmpty()) {
            return null;
        }
        String subjectIndividual_ = null;

        String nameLF[] = subjectIndividual.split("[,|' ']");  // separated by comma or space
        if (nameLF.length == 2) {
            subjectIndividual = nameLF[0] + " " + nameLF[1];
            subjectIndividual_ = nameLF[1] + " " + nameLF[0];   // for fuzzy search: unordered first and last names
        }
                            
        String queryStr;
        Request request = null;
        String subjIndField;
        String[] subjInds;
        List<String> list = new ArrayList<String>();

        queryStr = "select SubjectIndividual, RequestNumber from FD.CtuRequest";

        Session session = null;

        try {
            session = HibernateUtil.getSessionFactory().openSession();
            Query query = session.createSQLQuery(queryStr);

            ScrollableResults resultSet = query.scroll();
            if (resultSet.first()) {
                do {

                    subjIndField = (null == resultSet.get(0)) ? "" : resultSet.get(0).toString();

                    if (!subjIndField.isEmpty()) {
                        subjInds = subjIndField.split(";");

                        for (int i = 0; i < subjInds.length; i++) {
                            // Fuzzy name search for unordered first and last name
                            if (subjectIndividual.equalsIgnoreCase(subjInds[i].trim()) ||
                                subjectIndividual_.equalsIgnoreCase(subjInds[i].trim())) {
                                
                                request.setRequestNumber((null == resultSet.get(1)) ? "" : resultSet.get(1).toString());
                                list.add(request.getRequestNumber());
                                break;
                            }
                            
                        }
                    }
                } while (resultSet.next());
            }

        } catch (Exception hqEx) {
            logger.error("====exception in RT DAO:" + hqEx.getMessage());
            throw hqEx;
        } finally {
            if (session != null) {
            session.close(); }
        }
        return list;
    }

    public List<Request> getRequestList(String subjectIndividual) throws Exception {
        if (null == subjectIndividual || subjectIndividual.isEmpty()) {
            return null;
        }

        String subjectIndividualLF = null;
        String nameLF[] = subjectIndividual.split(",");
        if (nameLF.length == 2) {
            subjectIndividualLF = nameLF[1].trim() + " " + nameLF[0].trim();
        }

        List<Request> requestList = new ArrayList<Request>();
        String queryStr;
        Request request = null;
        String subjIndField = null;
        String name = null;
        String[] subjInds = null;

        String fieldNames = " REQUESTNUMBER, SUBJECTINDIVIDUAL ";

        queryStr = "select " + fieldNames + " from FD.CTUREQUEST order by LastUpdateTimeStamp DESC ";

        Session session = null;

        try {
            session = HibernateUtil.getSessionFactory().openSession();
            Query query = session.createSQLQuery(queryStr);

            ScrollableResults resultSet = query.scroll();
            if (resultSet.first()) {
                do {

                    subjIndField = (null == resultSet.get(1)) ? "" : resultSet.get(1).toString();

                    if (!subjIndField.isEmpty()) {
                        subjInds = subjIndField.split(";");
                        for (int i = 0; i < subjInds.length; i++) {
                            name = subjInds[i].trim();
                            if (!name.isEmpty()) {
                                if (name.equalsIgnoreCase(subjectIndividual)
                                        || name.equalsIgnoreCase(subjectIndividualLF)) {
                                    request = new Request();

                                    request.setRequestNumber((null == resultSet.get(0)) ? "" : resultSet.get(0).toString());
                                    requestList.add(request);
                                    break;
                                }
                            }
                        }
                    }
                } while (resultSet.next());
            }

        } catch (Exception hqEx) {
            logger.error("====exception in RT DAO getRequestList(String subjectIndividual):" + hqEx.getMessage());
            throw hqEx;
        } finally {
            if (session != null) {
            session.close(); }
        }
        return requestList;
    }

    public List<Request> getRequestsForSubject(String subjectField, String ajaxName) throws Exception {
        if (null == subjectField || subjectField.isEmpty()) {
            return null;
        }
        
        // Fuzzy name search
        String ajaxName_ = "";
        String nameLF[] = ajaxName.split("[,|' ']+");  // separated by comma or spaces
        if (nameLF.length == 2) {
            ajaxName = nameLF[0] + " " + nameLF[1];
            ajaxName_ = nameLF[1] + " " + nameLF[0];   // for fuzzy search: unordered first and last names
        }
                            
        List<Request> requestList = new ArrayList<Request>();

        Request request = null;
        String subjectString = null;
        String[] subjects = null;
        String subject = "";

        String fieldNames = " REQUESTNUMBER, " + subjectField;

        String queryStr = "select " + fieldNames + " from FD.CTUREQUEST order by LastUpdateTimeStamp DESC ";

        Session session = null;

        try {
            session = HibernateUtil.getSessionFactory().openSession();
            Query query = session.createSQLQuery(queryStr);

            ScrollableResults resultSet = query.scroll();
            if (resultSet.first()) {
                do {

                    subjectString = (null == resultSet.get(1)) ? "" : resultSet.get(1).toString();

                    if (!subjectString.isEmpty()) {
                        subjects = subjectString.split(";");
                        for (int i = 0; i < subjects.length; i++) {
                            subject = subjects[i].trim();
                            if (!subject.isEmpty()) {
                                if (ajaxName.equalsIgnoreCase(subject) ||
                                    ajaxName_.equalsIgnoreCase(subject)) {
                                    
                                    request = new Request();
                                    request.setRequestNumber((null == resultSet.get(0)) ? "" : resultSet.get(0).toString());
                                    requestList.add(request);
                                    break;
                                }
                            }
                        }
                    }
                } while (resultSet.next());
            }

        } catch (Exception hqEx) {
            logger.error("====exception in RT DAO getRequestsForSubject:" + hqEx.getMessage());
            throw hqEx;
        } finally {
            if (session != null) {
            session.close(); }
        }
        return requestList;
    }


    public JSONArray getJsonRequestsByFields(String fieldNames) throws Exception {

			logger.info("-------------:getRequestsByFields:");

        if (null == fieldNames || fieldNames.isEmpty()) {
            return null;
        }        
                            
        

        JSONArray array = new JSONArray();
        
        String queryStr = "select " + fieldNames + " from FD.CTUREQUEST order by LastUpdateTimeStamp DESC ";

        Session session = null;

        try {
            session = HibernateUtil.getSessionFactory().openSession();
            Query query = session.createSQLQuery(queryStr);

            ScrollableResults resultSet = query.scroll();
            if (resultSet.first()) {
                do {
                                    
                    JSONObject obj = new JSONObject();
                    obj.put("RequestNumber", (null == resultSet.get(0)) ? "" : resultSet.get(0).toString() );
                    obj.put("RequestType", (null == resultSet.get(1)) ? "" : resultSet.get(1).toString() );
                    obj.put("RequestDate", (null == resultSet.get(2)) ? "" : resultSet.get(2).toString() );
                    obj.put("SubjectCompany", (null == resultSet.get(3)) ? "" : resultSet.get(3).toString() );
                    
                    
                    array.put (obj);

                    
                } while (resultSet.next());
            }

        } catch (Exception hqEx) {
            logger.error("====exception in RT DAO getRequestsByFields:" + hqEx.getMessage());
            throw hqEx;
        } finally {
            if (session != null) {
            session.close(); }
        }
        
        
        return array;
    }

   // for testing with 20 rows from lastQuery
    public String getCsvRequestsByFields1(String fieldNames) throws Exception {


        if (null == fieldNames || fieldNames.isEmpty()) {
            return null;
        }        
                            
        String csvString = fieldNames + '\n';
        String[] fieldNameArray = fieldNames.split(",");

        for (Request request : lastRequestList) {
        	
        	for (String fieldName : fieldNameArray) {
        		if ("RequestNumber".equals(fieldName)) {
        			csvString += request.getRequestNumber () + ",";
        		}
        		else if ("RequestType".equals(fieldName)) {
        			csvString += request.getRequestType () + ",";
        		}
        		else if ("RequestDate".equals(fieldName)) {
        			csvString += request.getRequestDate () + ",";
        		}
        	}
            csvString = csvString.substring(0, csvString.length()-1) + '\n';    // remove the last comma and add linebreak
        }
        
        
        return csvString;
    }



    public String getCsvRequestsByFields(String fieldNames,  String searchStatus, String searchData) throws Exception {

		logger.info("-------------BEGIN:getCsvRequestsByFields:" );

        if (null == fieldNames || fieldNames.isEmpty()) {
            return null;
        }        
        	
        // call getRequestList using lastSearch parameters
		List<Request> requestList = getRequestListForExport (searchStatus, searchData);
                            
        String csvString = fieldNames + '\n';
        String[] fieldNameArray = fieldNames.split(",");

        for (Request request : requestList) {
        	
        	for (String fieldName : fieldNameArray) {
        		csvString += "\"";
        		if ("RequestNumber".equals(fieldName)) {
        			csvString += request.getRequestNumber () + "\",";
        		}
        		else if ("RequestType".equals(fieldName)) {
        			csvString += request.getRequestType () + "\",";
        		}
        		else if ("RequestStatus".equals(fieldName)) {
        			csvString += request.getRequestStatus () + "\",";
        		}
        		else if ("RequestDate".equals(fieldName)) {
        			csvString += request.getRequestDateStr () + "\",";
        		}
        		else if ("AirportCode".equals(fieldName)) {
        			csvString += request.getAirport () + "\",";
        		}
                        else if ("From".equals(fieldName)) {
        			csvString += request.getInLieuAirport () + "\",";
        		}
                        else if ("SubjectIndividual".equals(fieldName)) {
        			csvString += request.getSubjectIndividual ().replaceAll("(\\r|\\n)", "") + "\",";

        		}
        		else if ("SubjectCompany".equals(fieldName)) {
        			csvString += request.getSubjectCompany ().replaceAll("(\\r|\\n)", "") + "\",";
        		}
        		else if ("SubjectRegionID".equals(fieldName)) {
        			csvString += request.getSubjectRegion () + "\",";
        		}
        		else if ("Recommendation".equals(fieldName)) {
        			csvString += request.getRecommendation ().replaceAll("(\\r|\\n)", "") + "\",";
        		}
        		else if ("Comments".equals(fieldName)) {
        			csvString += request.getComments ().replaceAll("(\\r|\\n)", "") + "\",";
        		}

        		else if ("DerogLevel".equals(fieldName)) {
        			csvString += request.getDerogLevel () + "\",";
        		}
        		else if ("CreateUsername".equals(fieldName)) {
        			csvString += request.getCreateUserName () + "\",";
        		}
        		else if ("CreateTimestamp".equals(fieldName)) {
        			csvString += request.getCreateTimestampStr () + "\",";
        		}
        		else if ("LastUpdateUsername".equals(fieldName)) {
        			csvString += request.getLastUpdateUserName () + "\",";
        		}
        		else if ("LastUpdateTimestamp".equals(fieldName)) {
        			csvString += request.getLastUpdateTimestampStr () + "\",";
        		}
        		else if ("LeadTargeter".equals(fieldName)) {
        			csvString += request.getLeadTargeterName () + "\",";
        		}
        		else if ("CoTargeters".equals(fieldName)) {
        			csvString += request.getCoTargeterName () + "\",";
        		}
        		else if ("RequestorName".equals(fieldName)) {
        			csvString += request.getRequestorName () + "\",";
        		}
                else if ("Requestor".equals(fieldName)) {
        			csvString += request.getRequestor () + "\",";
        		}
        		else if ("STAInformation".equals(fieldName)) {
        			if (null == request.getStaList ()) {
	        			csvString += "\",";
        			}
        			else {
	        			csvString += Arrays.toString(request.getStaList ()) + "\",";
        			}
        		}
        	}
            csvString = csvString.substring(0, csvString.length()-1) + '\n';    // remove the last comma and add linebreak
        }
        

		logger.info("-------------END:getCsvRequestsByFields:" );
		
		
        
        return csvString;
    }


    public String getXmlRequestsByFields(String fieldNames, String searchStatus, String searchData) throws Exception {

			logger.info("-------------:getXmlRequestsByFields:"  );						

        if (null == fieldNames || fieldNames.isEmpty()) {
            return null;
        }        
                            
        String xmlString = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<root>\n";
        
        // call getRequestList using lastSearch parameters
		List<Request> requestList = getRequestListForExport (searchStatus, searchData);
                            
        String[] fieldNameArray = fieldNames.split(",");

        for (Request request : requestList) {
        	
            xmlString += "<row>\n";
                
        	for (String fieldName : fieldNameArray) {
        		
        		if ("RequestNumber".equals(fieldName)) {
                    xmlString += "<" + fieldName + ">" + request.getRequestNumber () + "</" + fieldName + ">\n";    
        		}
        		else if ("RequestType".equals(fieldName)) {
                    xmlString += "<" + fieldName + ">" + request.getRequestType () + "</" + fieldName + ">\n";    
        		}
        		else if ("RequestStatus".equals(fieldName)) {
                    xmlString += "<" + fieldName + ">" + request.getRequestStatus () + "</" + fieldName + ">\n";    
        		}
        		else if ("RequestDate".equals(fieldName)) {
                    xmlString += "<" + fieldName + ">" + request.getRequestDateStr () + "</" + fieldName + ">\n";    
        		}
        		else if ("AirportCode".equals(fieldName)) {
                    xmlString += "<" + fieldName + ">" + request.getAirport () + "</" + fieldName + ">\n";    
        		}
                else if ("From".equals(fieldName)) {
                    xmlString += "<" + fieldName + ">" + request.getInLieuAirport () + "</" + fieldName + ">\n";    
        		}
                else if ("SubjectIndividual".equals(fieldName)) {
                    xmlString += "<" + fieldName + ">" + request.getSubjectIndividual().replaceAll("(\\r|\\n)", "").replaceAll("&", "&amp;").replaceAll("<","&lt;") + "</" + fieldName + ">\n";    
        		}
        		else if ("SubjectCompany".equals(fieldName)) {
                    xmlString += ("<" + fieldName + ">" + request.getSubjectCompany().replaceAll("(\\r|\\n)", "").replaceAll("&", "&amp;").replaceAll("<","&lt;")  + "</" + fieldName + ">\n");    
        		}
        		else if ("SubjectRegionID".equals(fieldName)) {
                    xmlString += "<" + fieldName + ">" + request.getSubjectRegion() + "</" + fieldName + ">\n";    
        		}
        		else if ("Recommendation".equals(fieldName)) {
                    xmlString += "<" + fieldName + ">" + request.getRecommendation ().replaceAll("(\\r|\\n)", "").replaceAll("&", "&amp;").replaceAll("<","&lt;") + "</" + fieldName + ">\n";    
        		}
        		else if ("Comments".equals(fieldName)) {
                    xmlString += "<" + fieldName + ">" + request.getComments().replaceAll("(\\r|\\n)", "").replaceAll("&", "&amp;").replaceAll("<","&lt;") + "</" + fieldName + ">\n";    
        		}
        		else if ("DerogLevel".equals(fieldName)) {
                    xmlString += "<" + fieldName + ">" + request.getDerogLevel () + "</" + fieldName + ">\n";    
        		}
        		else if ("CreateUsername".equals(fieldName)) {
                    xmlString += "<" + fieldName + ">" + request.getCreateUserName () + "</" + fieldName + ">\n";    
        		}
        		else if ("CreateTimestamp".equals(fieldName)) {
                    xmlString += "<" + fieldName + ">" + request.getCreateTimestampStr () + "</" + fieldName + ">\n";    
        		}
        		else if ("LastUpdateUsername".equals(fieldName)) {
                    xmlString += "<" + fieldName + ">" + request.getLastUpdateUserName () + "</" + fieldName + ">\n";    
        		}
        		else if ("LastUpdateTimestamp".equals(fieldName)) {
                    xmlString += "<" + fieldName + ">" + request.getLastUpdateTimestampStr () + "</" + fieldName + ">\n";    
        		}
        		else if ("LeadTargeter".equals(fieldName)) {
                    xmlString += "<" + fieldName + ">" + request.getLeadTargeterName () + "</" + fieldName + ">\n";    
        		}
        		else if ("CoTargeters".equals(fieldName)) {
                    xmlString += "<" + fieldName + ">" + request.getCoTargeterName () + "</" + fieldName + ">\n";    
        		}
                else if ("Requestor".equals(fieldName)) {
                    xmlString += "<" + fieldName + ">" + request.getRequestor ().replaceAll("&", "&amp;") + "</" + fieldName + ">\n";    
        		}
        		else if ("STAInformation".equals(fieldName)) {
        			if (null == request.getStaList ()) {
	                    xmlString += "<" + fieldName + "></" + fieldName + ">\n";   
        			}
        			else {
	                     xmlString += "<" + fieldName + ">\n";   
	                     	
		             	 Sta[] staList = request.getStaList ();
		             	 for (Sta staRow : staList) {
		                    xmlString += "<staRow>" + staRow.toString ().replaceAll("&", "&amp;").replaceAll("<","&lt;") + "</staRow>\n";   
		             	 }
		             	 
	                     xmlString += "</" + fieldName + ">\n";   
        			}
        		}
        	}
            xmlString += "</row>\n";
        }
        xmlString += "</root>";
        
            
        logger.info(" ---- END: getXmlRequestsByFields:" );
        return xmlString;
    }


    public String getXmlRequestsByFields1(String fieldNames) throws Exception {

			

        if (null == fieldNames || fieldNames.isEmpty()) {
            return null;
        }        
                            
        String xmlString = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<root>\n";
        
        String[] fieldNameArray = fieldNames.split(",");
        
        String queryStr = "select " + fieldNames + " from FD.CTUREQUEST order by LastUpdateTimeStamp DESC ";

        Session session = null;

        try {
            session = HibernateUtil.getSessionFactory().openSession();
            Query query = session.createSQLQuery(queryStr);

            ScrollableResults resultSet = query.scroll();
            if (resultSet.first()) {
                do {
                    xmlString += "<row>\n";

                    xmlString += "<" + fieldNameArray[0] + ">";                
                    xmlString += (null == resultSet.get(0)) ? "" : resultSet.get(0).toString() ;
                    xmlString += "</" + fieldNameArray[0] + ">\n";                
                    	
                    xmlString += "<" + fieldNameArray[1] + ">";                
                    xmlString +=  (null == resultSet.get(1)) ? "" : resultSet.get(1).toString() ;
                    xmlString += "</" + fieldNameArray[1] + ">\n";                

                    xmlString += "<" + fieldNameArray[2] + ">";                
                    xmlString +=  (null == resultSet.get(2)) ? "" : resultSet.get(2).toString() ;
                    xmlString += "</" + fieldNameArray[2] + ">\n";                
                    
                    xmlString += "</row>\n";
                } while (resultSet.next());
                xmlString += "</root>";
            }

        } catch (Exception hqEx) {
            logger.error("====exception in RT DAO getRequestsByFields:" + hqEx.getMessage());
            throw hqEx;
        } finally {
            if (session != null) {
            session.close(); }
        }

        return xmlString;
    }


    public void saveRequestHistory(Session session, Cturequest req) throws QueryException {
        try {
            BigDecimal historyId = getSeqNextVal(session, "FD.CtuRequestHistoryId_Seq");

            String fieldNames = "(RequestId, RequestNumber, RequestStatus, LEADTARGETER, CoTargeters, SUBJECTINDIVIDUAL, SubjectCompany, SubjectRegionId, RequesterAgencyId, Requester, RequestorName, AirportId, DerogLevel, RECOMMENDATION, COMMENTS, StaInformation, LastUpdateUserName, LastUpdateTimeStamp, InLieuAirport)";

            String queryStr = "insert into FD.CtuRequestHistory " + fieldNames
                + " values (:historyId, :getRequestNumber, :getRequestStatus, :getLeadTargeter, :getCoTargeters, :getSubjectIndividual, :getSubjectCompany, :getSubjectReqionID, :getRequesterAgencyID, :getRequester, :getRequestorName, :getAirportId, :getDerogLevel, :getRecommendation, :getComments, :getStaInformation, :getLastUpdateUserName, :getLastUpdateTimestamp, :getInLieuAirport)";

            Query query = session.createSQLQuery(queryStr);
            query.setParameter("historyId", historyId);
            query.setParameter("getRequestNumber", req.getRequestNumber());
            query.setParameter("getRequestStatus", req.getRequestStatus());
            query.setParameter("getLeadTargeter", req.getLeadTargeter());
            query.setParameter("getCoTargeters", req.getCoTargeter());
            query.setParameter("getSubjectIndividual", req.getSubjectIndividual());
            query.setParameter("getSubjectCompany", req.getSubjectCompany());
            query.setParameter("getSubjectReqionID", req.getSubjectReqionID());
            query.setParameter("getRequesterAgencyID", req.getRequesterAgencyID());   // requestor number
            query.setParameter("getRequester", req.getRequester());   // requestor
            query.setParameter("getRequestorName", req.getRequestorName());
            query.setParameter("getAirportId", req.getAirportID());
            query.setParameter("getDerogLevel", req.getDerogLevel());
            query.setParameter("getRecommendation", req.getRecommendation());
            query.setParameter("getComments", req.getComments());
            query.setParameter("getStaInformation", req.getStaInformation());
            query.setParameter("getLastUpdateUserName", req.getLastUpdateUserName());
            query.setParameter("getLastUpdateTimestamp", req.getLastUpdateTimestamp());
            query.setParameter("getInLieuAirport", req.getInLieuAirport());
            query.executeUpdate();
            session.flush();

        } catch (QueryException hqEx) {
            logger.error("====exception in RT DAO:" + hqEx.getMessage());
            throw hqEx;
        } 
    }

    public List<Request> getRequestHistory(String requestNumber) throws Exception {
        RequestReferenceData requestReferenceData = RequestReferenceData.getInstance();

        if (null == requestNumber || requestNumber.isEmpty()) {
            return null;
        }
        List<Request> requestList = new ArrayList<Request>();

        String idString = "";

        String queryStr;
        Request request = null;

        String fieldNames = " REQUESTNUMBER, REQUESTSTATUS, REQUESTTYPE, REQUESTDATE, REQUESTER, DEROG, DEROGLEVEL, "
                + "AIRPORTID, SUBJECTREGIONID, LEADTARGETER, COTARGETERS, SUBJECTINDIVIDUAL, SUBJECTCOMPANY, RECOMMENDATION, "
                + "COMMENTS, REQUESTORNAME, REQUESTERAGENCYID, STAINFORMATION, LastUpdateUserName, LastUpdateTimeStamp, inLieuAirport ";

        queryStr = "select " + fieldNames + " from FD.CtuRequestHistory where REQUESTNUMBER = '" + requestNumber
                + "' order by LastUpdateTimeStamp DESC";

        Session session = null;

        try {
            session = HibernateUtil.getSessionFactory().openSession();
            Query query = session.createSQLQuery(queryStr);

            ScrollableResults resultSet = query.scroll();
            if (resultSet.first()) {
                do {

                    request = new Request();
                    request.setRequestNumber((null == resultSet.get(0)) ? "" : resultSet.get(0).toString());
                    request.setRequestStatus((null == resultSet.get(1)) ? "" : resultSet.get(1).toString());
                    request.setRequestType((null == resultSet.get(2)) ? "" : resultSet.get(2).toString());
                    request.setRequestDate((null == resultSet.get(3)) ? null : dateFormat.parse(resultSet.get(3).toString().substring(0, 10)));
                    request.setDerogFound((null == resultSet.get(5)) ? false : true);
                    idString = (null == resultSet.get(6)) ? "0" : resultSet.get(6).toString();  // derogLevel
                    request.setDerogLevel(translateDerogLevel(idString));
                    idString = (null == resultSet.get(7)) ? "0" : resultSet.get(7).toString();  // airport -- should get airport name from DB
                    request.setAirport(getAirportName(requestReferenceData.getAirportNamesLinkedMap(), idString));  // airportId in NEW list
                    idString = (null == resultSet.get(8)) ? "0" : resultSet.get(8).toString();  // subjectRegionId
                    request.setSubjectRegion(getName(requestReferenceData.getSubjectRegionLinkedMap(), idString));

                    idString = (null == resultSet.get(9)) ? "0" : resultSet.get(9).toString();  // leadtargeter
                    request.setLeadTargeterName(getName1(requestReferenceData.getTargeterLinkedMap(), idString));

                    idString = (null == resultSet.get(10)) ? "" : resultSet.get(10).toString();  // cotargeters
                    request.setCoTargeterName(getNames1(requestReferenceData.getTargeterLinkedMap(), idString));

                    request.setSubjectIndividual((null == resultSet.get(11)) ? "" : resultSet.get(11).toString());
                    request.setSubjectCompany((null == resultSet.get(12)) ? "" : resultSet.get(12).toString());
                    request.setRecommendation((null == resultSet.get(13)) ? "" : resultSet.get(13).toString());
                    request.setComments((null == resultSet.get(14)) ? "" : resultSet.get(14).toString());
                    request.setRequestorName((null == resultSet.get(15)) ? "" : resultSet.get(15).toString());
                    request.setRequestor((null == resultSet.get(16)) ? "0" : resultSet.get(16).toString());
                    request.setStaInformation((null == resultSet.get(17)) ? "" : resultSet.get(17).toString());
                    request.setLastUpdateUserName((null == resultSet.get(18)) ? "" : resultSet.get(18).toString());
                    date = (null == resultSet.get(19)) ? null : timestampFormat.parse(resultSet.get(19).toString());
                    request.setLastUpdateTimestamp(new Timestamp(date.getTime()));

                    idString = (null == resultSet.get(20)) ? "" : resultSet.get(20).toString();  // inLieuAirport
                    request.setInLieuAirport(translateInLieuAirport(idString));

                    requestList.add(request);

                } while (resultSet.next());
            }
        } catch (Exception hqEx) {
            logger.error("====exception in RT getRequestHistory DAO:" + hqEx.getMessage());
            throw hqEx;
        } finally {
            if (session != null) {
            session.close(); }
        }
        return requestList;
    }

// This method is used for Duplicate Subject Individual dialog
    public Request getRequest(String requestNumber) throws Exception {
        
        if (null == requestNumber || requestNumber.isEmpty()) {
            return null;
        }
        
        
        RequestReferenceData requestReferenceData = RequestReferenceData.getInstance();

        String airportName = "";
        String coTargeters = "";
        String airportKey;
        String queryStr;
        Request request = null;

        String fieldNames = " R.REQUESTNUMBER, R.REQUESTSTATUS, R.REQUESTTYPE, R.REQUESTDATE, R.REQUESTER, R.DEROG, R.DEROGLEVEL, "
                + "R.AIRPORTID, R.SUBJECTREGIONID, R.LEADTARGETER, R.COTARGETERS, R.SUBJECTINDIVIDUAL, R.SUBJECTCOMPANY, R.RECOMMENDATION, "
                + "R.COMMENTS, R.REQUESTORNAME, R.REQUESTERAGENCYID, R.STAINFORMATION,  R.CreateUserName, R.CreateTimestamp, "
                + "R.LastUpdateUsername, R.LastUpdateTimestamp, R.inLieuAirport ";

        queryStr = "select " + fieldNames + " from FD.CTUREQUEST R where R.REQUESTNUMBER = '" + requestNumber + "'";

        Session session = null;

        try {
            session = HibernateUtil.getSessionFactory().openSession();
            Query query = session.createSQLQuery(queryStr);

            ScrollableResults resultSet = query.scroll();
            if (resultSet.first()) {
                request = new Request();
                request.setRequestNumber((null == resultSet.get(0)) ? "" : resultSet.get(0).toString());
                request.setRequestStatus((null == resultSet.get(1)) ? "" : resultSet.get(1).toString());
                request.setRequestType((null == resultSet.get(2)) ? "" : resultSet.get(2).toString());
                request.setRequestDate((null == resultSet.get(3)) ? null : dateFormat.parse(resultSet.get(3).toString().substring(0, 10)));
                request.setDerogFound((null == resultSet.get(5)) ? false : true);
                request.setDerogLevel((null == resultSet.get(6)) ? "0" : resultSet.get(6).toString());
                request.setAirportKey((null == resultSet.get(7)) ? "0" : resultSet.get(7).toString());
                request.setSubjectRegionId((null == resultSet.get(8)) ? "0" : resultSet.get(8).toString());
                request.setLeadTargeterId((null == resultSet.get(9)) ? "0" : resultSet.get(9).toString());

                coTargeters = (null == resultSet.get(10)) ? "0" : resultSet.get(10).toString();
                request.setSubjectIndividual((null == resultSet.get(11)) ? "" : resultSet.get(11).toString());
                request.setSubjectCompany((null == resultSet.get(12)) ? "" : resultSet.get(12).toString());
                request.setRecommendation((null == resultSet.get(13)) ? "" : resultSet.get(13).toString());
                request.setComments((null == resultSet.get(14)) ? "" : resultSet.get(14).toString());
                request.setRequestorName((null == resultSet.get(15)) ? "" : resultSet.get(15).toString());
                request.setRequestorId((null == resultSet.get(16)) ? "0" : resultSet.get(16).toString());
                request.setStaInformation((null == resultSet.get(17)) ? "" : resultSet.get(17).toString());

                request.setCreateUserName((null == resultSet.get(18)) ? "" : resultSet.get(18).toString().split("@")[0]);
                date = (null == resultSet.get(19)) ? null : timestampFormat.parse(resultSet.get(19).toString().substring(0, 20));
                if (null != date) {
                    request.setCreateTimestamp(new Timestamp(date.getTime()));
                }
                request.setLastUpdateUserName((null == resultSet.get(20)) ? "" : resultSet.get(20).toString().split("@")[0]);
                date = (null == resultSet.get(21)) ? null : timestampFormat.parse(resultSet.get(21).toString().substring(0, 20));
                if (null != date) {
                    request.setLastUpdateTimestamp(new Timestamp(date.getTime()));
                }
                               
                request.setInLieuAirport((null == resultSet.get(22)) ? "" : resultSet.get(22).toString());
                airportKey = request.getAirportKey();
                airportName = "";
                if (airportKey != null || !airportKey.isEmpty()) {
                    // should use getName1
                    for (Iterator it = requestReferenceData.getAirportNamesLinkedMap().entrySet().iterator(); it.hasNext();) {
                        Map.Entry entry = (Map.Entry) it.next();
                        String key = (String) entry.getKey();   // new Key = airportCode + airportId
                        if (key.split("~~")[1].equals(airportKey)) {
                            airportName = (String) entry.getValue();
                            airportKey = key;
                            break;
                        }
                    }
                    
                }
                request.setAirportKey(airportName);
   
                request.setAirport(airportName);               

                // convert derog level
                String derogLevel = request.getDerogLevel();
                if (derogLevel.equals("2")) {
                    request.setDerogLevel("Medium");
                } else if (derogLevel.equals("3")) {
                    request.setDerogLevel("High");
                } else if (derogLevel.equals("1")) {
                    request.setDerogLevel("Low");
                } else {
                    request.setDerogLevel("");
                }

                String inLieuAirport = request.getInLieuAirport();
                switch(inLieuAirport){
                    case "1": request.setInLieuAirport("HQ");
                        break;
                    case "2": request.setInLieuAirport("Other");
                        break;
                    case "": request.setInLieuAirport("");
                }
                
	        	requestReferenceData.setTargeterLinkedMap (this.getTargeterList ());   // for all TARs - need optimization: requestReferenceData.getAllTargeterMap.
                request.setLeadTargeterName(getName1(requestReferenceData.getTargeterLinkedMap(), request.getLeadTargeterId()));
                request.setSubjectRegion(getName(requestReferenceData.getSubjectRegionLinkedMap(), request.getSubjectRegionId()));

                String[] coTargeterAry;
                String cotargeterNames = "";
                coTargeterAry = coTargeters.split(",");
                for (int i = 0; i < coTargeterAry.length; i++) {
                    cotargeterNames += getName1(requestReferenceData.getTargeterLinkedMap(), coTargeterAry[i].trim());
                    cotargeterNames += "; ";
                }
                cotargeterNames = cotargeterNames.trim();
                if (cotargeterNames.endsWith(";")) {
                    cotargeterNames = cotargeterNames.substring(0, cotargeterNames.length() - 1);
                }
                request.setCoTargeterName(cotargeterNames);

                request.setRequestor(getRequestorByRequestType(request.getRequestType(), request.getRequestorId()));
            }
        } catch (Exception hqEx) {
            logger.error("====exception in RT DAO:" + hqEx.getMessage());
            throw hqEx;
        } finally {
            if (session != null) {
            session.close(); }
        }
        return request;
    }

    private String getRequestorByRequestType(String requestType, String key) {

        RequestReferenceData requestReferenceData = RequestReferenceData.getInstance();

        if (requestType.equals("CI")) {
            return getName(requestReferenceData.getCargoIncidentLinkedMap(), key);
        } else if (requestType.equals("OGA")) {
            return getName(requestReferenceData.getOgaReferralLinkedMap(), key);
        } else if (requestType.equals("JO")) {
            return getName(requestReferenceData.getJointOperationsLinkedMap(), key);
        } else {
        	requestReferenceData.setCcsfApprovalLinkedMap (this.getCCSFApprovalList ());   // for all PSIs - need optimization
            return getName1(requestReferenceData.getCcsfApprovalLinkedMap(), key);
        }
    }

    private String getRequestorByRequestType1(String requestType, String key) {

        RequestReferenceData requestReferenceData = RequestReferenceData.getInstance();

        if (requestType.equals("CI")) {
            return getName(requestReferenceData.getCargoIncidentLinkedMap(), key);
        } else if (requestType.equals("OGA")) {
            return getName(requestReferenceData.getOgaReferralLinkedMap(), key);
        } else if (requestType.equals("JO")) {
            return getName(requestReferenceData.getJointOperationsLinkedMap(), key);
        } else {
        	
            return getName1(requestReferenceData.getCcsfApprovalLinkedMap(), key);
        }
    }

    
    public List<Request> getRequestList(String searchStatus, String searchData) throws Exception {
        
        String airportName = "";
        String airportKey;
        String queryStr;
        String searchString = null;
        RequestReferenceData requestReferenceData = RequestReferenceData.getInstance();

        if (null != searchData) {
            searchString = searchData.toUpperCase();
        }

        String fieldNames = " R.REQUESTNUMBER, R.REQUESTSTATUS, R.REQUESTTYPE, R.REQUESTDATE, R.REQUESTER, R.DEROG, R.DEROGLEVEL, "
                + "R.AIRPORTID, R.SUBJECTREGIONID, R.LEADTARGETER, R.COTARGETERS, R.SUBJECTINDIVIDUAL, R.SUBJECTCOMPANY, R.RECOMMENDATION, "
                + "R.COMMENTS, R.REQUESTORNAME, R.REQUESTERAGENCYID, R.STAINFORMATION, R.CreateUserName, R.CreateTimestamp, R.LastUpdateUsername, R.LastUpdateTimestamp, R.INLIEUAIRPORT ";

        String joinTables = " inner join fd.cturequesttype TYPE on R.requesttype=TYPE.requesttype "
                + "left join fd.ctusubjectregion REG on R.subjectregionid=REG.subjectregionid "
                + "left join fd.orghierarchy AIR on R.airportid=AIR.orgid "
                + "left join fd.orghierarchy PSI on R.REQUESTERAGENCYID=PSI.orgid "
                + "left join FD.orghierarchy TAR on R.leadtargeter=TAR.orgid ";
       
        String searchTextCompare = " upper(R.REQUESTNUMBER) like '%" + searchString + "%'"
                + " or upper(R.REQUESTSTATUS) like '%" + searchString + "%'"
                + " or upper(R.REQUESTER) like '%" + searchString + "%'"
                + " or upper(R.REQUESTORNAME) like '%" + searchString + "%'"
                + " or upper(R.SUBJECTINDIVIDUAL) like '%" + searchString + "%'"
                + " or upper(R.SUBJECTCOMPANY) like '%" + searchString + "%'"
                + " or upper(R.RECOMMENDATION) like '%" + searchString + "%'"
                + " or upper(R.COMMENTS) like '%" + searchString + "%'"
                + " or upper(R.CreateUserName) like '%" + searchString + "%' "
                + " or upper(R.LastUpdateUsername) like '%" + searchString + "%' "
                + " or upper(R.REQUESTDATE) like '%" + searchString + "%' ";

        String searchSelectCompare = " or upper(TYPE.REQUESTNAME) like '%" + searchString + "%'"
                + " or upper(AIR.ORGNAME) like '%" + searchString + "%'"
                + " or upper(REG.REGIONNAME) like '%" + searchString + "%'"
                + " or upper(PSI.contactFirstname || ' ' || PSI.contactLastName) like '%" + searchString + "%' "
                + " or upper(tar.contactFirstname || ' ' || tar.contactLastName) like '%" + searchString + "%' ";

        queryStr = "select " + fieldNames + " from FD.CTUREQUEST R ";

        if ("AdvancedSearch".equals(searchStatus)) {
            if (null != searchData) {
                queryStr += searchData;
                queryStr += " ORDER BY R.LASTUPDATETIMESTAMP DESC ";
            }
        } else {
            if (null != searchData) {
                queryStr += joinTables;
            }

            if (null != searchStatus) {
                queryStr += " where R.REQUESTSTATUS='" + searchStatus + "'";
                if (null != searchData) {
                    queryStr += " and (" + searchTextCompare + searchSelectCompare + ")";
                }
                queryStr += " ORDER BY R.LASTUPDATETIMESTAMP ASC ";
            } else {
                if (null != searchData) {
                    queryStr += " where " + searchTextCompare + searchSelectCompare;
                }
                queryStr += " ORDER BY R.LASTUPDATETIMESTAMP DESC ";
            }
        }
        List<Request> requestList = new ArrayList<Request>();
        Session session = null;

        try {
            session = HibernateUtil.getSessionFactory().openSession();
            Query query = session.createSQLQuery(queryStr);

            ScrollableResults resultSet = query.scroll();
            if (resultSet.first()) {
                do {
                    Request request = new Request();
                    request.setRequestNumber((null == resultSet.get(0)) ? "" : resultSet.get(0).toString());
                    request.setRequestStatus((null == resultSet.get(1)) ? "" : resultSet.get(1).toString());
                    request.setRequestType((null == resultSet.get(2)) ? "" : resultSet.get(2).toString());
                    request.setRequestDate((null == resultSet.get(3)) ? null : dateFormat.parse(resultSet.get(3).toString().substring(0, 10)));
                    request.setDerogFound((null == resultSet.get(5)) ? false : true);
                    request.setDerogLevel((null == resultSet.get(6)) ? "0" : resultSet.get(6).toString());
                    request.setAirportKey((null == resultSet.get(7)) ? "0" : resultSet.get(7).toString());
                    request.setSubjectRegionId((null == resultSet.get(8)) ? "0" : resultSet.get(8).toString());
                    
                    request.setLeadTargeterId((null == resultSet.get(9)) ? "0" : resultSet.get(9).toString());
                    request.setCoTargeter((null == resultSet.get(10)) ? "0" : resultSet.get(10).toString());
                    request.setSubjectIndividual((null == resultSet.get(11)) ? "" : resultSet.get(11).toString());
                    request.setSubjectCompany((null == resultSet.get(12)) ? "" : resultSet.get(12).toString());
                    request.setRecommendation((null == resultSet.get(13)) ? "" : resultSet.get(13).toString());
                    request.setComments((null == resultSet.get(14)) ? "" : resultSet.get(14).toString());
                    request.setRequestorName((null == resultSet.get(15)) ? "" : resultSet.get(15).toString());
                    request.setStaInformation((null == resultSet.get(17)) ? "" : resultSet.get(17).toString());
                    request.setCreateUserName((null == resultSet.get(18)) ? "" : resultSet.get(18).toString());
                    date = (null == resultSet.get(19)) ? null : timestampFormat.parse(resultSet.get(19).toString().substring(0, 20));
                    if (null != date) {
                        request.setCreateTimestamp(new Timestamp(date.getTime()));
                    }
                    request.setLastUpdateUserName((null == resultSet.get(20)) ? "" : resultSet.get(20).toString());
                    date = (null == resultSet.get(21)) ? null : timestampFormat.parse(resultSet.get(21).toString().substring(0, 20));
                    if (null != date) {
                        request.setLastUpdateTimestamp(new Timestamp(date.getTime()));
                    }

                    request.setInLieuAirport((null == resultSet.get(22)) ? "" : resultSet.get(22).toString());
                    airportKey = request.getAirportKey();
                    airportName = "";
                    if (airportKey != null || !airportKey.isEmpty()) {
                        
                        for (Iterator it = requestReferenceData.getAirportNamesLinkedMap().entrySet().iterator(); it.hasNext();) {
                            Map.Entry entry = (Map.Entry) it.next();
                            String key = (String) entry.getKey();   // new Key = airportCode + airportId
                            if (key.split("~~")[1].equals(airportKey)) {
                                airportName = (String) entry.getValue();
                                airportKey = key;
                                break;
                            }
                        }
                        
                    }
                    request.setAirportKey(airportName);
                    request.setAirport(airportKey);
                  

                    // convert derog level
                    String derogLevel = request.getDerogLevel();
             
                    switch(derogLevel){
                        case "2": request.setDerogLevel("Medium");
                            break;
                        case "3": request.setDerogLevel("High");
                            break;
                        case "1": request.setDerogLevel("Low");
                            break;
                        case "": request.setDerogLevel("");
                    }

                    // convert in lieu of Airport
                    String inLieuAirport = request.getInLieuAirport();
                    switch(inLieuAirport){
                        case "1": request.setInLieuAirport("HQ");
                            break;
                        case "2": request.setInLieuAirport("Other");
                            break;
                        case "": request.setInLieuAirport("");
                    }
                    
                    request.setLeadTargeterName(getName1(requestReferenceData.getTargeterLinkedMap(), request.getLeadTargeterId()));
                    request.setSubjectRegion(getName(requestReferenceData.getSubjectRegionLinkedMap(), request.getSubjectRegionId()));

                    String[] cotargeters;
                    String cotargeterNames = "";
                    cotargeters = request.getCoTargeter().split(",");
                    for (int i = 0; i < cotargeters.length; i++) {
                        cotargeterNames += getName1(requestReferenceData.getTargeterLinkedMap(), cotargeters[i].trim());
                        cotargeterNames += "\n";
                    }
                    request.setCoTargeterName(cotargeterNames);

                    requestList.add(request);
                } while (resultSet.next());
            }

        } catch (Exception hqEx) {
            logger.error("====exception in RT DAO:" + hqEx.getMessage());
            throw hqEx;
        } finally {
            if (session != null) {
            session.close();}
        }
        return requestList;
    }

    public int getRequestCount() throws Exception {
        int count = 0;
        String queryStr = "SELECT COUNT(*) AS COUNT FROM FD.CTUREQUEST";
        Session session = null;

        try {
			session = HibernateUtil.getSessionFactory().openSession();
            Query query = session.createSQLQuery(queryStr);

            ScrollableResults resultSet = query.scroll();
            if (resultSet.first()) {
                if (null != resultSet.get(0)) {
                    count = (int) resultSet.get(0);
                }
            }
        } catch (Exception hqEx) {
            logger.error("====exception in RT DAO:" + hqEx.getMessage());
            throw hqEx;
        } finally {
            if (session != null) {
            session.close(); }
        }
        return count;
    }

    public int getRequestCount(String searchStatus, String searchData) throws Exception {
        int count = 0;

        String queryStr;
        String searchString = null;

        if (null != searchData) {
            searchString = fixRestoreSearchText(searchData).toUpperCase();
        }

        String joinTables = " inner join fd.cturequesttype TYPE on R.requesttype=TYPE.requesttype "
                + "left join fd.ctusubjectregion REG on R.subjectregionid=REG.subjectregionid "
                + "left join fd.orghierarchy AIR on R.airportid=AIR.orgid "
                + "left join fd.orghierarchy PSI on R.REQUESTERAGENCYID=PSI.orgid "
                + "left join FD.orghierarchy TAR on R.leadtargeter=TAR.orgid ";

        String searchTextCompare = " upper(R.REQUESTNUMBER) like '%" + searchString + "%'"
                + " or upper(R.REQUESTSTATUS) like '%" + searchString + "%'"
                + " or upper(R.REQUESTER) like '%" + searchString + "%'"
                + " or upper(R.REQUESTORNAME) like '%" + searchString + "%'"
                + " or upper(R.SUBJECTINDIVIDUAL) like '%" + searchString + "%'"
                + " or upper(R.SUBJECTCOMPANY) like '%" + searchString + "%'"
                + " or upper(R.RECOMMENDATION) like '%" + searchString + "%'"
                + " or upper(R.COMMENTS) like '%" + searchString + "%'"
                + " or upper(R.CreateUserName) like '%" + searchString + "%' "
                + " or upper(R.LastUpdateUsername) like '%" + searchString + "%' "
                + " or upper(R.REQUESTDATE) like '%" + searchString + "%' ";

        String searchSelectCompare = " or upper(TYPE.REQUESTNAME) like '%" + searchString + "%'"
                + " or upper(AIR.ORGNAME) like '%" + searchString + "%'"
                + " or upper(REG.REGIONNAME) like '%" + searchString + "%'"
                + " or upper(PSI.contactFirstname || ' ' || PSI.contactLastName) like '%" + searchString + "%' "
                + " or upper(tar.contactFirstname || ' ' || tar.contactLastName) like '%" + searchString + "%' ";

        queryStr = "SELECT COUNT(*) AS COUNT FROM FD.CTUREQUEST R ";

        if ("AdvancedSearch".equals(searchStatus)) {
            if (null != searchData) {
                queryStr += searchData;
               
            }
        } else {   // regular search
            if (null != searchData) {
                queryStr += joinTables;
            }

            if (null != searchStatus) {
                queryStr += " where R.REQUESTSTATUS='" + searchStatus + "'";
                if (null != searchData) {
                    queryStr += " and (" + searchTextCompare + searchSelectCompare + ")";
                }
                
            } else {
                if (null != searchData) {
                    queryStr += " where " + searchTextCompare + searchSelectCompare;
                }
                
            }
        }
        Session session = null;

        try {
            session = HibernateUtil.getSessionFactory().openSession();
            Query query = session.createSQLQuery(queryStr);

            ScrollableResults resultSet = query.scroll();
            if (resultSet.first()) {
                if (null != resultSet.get(0)) {
                    count = ((BigDecimal) resultSet.get(0)).intValueExact();
                }
            }
        } catch (Exception hqEx) {
            logger.error("====exception in RT DAO:" + hqEx.getMessage());
            throw hqEx;
        } finally {
            if (session != null) {
            session.close(); }
        }
        return count;
    }
    
    private String translateDerogLevel(String DerogLevelIndex) {
        
        if (DerogLevelIndex.equals("1")) {
            return "Low";
        } else if (DerogLevelIndex.equals("2")) {
            return "Medium";
        } else if (DerogLevelIndex.equals("3")) {
            return "High";
        } else {
            return "None";
        }
    }
    
    private String translateInLieuAirport(String inLieuAirportIndex) {
        
        if (inLieuAirportIndex.equals("1")) {
            return "HQ";
        } else if (inLieuAirportIndex.equals("2")) {
            return "Other";
        } else {
            return "";
        }
    }
    
    // Replace single quote to two single quotes for SQL search. Use this for basic search in this class
    private String fixRestoreSearchText(String s) {
        
        int len = s.length();
        String s1 = "";
        for(int i=0; i<len; i++) {
           if (s.charAt(i) == '\'') {
               if (i+1 < len && s.charAt(i+1) == '\'') {  // ''
                   i++;
               }
               s1 += "''";
           }
           else {
               s1 += s.charAt(i) + "";
           }
        }
        return s1.replace("<escript>", "</script>");
    }
    
    public List<Request> getRequestList(String searchStatus, String searchData, int startPageIndex, int recordsPerPage) throws Exception {
    	
		logger.info("-------------BEGIN:getRequestList:" + searchStatus + ", " + searchData);
    	
        RequestReferenceData requestReferenceData = RequestReferenceData.getInstance();
        requestReferenceData.setCcsfApprovalLinkedMap(this.getCCSFApprovalList());       // this is needed to get all PSIs for loading after saving
        requestReferenceData.setTargeterLinkedMap(this.getTargeterList ());       // this is needed to get all TARs for loading after saving

        String airportName = "";
        String airportId, leadTargeterId, requestorId, coTargeterIds;
        String queryStr;
        String searchString = null;
        startPageIndex--;    // index starts at 0
        int startRowNum = startPageIndex * recordsPerPage;
        int endRowNum = startRowNum + recordsPerPage;

        if (null != searchData) {
            searchString = fixRestoreSearchText(searchData).toUpperCase();
        }

        String fieldNames = " R.REQUESTNUMBER, R.REQUESTSTATUS, R.REQUESTTYPE, R.REQUESTDATE, R.REQUESTER, R.DEROG, R.DEROGLEVEL, "
                + "R.AIRPORTID, R.SUBJECTREGIONID, R.LEADTARGETER, R.COTARGETERS, R.SUBJECTINDIVIDUAL, R.SUBJECTCOMPANY, R.RECOMMENDATION, "
                + "R.COMMENTS, R.REQUESTORNAME, R.REQUESTERAGENCYID, R.STAINFORMATION, R.CreateUserName, R.CreateTimestamp, R.LastUpdateUsername, R.LastUpdateTimestamp, R.INLIEUAIRPORT ";

        String joinTables = " inner join fd.cturequesttype TYPE on R.requesttype=TYPE.requesttype "
                + "left join fd.ctusubjectregion REG on R.subjectregionid=REG.subjectregionid "
                + "left join fd.orghierarchy AIR on R.airportid=AIR.orgid "
                + "left join fd.orghierarchy PSI on R.REQUESTERAGENCYID=PSI.orgid "
                + "left join FD.orghierarchy TAR on R.leadtargeter=TAR.orgid ";

        String searchTextCompare = " upper(R.REQUESTNUMBER) like '%" + searchString + "%'"
                + " or upper(R.REQUESTSTATUS) like '%" + searchString + "%'"
                + " or upper(R.REQUESTER) like '%" + searchString + "%'"
                + " or upper(R.REQUESTORNAME) like '%" + searchString + "%'"
                + " or upper(R.SUBJECTINDIVIDUAL) like '%" + searchString + "%'"
                + " or upper(R.SUBJECTCOMPANY) like '%" + searchString + "%'"
                + " or upper(R.RECOMMENDATION) like '%" + searchString + "%'"
                + " or upper(R.COMMENTS) like '%" + searchString + "%'"
                + " or upper(R.CreateUserName) like '%" + searchString + "%' "
                + " or upper(R.LastUpdateUsername) like '%" + searchString + "%' "
                + " or upper(R.REQUESTDATE) like '%" + searchString + "%' ";

        String searchSelectCompare = " or upper(TYPE.REQUESTNAME) like '%" + searchString + "%'"
                + " or upper(AIR.ORGNAME) like '%" + searchString + "%'"
                + " or upper(REG.REGIONNAME) like '%" + searchString + "%'"
                + " or upper(PSI.contactFirstname || ' ' || PSI.contactLastName) like '%" + searchString + "%' "
                + " or upper(tar.contactFirstname || ' ' || tar.contactLastName) like '%" + searchString + "%' ";

        if (recordsPerPage > 0) {
            queryStr = "select * from ( select  a.*, rownum rnum from (select " + fieldNames + " from FD.CTUREQUEST R ";
        } else {
            queryStr = "select " + fieldNames + " from FD.CTUREQUEST R ";
        }

        if ("AdvancedSearch".equals(searchStatus)) {
            if (null != searchData) {
                queryStr += searchData;
                queryStr += " ORDER BY R.LASTUPDATETIMESTAMP DESC ";
            }
        } else {
            if (null != searchData) {
                queryStr += joinTables;
            }

            if (null != searchStatus) {
                queryStr += " where R.REQUESTSTATUS='" + searchStatus + "'";
                if (null != searchData) {
                    queryStr += " and (" + searchTextCompare + searchSelectCompare + ")";
                }
                queryStr += " ORDER BY R.LASTUPDATETIMESTAMP ASC ";
            } else {
                if (null != searchData) {
                    queryStr += " where " + searchTextCompare + searchSelectCompare;
                }
                queryStr += " ORDER BY R.LASTUPDATETIMESTAMP DESC ";
            }
        }

        if (recordsPerPage > 0) {
            queryStr += ") a  where rownum <= " + endRowNum + ") where rnum > " + startRowNum;
        }

        List<Request> requestList = new ArrayList<Request>();
        String[] mapData;
  
        
        Session session = null;

        try {
            session = HibernateUtil.getSessionFactory().openSession();
            Query query = session.createSQLQuery(queryStr);

            ScrollableResults resultSet = query.scroll();
            if (resultSet.first()) {
                do {
                    Request request = new Request();
                    request.setRequestNumber((null == resultSet.get(0)) ? "" : resultSet.get(0).toString());
                    request.setRequestStatus((null == resultSet.get(1)) ? "" : resultSet.get(1).toString());
                    request.setRequestType((null == resultSet.get(2)) ? "" : resultSet.get(2).toString());
                    request.setRequestDate((null == resultSet.get(3)) ? null : dateFormat.parse(resultSet.get(3).toString().substring(0, 10)));
                    request.setDerogFound((null == resultSet.get(5)) ? false : true);
                    request.setDerogLevel((null == resultSet.get(6)) ? "0" : resultSet.get(6).toString());
                    
                    airportId = (null == resultSet.get(7)) ? "0" : resultSet.get(7).toString();
                    mapData = getSortedMapData (requestReferenceData.getAirportNamesLinkedMap(), airportId);
                    request.setAirportKey(mapData[0]);
                    request.setAirport(mapData[1].split("-")[0]);  // remove any airportCode in the name
                   
                    request.setSubjectRegionId((null == resultSet.get(8)) ? "0" : resultSet.get(8).toString());

                    
                    leadTargeterId = (null == resultSet.get(9)) ? "0" : resultSet.get(9).toString();
                    mapData = getSortedMapData (requestReferenceData.getTargeterLinkedMap(), leadTargeterId);
                    request.setLeadTargeterId(mapData[0]);
                    request.setLeadTargeterName(mapData[1]);
                    
                    coTargeterIds = (null == resultSet.get(10)) ? "0" : resultSet.get(10).toString();
                    // build name+id indexes
                    
                    String[] cotargeters;
                    String cotargeterNames = "";
                    String coTargeterNameIDs = "";
                    cotargeters = coTargeterIds.split(",");
                    for (int i = 0; i < cotargeters.length; i++) {
                        mapData = getSortedMapData (requestReferenceData.getTargeterLinkedMap(), cotargeters[i].trim());
                        coTargeterNameIDs += mapData[0];
                        coTargeterNameIDs += ",";
                        cotargeterNames += mapData[1];
                        cotargeterNames += "\n";
                    }
                    
                    request.setCoTargeter(coTargeterNameIDs);
                    request.setCoTargeterName(cotargeterNames);
                    
                    request.setSubjectIndividual((null == resultSet.get(11)) ? "" : resultSet.get(11).toString());
                    request.setSubjectCompany((null == resultSet.get(12)) ? "" : resultSet.get(12).toString());
                    request.setRecommendation((null == resultSet.get(13)) ? "" : resultSet.get(13).toString());
                    request.setComments((null == resultSet.get(14)) ? "" : resultSet.get(14).toString());
                    request.setRequestorName((null == resultSet.get(15)) ? "" : resultSet.get(15).toString());
                    
                    requestorId = (null == resultSet.get(16)) ? "0" : resultSet.get(16).toString(); // RequesterAgencyId  (PSI and non-PSI)
                    
                    mapData = getSortedMapData (requestReferenceData.getCcsfApprovalLinkedMap (), requestorId);   // check for PSI
                    
                    if (mapData[0].equals("0")) {     // non-PSI
	                    request.setRequestor(requestorId);  
                    }
                    else {  // PSI
	                    request.setRequestor(mapData[0]);
                    }

                    request.setStaInformation((null == resultSet.get(17)) ? "" : resultSet.get(17).toString());
                    request.setCreateUserName((null == resultSet.get(18)) ? "" : resultSet.get(18).toString());
                    date = (null == resultSet.get(19)) ? null : timestampFormat.parse(resultSet.get(19).toString().substring(0, 20));
                    if (null != date) {
                        request.setCreateTimestamp(new Timestamp(date.getTime()));
                    }
                    request.setLastUpdateUserName((null == resultSet.get(20)) ? "" : resultSet.get(20).toString());
                    date = (null == resultSet.get(21)) ? null : timestampFormat.parse(resultSet.get(21).toString().substring(0, 20));
                    if (null != date) {
                        request.setLastUpdateTimestamp(new Timestamp(date.getTime()));
                    }

                    request.setInLieuAirport((null == resultSet.get(22)) ? "" : resultSet.get(22).toString());
                    
                    // convert derog level
                    String derogLevel = request.getDerogLevel();
                    if (derogLevel.equals("2")) {
                        request.setDerogLevel("Medium");
                    } else if (derogLevel.equals("3")) {
                        request.setDerogLevel("High");
                    } else if (derogLevel.equals("1")) {
                        request.setDerogLevel("Low");
                    } else {
                        request.setDerogLevel("");
                    }

                    // convert in lieu of Airport - should keep as text
                    String inLieuAirport = request.getInLieuAirport();
                    switch(inLieuAirport){
                        case "1": request.setInLieuAirport("HQ");
                            break;
                        case "2": request.setInLieuAirport("Other");
                            break;
                        case "": request.setInLieuAirport("");
                    }
                    
                    request.setSubjectRegion(getName(requestReferenceData.getSubjectRegionLinkedMap(), request.getSubjectRegionId()));

                    requestList.add(request);
                } while (resultSet.next());
            }

        } catch (Exception hqEx) {
            logger.error("====exception in RT DAO:" + hqEx.getMessage());
            throw hqEx;
        } finally {
            if (session != null) {
            session.close(); }
        }

		// for Export query
		lastSearchStatus = searchStatus;
		lastSearchData = searchData;
        lastRequestList = requestList;
        
		logger.info("-------------END:getRequestList:" + searchStatus + ", " + searchData);
        
        return requestList;
    }

    // modified from getRequestList - remove paging, set Date & Time strings
    private List<Request> getRequestListForExport(String searchStatus, String searchData) throws Exception {
    	
		logger.info("-------------BEGIN:getRequestListForExport:" + searchStatus + ", " + searchData);
    	
        RequestReferenceData requestReferenceData = RequestReferenceData.getInstance();
        requestReferenceData.setCcsfApprovalLinkedMap(this.getCCSFApprovalList());       // this is needed to get all PSIs for loading after saving
        requestReferenceData.setTargeterLinkedMap(this.getTargeterList ());       // this is needed to get all TARs for loading after saving

        String airportName = "";
        String airportId, leadTargeterId, requestorId, coTargeterIds;
        String queryStr;
        String searchString = null;

        if (null != searchData) {
            searchString = fixRestoreSearchText(searchData).toUpperCase();   // save this
        }

        String fieldNames = " R.REQUESTNUMBER, R.REQUESTSTATUS, R.REQUESTTYPE, R.REQUESTDATE, R.REQUESTER, R.DEROG, R.DEROGLEVEL, "
                + "R.AIRPORTID, R.SUBJECTREGIONID, R.LEADTARGETER, R.COTARGETERS, R.SUBJECTINDIVIDUAL, R.SUBJECTCOMPANY, R.RECOMMENDATION, "
                + "R.COMMENTS, R.REQUESTORNAME, R.REQUESTERAGENCYID, R.STAINFORMATION, R.CreateUserName, R.CreateTimestamp, R.LastUpdateUsername, R.LastUpdateTimestamp, R.INLIEUAIRPORT ";

        String joinTables = " inner join fd.cturequesttype TYPE on R.requesttype=TYPE.requesttype "
                + "left join fd.ctusubjectregion REG on R.subjectregionid=REG.subjectregionid "
                + "left join fd.orghierarchy AIR on R.airportid=AIR.orgid "
                + "left join fd.orghierarchy PSI on R.REQUESTERAGENCYID=PSI.orgid "
                + "left join FD.orghierarchy TAR on R.leadtargeter=TAR.orgid ";

        String searchTextCompare = " upper(R.REQUESTNUMBER) like '%" + searchString + "%'"
                + " or upper(R.REQUESTSTATUS) like '%" + searchString + "%'"
                + " or upper(R.REQUESTER) like '%" + searchString + "%'"
                + " or upper(R.REQUESTORNAME) like '%" + searchString + "%'"
                + " or upper(R.SUBJECTINDIVIDUAL) like '%" + searchString + "%'"
                + " or upper(R.SUBJECTCOMPANY) like '%" + searchString + "%'"
                + " or upper(R.RECOMMENDATION) like '%" + searchString + "%'"
                + " or upper(R.COMMENTS) like '%" + searchString + "%'"
                + " or upper(R.CreateUserName) like '%" + searchString + "%' "
                + " or upper(R.LastUpdateUsername) like '%" + searchString + "%' "
                + " or upper(R.REQUESTDATE) like '%" + searchString + "%' ";

        String searchSelectCompare = " or upper(TYPE.REQUESTNAME) like '%" + searchString + "%'"
                + " or upper(AIR.ORGNAME) like '%" + searchString + "%'"
                + " or upper(REG.REGIONNAME) like '%" + searchString + "%'"
                + " or upper(PSI.contactFirstname || ' ' || PSI.contactLastName) like '%" + searchString + "%' "
                + " or upper(tar.contactFirstname || ' ' || tar.contactLastName) like '%" + searchString + "%' ";

        queryStr = "select " + fieldNames + " from FD.CTUREQUEST R ";

        if ("AdvancedSearch".equals(searchStatus)) {
            if (null != searchData) {
                queryStr += searchData;
                queryStr += " ORDER BY R.LASTUPDATETIMESTAMP DESC ";
            }
        } else {
            if (null != searchData) {
                queryStr += joinTables;
            }

            if (null != searchStatus) {
                queryStr += " where R.REQUESTSTATUS='" + searchStatus + "'";
                if (null != searchData) {
                    queryStr += " and (" + searchTextCompare + searchSelectCompare + ")";
                }
                queryStr += " ORDER BY R.LASTUPDATETIMESTAMP ASC ";
            } else {
                if (null != searchData) {
                    queryStr += " where " + searchTextCompare + searchSelectCompare;
                }
                queryStr += " ORDER BY R.LASTUPDATETIMESTAMP DESC ";
            }
        }

        List<Request> requestList = new ArrayList<Request>();
        String[] mapData;
        
        Session session = null;

        try {
            session = HibernateUtil.getSessionFactory().openSession();
            Query query = session.createSQLQuery(queryStr);

            ScrollableResults resultSet = query.scroll();
            if (resultSet.first()) {
                do {
                    Request request = new Request();
                    request.setRequestNumber((null == resultSet.get(0)) ? "" : resultSet.get(0).toString());
                    request.setRequestStatus((null == resultSet.get(1)) ? "" : resultSet.get(1).toString());
                    request.setRequestType((null == resultSet.get(2)) ? "" : resultSet.get(2).toString());
                    
                    // for Export
                    request.setRequestDateStr((null == resultSet.get(3)) ? "" : resultSet.get(3).toString().substring(0, 10));
                    
                    request.setDerogFound((null == resultSet.get(5)) ? false : true);
                    request.setDerogLevel((null == resultSet.get(6)) ? "0" : resultSet.get(6).toString());
                    
                    airportId = (null == resultSet.get(7)) ? "0" : resultSet.get(7).toString();
                    mapData = getSortedMapData (requestReferenceData.getAirportNamesLinkedMap(), airportId);
                    
                    request.setAirport(mapData[1].split("-")[0]);  // remove any airportCode in the name
                   
                    request.setSubjectRegionId((null == resultSet.get(8)) ? "0" : resultSet.get(8).toString());

					// v5.1
                    leadTargeterId = (null == resultSet.get(9)) ? "0" : resultSet.get(9).toString();
                    mapData = getSortedMapData (requestReferenceData.getTargeterLinkedMap(), leadTargeterId);
                    
                    request.setLeadTargeterName(mapData[1]);
                    
                    coTargeterIds = (null == resultSet.get(10)) ? "0" : resultSet.get(10).toString();
                    // build name+id indexes
                    
                    String[] cotargeters;
                    String cotargeterNames = "";
                    String coTargeterNameIDs = "";
                    cotargeters = coTargeterIds.split(",");
                    for (int i = 0; i < cotargeters.length; i++) {
                        mapData = getSortedMapData (requestReferenceData.getTargeterLinkedMap(), cotargeters[i].trim());
                        coTargeterNameIDs += mapData[0];
                        coTargeterNameIDs += ",";
                        cotargeterNames += mapData[1];
                        cotargeterNames += "\n";
                    }
                    
                    
                    request.setCoTargeterName(cotargeterNames);
                    
                    request.setSubjectIndividual((null == resultSet.get(11)) ? "" : resultSet.get(11).toString());
                    request.setSubjectCompany((null == resultSet.get(12)) ? "" : resultSet.get(12).toString());
                    request.setRecommendation((null == resultSet.get(13)) ? "" : resultSet.get(13).toString());
                    request.setComments((null == resultSet.get(14)) ? "" : resultSet.get(14).toString());
                    request.setRequestorName((null == resultSet.get(15)) ? "" : resultSet.get(15).toString());
                    
                    requestorId = (null == resultSet.get(16)) ? "0" : resultSet.get(16).toString(); // RequesterAgencyId  (PSI and non-PSI)
                    
                    // for Export
                    request.setRequestor(getRequestorByRequestType1(request.getRequestType(), requestorId)); // use faster static PSI list 

                    request.setStaInformation((null == resultSet.get(17)) ? "" : resultSet.get(17).toString());
                    
                    // Extract STA details
                    
                    String staString = request.getStaInformation ();  
                    
                    if (null != staString && !staString.isEmpty()) {
                    	
                        staString += ";"; // take care of the last null credential (trick)
	                    String[] staStrArray = staString.split(";");
	                    
			            
			            
			            try {
	                    
		                    int staRows = Integer.parseInt(staStrArray[0]);
		                    Sta[] staObjArray = new Sta[staRows];
		                    String staSubject = null;
		                    
							int j =0;
		                    for (int i=0; i<staRows; i++) {
		                    	staSubject = (null == staStrArray[j+1]) ? "" : staStrArray[j+1];
		                    	
		                    	if (staSubject.isEmpty()) {
		                    		request.setStaList (null);
		                    		break;     // invalid
		                    	}
		                    	Sta sta = new Sta();
		                    	sta.setSubject(staSubject);
								sta.setStatus ((null == staStrArray[j+2]) ? "" : 
									getName(requestReferenceData.getFieldCallStaRequestLinkedMap (), staStrArray[j+2]));
								sta.setInlieuof ((null == staStrArray[j+3]) ? "" : 
									getName(requestReferenceData.getStaInLieuOfLinkedMap (), staStrArray[j+3]));
									                		
								sta.setCredential ((null == staStrArray[j+4]) ? "" : staStrArray[j+4]);
								
				            	
								staObjArray[i] = sta;
								j += 4;
				            }
				            if (null != staObjArray && staObjArray.length > 0) {
					            request.setStaList (staObjArray);
					            
				            }
			            }
			            catch (Exception e) {
				            logger.error (request.getRequestNumber() + ":----STA parse error:" + e.getMessage());
			            }
                    }
                    
                    request.setCreateUserName((null == resultSet.get(18)) ? "" : resultSet.get(18).toString());
                    request.setLastUpdateUserName((null == resultSet.get(20)) ? "" : resultSet.get(20).toString());

					// for Export
                    request.setCreateTimestampStr((null == resultSet.get(19)) ? "" : resultSet.get(19).toString().substring(0, 19));
                    request.setLastUpdateTimestampStr((null == resultSet.get(21)) ? "" : resultSet.get(21).toString().substring(0, 19));

                    request.setInLieuAirport((null == resultSet.get(22)) ? "" : resultSet.get(22).toString());
                    
                    // convert derog level
                    String derogLevel = request.getDerogLevel();
                    if (derogLevel.equals("2")) {
                        request.setDerogLevel("Medium");
                    } else if (derogLevel.equals("3")) {
                        request.setDerogLevel("High");
                    } else if (derogLevel.equals("1")) {
                        request.setDerogLevel("Low");
                    } else {
                        request.setDerogLevel("");
                    }

                    // convert in lieu of Airport - should keep as text
                    String airportFrom = request.getInLieuAirport();
                    switch(airportFrom){
                        case "1": request.setInLieuAirport("HQ");
                            break;
                        case "2": request.setInLieuAirport("Other");
                            break;
                        case "": request.setInLieuAirport("");
                    }
                    
                    request.setSubjectRegion(getName(requestReferenceData.getSubjectRegionLinkedMap(), request.getSubjectRegionId()));

                    requestList.add(request);

                } while (resultSet.next());
            }

        } catch (Exception hqEx) {
            logger.error("===exception in RT DAO getRequestListForExport:" + hqEx.getMessage());
            throw hqEx;
        } finally {
            if (session != null) {
            session.close(); }
        }
		logger.info("-------------END:getRequestListForExport:");
        return requestList;
    }

    private String getAirportName(Map<String, String> dataMap, String dataKey) {

        if (dataKey == null || dataKey.isEmpty()) {
            return "";
        } else {
            String key, id;
            for (Iterator it = dataMap.entrySet().iterator(); it.hasNext();) {
                Map.Entry entry = (Map.Entry) it.next();
                key = (String) entry.getKey();     // name~~id
                id = key.split("~~")[1];
                
                if (dataKey.equals(id)) {
                    return key.split("~~")[0];
                }
            }
            return "";
        }
    }

    // This sorted map is for Airports, PSIs, Targeters
    private String[] getSortedMapData(Map<String, String> dataMap, String dataKey) {

        String[] data = new String[2];
        data[0] = "0";
        data[1] = "";
        
        if (dataKey != null || !dataKey.isEmpty()) {
            for (Iterator it = dataMap.entrySet().iterator(); it.hasNext();) {
                Map.Entry entry = (Map.Entry) it.next();
                String key = (String) entry.getKey();   // mapKey = sorted value + Id
                if (key.split("~~")[1].equals(dataKey)) {    
                    data[0] = key;
                    data[1] = (String) entry.getValue();
                    return data;                    
                }
            }           
        }
        return data;
    }

    // For new targeter/PSI struct (firstname & id pairs)
    private String getName1(Map<String, String> dataMap, String dataKey) {

        if (dataKey == null || dataKey.isEmpty()) {
            return "";
        } else {
            for (Iterator it = dataMap.entrySet().iterator(); it.hasNext();) {
                Map.Entry entry = (Map.Entry) it.next();
                String key = (String) entry.getKey();
                String value = (String) entry.getValue();
                if (key.split("~~")[1].equalsIgnoreCase(dataKey)) {
                    return value;
                }
            }
            return "";
        }
    }

    private String getName(Map<String, String> dataMap, String dataKey) {

        if (dataKey == null || dataKey.isEmpty()) {
            return "";
        } else {
            for (Iterator it = dataMap.entrySet().iterator(); it.hasNext();) {
                Map.Entry entry = (Map.Entry) it.next();
                String key = (String) entry.getKey();
                String value = (String) entry.getValue();
                if (key.equalsIgnoreCase(dataKey)) {
                    return value;
                }
            }
            return "";
        }
    }

    private String getNames(Map<String, String> dataMap, String idString) {

        String[] nameAry;
        String nameString = "";
        nameAry = idString.split(",");
        for (int i = 0; i < nameAry.length; i++) {
            nameString += getName(dataMap, nameAry[i].trim());
            nameString += "; ";
        }
        if (nameString.trim().equals(";")) {
            return "";
        }
        return nameString;
    }

    // For new targeter struct (firstname & id pairs)
    private String getNames1(Map<String, String> dataMap, String idString) {

        String[] nameAry;
        String nameString = "";
        nameAry = idString.split(",");
        for (int i = 0; i < nameAry.length; i++) {
            nameString += getName1(dataMap, nameAry[i].trim());
            nameString += "; ";
        }
        if (nameString.trim().equals(";")) {
            return "";
        }
        return nameString;
    }

    public Map<String, String> getOgaReferralList() throws QueryException {

        Map<String, String> map = new LinkedHashMap<String, String>();
        String queryStr = "select OGAREFERRALID, REQUESTORAGENCY from FD.CTUOGAREFERRAL ORDER BY REQUESTORAGENCY";
        Session session = null;
        try {
            session = HibernateUtil.getSessionFactory().openSession();
            Query query = session.createSQLQuery(queryStr);

            ScrollableResults resultSet = query.scroll();
            if (resultSet.first()) {
                do {
                    map.put(resultSet.get(0).toString(), resultSet.get(1).toString());
                } while (resultSet.next());
            }

        } catch (HibernateException hqEx) {
            throw hqEx;
        } finally {
            if (session != null) {
            session.close(); }
        }
        return map;

    }

    public Map<String, String> getJointOperationsList() throws QueryException {
        Map<String, String> map = new LinkedHashMap<String, String>();

        String queryStr = "select JOINTOPERATIONID, REQUESTORAGENCY from FD.CTUJOINTOPERATIONS ORDER BY REQUESTORAGENCY";
        Session session = null;
        try {
			session = HibernateUtil.getSessionFactory().openSession();
            Query query = session.createSQLQuery(queryStr);

            ScrollableResults resultSet = query.scroll();
            if (resultSet.first()) {
                do {
                    map.put(resultSet.get(0).toString() , resultSet.get(1).toString());  // sort by id
                } while (resultSet.next());
            }

        } catch (HibernateException hqEx) {
            throw hqEx;
        } finally {
            if (session != null) {
            session.close(); }
        }
        return map;

    }

    public Map<String, String> getFieldCallStaRequestList() throws QueryException {
        Map<String, String> map = new LinkedHashMap<String, String>();

        String queryStr = "select REQUESTSTAID, STATYPE from FD.CTUFIELDCALLSTAREQUEST ORDER BY STATYPE";
        Session session = null;
        try {
            session = HibernateUtil.getSessionFactory().openSession();
            Query query = session.createSQLQuery(queryStr);

            ScrollableResults resultSet = query.scroll();
            if (resultSet.first()) {
                do {
                    map.put(resultSet.get(0).toString(), resultSet.get(1).toString());
                } while (resultSet.next());
            }

        } catch (HibernateException hqEx) {
            logger.error("getFieldCallStaRequestList exception");
            throw hqEx;
        } finally { 
            if (session != null) {
            session.close(); }
        }
        return map;

    }

    public Map<String, String> getStaInLieuOfList() throws QueryException {
        Map<String, String> map = new LinkedHashMap<String, String>();

        String queryStr = "select StaInLieuOfId, StaInLieuOfType from FD.CtuStaInLieuOf ORDER BY StaInLieuOfId";
        Session session = null;
        try {
            session = HibernateUtil.getSessionFactory().openSession();
            Query query = session.createSQLQuery(queryStr);

            ScrollableResults resultSet = query.scroll();
            if (resultSet.first()) {
                do {
                    map.put(resultSet.get(0).toString(), resultSet.get(1).toString());
                } while (resultSet.next());
            }

        } catch (HibernateException hqEx) {
            throw hqEx;
        } finally {
            if (session != null) {
            session.close(); }
        }
        return map;

    }

    public Map<String, String> getCargoIncidentList() throws QueryException {
        Map<String, String> map = new LinkedHashMap<String, String>();

        String queryStr = "select CARGOINCIDENTID, REQUESTORAGENCY from FD.CTUCARGOINCIDENT ORDER BY REQUESTORAGENCY";
        Session session = null;
        try {
            session = HibernateUtil.getSessionFactory().openSession();
            Query query = session.createSQLQuery(queryStr);

            ScrollableResults resultSet = query.scroll();
            if (resultSet.first()) {
                do {
                    map.put(resultSet.get(0).toString(), resultSet.get(1).toString());
                } while (resultSet.next());
            }

        } catch (HibernateException hqEx) {
            throw hqEx;
        } finally { 
            if (session != null) {
            session.close(); }
        }
        return map;

    }

    public Map<String, String> getCCSFApprovalListOld() throws QueryException {
        Map<String, String> map = new LinkedHashMap<String, String>();

        String queryStr = "select PSIID, PSINAMES from FD.CTUCCSFAPPROVAL ORDER BY PSINAMES";
        Session session = null;
        try {
            session = HibernateUtil.getSessionFactory().openSession();
            Query query = session.createSQLQuery(queryStr);

            ScrollableResults resultSet = query.scroll();
            if (resultSet.first()) {
                do {
                    map.put(resultSet.get(0).toString(), resultSet.get(1).toString());
                } while (resultSet.next());
            }

        } catch (HibernateException hqEx) {
            throw hqEx;
        } finally {
            if (session != null) {
            session.close(); }
        }
        return map;

    }

    public Map<String, String> getCCSFApprovalList() throws QueryException {
        Map<String, String> map = new LinkedHashMap<String, String>();

        String queryStr = "select OrgId, ContactFirstName, ContactLastName from FD.ORGHIERARCHY where orgrolecode='PSI' order by ContactFirstName";
        Session session = null;
        String firstName = null;
        String lastName = null;
        
        try {
            session = HibernateUtil.getSessionFactory().openSession();
            Query query = session.createSQLQuery(queryStr);

            ScrollableResults resultSet = query.scroll();
            if (resultSet.first()) {
                do {
                	firstName = (String)resultSet.get(1);
                	lastName = (String)resultSet.get(2);
                	
                	if (null != firstName && null != lastName &&
                		!firstName.trim().isEmpty() && !lastName.trim().isEmpty()) {
        
                		//order by firstName~~OrgId, firstName LastName
                        

                		map.put(resultSet.get(1).toString() + "~~" + resultSet.get(0).toString(), resultSet.get(1).toString() + " " + resultSet.get(2).toString());
                	}
                } while (resultSet.next());
            }

        } catch (Exception hqEx) {
        	logger.error("getCCSFApprovalList EXCEPTION:" + hqEx.getMessage());
            throw hqEx;
        } finally {
            if (session != null) {
            session.close(); }
        }
        return map;

    }

    public Map<String, String> getActiveCCSFApprovalList() throws QueryException {
        Map<String, String> map = new LinkedHashMap<String, String>();

        String queryStr = "select OrgId, ContactFirstName, ContactLastName from FD.ORGHIERARCHY where orgrolecode='PSI' and status='ACTIVE' order by ContactFirstName";
        Session session = null;
        
        String firstName = null;
        String lastName = null;
        
        try {
            session = HibernateUtil.getSessionFactory().openSession();
            Query query = session.createSQLQuery(queryStr);

            ScrollableResults resultSet = query.scroll();
            if (resultSet.first()) {
                do {
                	firstName = (String)resultSet.get(1);
                	lastName = (String)resultSet.get(2);
                	
                	if (null != firstName && null != lastName &&
                		!firstName.trim().isEmpty() && !lastName.trim().isEmpty()) {
        
                		// order by firstName~~OrgId, firstName LastName
                    
                		
                	
                		map.put(resultSet.get(1).toString() + "~~" + resultSet.get(0).toString(), resultSet.get(1).toString() + " " + resultSet.get(2).toString());
                	}
                } while (resultSet.next());
            }

        } catch (HibernateException hqEx) {
        	logger.error("getActiveCCSFApprovalList EXCEPTION:" + hqEx.getMessage());
        	
            throw hqEx;
        } finally { 
            if (session != null) {
            session.close(); }
        }
        return map;

    }

    public String processEditRequest(String requestNumber, String thisUser) throws QueryException {

        String queryStr3 = "select Requester from FD.CtuRequest where RequestNumber = '" + requestNumber + "'";
        String queryStr4 = "update Cturequest set Requester='" + thisUser + "' where RequestNumber= '" + requestNumber + "'";
        Session session = null;
        String returnedUser = "";
        Transaction tx = null;
        Query query;
        ScrollableResults resultSet;
        try {
            session = HibernateUtil.getSessionFactory().openSession();
            tx = session.beginTransaction();

            query = session.createSQLQuery(queryStr3);
            resultSet = query.scroll();
            if (resultSet.first()) {
                returnedUser = (String) resultSet.get(0);
            }
            if (null == returnedUser) {
                query = session.createQuery(queryStr4);
                query.executeUpdate();
                tx.commit();
                returnedUser = "";
            } else if (thisUser.equalsIgnoreCase(returnedUser)) {
                returnedUser = "";
            } 

        } catch (HibernateException hqEx) {
        	logger.error("processEditRequest EXCEPTION: " + hqEx.getMessage());
            throw hqEx;
        } finally {
            if (session != null) {
            session.close(); }
        }
        return returnedUser;
    }

    public void cancelEditRequest(String lockedUser) throws QueryException {

        String queryStr = "update Cturequest set Requester = NULL where Requester = '" + lockedUser + "'";

        Session session = null;
        Transaction tx = null;
        Query query;

        try {
            session = HibernateUtil.getSessionFactory().openSession();
            tx = session.beginTransaction();
            query = session.createQuery(queryStr);
            query.executeUpdate();
            tx.commit();

        } catch (HibernateException hqEx) {
        	logger.error("cancelEditRequest EXCEPTION: " + hqEx.getMessage());
        	
            throw hqEx;
        } finally {
            if (session != null) {
            session.close(); }
        }
    }

    public String saveRequestTracker(RequestTrackerData requestTrackerData) throws Exception {
        logger.info("-RT DAO----saveRequestTracker----Form data:" + requestTrackerData.toString());
        Map<String, String> map = new LinkedHashMap<String, String>();
        Transaction tx = null;
        Cturequest cr = null;
        boolean isUpdated = false;
        Session session = null;
        int requestId = 0;
        String requestType = null;
        Date requestDate = requestTrackerData.getRequestDate();


        try {
            session = HibernateUtil.getSessionFactory().openSession();
            tx = session.beginTransaction();
            cr = new Cturequest();
            // check to see if new or updated request
            String requestNumber = requestTrackerData.getRequestNumber();
            logger.info("DAO  -------- RequestNumber from browser:" + requestNumber);
            if (null == requestNumber || requestNumber.isEmpty()) {

                // find last sequence number based on request type  ctu_request
                int seqnumber = 0;
                try {
                   seqnumber = (int) getSeqNextVal(session, "FD.CtuRequestId_Seq").intValue();
                }
                catch (HibernateException e) {
                   seqnumber = (int) getSeqNextVal(session, "ctu_request").intValue();
                   logger.info ("======saveRequest-OLD ctu_request:" + seqnumber);
                }
                
                cr.setRequestID(seqnumber);

                requestType = requestTrackerData.getRequestType();

                Calendar cal = Calendar.getInstance();
                cal.setTime(requestDate);

                int yy = requestDate.getMonth() < 9 ? requestDate.getYear() : requestDate.getYear() + 1;

                String newRequestNumber = "CTU" + requestType + (yy % 100);

                int requestTypeSeq = 0;
                String requestTypeSeqStr = getRequestTypeSequence(session, newRequestNumber);
                try {
                    requestTypeSeq = Integer.parseInt(requestTypeSeqStr);
                    requestTypeSeq++;
                    requestTypeSeqStr = String.format("%4s", Integer.toString(requestTypeSeq)).replace(' ', '0');
                } catch (Exception e) {
					logger.warn(e.getMessage() + " Set requestTypeSeq = 0001");
                    requestTypeSeqStr = "0001";
                }

                newRequestNumber = newRequestNumber + "-" + requestTypeSeqStr;

                cr.setRequestNumber(newRequestNumber);
            } else {
                isUpdated = true;
                cr.setRequestNumber(requestNumber);
                requestId = (int) (getRequestId(session, requestNumber).intValue());

                cr.setRequestID(requestId);
            }


            
            cr.setRequester(requestTrackerData.getRequestor());
            
            
            cr.setRequesterAgencyID(requestTrackerData.getRequesterAgencyID ());
            
            cr.setRequestType(requestTrackerData.getRequestType());
            
            cr.setRequestDate(requestTrackerData.getRequestDate());
            
            cr.setRequestorName(requestTrackerData.getRequestorName());
            

            String airportCodeId = requestTrackerData.getAirportName();   

            int airportID = 0;

            try {
                airportID = Integer.parseInt(airportCodeId.split("~~")[1]);
                cr.setAirportID(airportID);
            } catch (Exception e) {
                logger.warn(airportCodeId + ": RT DAO Exception airportCodeId:" + e.getMessage());
                cr.setAirportID(0);
            }

            cr.setSubjectIndividual(requestTrackerData.getSubjectIndividual());
                        
            cr.setSubjectCompany(requestTrackerData.getSubjectCompany());
            
            String subjectRegion = requestTrackerData.getSubjectRegion();
            try {
                cr.setSubjectReqionID(Integer.parseInt(subjectRegion));
            } catch (Exception e) {
                logger.warn(subjectRegion + ": RT DAO setSubjectReqionID:" + e.getMessage());
                cr.setSubjectReqionID(0);    // NEED WORK
            }

            // common data for both new and update.
            // Get targeter list
            String leadTargeter = requestTrackerData.getLeadtargeter();
            String requestStatus = null;
            if (leadTargeter == null || leadTargeter.isEmpty() || leadTargeter.equals("0") || leadTargeter.contains("Select")) {
                leadTargeter = "0";
                requestStatus = "Unassigned";
            } else {
                requestStatus = "Open";
            }
            
            
            if (leadTargeter.contains("~~")) {
            	cr.setLeadTargeter(leadTargeter.split("~~")[1]);    // new tar
            }
            else {
	            cr.setLeadTargeter(leadTargeter);
            }
            
            if (requestTrackerData.isInvComplete() && (!leadTargeter.equals("0"))) {
                requestStatus = "Closed";
            }
            cr.setRequestStatus(requestStatus);
                    

            String coTargeters = requestTrackerData.getCotargeter();
            
           	String coTargeterIDs = "";

            if (leadTargeter.equals("0") || coTargeters == null || leadTargeter.isEmpty() || coTargeters.contains("Select")) {
                coTargeterIDs = "0";
            }
            else {
            	// extract targeter IDs from coTageters separated by commas
            	StringTokenizer st = new StringTokenizer(coTargeters, ",");
            	String token = null;
            	while (st.hasMoreElements()) {
            		token = st.nextElement().toString();
            		if (!coTargeterIDs.isEmpty()) {
            			coTargeterIDs += ",";
            		}
            		if (token.contains("~~")) {
            			coTargeterIDs += token.split("~~")[1];
            		}
            	}
            } 
            	
            
            cr.setCoTargeter(coTargeterIDs);

            String derogFound = requestTrackerData.isDerogFound() ? "Y" : null;
            cr.setDerog(derogFound);

            String derogLevelStr = requestTrackerData.getDerogLevel();
            String derogLevel = null;

            if (derogLevelStr == null) {
                derogLevel = "0";
            } else if (derogLevelStr.equalsIgnoreCase("Low")) {
                derogLevel = "1";
            } else if (derogLevelStr.equalsIgnoreCase("Medium")) {
                derogLevel = "2";
            } else if (derogLevelStr.equalsIgnoreCase("High")) {
                derogLevel = "3";
            }
            cr.setDerogLevel(derogLevel);
            
            String inLieuAirportStr = requestTrackerData.getInLieuAirport();
            String inLieuAirport = null;

            if (inLieuAirportStr == null) {
                inLieuAirport = "";
            } else if (inLieuAirportStr.equalsIgnoreCase("HQ")) {
                inLieuAirport = "1";
            } else if (inLieuAirportStr.equalsIgnoreCase("Other")) {
                inLieuAirport = "2";
            }
            cr.setInLieuAirport(inLieuAirport);
            cr.setStaInformation(requestTrackerData.getStaInformation());

            cr.setComments(requestTrackerData.getComments());
            cr.setRecommendation(requestTrackerData.getRecommendation());

            Date now = new Date();

            java.sql.Timestamp sqlTime = new java.sql.Timestamp(now.getTime());

            cr.setLastUpdateTimestamp(sqlTime);
            cr.setLastUpdateUserName(requestTrackerData.getUserId().split("@")[0]);

            // save the record for Request History (before save or update(cr))
            logger.info(" ------ saveRequestHistory" );
            saveRequestHistory(session, cr);

            if (isUpdated) {

            	
                // retain create user and time from the DB
            	String [] userNameTimestamp = getCreateUserNameTimestamp(session, cr.getRequestNumber());
            	


                cr.setCreateUserName(userNameTimestamp[0]);
                cr.setCreateTimeStamp(timestampFormatS.parse(userNameTimestamp[1]));
                
                logger.info(" ------ Update Request data:" + cr.toString());
                session.update(cr);
            } else {
                cr.setCreateTimeStamp(sqlTime);
                cr.setCreateUserName(requestTrackerData.getUserId());
                logger.info(" ------ Insert Request data:" + cr.toString());
                session.save(cr);
            }

            tx.commit();
        } catch (Exception hqEx) {
            logger.error(" ------Exception in saving/updating Request data:" + hqEx.getMessage());
            tx.rollback();
            if (session != null) {
            session.close(); }
            throw hqEx;
        } 
        session.close();
        return cr.getRequestNumber();
    }


    private BigDecimal getSeqNextVal(Session session, String sequence) {
        BigDecimal value = null;
        try {
            Query query = session.createSQLQuery("select " + sequence + ".nextval from Dual");

            ScrollableResults resultSet = query.scroll();
            if (resultSet.first()) {
                value = (BigDecimal) resultSet.get(0);
            }
            session.flush();

        } catch (HibernateException hqEx) {
            logger.error("-HibernateException:" + sequence);
            throw hqEx;
        } 
        return value;

    }

    private BigDecimal getRequestId(Session session, String requestNumber) {
        BigDecimal value = null;
        try {
            Query query = session.createSQLQuery("select requestid from fd.cturequest where requestnumber = '" + requestNumber + "'");

            List<Object[]> result = new ArrayList<Object[]>();
            ScrollableResults resultSet = query.scroll();
            if (resultSet.first()) {
                value = (BigDecimal) resultSet.get(0);
            }
            session.flush();

        } catch (HibernateException hqEx) {

            throw hqEx;
        } 
        return value;
    }

    private String getRequestTypeSequence(Session session, String preRequestNumber) {
        String value = "0000";
        try {
            Query query = session.createSQLQuery("select max(substr(RequestNumber, -4)) from fd.CtuRequest where RequestNumber like '" + preRequestNumber + "%'");

            List<Object[]> result = new ArrayList<Object[]>();
            ScrollableResults resultSet = query.scroll();
            if (resultSet.first()) {
                value = (String) resultSet.get(0);
            }
            session.flush();
        } catch (HibernateException hqEx) {
            throw hqEx;
        } 
        return value;

    }


    private String[] getCreateUserNameTimestamp(Session session, String requestNumber) {
    	String[] values = new String[2];
        try {
            Query query = session.createSQLQuery("select CreateUserName, CreateTimestamp from fd.CtuRequest where RequestNumber = '" + requestNumber + "'");

            List<Object[]> result = new ArrayList<Object[]>();
            ScrollableResults resultSet = query.scroll();
            if (resultSet.first()) {
                //createUserName 
            	values[0] = (null == resultSet.get(0)) ? "" : resultSet.get(0).toString();
                //createTimestamp 
            	values[1] = (null == resultSet.get(1)) ? "" : resultSet.get(1).toString();
            }
            
            session.flush();
        } catch (HibernateException hqEx) {
            throw hqEx;
        } 
        return values;

    }


    public Map<String, String> getTargeterList() throws QueryException {
        Map<String, String> map = new LinkedHashMap<String, String>();

        String queryStr = "select OrgId, ContactFirstName, ContactLastName from FD.ORGHIERARCHY where orgrolecode='TAR' order by ContactFirstName";
        Session session = null;
        
        String firstName = null;
        String lastName = null;
        
        try {
            session = HibernateUtil.getSessionFactory().openSession();
            Query query = session.createSQLQuery(queryStr);

            ScrollableResults resultSet = query.scroll();
            if (resultSet.first()) {
                do {
                	firstName = (String)resultSet.get(1);
                	lastName = (String)resultSet.get(2);
                	
                	if (null != firstName && null != lastName &&
                		!firstName.trim().isEmpty() && !lastName.trim().isEmpty()) {
                	
                    // order by firstName~~OrgId, firstName LastName
                	
                		map.put(resultSet.get(1).toString() + "~~" + resultSet.get(0).toString(), resultSet.get(1).toString() + " " + resultSet.get(2).toString());
                        
                	}
                } while (resultSet.next());
            }
        } catch (HibernateException hqEx) {
        	
        	logger.error("getTargeterList EXCEPTION:" + hqEx.getMessage());
        	
            throw hqEx;
        } finally {
            if (session != null) {
            session.close(); }
        }
        return map;
  }


    public Map<String, String> getActiveTargeterList() throws QueryException {
        Map<String, String> map = new LinkedHashMap<String, String>();

        String queryStr = "select OrgId, ContactFirstName, ContactLastName from FD.ORGHIERARCHY where orgrolecode='TAR' and status='ACTIVE' order by ContactFirstName";
        Session session = null;
        String firstName = null;
        String lastName = null;
        
        try {
            session = HibernateUtil.getSessionFactory().openSession();
            Query query = session.createSQLQuery(queryStr);

            ScrollableResults resultSet = query.scroll();
            if (resultSet.first()) {
                do {
                	firstName = (String)resultSet.get(1);
                	lastName = (String)resultSet.get(2);
                	
                	if (null != firstName && null != lastName &&
                		!firstName.trim().isEmpty() && !lastName.trim().isEmpty()) {
                	
                    // order by firstName~~OrgId, firstName LastName
                	
                		map.put(resultSet.get(1).toString() + "~~" + resultSet.get(0).toString(), resultSet.get(1).toString() + " " + resultSet.get(2).toString());
                	}
                } while (resultSet.next());
            }
        } catch (HibernateException hqEx) {
        	logger.error("getActiveTargeterList EXCEPTION:" + hqEx.getMessage());
        	
            throw hqEx;
        } finally {
            if (session != null) {
            session.close(); }
        }
        return map;
  }
    
    
    public void debugSqlStr(final String queryStr) throws QueryException {

        logger.info("-----debugSqlStr-----:" + queryStr);
        Session session = null;
        try {
            session = HibernateUtil.getSessionFactory().openSession();
            Query query = session.createSQLQuery(queryStr);

            ScrollableResults resultSet = query.scroll ();

        logger.info("-----debugSqlStr-----");
            logger.info(resultSet.get(0).toString() +" " + resultSet.get(1).toString() + " " + resultSet.get(2).toString());
            Object[] objs = resultSet.get ();
            int colCount = objs.length;
            logger.info(colCount);
            
            if (resultSet.first()) {
                logger.info(resultSet.get(0).toString() +" " + resultSet.get(1).toString() + " " + resultSet.get(2).toString());
            	
	            logger.info(resultSet.getRowNumber ());
                do {
	            logger.info(resultSet.getRowNumber ());
                	for (int i = 0; i < colCount; i++) {
                       logger.info((null == resultSet.get(i)) ? "" : resultSet.get(i).toString());
                	}
                } while (resultSet.next());
            }
        } catch (HibernateException hqEx) {
            throw hqEx;
        } finally {
            if (session != null) {
            session.close(); }
        }
  }
    
      
    
    /**
     * Gets a connection to the database.
     *
     * If the dataSource is null, it looks up the dataSource again, otherwise it
     * gets a connection from the dataSource.
     *
     * @return Connection
     */
    protected Connection getConnection()
            throws SQLException {
        return ConnectionUtil.getConnection();
    }
}
