/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ctu.tsa.fas.expandedsearch.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

/**
 *
 * @author Binh.Nguyen
 */
public class IacPrincipalsModel implements Serializable{
    private static final long serialVersionUID = -8767337899673261248L;
    private String credential;
    private String firstName;
    private String lastName;
    private String personTitle;
    private String phoneNumber;
    private String emailAddress;
	private String state;
	private String country;
		
    public IacPrincipalsModel() {
    }
        
    public IacPrincipalsModel(String credential, String firstName, String lastName, 
		String personTitle, String phoneNumber, String emailAddress, String state, String country) {
		this.credential = credential;
        this.firstName = firstName;
		this.lastName = lastName;
        this.personTitle = personTitle;
		this.phoneNumber = phoneNumber;
		this.emailAddress = emailAddress;
		this.state = state;
		this.country = country;
    }
    
    public void setCredential (String credential) {
		this.credential = credential; 
    }

    public void setFirstName (String firstName) {
		this.firstName = firstName; 
    }
	
    public void setLastName(String lastName) {
		this.lastName = lastName; 
    }
        
    public void setPersonTitle (String personTitle) {
		this.personTitle = personTitle; 
    }
    
    public void setPhoneNumber(String phoneNumber) {
    	this.phoneNumber = phoneNumber; 
    } 
	
	public void setEmailAddress(String emailAddress) {
    	this.emailAddress = emailAddress; 
    }
	
	public void setState(String state) {
    	this.state = state; 
    }
	
	public void setCountry(String country) {
    	this.country = country; 
    }
	
    public String getCredential () {
		return (this.credential); 
    }

    public String getFirstName () {
    	return (this.firstName); 
    }

    public String getLastName () {
        return (this.lastName); 
    }
        
    public String getPersonTitle () {
		return (this.personTitle); 
    }
	
    public String getPhoneNumber () {
		return (this.phoneNumber); 
    }
	
	public String getEmailAddress () {
		return (this.emailAddress); 
    }

	public String getState () {
		return (this.state); 
    }
	
	public String getCountry () {
		return (this.country); 
    }
	
    public String toString () {

	String sep = System.getProperty("line.separator");

	StringBuffer buffer = new StringBuffer();
	buffer.append(sep);		
	buffer.append("credential = ");
	buffer.append(credential);
	buffer.append(sep);
	buffer.append("firstName = ");
	buffer.append(firstName);
    buffer.append(sep);
	buffer.append("lastName = ");
	buffer.append(lastName);
	buffer.append(sep);
	buffer.append("personTitle = ");
	buffer.append(personTitle);
	buffer.append(sep);
	buffer.append("phoneNumber = ");
	buffer.append(phoneNumber);
	buffer.append(sep);     		
	buffer.append("emailAddress = ");
	buffer.append(emailAddress);
	buffer.append(sep);
	buffer.append("state = ");
	buffer.append(state);
	buffer.append(sep);
	buffer.append("country = ");
	buffer.append(country);
	buffer.append(sep);
	
	return buffer.toString();
    }
}
