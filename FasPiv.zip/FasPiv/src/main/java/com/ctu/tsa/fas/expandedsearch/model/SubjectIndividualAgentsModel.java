/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ctu.tsa.fas.expandedsearch.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

/**
 *
 * @author Binh.Nguyen
 */
public class SubjectIndividualAgentsModel implements Serializable{
    private static final long serialVersionUID = -8767337899673261248L;
    private String subjectIndividualAgentName;
	private String subjectIndividualAgentId;
        private String subjectIndividualPartyId;
	private String subjectIndividualAgentCity;
	private String subjectIndividualAgentState;
	private String subjectIndividualAgentAssociatedIac;
	private String subjectIndividualAgentStartDate;
	private String subjectIndividualAgentEndDate;
		
    public SubjectIndividualAgentsModel() {
    }
        
    public SubjectIndividualAgentsModel(String subjectIndividualAgentName, 
	    String subjectIndividualAgentId, String subjectIndividualPartyId, String subjectIndividualAgentCity, 
		String subjectIndividualAgentState, String subjectIndividualAgentAssociatedIac,
		String subjectIndividualAgentStartDate, String subjectIndividualAgentEndDate) {		
		this.subjectIndividualAgentName = subjectIndividualAgentName;
                this.subjectIndividualAgentId = subjectIndividualAgentId;
                this.subjectIndividualPartyId = subjectIndividualPartyId;
		this.subjectIndividualAgentCity = subjectIndividualAgentCity;       
		this.subjectIndividualAgentState = subjectIndividualAgentState;
		this.subjectIndividualAgentAssociatedIac = subjectIndividualAgentAssociatedIac;
		this.subjectIndividualAgentStartDate = subjectIndividualAgentStartDate;
		this.subjectIndividualAgentEndDate = subjectIndividualAgentEndDate;
    }
    
    public String getSubjectIndividualAgentName() {        	
	return subjectIndividualAgentName;
    }
    
    public void setSubjectIndividualAgentName(String subjectIndividualAgentName) {
	this.subjectIndividualAgentName = subjectIndividualAgentName;
    }
	
	public String getSubjectIndividualAgentId() {        	
	return subjectIndividualAgentId;
    }
    
    public void setSubjectIndividualAgentId(String subjectIndividualAgentId) {
	this.subjectIndividualAgentId = subjectIndividualAgentId;
    }
    
    public String getSubjectIndividualPartyId() {        	
	return subjectIndividualPartyId;
    }
    
    public void setSubjectIndividualPartyId(String subjectIndividualPartyId) {
	this.subjectIndividualPartyId = subjectIndividualPartyId;
    }
	
	public String getSubjectIndividualAgentCity() {        	
	return subjectIndividualAgentCity;
    }
    
    public void setSubjectIndividualAgentCity(String subjectIndividualAgentCity) {
	this.subjectIndividualAgentCity = subjectIndividualAgentCity;
    }
	
	public String getSubjectIndividualAgentState() {        	
	return subjectIndividualAgentState;
    }
    
    public void setSubjectIndividualAgentState(String subjectIndividualAgentState) {
	this.subjectIndividualAgentState = subjectIndividualAgentState;
    }
	
	public String getSubjectIndividualAgentAssociatedIac() {        	
	return subjectIndividualAgentAssociatedIac;
    }
    
    public void setSubjectIndividualAgentAssociatedIac(String subjectIndividualAgentAssociatedIac) {
	this.subjectIndividualAgentAssociatedIac = subjectIndividualAgentAssociatedIac;
    }
	
	public String getSubjectIndividualAgentStartDate() {        	
	return subjectIndividualAgentStartDate;
    }
    
    public void setSubjectIndividualAgentStartDate(String subjectIndividualAgentStartDate) {
	this.subjectIndividualAgentStartDate = subjectIndividualAgentStartDate;
    }
	
	public String getSubjectIndividualAgentEndDate() {        	
	return subjectIndividualAgentEndDate;
    }
    
    public void setSubjectIndividualAgentEndDate(String subjectIndividualAgentEndDate) {
	this.subjectIndividualAgentEndDate = subjectIndividualAgentEndDate;
    }
	
    public String toString () {

	String sep = System.getProperty("line.separator");

	StringBuffer buffer = new StringBuffer();
	buffer.append(sep);			
    buffer.append("subjectIndividualAgentName= ");
	buffer.append(subjectIndividualAgentName);
	buffer.append(sep);
	buffer.append("subjectIndividualAgentId= ");
	buffer.append(subjectIndividualAgentId);
	buffer.append(sep);
        buffer.append("subjectIndividualPartyId= ");
	buffer.append(subjectIndividualPartyId);
	buffer.append(sep);
	buffer.append("subjectIndividualAgentCity= ");
	buffer.append(subjectIndividualAgentCity);
	buffer.append(sep);
	buffer.append("subjectIndividualAgentState= ");
	buffer.append(subjectIndividualAgentState);
	buffer.append(sep);		
	buffer.append("subjectIndividualAgentAssociatedIac= ");
	buffer.append(subjectIndividualAgentAssociatedIac);
	buffer.append(sep);
	buffer.append("subjectIndividualAgentStartDate= ");
	buffer.append(subjectIndividualAgentStartDate);
	buffer.append(sep);		
	buffer.append("subjectIndividualAgentEndDate= ");
	buffer.append(subjectIndividualAgentEndDate);
	buffer.append(sep);		
	
	return buffer.toString();
    }
}
