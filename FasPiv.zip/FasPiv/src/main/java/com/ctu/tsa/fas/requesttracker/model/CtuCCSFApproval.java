/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Eswara.Somu
 */

package com.ctu.tsa.fas.requesttracker.model;

import java.io.Serializable;
import java.util.Date;


public class CtuCCSFApproval implements Serializable {
 
private static final long serialVersionUID = -1260831298967580912L;

 
 private int psiID; 
 private String psiNames;
 private String description;
 private String creteUserId;
 private String lastUpdateuserId;
 private Date createtimestamp;
 private Date lastUpdateTimestamp;
 

    
 public CtuCCSFApproval() {

 
 }
public CtuCCSFApproval(int psiID, String psiNames, String description, String creteUserId, String lastUpdateuserId, Date createtimestamp) 
{
        this.psiID = psiID;
         this.psiNames = psiNames;
          this.description = description; 
          this.creteUserId = creteUserId; 
          this.lastUpdateuserId = lastUpdateuserId;
           this.createtimestamp = createtimestamp;
          
}
    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public int getPsiID() {
        return psiID;
    }

    public String getPsiNames() {
        return psiNames;
    }

    public String getDescription() {
        return description;
    }

    public String getCreteUserId() {
        return creteUserId;
    }

    public String getLastUpdateuserId() {
        return lastUpdateuserId;
    }



    public void setPsiID(int psiID) {
        this.psiID = psiID;
    }
       public Date getCreatetimestamp() {
        return createtimestamp;
    }



    public void setCreatetimestamp(Date createtimestamp) {
        this.createtimestamp = createtimestamp;
    }

 
    public Date getLastUpdateTimestamp() {
        return lastUpdateTimestamp;
    }

    public void setLastUpdateTimestamp(Date lastUpdateTimestamp) {
        this.lastUpdateTimestamp = lastUpdateTimestamp;
    }

    public void setPsiNames(String psiNames) {
        this.psiNames = psiNames;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setCreteUserId(String creteUserId) {
        this.creteUserId = creteUserId;
    }

    public void setLastUpdateuserId(String lastUpdateuserId) {
        this.lastUpdateuserId = lastUpdateuserId;
    }



 
}

    

