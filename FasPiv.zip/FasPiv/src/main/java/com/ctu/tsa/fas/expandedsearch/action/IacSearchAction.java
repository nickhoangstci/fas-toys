/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ctu.tsa.fas.expandedsearch.action;

import javax.servlet.http.HttpServletRequest;
import com.freightdesk.fdcommons.Credentials;
import com.freightdesk.fdcommons.SessionKey;
import com.freightdesk.fdcommons.SessionStore;
import javax.servlet.http.HttpSession;
import com.opensymphony.xwork2.ActionSupport;
import org.apache.log4j.Logger;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.ServletActionContext;
import crt.com.freightdesk.fdfolio.common.IncludesUtil;
import java.util.List;
import java.util.ArrayList;
import com.ctu.tsa.fas.expandedsearch.dao.ExpandedSearchIacDAO;
import com.ctu.tsa.fas.expandedsearch.model.IacDetails; 
import com.freightdesk.fdcommons.ApplicationProperties;
import com.freightdesk.fdcommons.LcpConstants;
import java.util.Map;
import java.util.HashMap;
import java.sql.*;
import java.util.Iterator;
import com.ctu.tsa.fas.expandedsearch.dao.ExpandedSearchIacDAO.MySqlResults;
import org.json.JSONArray;
import org.json.JSONObject;
import com.freightdesk.fdcommons.ApplicationTabs;


/**
 *
 * @author STCI
 */

public class IacSearchAction extends ActionSupport implements ServletRequestAware{
    protected Logger logger = Logger.getLogger(getClass());
    HttpServletRequest request = ServletActionContext.getRequest();   
    private String loginTimeRoleMsg;
    private String expandedSearchType = "";
    private String basicBtnClicked = "";
    private List<String> searchTypeList = new ArrayList();
    private String iacName = "";
    private String iacId = "";
    private String hdnIacName = "";
    private String hdnIacId = "";
    private List<Map> iacListMap = null;
    private List<Map> iacList = null;
    private long recordCount=0;        
    private String process;
    private String hdnProcess;
    private String origFrom="iacSummary";    
    private ExpandedSearchIacDAO dao = new ExpandedSearchIacDAO();
    private MySqlResults sqlResults = null;
    private String iacJsonStr = null;
      
	
    @Override
    public String execute()throws Exception {

        request = ServletActionContext.getRequest();
        HttpSession session = request.getSession(false);
        SessionStore store = SessionStore.getInstance(session);
        Credentials credentials = (Credentials) store.get(SessionKey.CREDENTIALS);
        List<IacDetails> iacDetails = new ArrayList<IacDetails>();
        int resultPerPageNumber;
        
        loginTimeRoleMsg = IncludesUtil.getWelcomeMsg(credentials)+ "<br>" + IncludesUtil.getExpireMsg(credentials);                

        SessionStore sessionStore = SessionStore.getInstance (request.getSession());
        sessionStore.put(SessionKey.CURRENT_TAB, ApplicationTabs.EXPANDEDSEARCH);
        setOrigFrom("iacSummary");
			
        searchTypeList = initSearchTypeList (searchTypeList);
        try {
            setHdnProcess (request.getParameter("hdnProcess"));
            logger.info(" ----IacSearchAction - execute(): hdnProcess: " + hdnProcess);
                
            if ((hdnProcess != null) && (hdnProcess.equalsIgnoreCase("searchResults"))){
                setProcess(hdnProcess);
                setRecordCount ((long)(sessionStore.get(SessionKey.TOTAL_COUNT)));
                
                return "displayIac";
            } 
        } catch (Exception ex) {
            logger.error("Unexpected exception in execute(): ", ex);
            throw ex;
        }
        
        iacList = new ArrayList<Map>();
        sessionStore.put(SessionKey.IAC_LIST, iacList);
		
        iacId = getIacId();
        iacName = getIacName();
        
        if ((getIacId().length() < 3) && (getIacName().length() < 3)){
            sessionStore.put (SessionKey.TOTAL_COUNT, new Long(0) );
            addFieldError("userDetailsErrorsHeader", getText("errors.header"));
            addActionError("Minimum of 3 alphanumeric characters must be entered in the search field");
            return "displayIac";
        }
        
        setIacId(getIacId().toUpperCase().replaceAll("<", "&lt").replaceAll(">", "&gt"));
        setIacName(getIacName().toUpperCase().replaceAll("<", "&lt").replaceAll(">", "&gt"));
        
	if (! iacId.trim().equals("")){
            sqlResults = (MySqlResults) dao.getIacRecordsByIacNum(iacId);
        } else if (! iacName.trim().equals("")){
	    sqlResults = (MySqlResults) dao.getIacRecordsByIacName(iacName);
        } 	
        
        recordCount = sqlResults.getTotalCount();
        
        if (recordCount > 0) { 
	    setIacList(sqlResults.getSListMap());
	    iacListMap = convertToIacListMap(iacList); 
            iacJsonStr = convertMapListToJsonString(iacListMap);
        }
        else {
	    iacListMap = new ArrayList<Map>();   
            iacJsonStr = new JSONArray().toString();
        }
        
        setRecordCount ( recordCount);
        sessionStore.put (SessionKey.IAC_LIST_JSON_STR, iacJsonStr);
        sessionStore.put (SessionKey.TOTAL_COUNT, recordCount );
        
        return "displayIac";
    }
    
    public String respondBtnSearchTypeReturn() throws java.lang.Exception {
        request = ServletActionContext.getRequest();
        HttpSession session = request.getSession(false);
        SessionStore store = SessionStore.getInstance(session);
        Credentials credentials = (Credentials) store.get(SessionKey.CREDENTIALS);
        loginTimeRoleMsg = IncludesUtil.getWelcomeMsg(credentials) + "<br>" + IncludesUtil.getExpireMsg(credentials);

        logger.debug("Starting respondBtnSearchTypeReturn ");
        SessionStore sessionStore = SessionStore.getInstance(request.getSession());
        return "display";
    }       
    
    public String getExpandedSearchType() {
	return expandedSearchType;
    }
        
    public void setExpandedSearchType(String expandedSearchType) {
	this.expandedSearchType = expandedSearchType; 
    }
    
    public String getIacName() {
	return iacName.toUpperCase();
    }
    
    public String getIacId() {
	return iacId.toUpperCase();
    }
        
    public void setIacName(String iacName) {
	this.iacName = iacName; 
    }
    
    public void setIacId(String iacId) {
	this.iacId = iacId; 
    }
    
    public String getHdnIacName() {
	return hdnIacName;
    }
    
    public String getHdnIacId() {
	return hdnIacId;
    }
        
    public void setHdnIacName(String hdnIacName) {
	this.hdnIacName = hdnIacName; 
    }
    
    public void setHdnIacId(String hdnIacId) {
	this.hdnIacId = hdnIacId; 
    }
    
    public List<String> getSearchTypeList() {
	return searchTypeList;
    }
        
    public void setSearchTypeList(List<String> searchTypeList) {
	this.searchTypeList = searchTypeList; 
    }
    
    public String getLoginTimeRoleMsg() {
        return loginTimeRoleMsg;
    }

    public void setLoginTimeRoleMsg(String loginTimeRoleMsg) {
        this.loginTimeRoleMsg = loginTimeRoleMsg;
    }

    @Override
    public void setServletRequest(HttpServletRequest request) {
        this.request = request;
    }

    public HttpServletRequest getServletRequest() {
        return this.request;
    }
    
    public String getBasicBtnClicked() {
        return basicBtnClicked;
    }

    public void setBasicBtnClicked(String basicBtnClicked) {
        this.basicBtnClicked = basicBtnClicked;
    }
    
    public long getRecordCount() {
    	return recordCount;
    }
        
    public void setRecordCount(long recordCount) {
    	this.recordCount = recordCount; 
    }
    
    private List<String> initSearchTypeList (List<String> inSearchTypeList){
        inSearchTypeList = new ArrayList(); 
        inSearchTypeList.add("IAC");
        inSearchTypeList.add("CCSF");        
        inSearchTypeList.add("Shipper");
        inSearchTypeList.add("Subject Company");
        inSearchTypeList.add("Subject Individual");
        
        return inSearchTypeList;
    }
    
    public List<Map> getIacListMap() {
        return iacListMap;
    }

    public void setIactMap(List<Map> iacListMap) {
        this.iacListMap = iacListMap;
    }
    
    public List<Map> getIacList() {
        return iacList;
    }

    public void setIacList(List<Map> iacList) {
        this.iacList = iacList;
    }       
    
    List<Map> convertToIacListMap(List<Map> theIacList){
    	
        List<Map> theIacListMap = new ArrayList();
        Map iacMap = new HashMap();
        Map map = null;
        Iterator<Map>  itrList = theIacList.iterator();
        
        while (itrList.hasNext()) {
            iacMap = (Map)itrList.next();
            
                map = new HashMap();				
                map.put("iacName", iacMap.get("iacName"));
                map.put("iacType", iacMap.get("iacType"));
                map.put("iacId", iacMap.get("iacId"));				
                map.put("iacStatus", iacMap.get("iacStatus")); 
                
                theIacListMap.add(map);
        }

    	logger.info(" ******** convertToIacListMap END" + theIacListMap.size());

        return theIacListMap ;
    }       
                
    
    public String getProcess() {
        return process;
    }

    public void setProcess(String process) {
        this.process = process;
    }
    
    public void setHdnProcess(String hdnProcess) {
        this.hdnProcess = hdnProcess;
    }

    public String getHdnProcess() {
        if (hdnProcess != null) return hdnProcess.trim();
            return hdnProcess;
    }
    
    public void setOrigFrom(String origFrom) {
        this.origFrom = origFrom;
    }

    public String getOrigFrom() {
        return origFrom;
    }
    
    private String convertMapListToJsonString(List<Map> list) {

	JSONArray ja = new JSONArray();
        JSONObject jo = null;
	String dataStr = null;
        dataStr = new JSONArray().toString();
	
        try {
            if (null != list && !list.isEmpty()) {

                for (Map<String, String> map : list) {
                    jo = new JSONObject();
                    for (Map.Entry<String, String> entry : map.entrySet()) {
                        jo.put(entry.getKey(), entry.getValue());
                    }
                    ja.put (jo);
                }
                dataStr = ja.toString();
            }
        } catch(Exception e) {
          logger.error ("Exception JSON conversion" + e);
        }
        return dataStr;
    }
}
