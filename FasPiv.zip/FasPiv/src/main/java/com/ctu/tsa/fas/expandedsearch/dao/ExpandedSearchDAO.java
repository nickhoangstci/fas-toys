/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ctu.tsa.fas.expandedsearch.dao;

import com.ctu.tsa.fas.hibernate.HibernateUtil;
import com.ctu.tsa.fas.expandedsearch.model.CcsfFacility;
import com.freightdesk.fdcommons.ConnectionUtil;
import static com.freightdesk.fdfolio.util.PasswordUpdater.DBDriver;
import static com.freightdesk.fdfolio.util.PasswordUpdater.IP;
import static com.freightdesk.fdfolio.util.PasswordUpdater.SID;
import static com.freightdesk.fdfolio.util.PasswordUpdater.pass;
import static com.freightdesk.fdfolio.util.PasswordUpdater.port;
import static com.freightdesk.fdfolio.util.PasswordUpdater.user;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import org.apache.log4j.Logger;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.*;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.QueryException;
import org.hibernate.ScrollableResults;
import org.hibernate.Session;
import org.hibernate.Transaction;
import java.sql.*;
import java.sql.DriverManager;
import java.util.Map;
import javax.persistence.metamodel.Type;
import oracle.jdbc.OracleTypes;
import oracle.jdbc.OracleResultSet;
//import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.pool.OracleDataSource;

/*
 * @author Kevin.Tsou
 */
public class ExpandedSearchDAO {
    
    private static ExpandedSearchDAO instance = null;
    protected Logger logger = Logger.getLogger(getClass());    

    public ExpandedSearchDAO() {

    }

    public static ExpandedSearchDAO getInstance() {
        if (instance == null) {
            instance = new ExpandedSearchDAO();
        }
        return instance;
    }
    

    
    public List<Map> getCcsfInfoByCertNum(String searchData) throws Exception {
    	
    	logger.info("getCcsfInfoByCertNum");
        Connection connection = null;
        String queryStr;
        String searchString = null;
        ResultSet sResultSet = null;
        
        
        try {
	        connection = com.freightdesk.fdcommons.ConnectionUtil.getConnection();

        } catch (Exception ex) {
            logger.error("getCcsfInfoByCertNum.getConnection() failed");
            throw (ex);
        }
        
        List<CcsfFacility> CcsfFacilities = new ArrayList<CcsfFacility>();
        Session session = null;
        String stProcName = "FD.FAS_CCSF_SEARCH.SEL_REC_BY_CCSF_CERT_NUM";
        String tCallableStmtStr = "{call " + stProcName + "(?,?)}";
        CallableStatement eStatement;

        try {
            eStatement = connection.prepareCall (tCallableStmtStr);
            logger.info(eStatement);
        } catch (Exception ex) {
            logger.error("getCcsfConnection failed" + ex.getMessage());
            throw (ex);
        }
        
        eStatement.setString(1, searchData);
        eStatement.registerOutParameter(2, OracleTypes.CURSOR);
        
        boolean eReturnCode;
        try {
            eReturnCode = eStatement.execute();
        } catch (Exception ex) {
            logger.error("after eStatement.execute failed:" + ex.getMessage());
            throw (ex);
        }
        
        sResultSet = (ResultSet) eStatement.getObject(2);
        List<Map> esListMap;
        
        esListMap = convertResultSetToListMap (sResultSet);
            
        com.freightdesk.fdcommons.ConnectionUtil.closeResources(connection, eStatement, sResultSet);
        
        return esListMap;
    }
    
    
    public List<Map> getCcsfInfoByFacilityName(String searchData) throws Exception {

    	logger.info("getCcsfInfoByCertNum");

        Connection connection = null;
        String queryStr;
        String searchString = null;
        ResultSet sResultSet = null;
        
        try {
	        connection = com.freightdesk.fdcommons.ConnectionUtil.getConnection();
        } catch (Exception ex) {
            logger.error("getCcsfInfoByFacilityName.getConnection() failed");
            throw (ex);
        }
        
        List<CcsfFacility> CcsfFacilities = new ArrayList<CcsfFacility>();
        Session session = null;
        String stProcName = "FD.FAS_CCSF_SEARCH.SEL_REC_BY_FACI_COMP_NAME";
        String tCallableStmtStr = "{call " + stProcName + "(?,?)}";
        CallableStatement eStatement;
        try {
            eStatement = connection.prepareCall (tCallableStmtStr);
            logger.info(eStatement);
        } catch (Exception ex) {
            logger.error("getCcsfConnection failed" + ex.getMessage());
            throw (ex);
        }

        
        eStatement.setString(1, searchData);
        eStatement.registerOutParameter(2, OracleTypes.CURSOR);
        
        boolean eReturnCode;
        try {
            eReturnCode = eStatement.execute();
        } catch (Exception ex) {
            logger.error("after eStatement.execute failed:" + ex.getMessage());
            throw (ex);
        }
        
       
        sResultSet = (ResultSet) eStatement.getObject(2);
        List<Map> esListMap;
        
        esListMap = convertResultSetToListMap (sResultSet);
            
        com.freightdesk.fdcommons.ConnectionUtil.closeResources(connection, eStatement, sResultSet);
        
        return esListMap;
    }
    
    public List<Map> getCcsfDetailByFacilityName(String certNumber, String facilityName) throws Exception {
        OracleDataSource ods = null;
        Connection connection = null;
        String queryStr;
        String searchString = null;
        ResultSet sResultSet = null;
        
        try {
	        connection = com.freightdesk.fdcommons.ConnectionUtil.getConnection();
        } catch (Exception ex) {
            logger.error("ods.getConnection() failed");
            throw (ex);
        }
        
        List<CcsfFacility> CcsfFacilities = new ArrayList<CcsfFacility>();
        Session session = null;
        String stProcName = "FD.FAS_CCSF_SEARCH.SEL_CCSF_DETAIL_BY_FACI_NAME";
        String tCallableStmtStr = "{call " + stProcName + "(?,?,?)}";
        CallableStatement eStatement;

        try {
            eStatement = connection.prepareCall (tCallableStmtStr);
            logger.info(eStatement);
        } catch (Exception ex) {
            logger.error("getCcsfConnection failed" + ex.getMessage());
            throw (ex);
        }

        
        eStatement.setString(1, certNumber);
        eStatement.setString(2, facilityName);
        eStatement.registerOutParameter(3, OracleTypes.CURSOR);
        
        boolean eReturnCode;
        try {
            eReturnCode = eStatement.execute();
        } catch (Exception ex) {
            logger.error("after eStatement.execute failed:" + ex.getMessage());
            throw (ex);
        }
        
        
        sResultSet = (ResultSet) eStatement.getObject(3);
        List<Map> esListMap;
        
        logger.info("before : sResultSet.next() ");		
        
        esListMap = convertResultSetToListMap (sResultSet);
		logger.info("after : sResultSet.next() ");	        
            
        com.freightdesk.fdcommons.ConnectionUtil.closeResources(connection, eStatement, sResultSet);
        
        return esListMap;
    }
  
    /**
     * Gets a connection to the database.
     *
     * If the dataSource is null, it looks up the dataSource again, otherwise it
     * gets a connection from the dataSource.
     *
     * @return Connection
     */
    
    public Connection getCcsfConnection() throws Exception {
        Connection connection = null;
        
        Class.forName("oracle.jdbc.OracleDriver"); 
        Class.forName(DBDriver);  
        logger.info("Ok classes loaded ");			
        
        try {
            connection =  DriverManager.getConnection("jdbc:oracle:thin:@" + IP + ":" + port + ":" + SID,user,pass);
        } catch (Exception ex) {
            logger.error("getCcsfConnection failed");
            throw (ex);
        } finally {
            logger.info("finally");
        }
        return connection;
    }
    
    private List<Map> convertResultSetToListMap (ResultSet searchResultSet) throws Exception{
        List<Map> listMap = new ArrayList();
        Map map = new HashMap();
        
      
        while (searchResultSet.next()){
            map = new HashMap();
            if (searchResultSet.getString("CCSFCERTIFICATIONNUM") == null){
                map.put("certificationNumber", "");
            } else {
                map.put("certificationNumber", searchResultSet.getString("CCSFCERTIFICATIONNUM"));
            }
            
            if (searchResultSet.getString("FACILITYNAME") == null){
                map.put("facilityName", "");
            } else {
                map.put("facilityName", searchResultSet.getString("FACILITYNAME"));
            }
            
            map.put("type", "FACILITYTYPE");
            
            if (searchResultSet.getString("IACNUM") == null){
                map.put("iacNumber", "");
            } else {
                map.put("iacNumber", searchResultSet.getString("IACNUM"));
            }
            
            if (searchResultSet.getString("CERTIFICATIONSTATUS") == null){
                map.put("ccsfStatus", "");
            } else {
                map.put("ccsfStatus", searchResultSet.getString("CERTIFICATIONSTATUS"));
            }
            
            if (searchResultSet.getString("IATACODE") == null){
                map.put("portCode", "");
            } else {
                map.put("portCode", searchResultSet.getString("IATACODE"));
            }
            
            if (searchResultSet.getString("FACILITYPHONE") == null){
                map.put("phone", "");
            } else {
                map.put("phone", searchResultSet.getString("FACILITYPHONE"));
            }
            
            if (searchResultSet.getString("FACILITYSTREETADDRESS") == null){
                map.put("addressLine1", "");
            } else {
                map.put("addressLine1", searchResultSet.getString("FACILITYSTREETADDRESS"));
            }
            
            if (searchResultSet.getString("FACILITYCITY") == null){
                map.put("city", "");
            } else {
                map.put("city", searchResultSet.getString("FACILITYCITY"));
            }
            
            if (searchResultSet.getString("FACILITYZIP") == null){
                map.put("zipPostalCode", "");
            } else {
                map.put("zipPostalCode", searchResultSet.getString("FACILITYZIP"));
            }
            
            if (searchResultSet.getString("FACILITYSTATE") == null){
                map.put("stateProvinceCode", "");
            } else {
                map.put("stateProvinceCode", searchResultSet.getString("FACILITYSTATE"));
            }
            
            if (searchResultSet.getString("NOTESFACILITY") == null){
                map.put("facilityNotes", "");
            } else {
                map.put("facilityNotes", searchResultSet.getString("NOTESFACILITY"));
            }
            
            if (searchResultSet.getString("NOTESCERTIFICATION") == null){
                map.put("certificationNotes", "");
            } else {
                map.put("certificationNotes", searchResultSet.getString("NOTESCERTIFICATION"));
            }
            
            if (searchResultSet.getString("DSA_CHANGEDETAIL") == null){
                map.put("dsaChangeDetails", "");
            } else {
                map.put("dsaChangeDetails", searchResultSet.getString("DSA_CHANGEDETAIL"));
            }
            
            if (searchResultSet.getString("NOTESASSESSMENT") == null){
                map.put("assessmentNotes", "");
            } else {
                map.put("assessmentNotes", searchResultSet.getString("NOTESASSESSMENT"));
            }
            
            if (searchResultSet.getString("FC1_FULLNAME") == null){
                map.put("fc1Fullname", "");
            } else {
                map.put("fc1Fullname", searchResultSet.getString("FC1_FULLNAME"));
            }
            
            if (searchResultSet.getString("FC1_TITLE") == null){
                map.put("fc1Title", "");
            } else {
                map.put("fc1Title", searchResultSet.getString("FC1_TITLE"));
            }
            
            if (searchResultSet.getString("FC1_PRIMARYPHONE") == null){
                map.put("fc1PrimaryPhone", "");
            } else {
                map.put("fc1PrimaryPhone", searchResultSet.getString("FC1_PRIMARYPHONE"));
            }
            
            if (searchResultSet.getString("FC1_EMAIL") == null){
                map.put("fc1Email", "");
            } else {
                map.put("fc1Email", searchResultSet.getString("FC1_EMAIL"));
            }
            
            if (searchResultSet.getString("FC2_FULLNAME") == null){
                map.put("fc2Fullname", "");
            } else {
                map.put("fc2Fullname", searchResultSet.getString("FC2_FULLNAME"));
            }
            
            if (searchResultSet.getString("FC2_TITLE") == null){
                map.put("fc2Title", "");
            } else {
                map.put("fc2Title", searchResultSet.getString("FC2_TITLE"));
            }
            
            if (searchResultSet.getString("FC2_PRIMARYPHONE") == null){
                map.put("fc2PrimaryPhone", "");
            } else {
                map.put("fc2PrimaryPhone", searchResultSet.getString("FC2_PRIMARYPHONE"));
            }
            
            if (searchResultSet.getString("FC2_EMAIL") == null){
                map.put("fc2Email", "");
            } else {
                map.put("fc2Email", searchResultSet.getString("FC2_EMAIL"));
            }
            
            if (searchResultSet.getString("REQUIRED_RECERTIFICATION_DATE") == null){
                map.put("requiredRecertificationDate", "");
            } else {
                map.put("requiredRecertificationDate", searchResultSet.getString("REQUIRED_RECERTIFICATION_DATE"));
            }
            
            if (searchResultSet.getString("RECERTIFICATION_DATE") == null){
                map.put("recertificationDate", "");
            } else {
                map.put("recertificationDate", searchResultSet.getString("RECERTIFICATION_DATE"));
            }
            
            if (searchResultSet.getString("RECERTIFICATIONSTATUS") == null){
                map.put("recertificationStatus", "");
            } else {
                map.put("recertificationStatus", searchResultSet.getString("RECERTIFICATIONSTATUS"));
            }
            
            if (searchResultSet.getString("OPERATIONALSTATUS") == null){
                map.put("operationalStatus", "");
            } else {
                map.put("operationalStatus", searchResultSet.getString("OPERATIONALSTATUS"));
            }
            
            if (searchResultSet.getString("APPLICATIONTYPE") == null){
                map.put("applicationType", "");
            } else {
                map.put("applicationType", searchResultSet.getString("APPLICATIONTYPE"));
            }
            
            if (searchResultSet.getString("APPLICATIONSTATUS") == null){
                map.put("applicationStatus", "");
            } else {
                map.put("applicationStatus", searchResultSet.getString("APPLICATIONSTATUS"));
            }
            
            if (searchResultSet.getString("SUSPENSE_DATE") == null){
                map.put("suspenseDate", "");
            } else {
                 map.put("suspenseDate", searchResultSet.getString("SUSPENSE_DATE"));
            }
            
            if (searchResultSet.getString("SUSPENSETYPE") == null){
                map.put("suspenseType", "");
            } else {
                map.put("suspenseType", searchResultSet.getString("SUSPENSETYPE"));
            }
            
            if (searchResultSet.getString("COMMODITYTYPESSHIPPED") == null){
                map.put("commodityTypesShipped", "");
            } else {
                map.put("commodityTypesShipped", searchResultSet.getString("COMMODITYTYPESSHIPPED"));
            }
            
            if (searchResultSet.getString("AMENDMENT") == null){
                map.put("amendment", "");
            } else {
                 map.put("amendment", searchResultSet.getString("AMENDMENT"));
            }
            
            if (searchResultSet.getString("AMENDMENT_EXPIREDATE") == null){
                map.put("amendmentExpireDate", "");
            } else {
                 map.put("amendmentExpireDate", searchResultSet.getString("AMENDMENT_EXPIREDATE"));
            }
            
            if (searchResultSet.getString("AMENDMENT_DETAILS") == null){
                map.put("amendmentDetails", "");
            } else {
                 map.put("amendmentDetails", searchResultSet.getString("AMENDMENT_DETAILS"));
            }
            listMap.add(map);
        }
        
        return listMap;
    }
}
