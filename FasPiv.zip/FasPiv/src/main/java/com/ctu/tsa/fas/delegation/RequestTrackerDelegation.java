/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ctu.tsa.fas.delegation;

import com.ctu.tsa.fas.requesttracker.dao.RequestTrackerDAO;
import com.ctu.tsa.fas.requesttracker.data.RequestTrackerData;
import com.ctu.tsa.fas.requesttracker.model.Request;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class RequestTrackerDelegation {


    public RequestTrackerDelegation() {
    }

    public Map<String, String> getSubjectRegionList() throws Exception {
        Map<String, String> map = new LinkedHashMap<String, String>();
        RequestTrackerDAO dao = new RequestTrackerDAO();
        try {
            map = dao.getSubjectRegionList();
            return map;
        } catch (Exception ex) {

            throw new Exception(ex);
        }
    }

    public Map<String, String> getOgaReferralList() throws Exception {
        RequestTrackerDAO dao = new RequestTrackerDAO();
        try {
            Map<String, String> map = new LinkedHashMap<String, String>();
            map = dao.getOgaReferralList();
            return map;
        } catch (Exception ex) {

            throw new Exception(ex);
        }
    }

    public Map<String, String> getJointOperationsList() throws Exception {
        RequestTrackerDAO dao = new RequestTrackerDAO();
        try {
            Map<String, String> map = new LinkedHashMap<String, String>();
            map = dao.getJointOperationsList();
            return map;
        } catch (Exception ex) {

            throw new Exception(ex);
        }
    }

    public Map<String, String> getFieldCallStaRequestList() throws Exception {
        RequestTrackerDAO dao = new RequestTrackerDAO();
        try {
            Map<String, String> map = new LinkedHashMap<String, String>();
            map = dao.getFieldCallStaRequestList();
            return map;
        } catch (Exception ex) {

            throw new Exception(ex);
        }
    }

    public Map<String, String> getStaInLieuOfList() throws Exception {
        RequestTrackerDAO dao = new RequestTrackerDAO();
        try {
            Map<String, String> map = new LinkedHashMap<String, String>();
            map = dao.getStaInLieuOfList();
            return map;
        } catch (Exception ex) {

            throw new Exception(ex);
        }
    }

    public Map<String, String> getCargoIncidentList() throws Exception {
        RequestTrackerDAO dao = new RequestTrackerDAO();
        try {
            Map<String, String> map = new LinkedHashMap<String, String>();
            map = dao.getCargoIncidentList();
            return map;
        } catch (Exception ex) {

            throw new Exception(ex);
        }
    }

    public Map<String, String> getCCSFApprovalList() throws Exception {
        RequestTrackerDAO dao = new RequestTrackerDAO();
        try {
            Map<String, String> map = new LinkedHashMap<String, String>();
            map = dao.getCCSFApprovalList();
            return map;
        } catch (Exception ex) {

            throw new Exception(ex);
        }
    }

    public Map<String, String> getTargeterList() throws Exception {
        RequestTrackerDAO dao = new RequestTrackerDAO();
        try {
            Map<String, String> map = new LinkedHashMap<String, String>();
            map = dao.getTargeterList();
            return map;
        } catch (Exception ex) {

            throw new Exception(ex);
        }
    }

    public Map<String, String> getAirportList() throws Exception {
        RequestTrackerDAO dao = new RequestTrackerDAO();
        try {
            Map<String, String> map;
            map = dao.getAirportList();
            return map;
        } catch (Exception ex) {

            throw new Exception(ex);
        }
    }

    public Map<String, String> getRequestTypeList() throws Exception {
        RequestTrackerDAO dao = new RequestTrackerDAO();
        try {
            Map<String, String> map = new LinkedHashMap<String, String>();
            map = dao.getRequestTypeList();
            return map;
        } catch (Exception ex) {

            throw new Exception(ex);
        }
    }

    public List<String> getSubjectIndividualList() throws Exception {
        RequestTrackerDAO dao = new RequestTrackerDAO();
        try {
            return dao.getSubjectIndividualList();
        } catch (Exception ex) {

            throw new Exception(ex);
        }
    }

    public List<String> getRequestNumberList(String subjectIndividual)  throws Exception {      
        RequestTrackerDAO dao = new RequestTrackerDAO();
        try {
            return dao.getRequestNumberList(subjectIndividual);
        } catch (Exception ex) {

            throw new Exception(ex);
        }
    }

    public List<Request> getRequestList(String subjectIndividual) throws Exception {
        RequestTrackerDAO dao = new RequestTrackerDAO();
        try {
            return dao.getRequestList(subjectIndividual);
        } catch (Exception ex) {
            throw new Exception(ex);
        }
    }


    public List<Request> getRequestList(String searchStatus, String searchData) throws Exception {
        RequestTrackerDAO dao = new RequestTrackerDAO();
        try {
            return dao.getRequestList(searchStatus, searchData);
        } catch (Exception ex) {
            throw new Exception(ex);
        }
    }

    public int getRequestCount(String searchStatus, String searchData) throws Exception {
        try {
            return RequestTrackerDAO.getInstance().getRequestCount(searchStatus, searchData);
        } catch (Exception ex) {
            throw new Exception(ex);
        }
    }

    public List<Request> getRequestList(String searchStatus, String searchData, int selectedPage, int pageSize) throws Exception {
        RequestTrackerDAO dao = new RequestTrackerDAO();
        try {
            return dao.getRequestList(searchStatus, searchData, selectedPage, pageSize);
        } catch (Exception ex) {
            throw new Exception(ex);
        }
    }

    public Request getRequest(String requestNumber) throws Exception {
        RequestTrackerDAO dao = new RequestTrackerDAO();
        try {
            return dao.getRequest(requestNumber);
        } catch (Exception ex) {
            throw new Exception(ex);
        }
    }

    public String saveRequestTracker(RequestTrackerData requestTrackerData) throws Exception {

        RequestTrackerDAO dao = new RequestTrackerDAO();
        try {
            return dao.saveRequestTracker(requestTrackerData);
        } catch (Exception ex) {

            throw new Exception(ex);
        }
 
    }

}
