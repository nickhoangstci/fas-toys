/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ctu.tsa.fas.expandedsearch.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

/**
 *
 * @author Binh.Nguyen
 */
public class IacAgentsModel implements Serializable{
    private static final long serialVersionUID = -8767337899673261248L;
    private String partyName;
	private String agentId;
	private String city;
	private String state;
	private String status;
	private String partyId;
		
    public IacAgentsModel() {
    }
        
    public IacAgentsModel(String partyName, String agentId, String city, String state, String status) {
		this.partyName = partyName;
        this.agentId = agentId;
		this.city = city;       
		this.state = state;
		this.status = status;
    }
    
    public void setPartyName (String partyName) {
		this.partyName = partyName; 
    }
	
	public void setAgentId (String agentId) {
		this.agentId = agentId; 
    }
	
	public void setCity (String city) {
		this.city = city; 
    }
	
    public void setState(String state) {
    	this.state = state; 
    }
	
	public void setStatus (String status) {
		this.status = status; 
    }
	
	public String getPartyName () {
		return (this.partyName); 
    }
	
	public String getAgentId () {
		return (this.agentId); 
    }
	
	public String getCity () {
		return (this.city); 
    }
	
	public String getState () {
		return (this.state); 
    }
	
	public String getStatus () {
		return (this.status); 
    }
	
    public String toString () {

	String sep = System.getProperty("line.separator");

	StringBuffer buffer = new StringBuffer();
	buffer.append(sep);		
	buffer.append("partyName = ");
	buffer.append(partyName);
	buffer.append(sep);
	buffer.append("agentId = ");
	buffer.append(agentId);
    buffer.append(sep);
	buffer.append("city = ");
	buffer.append(city);
	buffer.append(sep);
	buffer.append("state = ");
	buffer.append(state);
	buffer.append(sep);
	buffer.append("status = ");
	buffer.append(status);
	buffer.append(sep);     		
	
	return buffer.toString();
    }
	
	public IacAgentsModel (IacAgentsModel other) {
		if (this != other) {
			this.partyName = other.partyName;
			this.agentId = other.agentId;
			this.city = other.city;
			this.state = other.state;
			this.status = other.status;
			this.partyId = other.partyId;			
		}
	}
	
	public void setPartyId (String partyId) {
		this.partyId = partyId; 
	}
	
	public String getPartyId () {
		return (this.partyId); 
	}
}
