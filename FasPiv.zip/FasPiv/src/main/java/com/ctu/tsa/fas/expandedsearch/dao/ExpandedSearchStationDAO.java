/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ctu.tsa.fas.expandedsearch.dao;

/**
 *
 * @author kevin.tsou
 */

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import oracle.jdbc.OracleTypes;
import oracle.jdbc.pool.OracleDataSource;

import org.apache.log4j.Logger;
import org.hibernate.Session;

import com.ctu.tsa.fas.expandedsearch.model.IacDetails;
import com.ctu.tsa.fas.expandedsearch.model.StationDetails;

public class ExpandedSearchStationDAO {

	private static ExpandedSearchStationDAO instance = null;
	protected Logger logger = Logger.getLogger(getClass());

	public ExpandedSearchStationDAO() {
	}

	public static ExpandedSearchStationDAO getInstance() {
		if (instance == null) {
			instance = new ExpandedSearchStationDAO();
		}
		return instance;
	}

	public List<Map> getStationInfoByPartyId(long partyId, long objectId)
			throws Exception {
		OracleDataSource ods = null;
		Connection connection = null;
		String queryStr;
		String searchString = null;
		ResultSet sResultSet = null;
		List<Map> esListMap = null;

		try {
			connection = com.freightdesk.fdcommons.ConnectionUtil
					.getConnectionIacms();
		} catch (Exception ex) {
			logger.error("ods.getConnection() failed");
			throw (ex);
		}

		logger.info("getStationInfoByParthId:" + partyId);
		List<StationDetails> stationDetails = new ArrayList<StationDetails>();
		Session session = null;

		String stProcName = "EGOV_IAC.FAS_IAC_SEARCH.SEL_STATION_REC_BY_PARTY_ID";
		String tCallableStmtStr = "{call " + stProcName + "(?,?,?)}";

		CallableStatement eStatement = null;
        boolean eReturnCode;
		try {
			eStatement = connection.prepareCall(tCallableStmtStr);
			eStatement.setLong(1, partyId);
			eStatement.setLong(2, objectId);
			eStatement.registerOutParameter(3, OracleTypes.CURSOR);
			eReturnCode = eStatement.execute();
			sResultSet = (ResultSet) eStatement.getObject(3);
			esListMap = convertResultSetToListMap(sResultSet);			
		} catch (Exception ex) {
			logger.error("getStationConnection failed" + ex.getMessage());
			com.freightdesk.fdcommons.ConnectionUtil.closeResources(connection,
					eStatement, null);

			return new ArrayList();
		} finally {
            com.freightdesk.fdcommons.ConnectionUtil.closeResources(connection,eStatement, sResultSet);                       
        }
						
		return esListMap;
	}

	public List<Map> getAirportInfoByPartyId(long partyId) throws Exception {
		OracleDataSource ods = null;
		Connection connection = null;
		String queryStr;
		String searchString = null;
		ResultSet sResultSet = null;

		try {
			connection = com.freightdesk.fdcommons.ConnectionUtil
					.getConnectionIacms();
		} catch (Exception ex) {
			logger.error("ods.getConnection() failed");
			throw (ex);
		}

		logger.info("getAirportInfoByPartyId:" + partyId);
		List<StationDetails> stationDetails = new ArrayList<StationDetails>();
		Session session = null;

		String stProcName = "EGOV_IAC.FAS_IAC_SEARCH.SEL_AIRPORT_BY_PARTY_ID";
		String tCallableStmtStr = "{call " + stProcName + "(?,?)}";

		CallableStatement eStatement = null;
        boolean eReturnCode;
		List<Map> esListMap = null;
		try {
			eStatement = connection.prepareCall(tCallableStmtStr);
			eStatement.setLong(1, partyId);
		    eStatement.registerOutParameter(2, OracleTypes.CURSOR);
			eReturnCode = eStatement.execute();
			sResultSet = (ResultSet) eStatement.getObject(2);
			esListMap = convertAirportResultSetToListMap(sResultSet);
		} catch (Exception ex) {
			logger.error("getStationConnection failed" + ex.getMessage());
			throw (ex);
		} finally {
            com.freightdesk.fdcommons.ConnectionUtil.closeResources(connection,eStatement, sResultSet);                       
        }		

		return esListMap;
	}

	public List<Map> getContactsByPartyId(long partyId) throws Exception {

		logger.info("ExpandedSearchIacDAO - iacId:" + partyId);		  
		OracleDataSource ods = null;
		Connection connection = null;
		String queryStr;
		String searchString = null;
		ResultSet sResultSet = null;
		List<Map> esListMap = null;

		try {
			connection = com.freightdesk.fdcommons.ConnectionUtil
					.getConnectionIacms();
		} catch (Exception ex) {
			logger.error("ods.getConnection() failed");
			throw (ex);
		}

		List<IacDetails> iacDetails = new ArrayList<IacDetails>();
		Session session = null;
		String stProcName = "EGOV_IAC.FAS_IAC_SEARCH.SEL_ST_CONTACTS_BY_PARTY_ID";
		String tCallableStmtStr = "{call " + stProcName + "(?,?)}";
		logger.info("before connection.prepareCall :" + tCallableStmtStr);		
		CallableStatement eStatement = null;
		boolean eReturnCode;
		try {
			eStatement = connection.prepareCall(tCallableStmtStr);
			logger.info("eStatement:" + eStatement);			
			eStatement.setLong(1, partyId);
		    eStatement.registerOutParameter(2, OracleTypes.CURSOR);
			eReturnCode = eStatement.execute();
			sResultSet = (ResultSet) eStatement.getObject(2);
		    esListMap = convertResultSetToContactsMap(sResultSet);
		} catch (Exception ex) {
			logger.error("----connection.prepareCall failed" + ex.getMessage());
			com.freightdesk.fdcommons.ConnectionUtil.closeResources(connection,
					eStatement, null);
			return new ArrayList();			
		} finally {
            com.freightdesk.fdcommons.ConnectionUtil.closeResources(connection,eStatement, sResultSet);                       
        }
				
		return esListMap;
	}

	public List<Map> getNamesByPartyId(long partyId) throws Exception {

		OracleDataSource ods = null;
		Connection connection = null;
		String queryStr;
		String searchString = null;
		ResultSet sResultSet = null;

		try {
			connection = com.freightdesk.fdcommons.ConnectionUtil
					.getConnectionIacms();
		} catch (Exception ex) {
			logger.error("ods.getConnection() failed");
			throw (ex);
		}

		List<IacDetails> iacDetails = new ArrayList<IacDetails>();
		Session session = null;
		String stProcName = "EGOV_IAC.FAS_IAC_SEARCH.SEL_CONTACTS_NAMES_BY_PARTY_ID";
		String tCallableStmtStr = "{call " + stProcName + "(?,?)}";
		logger.info("before connection.prepareCall :" + tCallableStmtStr);		
		CallableStatement eStatement = null;
		boolean eReturnCode;
		List<Map> esListMap = null;
		try {
			eStatement = connection.prepareCall(tCallableStmtStr);
			eStatement.setLong(1, partyId);
		    eStatement.registerOutParameter(2, OracleTypes.CURSOR);
			eReturnCode = eStatement.execute();
			sResultSet = (ResultSet) eStatement.getObject(2);
			esListMap = convertResultSetToNamesMap(sResultSet);
		} catch (Exception ex) {
			logger.error("getIacConnection failed" + ex.getMessage());
			throw (ex);
		} finally {
            com.freightdesk.fdcommons.ConnectionUtil.closeResources(connection,eStatement, sResultSet);                       
        }		

		return esListMap;
	}

	private List<Map> convertResultSetToListMap(ResultSet searchResultSet)
			throws Exception {
		List<Map> listMap = new ArrayList();
		Map map = new HashMap();

		logger.info("stationDAO:convertResultSetToListMap stationDetails:");
		while (searchResultSet.next()) {
			map = new HashMap();
			if (searchResultSet.getString("PARTY_ID") == null) {
				map.put("partyId", "");
			} else {
				map.put("partyId", searchResultSet.getString("PARTY_ID"));
			}
			if (searchResultSet.getString("PARTY_NAME") == null) {
				map.put("partyName", "");
			} else {
				map.put("partyName", searchResultSet.getString("PARTY_NAME"));
			}

			if (searchResultSet.getString("COMMENTS") == null) {
				map.put("comments", "");
			} else {
				map.put("comments", searchResultSet.getString("COMMENTS"));
			}

			if (searchResultSet.getString("ACTIVE_FLAG") == null) {
				map.put("activeFlag", "");
			} else {
				map.put("activeFlag", searchResultSet.getString("ACTIVE_FLAG"));
			}

			if (searchResultSet.getString("ADDRESS1") == null) {
				map.put("address1", "");
			} else {
				map.put("address1", searchResultSet.getString("ADDRESS1"));
			}

			if (searchResultSet.getString("ADDRESS2") == null) {
				map.put("address2", "");
			} else {
				map.put("address2", searchResultSet.getString("ADDRESS2"));
			}

			if (searchResultSet.getString("CITY") == null) {
				map.put("city", "");
			} else {
				map.put("city", searchResultSet.getString("CITY"));
			}
			if (searchResultSet.getString("STATE") == null) {
				map.put("state", "");
			} else {
				map.put("state", searchResultSet.getString("STATE"));
			}

			if (searchResultSet.getString("POSTAL_CODE") == null) {
				map.put("postalCode", "");
			} else {
				map.put("postalCode", searchResultSet.getString("POSTAL_CODE"));
			}

			if (searchResultSet.getString("COUNTRY") == null) {
				map.put("country", "");
			} else {
				map.put("country", searchResultSet.getString("COUNTRY"));
			}

			if (searchResultSet.getString("IAC_ID") == null) {
				map.put("iacId", "");
			} else {
				map.put("iacId", searchResultSet.getString("IAC_ID"));
			}
			if (searchResultSet.getString("IAC_NAME") == null) {
				map.put("iacName", "");
			} else {
				map.put("iacName", searchResultSet.getString("IAC_NAME"));
			}

			if (searchResultSet.getString("APPROVAL_NBR") == null) {
				map.put("approvalNbr", "");
			} else {
				map.put("approvalNbr",
						searchResultSet.getString("APPROVAL_NBR"));
			}

			if (searchResultSet.getString("STATUS") == null) {
				map.put("status", "");
			} else {
				map.put("status", searchResultSet.getString("STATUS"));
			}

			listMap.add(map);
		}
		return listMap;
	}

	private List<Map> convertAirportResultSetToListMap(ResultSet searchResultSet)
			throws Exception {
		List<Map> listMap = new ArrayList();
		Map map = new HashMap();

		logger.info("stationDAO:convertAirportResultSetToListMap stationDetails:");
		while (searchResultSet.next()) {
			map = new HashMap();
			if (searchResultSet.getString("PARTY_ID") == null) {
				map.put("partyId", "");
			} else {
				map.put("partyId", searchResultSet.getString("PARTY_ID"));
			}
			if (searchResultSet.getString("AIRPORT_NAME") == null) {
				map.put("airportName", "");
			} else {
				map.put("airportName",
						searchResultSet.getString("AIRPORT_NAME"));
			}

			if (searchResultSet.getString("AIRPORT_ABBR") == null) {
				map.put("airportAbbr", "");
			} else {
				map.put("airportAbbr",
						searchResultSet.getString("AIRPORT_ABBR"));
			}

			listMap.add(map);
		}
		return listMap;
	}

	private List<Map> convertResultSetToContactsMap(ResultSet searchResultSet)
			throws Exception {
		List<Map> listMap = new ArrayList();
		Map map = new HashMap();
		String contactPointType;
		String emailAddress;
		String phoneLineType;
		String phoneNumber;

		map = new HashMap();

		while (searchResultSet.next()) {

			if (searchResultSet.getString("CONTACT_POINT_TYPE") == null) {
				contactPointType = "";
				logger.info("contactPointType:");				
			} else {
				contactPointType = searchResultSet
						.getString("CONTACT_POINT_TYPE");
				logger.info("contactPointType:" + contactPointType);						
			}

			if (searchResultSet.getString("EMAIL_ADDRESS") == null) {
				emailAddress = "";
				logger.info("emailAddress:");				
			} else {
				emailAddress = searchResultSet.getString("EMAIL_ADDRESS");
				logger.info("emailAddress:" + emailAddress);				
			}

			if (searchResultSet.getString("PHONE_LINE_TYPE") == null) {
				phoneLineType = "";
				logger.info("phoneLineType:");				
			} else {
				phoneLineType = searchResultSet.getString("PHONE_LINE_TYPE");
				logger.info("phoneLineType:" + phoneLineType);				
			}

			if (searchResultSet.getString("RAW_PHONE_NUMBER") == null) {
				phoneNumber = "";
				logger.info("phoneNumber:");				
			} else {
				phoneNumber = searchResultSet.getString("RAW_PHONE_NUMBER");
				logger.info("phoneNumber:" + phoneNumber);				
			}

			if (contactPointType.equalsIgnoreCase("EMAIL")) {
				map.put("emailAddress", emailAddress);
			} else if (contactPointType.equalsIgnoreCase("PHONE")) {
				if (phoneLineType.equalsIgnoreCase("WORK")) {
					map.put("workPhoneNumber", phoneNumber);
				} else if (phoneLineType.equalsIgnoreCase("24_HOUR_PHONE")) {
					map.put("h24HourPhoneNumber", phoneNumber);
				}
			}
		}

		listMap.add(map);

		return listMap;
	}

	private List<Map> convertResultSetToNamesMap(ResultSet searchResultSet)
			throws Exception {
		List<Map> listMap = new ArrayList();
		Map map = new HashMap();

		while (searchResultSet.next()) {
			map = new HashMap();
			if (searchResultSet.getString("PERSON_FIRST_NAME") == null) {
				map.put("firstName", "");
			} else {
				map.put("firstName",
						searchResultSet.getString("PERSON_FIRST_NAME"));
			}

			if (searchResultSet.getString("PERSON_MIDDLE_NAME") == null) {
				map.put("middleName", "");
			} else {
				map.put("middleName",
						searchResultSet.getString("PERSON_MIDDLE_NAME"));
			}

			if (searchResultSet.getString("PERSON_LAST_NAME") == null) {
				map.put("lastName", "");
			} else {
				map.put("lastName",
						searchResultSet.getString("PERSON_LAST_NAME"));
			}
			listMap.add(map);
		}

		return listMap;
	}
}
