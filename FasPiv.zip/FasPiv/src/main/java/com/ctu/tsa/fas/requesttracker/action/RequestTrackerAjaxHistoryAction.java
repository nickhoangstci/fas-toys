/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ctu.tsa.fas.requesttracker.action;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.ctu.tsa.fas.requesttracker.dao.RequestTrackerDAO;
import com.ctu.tsa.fas.requesttracker.data.RequestReferenceData;
import com.ctu.tsa.fas.requesttracker.model.Request;
import com.ctu.tsa.fas.requesttracker.model.RequestHistory;
import com.ctu.tsa.fas.requesttracker.model.Sta;
import com.opensymphony.xwork2.Action;

public class RequestTrackerAjaxHistoryAction implements Action {

    private Request request;
    private String message = null;
    private String requestNumberValue;
    private static boolean isBlocked = false;
    protected Logger logger = Logger.getLogger(getClass());
    
    public RequestTrackerAjaxHistoryAction() {
    }

    public String execute() {
    	
    	logger.info(" execute RequestTrackerAjaxHistoryAction" );
        RequestTrackerDAO dao = new RequestTrackerDAO();

        List<Request> requestHistoryList;
        requestHistoryList = null;
        RequestHistory requestHistory = null;
        try {
                
                requestHistoryList = dao.getRequestHistory(requestNumberValue);

                message = null;    // reset
                if (null != requestHistoryList && !requestHistoryList.isEmpty()) {
                    String actionMsg = "";
                    for (Request request : requestHistoryList) {

                        requestHistory = new RequestHistory();
                        requestHistory.setTimestamp(request.getLastUpdateTimestamp());
                        actionMsg += "Updated by    :" + request.getLastUpdateUserName().split("@")[0]; 
                        requestHistory.setAction(actionMsg);
                        message += requestHistory.toAjaxString();
                    }
                }
        } catch (Exception e) {
            logger.error (" ***RequestTrackerAjaxHistoryAction EXCEPTION: " + e.getMessage());
        }
        
        return SUCCESS;
    }
    
    private String getName(Map<String, String> dataMap, String dataKey) {   // from DAO

        if (dataKey == null || dataKey.isEmpty()) {
            return "";
        } else {
            for (Iterator it = dataMap.entrySet().iterator(); it.hasNext();) {
                Map.Entry entry = (Map.Entry) it.next();
                String key = (String) entry.getKey();
                String value = (String) entry.getValue();
                if (key.equalsIgnoreCase(dataKey)) {
                    return value;
                }
            }
            return "";
        }
    }
    
    private String getCcsfName(Map<String, String> dataMap, String dataKey) {   // from DAO

        if (dataKey == null || dataKey.isEmpty()) {
            return "";
        } else {
            for (Iterator it = dataMap.entrySet().iterator(); it.hasNext();) {
                Map.Entry entry = (Map.Entry) it.next();
                String key = (String) entry.getKey();
                String value = (String) entry.getValue();               
                if (key.contains(dataKey)) {
                    return value;
                }
            }
            return "";
        }
    }
    private String getRequestorByRequestType(Request request) {   // from DAO
        String requestNumber = request.getRequestNumber();
        String key = request.getRequestor();
        
        if ("0".equals(key)) {
            return "";
        }
        RequestReferenceData requestReferenceData = RequestReferenceData.getInstance();

        if (requestNumber.contains("CI")) {
            return getName(requestReferenceData.getCargoIncidentLinkedMap(), key);
        } else if (requestNumber.contains("OGA")) {
            return getName(requestReferenceData.getOgaReferralLinkedMap(), key);
        } else if (requestNumber.contains("JO")) {
            return getName(requestReferenceData.getJointOperationsLinkedMap(), key);
        } else {
            return getCcsfName(requestReferenceData.getCcsfApprovalLinkedMap(), key);
        }
    }
    


    private String getFieldChanges(String fieldName, String olderValue, String newerValue) {
    	
    	if (null == olderValue) {
    		olderValue = "";
    	}
    	
    	if (null == newerValue) {
    		newerValue = "";
    	}
    	
        if (olderValue.isEmpty() && newerValue.isEmpty()) {
            return "";
        } else if (olderValue.isEmpty()) {
            return "<font color=blue>" + fieldName + "</font><font color=red> Add    </font>" + newerValue.toUpperCase().replaceAll("<", "&lt").replaceAll(">", "&gt") + "<br>";
        } else if (newerValue.isEmpty()) {
            return "<font color=blue>" + fieldName + "</font><font color=red> Remove </font>" + olderValue.toUpperCase().replaceAll("<", "&lt").replaceAll(">", "&gt") + "<br>";
        } else if (!olderValue.trim().equals(newerValue.trim())) {
            if (olderValue.equals("BY")) {
                return "<font color=blue>" + fieldName + "</font>" + newerValue.toUpperCase().replaceAll("<", "&lt").replaceAll(">", "&gt") + "<br>";
            } else {
                return "<font color=blue>" + fieldName + "</font><font color=red> Change to </font>" + newerValue.toUpperCase().replaceAll("<", "&lt").replaceAll(">", "&gt") + "<br>";
            }
        }
        return "";
    }

    private Sta[] setStaObject(String staString) {

     	if (null == staString || staString.isEmpty()) {
     		return null;
     	}
     	
        staString += ";"; // take care of the last null credential (trick)
        String[] staStrArray = staString.split(";");
        RequestReferenceData requestReferenceData = RequestReferenceData.getInstance();              
        
        int staRows = Integer.parseInt(staStrArray[0]);
        ArrayList<Sta> staObjArray = new ArrayList<Sta>();
        String staSubject = null;
        
		int j =0;
			
        try {
            for (int i=0; i<staRows; i++) {
            	staSubject = (null == staStrArray[j+1]) ? "" : staStrArray[j+1];    // pass the STA row value
            	
            	if (staSubject.isEmpty()) {
            		break;     // invalid
            	}
            	Sta sta = new Sta();
            	
            	sta.setSubject(staSubject.toUpperCase());
				sta.setStatus ((null == staStrArray[j+2]) ? "" : 
					getName(requestReferenceData.getFieldCallStaRequestLinkedMap (), staStrArray[j+2]));
            	
            	try {
					sta.setInlieuof ((null == staStrArray[j+3]) ? "" : 
						getName(requestReferenceData.getStaInLieuOfLinkedMap (), staStrArray[j+3]));
            	}
		        catch (Exception e) {
		            logger.warn ( "set setInlieuof to blank " + e.getMessage());
		            sta.setInlieuof ("");
		        }
					                		
            	try {
					sta.setCredential ((null == staStrArray[j+4]) ? "" : staStrArray[j+4].toUpperCase());
            	}
		        catch (Exception e) {
		            logger.warn ( "set credential to blank " + e.getMessage());
		            sta.setCredential ("");
		        }
            					
                
                if (null != sta) {
					staObjArray.add(sta);
					j += 4;
                }
            }
        }
        catch (Exception e) {
            logger.error (staString + ":----STA parse error:" + e.getMessage());
        }
        if (staObjArray.size() == 0) {
        	return null;
        }
        return staObjArray.toArray(new Sta[staObjArray.size()]);
    }

    Sta[] removeItem(Sta[] oldArray, Sta item) {
    	Sta[] newArray = new Sta[oldArray.length-1];
    	int i = 0;
    	for (Sta x : oldArray) {
    		if (item != x ) {
    			newArray[i] = x;
    			i++;
    		}
    	}
    	return newArray;	
    }

    
    private String getStaFieldChanges(String fieldName, String olderValue, String newerValue) {
          	
    	String result = "";
    	
        if (null == olderValue) {
        	olderValue = "";
        }
    	
        if (null == newerValue) {
        	newerValue = "";
        }
    	
        if (olderValue.isEmpty() && newerValue.isEmpty()) {
            return "";
        }
        
    	Sta[] newStaArray = setStaObject(newerValue);
            
        if (olderValue.isEmpty() && newStaArray != null ) {
            result =  "<font color=blue>" + fieldName + "</font><font color=red> Add    </font>" + Arrays.toString(newStaArray).toUpperCase().replaceAll("<", "&lt").replaceAll(">", "&gt") + "<br>";
            
        } else if ( newerValue.isEmpty() || null == newStaArray) {
            return "<font color=blue>" + fieldName + "</font><font color=red> Remove</font> all STA rows<br>";
            
        } else if (!olderValue.trim().equalsIgnoreCase(newerValue.trim()) &&  newStaArray != null) {
	    	        	
            return "<font color=blue>" + fieldName + "</font><font color=red> Change to </font>" + Arrays.toString(newStaArray).toUpperCase().replaceAll("<", "&lt").replaceAll(">", "&gt") + "<br>";
        }
        return result;
    }

    private String toStaArrayString(Sta[] staList) {
   		String staString = "";
     	 for (Sta staRow : staList) {
            staString += staRow.toString () + "\n";   
     	 }
     	 return staString;

    }

    private String getStaFieldChangesDetails(String fieldName, String olderValue, String newerValue) {
    	String result = "";
        if (olderValue.isEmpty() && newerValue.isEmpty()) {
            return "";
        } else if (olderValue.isEmpty()) {
            result =  "<font color=blue>" + fieldName + "</font><font color=red> Add    </font>" + toStaArrayString(setStaObject(newerValue)) + "<br>";
            
        } else if (newerValue.isEmpty()) {
            return "<font color=blue>" + fieldName + "</font><font color=red> Remove</font> all STA rows<br>";
            
        } else if (!olderValue.trim().equalsIgnoreCase(newerValue.trim())) {
	    	Sta[] oldStaObjArray = setStaObject(olderValue);
	    	Sta[] newStaObjArray = setStaObject(newerValue);
	    	
        	for (Sta newStaRow : newStaObjArray) {
            	for (Sta oldStaRow : oldStaObjArray) {
            		
            		String compareResult = oldStaRow.compare(newStaRow);
            		if (("SAME").equals(compareResult)) {
            			oldStaObjArray = removeItem(oldStaObjArray, oldStaRow);
            			newStaObjArray = removeItem(newStaObjArray, newStaRow);
            		}
            		else if (("SAME_SUBJECT").equals(compareResult)) {
						result += "<font color=blue>" + fieldName + "</font><font color=red> Change from </font>" + oldStaRow.toString()
            				+ "<br><font color=red> to </font>" + newStaRow.toString() + "<br>";
            			oldStaObjArray = removeItem(oldStaObjArray, oldStaRow);
            			newStaObjArray = removeItem(newStaObjArray, newStaRow);
            		}
            	}
           	}
        	
        	for (Sta oldStaRow : oldStaObjArray) {
	            result += "<font color=blue>" + fieldName + "</font><font color=red> Remove </font>" + toStaArrayString(oldStaObjArray) + "<br>";
        	}
        	
        	for (Sta newStaRow : newStaObjArray) {
	            result += "<font color=blue>" + fieldName + "</font><font color=red> Add </font>" + toStaArrayString(newStaObjArray) + "<br>";
        	}
        }
        return result;
    }


    private String getStaFieldChangesOld(String fieldName, String olderValue, String newerValue) {
        if (olderValue.isEmpty() && newerValue.isEmpty()) {
            return "";
        } else if (olderValue.isEmpty()) {
            return "<font color=blue>" + fieldName + "</font><font color=red> Add    </font>" + newerValue.split(";")[0].toUpperCase().replaceAll("<", "&lt").replaceAll(">", "&gt") + " data row(s)<br>";
        } else if (newerValue.isEmpty()) {
            return "<font color=blue>" + fieldName + "</font><font color=red> Remove</font> all data rows<br>";
        } else if (!olderValue.trim().equals(newerValue.trim())) {
            return "<font color=blue>" + fieldName + "</font><font color=red> Change to </font> new values<br>";
        }
        return "";
    }

    private String getRequestChanges(Request olderRequest, Request newerRequest) {

        String actionMsg = "";

        if (olderRequest == null) {
            actionMsg += getFieldChanges("Status:        ", "", newerRequest.getRequestStatus());
            actionMsg += getFieldChanges("Requestor:     ", "", getRequestorByRequestType(newerRequest));
            actionMsg += getFieldChanges("Requestor Name:", "", newerRequest.getRequestorName());
            actionMsg += getFieldChanges("Airport:       ", "", newerRequest.getAirport());
            actionMsg += getFieldChanges("From:   		 ", "", newerRequest.getInLieuAirport());
            actionMsg += getFieldChanges("Individual:    ", "", newerRequest.getSubjectIndividual());
            actionMsg += getFieldChanges("Company:       ", "", newerRequest.getSubjectCompany());
            actionMsg += getFieldChanges("Region:        ", "", newerRequest.getSubjectRegion());
            actionMsg += getFieldChanges("Lead Targeter: ", "", newerRequest.getLeadTargeterName());
            actionMsg += getFieldChanges("Co-Targeter:   ", "", newerRequest.getCoTargeterName());
            actionMsg += getFieldChanges("Derog Level:   ", "", newerRequest.getDerogLevel());
            actionMsg += getFieldChanges("Comments:      ", "", newerRequest.getComments());
            actionMsg += getFieldChanges("Recommendation:", "", newerRequest.getRecommendation());           
            actionMsg += getStaFieldChanges("STA:        ", "", newerRequest.getStaInformation());
        } else {
            actionMsg += getFieldChanges("Status:        ", olderRequest.getRequestStatus(), newerRequest.getRequestStatus());
            actionMsg += getFieldChanges("Requestor:     ", getRequestorByRequestType(olderRequest), getRequestorByRequestType(newerRequest));
            actionMsg += getFieldChanges("Requestor Name:", olderRequest.getRequestorName(), newerRequest.getRequestorName());
            actionMsg += getFieldChanges("Individual:    ", olderRequest.getSubjectIndividual(), newerRequest.getSubjectIndividual());
            actionMsg += getFieldChanges("Company:       ", olderRequest.getSubjectCompany(), newerRequest.getSubjectCompany());
            actionMsg += getFieldChanges("Region:        ", olderRequest.getSubjectRegion(), newerRequest.getSubjectRegion());
            actionMsg += getFieldChanges("Recommendation:", olderRequest.getRecommendation(), newerRequest.getRecommendation());
            actionMsg += getFieldChanges("Comments:      ", olderRequest.getComments(), newerRequest.getComments());
            actionMsg += getFieldChanges("Lead Targeter: ", olderRequest.getLeadTargeterName(), newerRequest.getLeadTargeterName());
            actionMsg += getFieldChanges("Co-Targeter:   ", olderRequest.getCoTargeterName(), newerRequest.getCoTargeterName());
            actionMsg += getFieldChanges("Airport:       ", olderRequest.getAirport(), newerRequest.getAirport());
            actionMsg += getFieldChanges("Derog Level:   ", olderRequest.getDerogLevel(), newerRequest.getDerogLevel());
            actionMsg += getFieldChanges("From:   ", olderRequest.getInLieuAirport(), newerRequest.getInLieuAirport());
            actionMsg += getStaFieldChanges("STA:        ", olderRequest.getStaInformation(), newerRequest.getStaInformation());
        }
        return actionMsg;
    }

    public String getHistoryByRequestNumberAction() {

            
        try {

            if (isBlocked || requestNumberValue == null) {
                logger.error(isBlocked + " **isBlocked* AJAX HistoryByRequestNumberAction requestNumber:*requestNumberValue*** " + requestNumberValue);
                Thread.sleep(3000);
                message = "";
                isBlocked = false;
            } else {
            	logger.info("getHistoryByRequestNumberAction - isBlocked:" + isBlocked);
                isBlocked = true;

                RequestTrackerDAO dao = new RequestTrackerDAO();

                List<Request> requestHistoryList;
                requestHistoryList = null;
                RequestHistory requestHistory = null;
                requestHistoryList = dao.getRequestHistory(requestNumberValue);

                message = new String();    // reset
                if (null != requestHistoryList && !requestHistoryList.isEmpty()) {
                    Request newerRequest = requestHistoryList.get(0);
                    String actionMsg;
                    for (Request request : requestHistoryList) {

                        actionMsg = getRequestChanges(request, newerRequest);

                        if (!actionMsg.isEmpty()) {
                            requestHistory = new RequestHistory();
                            requestHistory.setTimestamp(newerRequest.getLastUpdateTimestamp());
                            actionMsg += getFieldChanges("Updated by    :", "BY", newerRequest.getLastUpdateUserName().split("@")[0]);  // important to be here
                            requestHistory.setAction(actionMsg);
                            newerRequest = request;
                            
                            message += requestHistory.toAjaxString() + "~";
                        }
                    }
                  
                    // initial request
                    Request initialRequest = requestHistoryList.get(requestHistoryList.size() - 1);
                    requestHistory = new RequestHistory();
                    requestHistory.setTimestamp(initialRequest.getLastUpdateTimestamp());
                    actionMsg = getRequestChanges(null, initialRequest);
                    actionMsg += getFieldChanges("Created by    :", "BY", initialRequest.getLastUpdateUserName().split("@")[0]); // important to be here
                    requestHistory.setAction(actionMsg);
                    message += requestHistory.toAjaxString();

                    if (message.length() < 1) {
                        message = "timestamp~" + request.getLastUpdateTimestamp() + "~action~no change";
                    }
                }

             isBlocked = false;
            }
        } catch (Exception e) {
            logger.error(" ***getHistoryByRequestNumberAction EXCEPTION: " + e.getMessage());
        }
        return SUCCESS;
        
    }

    public String getRequestNumberValue() {
        return requestNumberValue;
    }

    public void setRequestNumberValue(String requestNumberValue) {
        this.requestNumberValue = requestNumberValue;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

}
