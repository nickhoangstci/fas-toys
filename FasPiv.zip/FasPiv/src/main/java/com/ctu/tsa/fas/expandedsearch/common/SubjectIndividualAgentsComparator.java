/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ctu.tsa.fas.expandedsearch.common;
import java.io.Serializable;
import java.util.Comparator;

import org.apache.log4j.Logger;
import com.ctu.tsa.fas.expandedsearch.model.SubjectIndividualAgentsModel;

/**
 *
 * @author Binh.Nguyen
 */
public class SubjectIndividualAgentsComparator implements Comparator<SubjectIndividualAgentsModel>, Serializable{
    private static final long serialVersionUID = 11L;

    private Logger logger = Logger.getLogger(SubjectIndividualAgentsComparator.class);
    private boolean ascendingAgents;
    private String colName;
    
    public SubjectIndividualAgentsComparator(String colName, boolean ascendingAgents) {
	this.ascendingAgents = ascendingAgents;
	this.colName = colName;
    }
    
    @SuppressWarnings("unchecked")
    public int compare(SubjectIndividualAgentsModel o1, SubjectIndividualAgentsModel o2) {
        int result = 0;
        
      try {
            Object value1 = null;
            Object value2 = null;
            
        if (colName.equalsIgnoreCase("subjectIndividualAgentName")) {
		   value1 = o1.getSubjectIndividualAgentName();
		   value2 = o2.getSubjectIndividualAgentName();
        } else if (colName.equalsIgnoreCase("subjectIndividualAgentId")) {
		   value1 = o1.getSubjectIndividualAgentId();
		   value2 = o2.getSubjectIndividualAgentId();
        } else if (colName.equalsIgnoreCase("subjectIndividualAgentCity")) {
		   value1 = o1.getSubjectIndividualAgentCity();
		   value2 = o2.getSubjectIndividualAgentCity();
		} else if (colName.equalsIgnoreCase("subjectIndividualAgentState")) {
		   value1 = o1.getSubjectIndividualAgentState();
		   value2 = o2.getSubjectIndividualAgentState();
        } else if (colName.equalsIgnoreCase("subjectIndividualAgentAssociatedIac")) {
		   value1 = o1.getSubjectIndividualAgentAssociatedIac();
		   value2 = o2.getSubjectIndividualAgentAssociatedIac();	
        } else if (colName.equalsIgnoreCase("subjectIndividualAgentStartDate")) {
		   value1 = o1.getSubjectIndividualAgentStartDate();
		   value2 = o2.getSubjectIndividualAgentStartDate();
        } else if (colName.equalsIgnoreCase("subjectIndividualAgentEndDate")) {
		   value1 = o1.getSubjectIndividualAgentEndDate();
		   value2 = o2.getSubjectIndividualAgentEndDate();		   
        } else {
		logger.warn("Could not map " + colName + " to class attribute");
        }
            
        // Null is lesser than anything else.
        if ((value1 == null) && (value2 == null)) {
		       result = 0;            
        } else if (value1 instanceof Comparable) {
		    // the attribute values are Comparable, we have hit the JackPot.  We have absolutely nothing intelligent to do
		      @SuppressWarnings("rawtypes")
		      Comparable comp1 = (Comparable) value1;
		      @SuppressWarnings("rawtypes")
		      Comparable comp2 = (Comparable) value2;
		      result = comp1.compareTo(comp2);
        } else {
		       logger.warn("Dont know how to sort by " + colName);
        }

        if (!ascendingAgents) {
		result = 0 - result;
        }
      }
      catch (Exception ex) {
            //ex.printStackTrace();
            logger.error("Exception : " + ex.getMessage());
	 }
        return result;
    }
}
