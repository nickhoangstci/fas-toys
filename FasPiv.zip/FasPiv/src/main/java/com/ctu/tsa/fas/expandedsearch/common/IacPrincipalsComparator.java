/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ctu.tsa.fas.expandedsearch.common;
import java.io.Serializable;
import java.util.Comparator;

import org.apache.log4j.Logger;
import com.ctu.tsa.fas.expandedsearch.model.IacPrincipalsModel;

/**
 *
 * @author Binh.Nguyen
 */
public class IacPrincipalsComparator implements Comparator<IacPrincipalsModel>, Serializable{
    private static final long serialVersionUID = 11L;

    private Logger logger = Logger.getLogger(IacPrincipalsComparator.class);
    private boolean ascendingPrincipals;
    private String colName;
    
    public IacPrincipalsComparator(String colName, boolean ascendingPrincipals) {
	this.ascendingPrincipals = ascendingPrincipals;
	this.colName = colName;
    }
    
    @SuppressWarnings("unchecked")
    public int compare(IacPrincipalsModel o1, IacPrincipalsModel o2) {
        int result = 0;
        
      try {
            Object value1 = null;
            Object value2 = null;
            
        if (colName.equalsIgnoreCase("credential")) {
		value1 = o1.getCredential();
		value2 = o2.getCredential();
        } else if (colName.equalsIgnoreCase("firstName")) {
		value1 = o1.getFirstName();
        value2 = o2.getFirstName();
        } else if (colName.equalsIgnoreCase("lastName")) {
		value1 = o1.getLastName();
		value2 = o2.getLastName();
        } else if (colName.equalsIgnoreCase("personTitle")) {
		value1 = o1.getPersonTitle();
		value2 = o2.getPersonTitle();
        } else if (colName.equalsIgnoreCase("phoneNumber")) {
		value1 = o1.getPhoneNumber();
		value2 = o2.getPhoneNumber();
		} else if (colName.equalsIgnoreCase("emailAddress")) {
		value1 = o1.getEmailAddress();
		value2 = o2.getEmailAddress();
		} else if (colName.equalsIgnoreCase("state")) {
		value1 = o1.getState();
		value2 = o2.getState();
		} else if (colName.equalsIgnoreCase("country")) {
		value1 = o1.getCountry();
		value2 = o2.getCountry();
        } else {
		logger.warn("Could not map " + colName + " to class attribute");
        }
            
        // Null is lesser than anything else.
        if ((value1 == null) && (value2 == null)) {
		result = 0;
        } else if ((value1 == null) && (value2 != null)) {
		result = -1;
        } else if ((value1 != null) && (value2 == null)) {
		result = 1;
        } else if (value1 instanceof Comparable) {
		// the attribute values are Comparable, we have hit the JackPot.  We have absolutely nothing intelligent to do
		@SuppressWarnings("rawtypes")
		Comparable comp1 = (Comparable) value1;
		@SuppressWarnings("rawtypes")
		Comparable comp2 = (Comparable) value2;
		result = comp1.compareTo(comp2);
        } else {
		logger.warn("Dont know how to sort by " + colName);
        }

        if (result == 0) {
		result = -1; // to help in table sort
        }

        if (!ascendingPrincipals) {
		result = 0 - result;
        }
      }
      catch (Exception ex) {
            //ex.printStackTrace();
            logger.error("Exception : " + ex.getMessage());
	 }
        return result;
    }
}
