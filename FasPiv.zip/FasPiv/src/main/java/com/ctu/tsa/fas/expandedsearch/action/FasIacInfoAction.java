/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ctu.tsa.fas.expandedsearch.action;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.log4j.Logger;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.json.JSONArray;
import org.json.JSONObject;

import com.ctu.tsa.fas.expandedsearch.dao.ExpandedSearchIacDAO;
import com.ctu.tsa.fas.expandedsearch.model.IacDetails;
import com.freightdesk.fdcommons.Credentials;
import com.freightdesk.fdcommons.SessionKey;
import com.freightdesk.fdcommons.SessionStore;
import com.opensymphony.xwork2.ActionSupport;

import crt.com.freightdesk.fdfolio.common.IncludesUtil;

/**
 *
 * @author Binh.Nguyen
 */
public class FasIacInfoAction extends ActionSupport implements ServletRequestAware{
    protected Logger logger = Logger.getLogger(getClass());
    HttpServletRequest request = ServletActionContext.getRequest();    
    private String loginTimeRoleMsg;	
    private String iacName;
    private String iacType;
    private String iacId;
    private String iacState;
    private String iacStatus;
    private String iacAddress1;
    private String iacAddress2;
    private String iacCity;
    private String iacZipPostalCode;
    private int partyId;
    private String iacSicCode;
    private String iacPhone;
    private String iacCountry;
    private String iacEinNumber;
    private String iacKnownAs1;
    private String iacKnownAs2;
    private String iacKnownAs3;
    private String iacFirstName;
    private String iacLastName;
    private String iacEmail;
    private String iacDesignation;
    private String iacTitle;
    private long iacCredential = 0;
    private String iacInitialApprovalDate;
    private String iacLastApprovalDate;
    private String iacExpirationDate;
    private String iacApprovingAgent;
    private String iacComments;
    List<Map> secCordMap = new ArrayList();
    List<Map> principleCordMap = new ArrayList();
    List<Map> stationMap = new ArrayList();
    List<Map> agentMap = new ArrayList();
    List<Map> dirEmpMap = new ArrayList();
    List<Map> agentEmpMap = new ArrayList();
    private String origFrom="";
    private List<Map> iacList;        		
    private String credential;
    private String firstName;
    private String lastName;
    private String personTitle;
    private String phoneNumber;
    private String emailAddress;
    private String state;
    private String country;		
    private String partyName;
    private String agentId;
    private String city;
    private String status;   	
    private String active;			
    private String staId;
    private String creationDate;
    private String issuedOnDate;
    private String expiresOnDate;
    private String staStatus;	    
    private String agentName;  	   
    private Runtime runtime = Runtime.getRuntime();

	
    @Override
    public String execute()throws Exception {
        request = ServletActionContext.getRequest();
        final HttpSession session = request.getSession(false);
        SessionStore store = SessionStore.getInstance(session);
        Credentials credentials = (Credentials) store.get(SessionKey.CREDENTIALS);
        final ExpandedSearchIacDAO dao = new ExpandedSearchIacDAO();
        List<IacDetails> iacDetails = new ArrayList<IacDetails>();
        Map theIacMap = new HashMap();
		String temp;
        
        int listSize = 0;		
        
        long startTime = System.currentTimeMillis();

	    logger.info("FasIacInfoAction execute(): begin");
        loginTimeRoleMsg = IncludesUtil.getWelcomeMsg(credentials)+ "<br>" + IncludesUtil.getExpireMsg(credentials);                
	
        SessionStore sessionStore = SessionStore.getInstance (request.getSession());
		       
        setOrigFrom(getOrigFrom());
        
	    setIacList(dao.getIacDetailsByIacName(getIacId(), getIacName()));	
        
        if ((iacList == null) || (iacList.isEmpty())){
            listSize = 0;
        } else {
            listSize = iacList.size();
        }
		
        if (listSize > 0) {		    
            theIacMap = iacList.get(0);						
			
            setIacName((String)theIacMap.get("iacName"));
            setIacType((String)theIacMap.get("iacType"));
            setIacId((String)theIacMap.get("iacId"));
            setIacState((String)theIacMap.get("iacState"));
            setIacStatus((String)theIacMap.get("iacStatus"));
            setIacAddress1((String)theIacMap.get("iacAddress1"));
            setIacAddress2((String)theIacMap.get("iacAddress2"));
            setIacSicCode((String)theIacMap.get("iacSicCode"));
            setIacCity((String)theIacMap.get("iacCity"));
            setIacPhone((String)theIacMap.get("iacPhone"));
            setIacEinNumber((String)theIacMap.get("iacEinNumber"));
            setIacKnownAs1((String)theIacMap.get("iacKnownAs1"));
            setIacKnownAs2((String)theIacMap.get("iacKnownAs2"));
            setIacKnownAs3((String)theIacMap.get("iacKnownAs3"));
            setIacFirstName((String)theIacMap.get("iacFirstName"));
            setIacLastName((String)theIacMap.get("iacLastName"));
            setIacEmail((String)theIacMap.get("iacEmail"));
            setIacDesignation((String)theIacMap.get("iacDesignation"));
            setPartyId((int)theIacMap.get("partyId"));
            setIacComments((String)theIacMap.get("iacComments"));
            setIacTitle((String)theIacMap.get("iacTitle"));			
            setCredential((String)theIacMap.get("credential"));
            setFirstName((String)theIacMap.get("firstName"));
            setLastName((String)theIacMap.get("lastName"));
            setPersonTitle((String)theIacMap.get("personTitle"));
            setPhoneNumber((String)theIacMap.get("phoneNumber"));
            setEmailAddress((String)theIacMap.get("emailAddress"));
            setState((String)theIacMap.get("state"));
            setCountry((String)theIacMap.get("country"));
            setPartyName((String)theIacMap.get("partyName"));
            setAgentId((String)theIacMap.get("agentId"));
            setCity((String)theIacMap.get("city"));
            setStatus((String)theIacMap.get("status"));			
            setActive((String)theIacMap.get("active"));			
            setStaId((String)theIacMap.get("staId"));
            setCreationDate((String)theIacMap.get("creationDate"));
            setIssuedOnDate((String)theIacMap.get("issuedOnDate"));
            setExpiresOnDate((String)theIacMap.get("expiresOnDate"));
            setStaStatus((String)theIacMap.get("staStatus"));
            setAgentName((String)theIacMap.get("agentName"));
		
            if ((String)theIacMap.get("iacInitialApprovalDate") != null && 
                !(theIacMap.get("iacInitialApprovalDate").equals(""))){
		        temp = (String)theIacMap.get("iacInitialApprovalDate");
		        setIacInitialApprovalDate(temp.substring(0, (temp).indexOf(' ')));
            }
            else {
		    setIacInitialApprovalDate ("");
            }
            
            if ((String)theIacMap.get("iacLastApprovalDate") != null && 
                !(theIacMap.get("iacLastApprovalDate").equals(""))){
		      temp = (String)theIacMap.get("iacLastApprovalDate");
		      setIacLastApprovalDate(temp.substring(0, (temp).indexOf(' ')));
            }
            else {
		    setIacLastApprovalDate ("");
            }
            
            if ((String)theIacMap.get("iacExpirationDate") != null && 
                !(theIacMap.get("iacExpirationDate").equals(""))){
		     temp = (String)theIacMap.get("iacExpirationDate");
		     setIacExpirationDate(temp.substring(0, (temp).indexOf(' ')));
            }
            else {
		    setIacExpirationDate ("");
            }
            
            setIacApprovingAgent((String)theIacMap.get("iacApprovingAgent"));
            setIacApprovingAgent(iacApprovingAgent.substring((iacApprovingAgent.indexOf('-')+ 1)));
            setIacCredential((long)theIacMap.get("iacCredential"));
			
            setIacZipPostalCode((String)theIacMap.get("iacZipPostalCode"));
            setIacState((String)theIacMap.get("iacState"));
            if (theIacMap.get("iacState") != null && theIacMap.get("iacState") != ""){
                setIacCountry("UNITED STATES");
            } 
        }
        
	    
        if (listSize > 0) {

            Thread thread1;
            thread1 = new Thread() {
                @Override
                public void run() {
                    try {
                        ExpandedSearchIacDAO dao = ExpandedSearchIacDAO.getInstance();
                        long t0 = System.currentTimeMillis();
                        
                        JSONArray[] staAry = dao.getStaByPartyId(getPartyId());
                        
                        session.setAttribute("STA_AGENT_EMP_LIST", staAry[1].toString());
                        
                        session.setAttribute("STA_DIR_EMP_LIST", staAry[0].toString());
                        
                        logger.info("STA_EMP_LIST Elapsed Time :" + (System.currentTimeMillis() - t0));
                        
                    }
                    catch (Exception e) {
                        logger.error("t1:" + e.getMessage());
                    }
                }
            };
            
            Thread thread2 = new Thread() {
                @Override
                public void run() {
                	try {
                            ExpandedSearchIacDAO dao = ExpandedSearchIacDAO.getInstance();
                            setStationMap(convertStationToStationMap(dao.getStationByIacNum(getIacId())));    
            		    session.setAttribute("STATION_LIST", IncludesUtil.convertMapListToJsonString(stationMap));	
            		    
            		    // Certification
                        
                        JSONArray ja = new JSONArray();                	
                        JSONObject jo = new JSONObject();
                		
                		jo.put("iacNumber", getIacId());
                		jo.put("initialApprovalDate", getIacInitialApprovalDate());
                		jo.put("lastApprovalDate", getIacLastApprovalDate());
                		jo.put("expirationDate", getIacExpirationDate());
                		jo.put("approvingAgent", getIacApprovingAgent());
                		
                		ja.put (jo);
                        
            		    session.setAttribute("CERT_LIST", ja.toString());	            		    
            		    
                	}
                    catch (Exception e) {
                  	  logger.error("t2:" + e.getMessage());
                    }
                }
            };
            
            Thread thread3 = new Thread() {
                @Override
                public void run() {
                	try {
                            ExpandedSearchIacDAO dao = ExpandedSearchIacDAO.getInstance();
                            setAgentMap(convertAgentToAgentMap(dao.getAgentByIacNum(getIacId())));

            		    session.setAttribute("AGENT_LIST", IncludesUtil.convertMapListToJsonString(agentMap));					
                	}
                    catch (Exception e) {
                  	  logger.error("t3:" + e.getMessage());
                    }
                }
            };
            
            Thread thread4 = new Thread() {
                @Override
                public void run() {
                	try {
                            ExpandedSearchIacDAO dao = ExpandedSearchIacDAO.getInstance();
                            setSecCordMap (convertIacListToSecCordMap(iacList));

            		    session.setAttribute("SEC_CORD_LIST", IncludesUtil.convertMapListToJsonString(secCordMap));					
            		    
                        setPrincipleCordMap(convertPrincipleCordToPrincipleCordMap(dao.getPrincipleCord(getPartyId())));

            		    session.setAttribute("PRIN_CORD_LIST", IncludesUtil.convertMapListToJsonString(principleCordMap));					
                	    
                	}
                    catch (Exception e) {
                  	  logger.error("t4:" + e.getMessage());
                    }
                }
            };
            
            // Start the threads
            thread1.start();
            thread2.start();
            thread3.start();
            thread4.start();

            // Wait for them to finish
            try {
                thread1.join();
                thread2.join();
                thread3.join();
                thread4.join();
        	}
            catch (Exception e) {
          	  logger.error("threads join:" + e.getMessage());
            }

        }
        
		String debugMsg = "IAC DETAILS **** Memory used: " + (runtime.totalMemory() - runtime.freeMemory())/1000 + " Elapsed Time :" + (System.currentTimeMillis() - startTime);
		logger.info(debugMsg);
	    session.setAttribute("DEBUG_MSG", debugMsg);        
                        
        return "displayIacInfo";
    }    			   	   	
	
    
    public List<Map> convertIacListToSecCordMap(List<Map> list) {
        List<Map> theSecCordMap = new ArrayList();
        Map map = new HashMap();
        Iterator<Map>  itrList = list.iterator();
        Map secCordMap = new HashMap();
        
        while (itrList.hasNext()) {
            secCordMap = (Map)itrList.next();
            map = new HashMap();
            map.put("iacFirstName", secCordMap.get("iacFirstName"));
            map.put("iacLastName", secCordMap.get("iacLastName"));
            map.put("iacEmail", secCordMap.get("iacEmail"));
            map.put("iacDesignation", secCordMap.get("iacDesignation"));
            map.put("iacPhone", secCordMap.get("iacPhone"));
						 
			if ((secCordMap.get("iacFirstName") == "") && (secCordMap.get("iacLastName") == "") && 
			    (secCordMap.get("iacEmail") == "") && (secCordMap.get("iacDesignation") == "") && 
				(secCordMap.get("iacPhone") == "")){
				logger.info("FasIacInfoAction - convertIacListToSecCordMap: Blank");
			} else {
				theSecCordMap.add(map);
			}			
        }
        
        return (theSecCordMap);
    }  
    
	public List<Map> convertPrincipleCordToPrincipleCordMap(List<Map> list) {
        List<Map> thePrincipleCordMap = new ArrayList();
        Map map = new HashMap();
        Iterator<Map>  itrList = list.iterator();
        Map principleCordMap = new HashMap();
        
        while (itrList.hasNext()) {
            principleCordMap = (Map)itrList.next();
            map = new HashMap();
            map.put("credential", principleCordMap.get("credential"));
            map.put("firstName", principleCordMap.get("firstName"));
            map.put("lastName", principleCordMap.get("lastName"));
            map.put("personTitle", principleCordMap.get("personTitle"));
            map.put("phoneNumber", principleCordMap.get("phoneNumber"));
            map.put("emailAddress", principleCordMap.get("emailAddress"));
            map.put("state", principleCordMap.get("state"));
            map.put("country", principleCordMap.get("country"));
            thePrincipleCordMap.add(map);
        }
        
        return (thePrincipleCordMap);
    } 
	
    public List<Map> convertStaToDirEmpMap(List<Map> list) {
        List<Map> theDirEmpMap = new ArrayList();
        Map map = new HashMap();
        Iterator<Map>  itrList = list.iterator();
        Map dirEmpMap = new HashMap();
		String temp;
        
        while (itrList.hasNext()) {
            dirEmpMap = (Map)itrList.next();
            map = new HashMap();
            map.put("staId", dirEmpMap.get("staId"));
            map.put("agentName", dirEmpMap.get("agentName"));
			if (dirEmpMap.get("creationDate") != null && !(dirEmpMap.get("creationDate").equals(""))){
				temp = (String)dirEmpMap.get("creationDate");
				map.put("creationDate", temp.substring(0, (temp).indexOf(' ')));
			}
			else {
				map.put("creationDate", "");
			}
            
			if (dirEmpMap.get("issuedOnDate") != null && !(dirEmpMap.get("issuedOnDate").equals(""))){
				temp = (String)dirEmpMap.get("issuedOnDate");
				map.put("issuedOnDate", temp.substring(0, (temp).indexOf(' ')));
			}
			else {
				map.put("issuedOnDate", "");
			}
            
			if (dirEmpMap.get("expiresOnDate") != null && !(dirEmpMap.get("expiresOnDate").equals(""))){
				temp = (String)dirEmpMap.get("expiresOnDate");
				map.put("expiresOnDate", temp.substring(0, (temp).indexOf(' ')));
			}
			else {
				map.put("expiresOnDate", "");
			}
            map.put("staStatus", dirEmpMap.get("staStatus"));
            map.put("status", dirEmpMap.get("status"));
            map.put("firstName", dirEmpMap.get("firstName"));
            map.put("lastName", dirEmpMap.get("lastName"));
            map.put("sponsorType", dirEmpMap.get("sponsorType"));
            if (dirEmpMap.get("sponsorType").equals("indirect carrier")){
                theDirEmpMap.add(map); 
            }
        }
        
        return (theDirEmpMap);
    }   
    
    public List<Map> convertStaToAgentEmpMap(List<Map> list) {
        List<Map> theAgentEmpMap = new ArrayList();
        Map map = new HashMap();
        Iterator<Map>  itrList = list.iterator();
        Map agentEmpMap = new HashMap();
		String temp;
        
        while (itrList.hasNext()) {
            agentEmpMap = (Map)itrList.next();
            map = new HashMap();
            map.put("staId", agentEmpMap.get("staId"));
            map.put("agentName", agentEmpMap.get("agentName"));
            
			if (agentEmpMap.get("creationDate") != null && !(agentEmpMap.get("creationDate").equals(""))){
				temp = (String)agentEmpMap.get("creationDate");
				map.put("creationDate", temp.substring(0, (temp).indexOf(' ')));
			}
			else {
				map.put("creationDate", "");
			}
            
			if (agentEmpMap.get("issuedOnDate") != null && !(agentEmpMap.get("issuedOnDate").equals(""))){
				temp = (String)agentEmpMap.get("issuedOnDate");
				map.put("issuedOnDate", temp.substring(0, (temp).indexOf(' ')));
			}
			else {
				map.put("issuedOnDate", "");
			}
            
			if (agentEmpMap.get("expiresOnDate") != null && !(agentEmpMap.get("expiresOnDate").equals(""))){
				temp = (String)agentEmpMap.get("expiresOnDate");
				map.put("expiresOnDate", temp.substring(0, (temp).indexOf(' ')));
			}
			else {
				map.put("expiresOnDate", "");
			}
			
            map.put("staStatus", agentEmpMap.get("staStatus"));
            map.put("status", agentEmpMap.get("status"));
            map.put("firstName", agentEmpMap.get("firstName"));
            map.put("lastName", agentEmpMap.get("lastName"));
            map.put("sponsorType", agentEmpMap.get("sponsorType"));
            if (agentEmpMap.get("sponsorType").equals("indirect carrier agent")){
                theAgentEmpMap.add(map); 
            }
        }
        
        return (theAgentEmpMap);
    }   
    
    public List<Map> convertStationToStationMap(List<Map> list) {
        List<Map> theStationMap = new ArrayList();
        Map map = new HashMap();
        Iterator<Map>  itrList = list.iterator();
        Map stationMap = new HashMap();
        
        while (itrList.hasNext()) {
            stationMap = (Map)itrList.next();
            map = new HashMap();
            map.put("partyName", stationMap.get("partyName"));
            map.put("partyId", stationMap.get("partyId"));
            map.put("objectId", stationMap.get("objectId"));
            map.put("city", stationMap.get("city"));
            map.put("state", stationMap.get("state"));
            map.put("active", stationMap.get("active"));
            theStationMap.add(map);
        }
        
        return (theStationMap);
    } 
    
    public List<Map> convertAgentToAgentMap(List<Map> list) {
        List<Map> theAgentMap = new ArrayList();
        Map map = new HashMap();
        Iterator<Map>  itrList = list.iterator();
        Map agentMap = new HashMap();
        
        while (itrList.hasNext()) {
            agentMap = (Map)itrList.next();
            map = new HashMap();
            map.put("partyName", agentMap.get("partyName"));
            map.put("partyId", agentMap.get("partyId"));
            map.put("agentId", agentMap.get("agentId"));
            map.put("city", agentMap.get("city"));
            map.put("state", agentMap.get("state"));
            map.put("status", agentMap.get("status"));
            theAgentMap.add(map);
        }
        
        return (theAgentMap);
    } 	    
    
    public String getLoginTimeRoleMsg() {
        return loginTimeRoleMsg;
    }

    public void setLoginTimeRoleMsg(String loginTimeRoleMsg) {
        this.loginTimeRoleMsg = loginTimeRoleMsg;
    }
    
    @Override
    public void setServletRequest(HttpServletRequest request) {
        this.request = request;
    }

    public HttpServletRequest getServletRequest() {
        return this.request;
    }
    
   
    public void setIacList(List<Map> iacList) {
        this.iacList = iacList;
    }		
        
    public String getIacType() {
        if (iacType == null){
            this.iacType = "";
	}
		
	return StringEscapeUtils.unescapeHtml4(iacType);
    }
    
    public void setIacType(String iacType) {
	this.iacType = iacType;
    }  
    
	public String getIacComments() {
        if (iacComments == null){
            this.iacComments = "";
	}
		
	return StringEscapeUtils.unescapeHtml4(iacComments);
    }
    
    public void setIacComments(String iacComments) {
	this.iacComments = iacComments;
    }  
	
	public String getIacInitialApprovalDate() {
        if (iacInitialApprovalDate == null){
            this.iacInitialApprovalDate = "";
	}
		
	return StringEscapeUtils.unescapeHtml4(iacInitialApprovalDate);
    }
    
    public void setIacInitialApprovalDate(String iacInitialApprovalDate) {
	this.iacInitialApprovalDate = iacInitialApprovalDate;
    }
	
	public String getIacLastApprovalDate() {
        if (iacLastApprovalDate == null){
            this.iacLastApprovalDate = "";
	}
		
	return StringEscapeUtils.unescapeHtml4(iacLastApprovalDate);
    }
    
    public void setIacLastApprovalDate(String iacLastApprovalDate) {
	this.iacLastApprovalDate = iacLastApprovalDate;
    }
	
	public String getIacExpirationDate() {
        if (iacExpirationDate == null){
            this.iacExpirationDate = "";
	}
		
	return StringEscapeUtils.unescapeHtml4(iacExpirationDate);
    }
    
    public void setIacExpirationDate(String iacExpirationDate) {
	this.iacExpirationDate = iacExpirationDate;
    }
	
	public String getIacApprovingAgent() {
        if (iacApprovingAgent == null){
            this.iacApprovingAgent = "";
	}
		
	return StringEscapeUtils.unescapeHtml4(iacApprovingAgent);
    }
    
    public void setIacApprovingAgent(String iacApprovingAgent) {
	this.iacApprovingAgent = iacApprovingAgent;
    }
	
    public String getIacId() {
        if (iacId == null){
            this.iacId = "";
	}	
	return StringEscapeUtils.unescapeHtml4(iacId);
    }
    
    public void setIacId(String iacId) {
	this.iacId = iacId;
    }  
    
    public int getPartyId() {
        return partyId;
    }
    
    public void setPartyId(int partyId) {
	this.partyId = partyId;
    }  
    
    public List<Map> getIacList() {
        return iacList;
    } 		
    
    public String getIacName() {
        if (iacName == null){
            this.iacName = "";
	}			
        return (iacName);
    }
    
    public void setIacName(String  iacName) {
	this.iacName =  iacName;
    }     
    
    public String getIacStatus() {
        if (iacStatus == null){
            this.iacStatus = "";
	}
		
	return StringEscapeUtils.unescapeHtml4(iacStatus);
    }
    
    public void setIacStatus(String iacStatus) {
	this.iacStatus = iacStatus;
    }

    public long getIacCredential() {       
		
	return iacCredential;	
    }
    
    public void setIacCredential(long iacCredential) {
	this.iacCredential = iacCredential;
    }

	public String getIacFirstName() {
        if (iacFirstName == null){
            this.iacFirstName = "";
	}
		
	return StringEscapeUtils.unescapeHtml4(iacFirstName);	
    }
    
    public void setIacFirstName(String iacFirstName) {
	this.iacFirstName = iacFirstName;
    }
	
    public String getIacLastName() {
        if (iacLastName == null){
            this.iacLastName = "";
	}
		
	return StringEscapeUtils.unescapeHtml4(iacLastName);	
    }
    
    public void setIacLastName(String iacLastName) {
	this.iacLastName = iacLastName;
    }	
    
	public String getIacEmail() {
        if (iacEmail == null){
            this.iacEmail = "";
	}
		
	return StringEscapeUtils.unescapeHtml4(iacEmail);	
    }
    
    public void setIacEmail(String iacEmail) {
	this.iacEmail = iacEmail;
    }
	
	public String getIacDesignation() {
        if (iacDesignation == null){
            this.iacDesignation = "";
	}
		
	return StringEscapeUtils.unescapeHtml4(iacDesignation);	
    }
    
    public void setIacDesignation(String iacDesignation) {
	this.iacDesignation = iacDesignation;
    }
	
	public String getIacTitle() {
        if (iacTitle == null){
            this.iacTitle = "";
	}
		
	return StringEscapeUtils.unescapeHtml4(iacTitle);	
    }
    
    public void setIacTitle(String iacTitle) {
	this.iacTitle = iacTitle;
    }
	
    public String getIacSicCode() {
        if (iacSicCode == null){
            this.iacSicCode = "";
	}
    
	return StringEscapeUtils.unescapeHtml4(iacSicCode);	
	}

    public void setIacSicCode(String iacSicCode) {
        if (iacSicCode.equalsIgnoreCase("4212")){
            this.iacSicCode = "4212 Local Trucking, Without Storage";
        } else if (iacSicCode.equalsIgnoreCase("4213")){
            this.iacSicCode = "4213 Trucking, Except Local";
        } else if (iacSicCode.equalsIgnoreCase("4214")){
            this.iacSicCode = "4214 Local Trucking, With Storage";
        } else if (iacSicCode.equalsIgnoreCase("4513")){
            this.iacSicCode = "4513 Air Courier Services Establishments";
        } else if (iacSicCode.equalsIgnoreCase("4731")){
            this.iacSicCode = "Freight Transpotation Arrangement";
        } else if (iacSicCode.equalsIgnoreCase("4789")){
            this.iacSicCode = "4789 Transportation Services";
        } else {
            this.iacSicCode = iacSicCode;
        }
    }
    
    public String getIacPhone() {
	    if (iacPhone == null){
            this.iacPhone = "";
	}
	
    return StringEscapeUtils.unescapeHtml4(iacPhone);	
    }

    public void setIacPhone(String iacPhone) {
        this.iacPhone = iacPhone;
    }
            
    public String getIacAddress1() {
	    if (iacAddress1 == null){
            this.iacAddress1 = "";
	}
	
    return StringEscapeUtils.unescapeHtml4(iacAddress1);	
    }

    public void setIacAddress1(String iacAddress1) {
        this.iacAddress1 = iacAddress1;
    } 
	
	public String getIacAddress2() {
	    if (iacAddress2 == null){
            this.iacAddress2 = "";
	}
	
    return StringEscapeUtils.unescapeHtml4(iacAddress2);	
    }

    public void setIacAddress2(String iacAddress2) {
        this.iacAddress2 = iacAddress2;
    } 

	public String getIacKnownAs1() {
	    if (iacKnownAs1 == null){
            this.iacKnownAs1 = "";
	}
	
    return StringEscapeUtils.unescapeHtml4(iacKnownAs1);	
    }

    public void setIacKnownAs1(String iacKnownAs1) {
        this.iacKnownAs1 = iacKnownAs1;
    } 
	
	public String getIacKnownAs2() {
	    if (iacKnownAs2 == null){
            this.iacKnownAs2 = "";
	}
	
    return StringEscapeUtils.unescapeHtml4(iacKnownAs2);	
    }

    public void setIacKnownAs2(String iacKnownAs2) {
        this.iacKnownAs2 = iacKnownAs2;
    } 
    
	public String getIacKnownAs3() {
	    if (iacKnownAs3 == null){
            this.iacKnownAs3 = "";
	}
	
    return StringEscapeUtils.unescapeHtml4(iacKnownAs3);	
    }

    public void setIacKnownAs3(String iacKnownAs3) {
        this.iacKnownAs3 = iacKnownAs3;
    } 
	
    public String getIacCity() {
	if (iacCity == null){
            this.iacCity = "";
	}
	
    return StringEscapeUtils.unescapeHtml4(iacCity); 	
    }

    public void setIacCity(String iacCity) {
        this.iacCity = iacCity;
    }
    
    public String getIacState() {
	if (iacState == null){
            this.iacState = "";
	}
	
    return StringEscapeUtils.unescapeHtml4(iacState);	
    }

    public void setIacState(String iacState) {
        this.iacState = iacState;
    }
    
    public String getIacZipPostalCode() {
	if (iacZipPostalCode == null){
            this.iacZipPostalCode = "";
	}
	
    return StringEscapeUtils.unescapeHtml4(iacZipPostalCode);	
    }

    public void setIacZipPostalCode(String iacZipPostalCode) {
        this.iacZipPostalCode = iacZipPostalCode;
    }
    	
    public String getIacEinNumber() {
	if (iacEinNumber == null){
            this.iacEinNumber = "";
	}
	
    return StringEscapeUtils.unescapeHtml4(iacEinNumber);	
    }

    public void setIacEinNumber(String iacEinNumber) {
        this.iacEinNumber = iacEinNumber;
    }
	
	public String getIacCountry() {
	if (iacCountry == null){
            this.iacCountry = "";
	}
	
    return StringEscapeUtils.unescapeHtml4(iacCountry);	
    }

    public void setIacCountry(String iacCountry) {
        this.iacCountry = iacCountry;
    }				
	
	public void setAgentName (String agentName) {
		this.agentName = agentName; 
    }
	
	public void setStaId (String staId) {
		this.staId = staId; 
    }
	
	public void setCreationDate (String creationDate) {
		this.creationDate = creationDate; 
    }
	
	public void setIssuedOnDate (String issuedOnDate) {
		this.issuedOnDate = issuedOnDate; 
    }
	
	public void setExpiresOnDate (String expiresOnDate) {
		this.expiresOnDate = expiresOnDate; 
    }
	
	public void setStaStatus (String staStatus) {
		this.staStatus = staStatus; 
    }
	
	
	public void setActive (String active) {
		this.active = active; 
    }
	
	public void setPartyName (String partyName) {
		this.partyName = partyName; 
    }
	
	public void setAgentId (String agentId) {
		this.agentId = agentId; 
    }
	
    public void setCity(String city) {
		this.city = city; 
    }
        
    public void setStatus (String status) {
		this.status = status; 
    }
	
	public String getAgentName () {
		return (this.agentName); 
    }
	
	public String getStaId () {
		return (this.staId); 
    }
	
	public String getCreationDate () {
		return (this.creationDate); 
    }
	
	public String getIssuedOnDate () {
		return (this.issuedOnDate); 
    }
	
	public String getExpiresOnDate () {
		return (this.expiresOnDate); 
    }
	
    public String getStaStatus () {
		return (this.staStatus); 
    }
	
	public String getActive () {
		return (this.active); 
    }
	
    public String getPartyName () {
		return (this.partyName); 
    }
	
	public String getAgentId () {
		return (this.agentId); 
    }
	
	public String getCity () {
		return (this.city); 
    }
	
	public String getStatus () {
		return (this.status); 
    }	
	
	public void setCredential (String credential) {
		this.credential = credential; 
    }
	
	public void setFirstName (String firstName) {
		this.firstName = firstName; 
    }
	
    public void setLastName(String lastName) {
		this.lastName = lastName; 
    }
        
    public void setPersonTitle (String personTitle) {
		this.personTitle = personTitle; 
    }
    
    public void setPhoneNumber(String phoneNumber) {
    	this.phoneNumber = phoneNumber; 
    } 
	
	public void setEmailAddress(String emailAddress) {
    	this.emailAddress = emailAddress; 
    }
	
	public void setState(String state) {
    	this.state = state; 
    }
	
	public void setCountry(String country) {
    	this.country = country; 
    }
	
    public String getCredential () {		
    if (credential == null){
            this.credential = "";
	}
		
	return StringEscapeUtils.unescapeHtml4(credential);	
    }		

    public String getFirstName () {
    if (firstName == null){
            this.firstName = "";
	}
		
	return StringEscapeUtils.unescapeHtml4(firstName);	
    }

    public String getLastName () {
    if (lastName == null){
            this.lastName = "";
	}
		
	return StringEscapeUtils.unescapeHtml4(lastName);	 
    }
        
    public String getPersonTitle () {
	if (personTitle == null){
            this.personTitle = "";
	}
		
	return StringEscapeUtils.unescapeHtml4(personTitle);
    }
	
    public String getPhoneNumber () {
	if (phoneNumber == null){
            this.phoneNumber = "";
	}
		
	return StringEscapeUtils.unescapeHtml4(phoneNumber);
    }
	
	public String getEmailAddress () {
	if (emailAddress == null){
            this.emailAddress = "";
	}
		
	return StringEscapeUtils.unescapeHtml4(emailAddress); 
    }

	public String getState () {
	if (state == null){
            this.state = "";
	}
		
	return StringEscapeUtils.unescapeHtml4(state);
    }
	
	public String getCountry () {
	if (country == null){
            this.country = "";
	}
		
	return StringEscapeUtils.unescapeHtml4(country); 
    }   	
	   
    public void setOrigFrom(String origFrom) {
        this.origFrom = origFrom;
    }

    public String getOrigFrom() {
        return origFrom;
    }
		
    public void setPrincipleCordMap(List<Map> principleCordMap) {
        this.principleCordMap = principleCordMap;
    }
    
    public void setSecCordMap(List<Map> secCordMap) {
        this.secCordMap = secCordMap;
    }
    
    public void setStationMap(List<Map> stationMap) {
        this.stationMap = stationMap;
    }
    
    public void setAgentMap(List<Map> agentMap) {
        this.agentMap = agentMap;
    }
    
    public void setDirEmpMap(List<Map> dirEmpMap) {
        this.dirEmpMap = dirEmpMap;
    }
    
    public void setAgentEmpMap(List<Map> agentEmpMap) {
        this.agentEmpMap = agentEmpMap;
    }	
	
    public List<Map> getPrincipleCordMap() {
        return principleCordMap;
    } 
    
    public List<Map> getSecCordMap() {
        return secCordMap;
    } 
    
    public List<Map> getStationMap() {
        return stationMap;
    } 
    
    public List<Map> getAgentMap() {
        return agentMap;
    } 
    
    public List<Map> getDirEmpMap() {
        return dirEmpMap;
    } 
    
    public List<Map> getAgentEmpMap() {
        return agentEmpMap;
    } 
	
}
