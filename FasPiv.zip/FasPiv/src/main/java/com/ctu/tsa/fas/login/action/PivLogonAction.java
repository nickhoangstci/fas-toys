/**
 */

package com.ctu.tsa.fas.login.action;

import java.util.HashMap;

import javax.security.auth.login.AccountExpiredException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.log4j.Logger;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.springframework.security.core.context.SecurityContextHolder;

import com.freightdesk.fdcommons.ActionErrors;
import com.freightdesk.fdcommons.ActionMessage;
import com.freightdesk.fdcommons.ActionMessages;
import com.freightdesk.fdcommons.Credentials;
import com.freightdesk.fdcommons.InvalidUserException;
import com.freightdesk.fdcommons.LicenseProperties;
import com.freightdesk.fdcommons.SessionKey;
import com.freightdesk.fdcommons.SessionStore;
import com.freightdesk.fdcommons.UserNotActiveException;
import com.freightdesk.fdcommons.asyncprocess.AsyncProcessManager;
import com.freightdesk.fdcommons.asyncprocess.AsyncProcessingLogModel;
import com.opensymphony.xwork2.ActionSupport;

import crt.com.freightdesk.fdfolio.common.IncludesUtil;
import crt.com.freightdesk.fdfolio.setup.SystemMessageManager;
import crt.com.ntelx.fdsuite.common.RequestDetails;
import crt.com.ntelx.nxcommons.AuthenticationUtils;
import ctu.com.tsa.fas.ctu.Ctuuser;


public class PivLogonAction extends ActionSupport implements ServletRequestAware {

    protected Logger logger = Logger.getLogger(getClass());
    HttpServletRequest request = ServletActionContext.getRequest();
    
    private String pivUserName;
    Ctuuser ctuuser = new Ctuuser();
    private String domainName;
    private String myAction;
    private String messageText;
    private String faqTxt;
    private String loginTimeRoleMsg;
    private String btnLogin;
    private String password;


    public String execute() throws Exception {
    	
    	
    	logger.info("execute PIV logon--------");
    	
        request = ServletActionContext.getRequest();        		
        if (!hasValidLicense()) {
            logger.debug("License for NXsuite is not valid or expired, redirecting to login page");
            ActionErrors errors = new ActionErrors();
            errors.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("error.licenseExpired"));
            return "licenseExpired";
        }
        
        // check if browser version is supported
	RequestDetails requestDetails = new RequestDetails(request);
	if (requestDetails.browserNotSupported()) {
            logger.debug(requestDetails);
            // forward to not supported page
            return "help";
        }
        
    	// invalidating any active sessions before display
        HttpSession session = request.getSession(false);
        SessionStore store = SessionStore.getInstance(session);
        
        // POAM HttpOnly Secure
        HttpServletResponse response = (HttpServletResponse)ServletActionContext.getResponse();
        String secure = "";
        if (request.isSecure()) {
          secure = "; Secure";
        }
        
        
        response.setHeader("SET-COOKIE", "JSESSIONID=" + request.getSession().getId()
                         + "; Path=" + request.getContextPath() + "; HttpOnly" + secure);  
        
        pivUserName = StringEscapeUtils.escapeHtml(getPivUserName().replaceAll("&lt;", "<").replaceAll("&quot;", "").replaceAll("&gt;", ">"));			
        logger.info("-----Input pivUserName: " + pivUserName);
        
        if (pivUserName.isEmpty()) {
        
        // PIV
		System.out.println("NAME:" + SecurityContextHolder.getContext().getAuthentication().getName());
		System.out.println("toString:" + SecurityContextHolder.getContext().getAuthentication().toString());
		System.out.println("Credentials:" + SecurityContextHolder.getContext().getAuthentication().getCredentials().toString());     
		
		pivUserName = SecurityContextHolder.getContext().getAuthentication().getName();
                
        }
        //------------------------------------------------
        password = "NH@dte0987";
        
        domainName = com.freightdesk.fdcommons.GlobalConstants.FAS_DOMAIN;
        String cred = pivUserName.trim() + "," + "NH@dte0987";
        if (session != null) {
            logger.debug("!! invalidating active session");
            store = SessionStore.getInstance(session);
            store.invalidateSessions(request);
        }
        
        ///starting the implementation for the forward page
        AsyncProcessingLogModel asyncLogModel = new AsyncProcessingLogModel();
        AsyncProcessManager asyncManager = new AsyncProcessManager();
        /**
         * The following try catch blocks are sequenced so that different error
         * conditions can be handled differently.
         */
        try {

        	//pivUserName = StringEscapeUtils.escapeHtml(getUsername().replaceAll("&lt;", "<").replaceAll("&quot;", "").replaceAll("&gt;", ">"));			
			password = password.replaceAll("&lt;", "<").replaceAll("&quot;", "").replaceAll("&gt;", ">");
			
			// Record attempted logins in the ASYNCPROCESSINGLOG table
            asyncLogModel.init(pivUserName, domainName, "LOGIN",  "SECURITY", "In process login", request.getRemoteAddr());
            // add the browser details to the login
            requestDetails = new RequestDetails(request);
            asyncLogModel.setBrowser(requestDetails.getBrowser().toUpperCase());
            asyncLogModel.setBrowserVersion(requestDetails.getVersion());
            asyncLogModel = asyncManager.createAsyncProcessLog(asyncLogModel);           
        
        
        //--------------------------------------------------
        
          logger.info(request.getRemoteAddr() + "-----getBrowser: " + requestDetails.getBrowser().toUpperCase());
            Credentials credentials = AuthenticationUtils.getPivCredentials(pivUserName, domainName, request.getRemoteAddr());
            logger.info("-----after getPivCredentials: ");

            session = request.getSession();

            // Record successful login in the ASYNCPROCESSINGLOG table
            asyncManager.logResult(asyncLogModel, true, "Successful login", "respondCredentials");
            // only for debugging purposes
            session.setAttribute("TimeUserLoggedIn", new java.util.Date());
            // Stores the credentials in the SessionStore
            if (credentials.getDateFormat() == null || credentials.getDateFormat().equals(""))
                credentials.setDateFormat("yyyy-MM-dd");

            store = SessionStore.getInstance(session);
            store.put(SessionKey.CREDENTIALS, credentials);
            // Stores the access list in the SessionStore
            HashMap<String, String> accessList = AuthenticationUtils.getNxRolePermissionList(credentials.getRole());
            store.put(SessionKey.ACCESS_CONTROL_LIST, accessList);
            logger.info("-----getNxRolePermissionList: " + credentials.getRole());
            
            loginTimeRoleMsg = IncludesUtil.getWelcomeMsg(credentials)+ "<br>" + IncludesUtil.getExpireMsg(credentials);
            SystemMessageManager messageManager = SystemMessageManager.getInstance();
            messageText = messageManager.getMessageModel().getMessageText();
            faqTxt = messageManager.getMessageModel().getFaqTxt();
            
            if (credentials.getUserId() != null) {
            	
			    pivUserName = credentials.getUserId();
            	
            	AuthenticationUtils.updateLastLoginTimestamp(credentials.getSystemUserId());
            	logger.info("------- SUCCESS pivUserName:" + pivUserName);

				return "success";
				
            } 
            else {
            	logger.info("------- ERROR pivUserName:" + pivUserName);
                return "error";
            }
        } // catches all exceptions and logs
        // all business exceptions are logged with logger.debug, system exceptions with logger.error
        catch (UserNotActiveException unaEx) {
            logger.info("UserAccess " + pivUserName + ". Login Error " + "User Not Active.");
            logger.error("respondBtnCredentials(): UserNotActiveException");
            asyncManager.logResult(asyncLogModel, false, "Failed login due to user not being active.", "UserNotActiveException");
			addActionError(getText("error.login.userNotActive"));
        } 
        catch (InvalidUserException ivEx) {
            if (ivEx.getMessage().equals("-1")) {			    		        
                setPivUserName(StringEscapeUtils.escapeHtml(getPivUserName().replaceAll("&lt;", "").replaceAll("&quot;", "").replaceAll("&gt;", "")));	
				
				logger.info("UserAccess " + pivUserName + ". Login Error " + "pivUserName Does Not Exist.");
                asyncManager.logResult(asyncLogModel, false, "Failed login due to unknown user id.", "InvalidUserException");
				addActionError(getText("error.login.generic"));
            }
        } 
        catch (AccountExpiredException auEx) {
            logger.error("UserAccess " + pivUserName + ". Login Error " + "Account Locked.");
            asyncManager.logResult(asyncLogModel, false, "Failed login due to excessive failed login attempts.", "AccountExpiredException");
			addActionError(getText("error.login.failedLoginExceeded"));
        } 
        catch (RuntimeException ex) {
            logger.error("respondBtnCredentials(): ConnectionException", ex);
            asyncManager.logResult(asyncLogModel, false, "Failed login due to runtime exception.", "RuntimeException");
			addActionError(getText("error.login.connectionFailed"));
        } 
        catch (Exception systemException) {		    		    

            logger.error("respondBtnCredentials(): SystemException", systemException);
            asyncManager.logResult(asyncLogModel, false, "Failed login due to system exception.", "systemException");
			addActionError(getText("error.login.generic"));
        }
    	logger.info("------- display pivUserName:" + pivUserName);

		return "display";

    }
	
	public String getBtnLogin () {return btnLogin;}
    public void setBtnLogin (String btnLogin) {this.btnLogin = btnLogin;}

    public boolean hasValidLicense() {
        return LicenseProperties.isProductLicensed("FDSuite");
    }

    public void validate() {        
    }

    public void setServletRequest(HttpServletRequest request) {
        this.request = request;
    }

    public HttpServletRequest getServletRequest() {
        return this.request;
    }

    public Ctuuser getModel() {
        return ctuuser;
    }

    public Ctuuser getCtuuser() {
        return ctuuser;
    }

    public void setCtuuser(Ctuuser ctuuser) {
        this.ctuuser = ctuuser;
    }
        	
	public String getPivUserName() {
        return pivUserName;
    }

    public void setPivUserName(String pivUserName) {
        this.pivUserName = pivUserName;
    }
    	
    public String getDomainName() {
        return domainName;
    }

    public void setDomainName(String domainName) {
        this.domainName = domainName;
    }
    
    public String getFaqTxt() {
        if (faqTxt == null)
	{
            this.faqTxt = "";
	}
		
	return faqTxt;
    }
    
    public void setFaqTxt(String faqTxt) {
	this.faqTxt = faqTxt;
    }
        
    public String getMessageText() {
	return messageText;
    }
        
    public void setMessageText(String messageText) {
	this.messageText = messageText; 
    }
    
    public String getLoginTimeRoleMsg() {
        return loginTimeRoleMsg;
    }

    public void setLoginTimeRoleMsg(String loginTimeRoleMsg) {
        this.loginTimeRoleMsg = loginTimeRoleMsg;
    }
    
    public String getMyAction() {
        return myAction;
    }

    public void setMyAction(String myAction) {
        this.myAction = myAction;
    }
    
    public void setActionMessage(HttpServletRequest request, String[] messageKeyObject) {
        int length = messageKeyObject.length;
        logger.debug("messageKeyObject.length = " + length);
        ActionMessage actionMessage = null;
        switch (length) {
            case 2:
                logger.debug("messagekeyvalues" + messageKeyObject[0]);
                actionMessage = new ActionMessage(messageKeyObject[0], (Object) messageKeyObject[1]);
                break;
            case 3:
                actionMessage = new ActionMessage(messageKeyObject[0], messageKeyObject[1], messageKeyObject[2]);
                break;
            case 4:
                actionMessage = new ActionMessage(messageKeyObject[0], messageKeyObject[1], messageKeyObject[2], messageKeyObject[3]);
                break;
            case 5:
                actionMessage = new ActionMessage(messageKeyObject[0], messageKeyObject[1], messageKeyObject[2], messageKeyObject[3], messageKeyObject[4]);
                break;
            default:
                actionMessage = new ActionMessage(messageKeyObject[0]);
        }

        ActionMessages messages = new ActionMessages();
        messages.add(ActionMessages.GLOBAL_MESSAGE, actionMessage);

        logger.debug("message has been set on request");
    }
}
