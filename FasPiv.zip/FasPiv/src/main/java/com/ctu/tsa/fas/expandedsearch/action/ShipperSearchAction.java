/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ctu.tsa.fas.expandedsearch.action;

import javax.servlet.http.HttpServletRequest;
import com.freightdesk.fdcommons.Credentials;
import com.freightdesk.fdcommons.SessionKey;
import com.freightdesk.fdcommons.SessionStore;
import javax.servlet.http.HttpSession;
import com.opensymphony.xwork2.ActionSupport;
import org.apache.log4j.Logger;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.ServletActionContext;
import crt.com.freightdesk.fdfolio.common.IncludesUtil;
import java.util.List;
import java.util.ArrayList;
import com.ctu.tsa.fas.expandedsearch.dao.ExpandedSearchShipperDAO;
import com.ctu.tsa.fas.requesttracker.dao.RequestTrackerDAO;
import com.ctu.tsa.fas.expandedsearch.model.ShipperDetails; 
import com.freightdesk.fdcommons.ApplicationProperties;
import com.freightdesk.fdcommons.LcpConstants;
import java.util.Map;
import java.util.HashMap;
import java.sql.*;
import java.util.Iterator;
import com.ctu.tsa.fas.expandedsearch.dao.ExpandedSearchShipperDAO.MyShipperSqlResults;
import com.freightdesk.fdcommons.ApplicationTabs;

/**
 *
 * @author Binh.Nguyen
 */
public class ShipperSearchAction extends ActionSupport implements ServletRequestAware{
    protected Logger logger = Logger.getLogger(getClass());
    HttpServletRequest request = ServletActionContext.getRequest();    
    private String loginTimeRoleMsg;
    private String expandedSearchType = "";
    private String basicBtnClicked = "";
    private List<String> searchTypeList = new ArrayList<>();
    private String shipperName = "";
    private String shipperNameStr = "";
    private String shipperType = "";
    private String shipperId = "";
    private String shipperStatus = "";
    private String shipperNumber = "";
    private String shipperNumberStr = "";
    private String stateCodeStr = "";
    private String iacNumberStr = "";
    private String iacAcCompanyName = "";
    private String iacAcCompanyNameStr = "";
    private String dispositionCode = "";
    private long organizationProfileId = 0L;
    private String virtualShipper = "";
    private List<Map> shipperListMap;
    private List<Map> shipperList;
    private long recordCount = 0;
    private String pagerOffset;
    private int noOfShipperRecordsToLoad = 100;
    private String noOfShipperRecordsToLoadStr = "";          
    private String stateCode;		
	private int pageSize = 25;		
	private long startTime = 0;
    private Runtime runtime = Runtime.getRuntime();
	private String debugMsg = null;
    
	
    
    @Override
    public String execute()throws Exception {
    	
    	startTime = System.currentTimeMillis();

        request = ServletActionContext.getRequest();
        HttpSession session = request.getSession(false);
        SessionStore store = SessionStore.getInstance(session);
        Credentials credentials = (Credentials) store.get(SessionKey.CREDENTIALS);
        ExpandedSearchShipperDAO dao = new ExpandedSearchShipperDAO();
        List<ShipperDetails> shipperDetails = new ArrayList<ShipperDetails>();
        ResultSet searchResultSet;    
        MyShipperSqlResults myShipperSqlResults;
        int totalCount = 0;
        	    
        logger.info("execute(): begin");
        loginTimeRoleMsg = IncludesUtil.getWelcomeMsg(credentials)+ "<br>" + IncludesUtil.getExpireMsg(credentials);               

        SessionStore sessionStore = SessionStore.getInstance (request.getSession());
        sessionStore.put(SessionKey.CURRENT_TAB, ApplicationTabs.EXPANDEDSEARCH);       		
		
        try {            
            noOfShipperRecordsToLoad = 100;
            noOfShipperRecordsToLoadStr = Integer.toString(noOfShipperRecordsToLoad);            
        } catch (Exception ignored) {
            logger.debug ("ADDRESSBOOK_MAXIMUM_RESULTS property is not set, defaulting to 100 " + ignored);          
        }
        
        setNoOfShipperRecordsToLoad(getNoOfShipperRecordsToLoad());
        
        
        searchTypeList = initSearchTypeList (searchTypeList);                   		                
                        
    	logger.info("INITIAL SEARCH:" + pageSize); 
        
        logger.info("number: " + getShipperNumberStr () + ", name:" + getShipperNameStr () + ", iacNumber:" + getIacNumberStr () +
        	 ", IacCo:" + getIacAcCompanyNameStr ()   	+ ", state:" + getStateCodeStr ()) ;
        
        setShipperNumberStr(getShipperNumberStr().toUpperCase().replaceAll("<", "&lt").replaceAll(">", "&gt"));
        setShipperNameStr(getShipperNameStr().toUpperCase().replaceAll("<", "&lt").replaceAll(">", "&gt"));
        setIacNumberStr(getIacNumberStr().toUpperCase().replaceAll("<", "&lt").replaceAll(">", "&gt"));
        setIacAcCompanyNameStr(getIacAcCompanyNameStr().toUpperCase().replaceAll("<", "&lt").replaceAll(">", "&gt"));
                
        String shipperId = getShipperNumberStr().trim();
        if (shipperId.isEmpty()) {
        	shipperId = "%";
        }
        else {
        	shipperId = shipperId.toUpperCase();
        }
        
        String shipperName = getShipperNameStr().trim();
        if (shipperName.isEmpty()) {
        	shipperName = "%";
        }
        else {
        	shipperName = shipperName.toUpperCase();
        }
        
        String iacNumber = getIacNumberStr().trim();
        if (iacNumber.isEmpty()) {
        	iacNumber = "%";
        }
        else {
        	iacNumber = iacNumber.toUpperCase();
        }
        
        String iacAcCompany = getIacAcCompanyNameStr().trim();
        if (iacAcCompany.isEmpty()) {
        	iacAcCompany = "%";
        }
        else {
        	iacAcCompany = iacAcCompany.toUpperCase();
        }
        
        String stateCode = getStateCodeStr ().trim();
        if (stateCode.isEmpty()) {
        	stateCode = "%";
        }

        logger.info("number:" + shipperId + ", name:" + shipperName + ", iacNumber:" + iacNumber +
        	 ", IacCo:" + iacAcCompany 	+ ", state:" + stateCode) ;
        
        if ((! shipperId.equals("%")) && (shipperName.equals("%")) &&
                (iacNumber.equals("%")) && (iacAcCompany.equals("%"))) {
            shipperList = new ArrayList<Map>();
            sessionStore.put (SessionKey.TOTAL_COUNT, new Long(0));
            addFieldError("userDetailsErrorsHeader", getText("errors.header"));
            addActionError("Please provide additional data in other search fields when searching by Shipper ID");
	    return ActionSupport.INPUT;    // invalid field size 
        } else if((shipperId.length() < 3) && (shipperName.length() < 3) 
                && (iacNumber.length() < 3) && (iacAcCompany.length() < 3)){
            shipperList = new ArrayList<Map>(); 
            sessionStore.put (SessionKey.TOTAL_COUNT, new Long(0));
            addFieldError("userDetailsErrorsHeader", getText("errors.header"));
            addActionError("Minimum of 3 alphanumeric characters must be entered in the search field");
	    return ActionSupport.INPUT;    // invalid field size 
        }
        
        if ((! shipperId.equals("%")) && (! iacNumber.equals("%"))){
            myShipperSqlResults = (MyShipperSqlResults)dao.getShipperInfoByIacNumberShipperId(iacNumber, shipperId);
            setShipperList(myShipperSqlResults.getSListMap());
            totalCount = (int) myShipperSqlResults.getTotalCount();
            
            logger.info(shipperName + " :COUNT: " + totalCount);
            if (! shipperName.equals("%")
                || ! iacAcCompany.equals("%")){
                setShipperList(selShipperRecByShipperName(shipperList, shipperName));
                setShipperList(selShipperRecByIacAcCompany(shipperList, iacAcCompany)); 
                totalCount = shipperList.size();
                logger.info(" shipperName:" +shipperName + " company:" + iacAcCompany + " :COUNT: " + totalCount);
            }
        } else if ((! shipperId.equals("%")) && (! iacAcCompany.equals("%"))){
            myShipperSqlResults = (MyShipperSqlResults)dao.getShipperInfoByIacAcCompanyNameShipperId(iacAcCompany, shipperId);
            setShipperList(myShipperSqlResults.getSListMap());
            totalCount = (int) myShipperSqlResults.getTotalCount();
            
            logger.info(shipperName + " :COUNT: " + totalCount);
            if (! shipperName.equals("%")
                || ! iacNumber.equals("%")){
                setShipperList(selShipperRecByShipperName(shipperList, shipperName));
                setShipperList(selShipperRecByIacNumber(shipperList, iacNumber));   
                totalCount = shipperList.size();
                logger.info("shipperName:" +shipperName + " number:" +iacNumber + " company:" + iacAcCompany + " :COUNT: " + totalCount);
                }
        } else if ((! shipperName.equals("%")) && (! iacNumber.equals("%"))){
            myShipperSqlResults = (MyShipperSqlResults)dao.getShipperInfoByShipperNameIacNumber(shipperName, iacNumber);
            setShipperList(myShipperSqlResults.getSListMap());
            totalCount = shipperList.size();
            if (! shipperId.equals("%")
                || ! iacAcCompany.equals("%")){
                setShipperList(selShipperRecByShipperId(shipperList, shipperId)); 
                setShipperList(selShipperRecByIacAcCompany(shipperList, iacAcCompany)); 
                totalCount = shipperList.size();
            }
        } else if (! shipperName.equals("%")){ 
        	myShipperSqlResults = (MyShipperSqlResults)dao.getShipperInfoByShipperName(shipperName);
                setShipperList(myShipperSqlResults.getSListMap());
                totalCount = (int) myShipperSqlResults.getTotalCount();
                
                logger.info(shipperName + " :COUNT: " + totalCount);
                
                if (! shipperId.equals("%")
                    || ! iacNumber.equals("%")
                    || ! iacAcCompany.equals("%")){
                    setShipperList(selShipperRecByShipperId(shipperList, shipperId)); 
                    setShipperList(selShipperRecByIacNumber(shipperList, iacNumber)); 
                    setShipperList(selShipperRecByIacAcCompany(shipperList, iacAcCompany)); 
                    totalCount = shipperList.size();

                    logger.info("if:" +shipperId + " number:" +iacNumber + " company:" + iacAcCompany + " :COUNT: " + totalCount);
                }
                
        } else if (! iacNumber.equals("%")){ 
                myShipperSqlResults = (MyShipperSqlResults)(dao.getShipperInfoByIacNumber(iacNumber));
                setShipperList(myShipperSqlResults.getSListMap());
                totalCount = (int) myShipperSqlResults.getTotalCount();
                logger.info(iacNumber + " :COUNT: " + totalCount);
                
                if (! shipperId.equals("%")
                    || ! shipperName.equals("%")
                    || ! iacAcCompany.equals("%")){
                    setShipperList(selShipperRecByShipperId(shipperList, shipperId)); 
                    setShipperList(selShipperRecByShipperName(shipperList, shipperName));
                    setShipperList(selShipperRecByIacAcCompany(shipperList, iacAcCompany)); 
                    totalCount = shipperList.size();
                    logger.info("shipperId:" +shipperId + " shipperName:" +shipperName + " company:" + iacAcCompany + " :COUNT: " + totalCount);

                }
                
        } else if (! iacAcCompany.equals("%")){ 
                myShipperSqlResults = (MyShipperSqlResults)(dao.getShipperInfoByIacAcCompanyName(iacAcCompany));
                setShipperList(myShipperSqlResults.getSListMap());
                totalCount = (int) myShipperSqlResults.getTotalCount();
                logger.info(iacAcCompany + " :COUNT: " + totalCount);
                
                if (! shipperId.equals("%")
                    || ! shipperName.equals("%")
                    || ! iacNumber.equals("%")){
                    setShipperList(selShipperRecByShipperId(shipperList, shipperId)); 
                    setShipperList(selShipperRecByShipperName(shipperList, shipperName));
                    setShipperList(selShipperRecByIacNumber(shipperList, iacNumber));  
                    totalCount = shipperList.size();
                    logger.info("shipperId:" +shipperId + " shipperName:" +shipperName + " iacNumber:" + iacNumber + " :COUNT: " + totalCount);
                }
                
        } else if (! shipperId.equals("%")){ 
                myShipperSqlResults = (MyShipperSqlResults) (dao.getShipperInfoByShipperId(shipperId));
                setShipperList(myShipperSqlResults.getSListMap());
                totalCount = (int) myShipperSqlResults.getTotalCount();
                logger.info(shipperId + " :COUNT: " + totalCount);

                if (! shipperName.equals("%")
                    || ! iacNumber.equals("%")
                    || ! iacAcCompany.equals("%")){
                    setShipperList(selShipperRecByShipperName(shipperList, shipperName));
                    setShipperList(selShipperRecByIacNumber(shipperList, iacNumber)); 
                    setShipperList(selShipperRecByIacAcCompany(shipperList, iacAcCompany));   
                    totalCount = shipperList.size();
                    logger.info("shipperName:" +shipperName + " number:" +iacNumber + " company:" + iacAcCompany + " :COUNT: " + totalCount);
                }

        } else if (stateCode.equals("%")
        	&& shipperId.equals("%")
        	&& shipperName.equals("%")
        	&& iacNumber.equals("%")
        	&& iacAcCompany.equals("%")
       		){ 
	            logger.info("No input: ");
                    shipperList = new ArrayList<Map>();
                    sessionStore.put (SessionKey.TOTAL_COUNT, new Long(0));
                    addFieldError("userDetailsErrorsHeader", getText("errors.header"));
                    addActionError("Please provide data in at least one field");
                    return ActionSupport.INPUT;    // invalid field size

        } else {
            logger.info("****************   search by any: ");
            setShipperList(dao.getShipperInfo(shipperId, iacNumber, shipperName, iacAcCompany, stateCode));
        }
        
        setRecordCount ( shipperList.size());
        setRecordCount ( totalCount);
        sessionStore.put (SessionKey.TOTAL_COUNT, new Long(totalCount)); 
        
	    session.setAttribute("SHIPPER_LIST", IncludesUtil.convertMapListToJsonString(shipperList));					

        
        logger.info(" :TOTAL COUNT: " + totalCount);
		debugMsg = "SHIPPER **** Memory: " + runtime.totalMemory()/1000 + ", Used: " + (runtime.totalMemory() - runtime.freeMemory())/1000 + " Elapsed Time :" + (System.currentTimeMillis() - startTime);
		logger.info(debugMsg);
	    session.setAttribute("DEBUG_MSG", debugMsg);
	    
	    
                
        return "displayShipper";
    }   
        
    public String respondBtnSearchTypeReturn() throws java.lang.Exception {
        request = ServletActionContext.getRequest();
        HttpSession session = request.getSession(false);
        SessionStore store = SessionStore.getInstance(session);
        Credentials credentials = (Credentials) store.get(SessionKey.CREDENTIALS);
        loginTimeRoleMsg = IncludesUtil.getWelcomeMsg(credentials) + "<br>" + IncludesUtil.getExpireMsg(credentials);

        logger.debug("ShipperSeachACtion - Starting respondBtnSearchTypeReturn ");
        
        SessionStore sessionStore = SessionStore.getInstance(request.getSession());
        
        return "display";
    }       
    
    public String getExpandedSearchType() {
	return expandedSearchType;
    }
        
    public void setExpandedSearchType(String expandedSearchType) {
	this.expandedSearchType = expandedSearchType; 
    }
	
	public String getShipperType() {
        return shipperType;
    }

    public void setShipperType(String shipperType) {
        this.shipperType = shipperType;
    }
	
	public String getShipperStatus() {
        return shipperStatus;
    }

    public void setShipperStatus(String shipperStatus) {
        this.shipperStatus = shipperStatus;
    }
	
    public List<String> getSearchTypeList() {
	return searchTypeList;
    }
        
    public void setSearchTypeList(List<String> searchTypeList) {
	this.searchTypeList = searchTypeList; 
    }
    
    public String getLoginTimeRoleMsg() {
        return loginTimeRoleMsg;
    }

    public void setLoginTimeRoleMsg(String loginTimeRoleMsg) {
        this.loginTimeRoleMsg = loginTimeRoleMsg;
    }

    @Override
    public void setServletRequest(HttpServletRequest request) {
        this.request = request;
    }

    public HttpServletRequest getServletRequest() {
        return this.request;
    }
    
    public String getBasicBtnClicked() {
        return basicBtnClicked;
    }

    public void setBasicBtnClicked(String basicBtnClicked) {
        this.basicBtnClicked = basicBtnClicked;
    }
	
    public String getIacAcCompanyName() {
        return iacAcCompanyName.toUpperCase();
    }

    public void setIacAcCompanyName(String iacAcCompanyName) {
        this.iacAcCompanyName = iacAcCompanyName;
    }
	
    public String getShipperNumber() {
        return shipperNumber.toUpperCase();
    }

    public void setShipperNumber(String shipperNumber) {
        this.shipperNumber = shipperNumber;
    }
    
    public String getShipperNumberStr() {
        return shipperNumberStr.toUpperCase();
    }

    public void setShipperNumberStr(String shipperNumberStr) {
        this.shipperNumberStr = shipperNumberStr;
    }
    
    public String getIacNumberStr() {
        return iacNumberStr.toUpperCase();
    }

    public void setIacNumberStr(String iacNumberStr) {
        this.iacNumberStr = iacNumberStr;
    }
	
    public String getDispositionCode() {
        return dispositionCode;
    }

    public void setDispositionCode(String dispositionCode) {
        this.dispositionCode = dispositionCode;
    }
	
    public String getVirtualShipper() {
        return virtualShipper;
    }
        
    public long getOrganizationProfileId() {
        return organizationProfileId;
    }

    public void setOrganizationProfileId(long organizationProfileId) {
        this.organizationProfileId = organizationProfileId;
    }

    public void setVirtualShipper(String virtualShipper) {
        this.virtualShipper = virtualShipper;
    }
	
    public String getShipperName() {
        return shipperName;
    }

    public void setShipperName(String shipperName) {
        this.shipperName = shipperName;
    }
    
    public String getShipperNameStr() {
        return shipperNameStr.toUpperCase();
    }

    public void setShipperNameStr(String shipperNameStr) {
        this.shipperNameStr = shipperNameStr;
    }
    
    public String getIacAcCompanyNameStr() {
        return iacAcCompanyNameStr.toUpperCase();
    }

    public void setIacAcCompanyNameStr(String iacAcCompanyNameStr) {
        this.iacAcCompanyNameStr = iacAcCompanyNameStr;
    }
    
    public long getRecordCount() {
	return recordCount;
    }
        
    public void setRecordCount(long recordCount) {
	this.recordCount = recordCount; 
    }
    
    public String getStateCode() {
        return stateCode;
    }

    public void setStateCode(String stateCode) {
        this.stateCode = stateCode;
    }
    
    
    private List<String> initSearchTypeList (List<String> inSearchTypeList){
        inSearchTypeList = new ArrayList<>();        
        inSearchTypeList.add("Shipper");
        inSearchTypeList.add("CCSF");
        inSearchTypeList.add("IAC");
        inSearchTypeList.add("Subject Company");
        inSearchTypeList.add("Subject Individual");
        
        return inSearchTypeList;
    }
    
    
    public List<Map> getShipperListMap() {
        return shipperListMap;
    }

    public void setShipperListMap(List<Map> shipperListMap) {
        this.shipperListMap = shipperListMap;
    }
    
    public List<Map> getShipperList() {
        return shipperList;
    }

    public void setShipperList(List<Map> shipperList) {
        this.shipperList = shipperList;
    }
    
    public String getPagerOffset() {
        return pagerOffset;
    }

    public void setPagerOffset(String pagerOffset) {
        this.pagerOffset = pagerOffset;
    }      
    
    
    List<Map> convertToShipperListMap(List<Map> theShipperList){
    	
        int starting_idx=0;

        if (request.getParameter("pager.offset") != null) {
            starting_idx = Integer.parseInt((String)request.getParameter("pager.offset"));
        }
                
        logger.info(starting_idx + ":-----starting_idx - pageSize---:" + pageSize + " listSize:" + theShipperList.size());

        return theShipperList.subList(starting_idx, Math.min(starting_idx + pageSize, theShipperList.size()));
     }    
    
    public void setNoOfShipperRecordsToLoad(int noOfShipperRecordsToLoad){
        this.noOfShipperRecordsToLoad = noOfShipperRecordsToLoad;
    }

    public int getNoOfShipperRecordsToLoad() {
        return noOfShipperRecordsToLoad;
    }  

	public void setNoOfShipperRecordsToLoadStr(String noOfShipperRecordsToLoadStr){
        this.noOfShipperRecordsToLoadStr = noOfShipperRecordsToLoadStr;
    }

    public String getNoOfShipperRecordsToLoadStr() {
        return noOfShipperRecordsToLoadStr;
    }
       
	public void setStateCodeStr (String stateCodeStr) {
		this.stateCodeStr = stateCodeStr; 
	}

	public String getStateCodeStr () {
		return (this.stateCodeStr); 
	}
	
	public void setShipperId(String shipperId) {
        this.shipperId = shipperId;
    }
        
    public String getShipperId() {
        return shipperId;
    }
	
    public List<Map> selShipperRecByShipperId(List<Map> theShipperList, String shipperIdStr){
        List<Map> theShipperListMap = new ArrayList();
        Map shipperMap = new HashMap();
        Map map = new HashMap();
        
        Iterator<Map>  itrList = theShipperList.iterator();
        if (shipperIdStr.equals("%")){
            return theShipperList;
        } else {
            while (itrList.hasNext()) {
                shipperMap = (Map)itrList.next();
                
                if (shipperMap.get("shipperId") != null && shipperMap.get("shipperId") != ""){
                    if (((((String)shipperMap.get("shipperId")).toUpperCase()).equals(shipperIdStr.toUpperCase())) || 
					    ((shipperIdStr.contains("%")) && (((String)shipperMap.get("shipperId")).length() >= shipperIdStr.indexOf('%'))
					           && (((((String)shipperMap.get("shipperId")).toUpperCase()).substring(0, (shipperIdStr.toUpperCase().indexOf('%')-1))).equals(shipperIdStr.toUpperCase().substring(0, (shipperIdStr.indexOf('%')-1)))))) {
                        theShipperListMap.add(shipperMap);                 
					}                              
                }
            }
        }
        return theShipperListMap;
    }
    
    public List<Map> selShipperRecByShipperName(List<Map> theShipperList, String shipperNameStr){
        List<Map> theShipperListMap = new ArrayList();
        Map shipperMap = new HashMap();
        Map map = new HashMap();
        
        Iterator<Map>  itrList = theShipperList.iterator();
        if (shipperNameStr.equals("%")){
            return theShipperList;
        } else {
            while (itrList.hasNext()) {
                shipperMap = (Map)itrList.next();
                if (shipperMap.get("shipperName") != null && shipperMap.get("shipperName") != ""){
                    if (((((String)shipperMap.get("shipperName")).toUpperCase()).equals(shipperNameStr.toUpperCase())) ||
					  ((shipperNameStr.contains("%")) && (((String)shipperMap.get("shipperName")).length() >= shipperNameStr.indexOf('%'))
         					 && (((((String)shipperMap.get("shipperName")).toUpperCase()).substring(0, (shipperNameStr.indexOf('%')-1))).equals(shipperNameStr.toUpperCase().substring(0, (shipperNameStr.indexOf('%')-1)))))) {
                        theShipperListMap.add(shipperMap);                    
					} 
                }
            }
        }
        return theShipperListMap;
    }
    
    public List<Map> selShipperRecByIacNumber(List<Map> theShipperList, String iacNumberStr){
        List<Map> theShipperListMap = new ArrayList();
        Map shipperMap = new HashMap();
        Map map = new HashMap();
        
        Iterator<Map>  itrList = theShipperList.iterator();
        if (iacNumberStr.equals("%")){
            return theShipperList;
        } else {
            while (itrList.hasNext()) {
                shipperMap = (Map)itrList.next();
                if (shipperMap.get("internalIacNumber") != null && shipperMap.get("internalIacNumber") != ""){
                    if (((((String)shipperMap.get("internalIacNumber")).toUpperCase()).equals(iacNumberStr.toUpperCase())) ||
					   ((iacNumberStr.contains("%")) && (((String)shipperMap.get("internalIacNumber")).length() >= iacNumberStr.indexOf('%'))
					   && ((((String)shipperMap.get("internalIacNumber")).toUpperCase()).substring(0, (iacNumberStr.indexOf('%')-1)).equals(iacNumberStr.toUpperCase().substring(0, (iacNumberStr.indexOf('%')-1)))))) {
                        theShipperListMap.add(shipperMap);                    
					} 
                }
            }
        }
        return theShipperListMap;
    }
    
    public List<Map> selShipperRecByIacAcCompany(List<Map> theShipperList, String iacAcCompanyStr){
        List<Map> theShipperListMap = new ArrayList();
        Map shipperMap = new HashMap();
        Map map = new HashMap();
        
        Iterator<Map>  itrList = theShipperList.iterator();
        if (iacAcCompanyStr.equals("%")){
            return theShipperList;
        } else {
            while (itrList.hasNext()) {
                shipperMap = (Map)itrList.next();
                if (shipperMap.get("iacAcCompanyName") != null && shipperMap.get("iacAcCompanyName") != ""){
                    if (((((String)shipperMap.get("iacAcCompanyName")).toUpperCase()).equals(iacAcCompanyStr.toUpperCase())) || 
					  ((iacAcCompanyStr.contains("%")) && (((String)shipperMap.get("iacAcCompanyName")).length() >= iacAcCompanyStr.indexOf('%'))
					    && ((((String)shipperMap.get("iacAcCompanyName")).toUpperCase()).substring(0, (iacAcCompanyStr.indexOf('%')-1)).equals(iacAcCompanyStr.toUpperCase().substring(0, (iacAcCompanyStr.indexOf('%')-1)))))) {
                        theShipperListMap.add(shipperMap);
                    } 
                }
            }
        }
        return theShipperListMap;
    }
}
