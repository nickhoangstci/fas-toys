/*
 * 
 */
package com.ctu.tsa.fas.requesttracker.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

/**
 *
 * @author Nick.Hoang
 * Note: It should be derived from RequestTrackerData, for application data.
 */
public class Request implements Serializable {

    private static final long serialVersionUID = -8767337899673261247L;

    private Date  requestDate;
    private String requestDateStr;
    private String requestNumber;
    private String requestStatus;
    private String requestorId;
    private String requestor;
    private String requestType;
    private boolean derogFound;
    private String derogLevel;
    private String airport;
    private String airportKey;
    private String subjectRegion;
    private String subjectRegionId;
    private String requestorName;
    private String subjectIndividual;
    private String subjectCompany;
    private String leadTargeterName;
    private String coTargeterName;
    private String leadTargeterId;
    private String coTargeter;
    private String staInformation;
    private Sta[] staList;
    private String recommendation;
    private String comments;
    private String createUserName; 
    private String lastUpdateUserName; 
    private String inLieuAirport;
    private Timestamp createTimestamp; 
    private Timestamp lastUpdateTimestamp; 
    private String createTimestampStr; 
    private String lastUpdateTimestampStr; 
    	
   
    public Date getRequestDate() {
        return requestDate;
    }

    public void setRequestDate(Date requestDate) {
        this.requestDate = requestDate;
    }

    public boolean isDerogFound() {
        return derogFound;
    }

    public void setDerogFound(boolean derogFound) {
        this.derogFound = derogFound;
    }

    public String getDerogLevel() {
        return derogLevel;
    }

    public void setDerogLevel(String derogLevel) {
        this.derogLevel = derogLevel;
    }

    public String getAirportKey() {
        return airportKey;
    }

    public void setAirportKey(String airportKey) {
        this.airportKey = airportKey;
    }

    public String getSubjectIndividual() {
        return subjectIndividual;
    }

    public void setSubjectIndividual(String subjectIndividual) {
        this.subjectIndividual = subjectIndividual;
    }

    public String getSubjectCompany() {
        return subjectCompany;
    }

    public void setSubjectCompany(String subjectCompany) {
        this.subjectCompany = subjectCompany;
    }

    public String getCoTargeter() {
        return coTargeter;
    }

    public void setCoTargeter(String coTargeter) {
        this.coTargeter = coTargeter;
    }

    public String getRecommendation() {
        return recommendation;
    }

    public void setRecommendation(String recommendation) {
        this.recommendation = recommendation;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }
    
    public String getAirport() {
        return airport;
    }

    public void setAirport(String airport) {
        this.airport = airport;
    }

    public String getRequestStatus() {
        return requestStatus;
    }

    public void setRequestStatus(String requestStatus) {
        this.requestStatus = requestStatus;
    }

    public String getRequestNumber() {
        return requestNumber;
    }

    public void setRequestNumber(String requestNumber) {
        this.requestNumber = requestNumber;
    }

 
    public String getRequestType() {
        return requestType;
    }

    public void setRequestType(String requestType) {
        this.requestType = requestType;
    }

    public String getSubjectRegion() {
        return subjectRegion;
    }

    public void setSubjectRegion(String subjectRegion) {
        this.subjectRegion = subjectRegion;
    }

    public String getRequestor() {
        return requestor;
    }

    public void setRequestor(String requestor) {
        this.requestor = requestor;
    }

    public String getSubjectRegionId() {
        return subjectRegionId;
    }

    public void setSubjectRegionId(String subjectRegionId) {
        this.subjectRegionId = subjectRegionId;
    }

    public String getRequestorName() {
        return requestorName;
    }

    public void setRequestorName(String requestorName) {
        this.requestorName = requestorName;
    }

    public String getLeadTargeterName() {
        return leadTargeterName;
    }

    public void setLeadTargeterName(String leadTargeterName) {
        this.leadTargeterName = leadTargeterName;
    }

    public String getCoTargeterName() {
        return coTargeterName;
    }

    public void setCoTargeterName(String coTargeterName) {
        this.coTargeterName = coTargeterName;
    }
    
    

    public String getLeadTargeterId() {
        return leadTargeterId;
    }

    public void setLeadTargeterId(String leadTargeterId) {
        this.leadTargeterId = leadTargeterId;
    }

    public String getRequestorId() {
        return requestorId;
    }

    public void setRequestorId(String requestorId) {
        this.requestorId = requestorId;
    }

    public String getStaInformation() {
        return staInformation;
    }

    public void setStaInformation(String staInformation) {
        this.staInformation = staInformation;
    }

    public Timestamp getLastUpdateTimestamp() {
        return lastUpdateTimestamp;
    }

    public void setLastUpdateTimestamp(Timestamp lastUpdateTimestamp) {
        this.lastUpdateTimestamp = lastUpdateTimestamp;
    }

    public String getLastUpdateUserName() {
        return lastUpdateUserName;
    }

    public void setLastUpdateUserName(String lastUpdateUserName) {
        this.lastUpdateUserName = lastUpdateUserName;
    }

    public String getCreateUserName() {
        return createUserName;
    }

    public void setCreateUserName(String createUserName) {
        this.createUserName = createUserName;
    }

    public Timestamp getCreateTimestamp() {
        return createTimestamp;
    }

    public void setCreateTimestamp(Timestamp createTimestamp) {
        this.createTimestamp = createTimestamp;
    }

    public String getInLieuAirport() {
        return inLieuAirport;
    }

    public void setInLieuAirport(String inLieuAirport) {
        this.inLieuAirport = inLieuAirport;
    }

// for Export
	public void setRequestDateStr (String requestDateStr) {
		this.requestDateStr = requestDateStr; 
	}

	public String getRequestDateStr () {
		return (this.requestDateStr); 
	}

	public void setCreateTimestampStr (String createTimestampStr) {
		this.createTimestampStr = createTimestampStr; 
	}

	public String getCreateTimestampStr () {
		return (this.createTimestampStr); 
	}

	
	public void setLastUpdateTimestampStr (String lastUpdateTimestampStr) {
		this.lastUpdateTimestampStr = lastUpdateTimestampStr; 
	}

	public String getLastUpdateTimestampStr () {
		return (this.lastUpdateTimestampStr); 
	}

	// for JSP    
    @Override
    public String toString() {
        return "Request{" + "requestDate=" + requestDate + ", requestNumber=" + requestNumber + ", requestStatus=" + requestStatus + ", requestorId=" + requestorId + ", requestor=" + requestor + ", requestType=" + requestType + ", derogFound=" + derogFound + ", derogLevel=" + derogLevel + ", airport=" + airport + ", airportKey=" + airportKey + ", subjectRegion=" + subjectRegion + ", subjectRegionId=" + subjectRegionId + ", requestorName=" + requestorName + ", subjectIndividual=" + subjectIndividual + ", subjectCompany=" + subjectCompany + ", leadTargeterName=" + leadTargeterName + ", coTargeterName=" + coTargeterName + ", leadTargeterId=" + leadTargeterId + ", coTargeter=" + coTargeter + ", staInformation=" + staInformation + ", recommendation=" + recommendation + ", comments=" + comments + ", createUserName=" + createUserName + ", createTimestamp=" + createTimestamp + ", lastUpdateUserName=" + lastUpdateUserName + ", lastUpdateTimestamp=" + lastUpdateTimestamp + ", inLieuAirport=" + inLieuAirport + '}';
    }

 
    public String toAjaxString() {
        return "requestDate==" + requestDate + "~~ requestNumber==" + requestNumber + "~~ requestStatus==" + requestStatus + "~~ requestorId==" + requestorId + "~~ requestor==" + requestor + "~~ requestType==" + requestType + "~~ derogFound==" + derogFound + "~~ derogLevel==" + derogLevel + "~~ airport==" + airport + "~~ airportKey==" + airportKey + "~~ subjectRegion==" + subjectRegion + "~~ subjectRegionId==" + subjectRegionId + "~~ requestorName==" + requestorName + "~~ subjectIndividual==" + subjectIndividual + "~~ subjectCompany==" + subjectCompany + "~~ leadTargeterName==" + leadTargeterName + "~~ coTargeterName==" + coTargeterName + "~~ leadTargeterId==" + leadTargeterId + "~~ coTargeter==" + coTargeter + "~~ staInformation==" + staInformation + "~~ recommendation==" + recommendation + "~~ comments==" + comments + "~~ createUserName==" + createUserName + "~~ createTimestamp==" + createTimestamp + "~~ lastUpdateUserName==" + lastUpdateUserName + "~~ lastUpdateTimestamp==" + lastUpdateTimestamp + "~~ inLieuAirport==" + inLieuAirport;
    }

	
	public void setStaList (Sta[] staList) {
		this.staList = staList; 
	}

	public Sta[] getStaList () {
		return (this.staList); 
	}

	

    
}
