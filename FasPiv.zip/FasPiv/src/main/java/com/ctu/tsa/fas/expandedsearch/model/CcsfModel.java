/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ctu.tsa.fas.expandedsearch.model;

import java.io.Serializable;
import java.math.BigInteger;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 *
 * @author Kevin.Tsou
 */
public class CcsfModel implements Serializable{
    private static final long serialVersionUID = -1106837298377580912L;
    
    private String facilityName;
    private String type;
    private String iacNumber;
    private String ccsfStatus;
    private String certificationNumber;
    private String staAuthorizationKey;
    
    public CcsfModel() {
    }
    
    public CcsfModel(String facilityName, String type, String iacNumber, String ccsfStatus, String certificationNumber,
            String staAuthorizationKey) {
        this.facilityName = facilityName;
        this.type = type;
        this.iacNumber = iacNumber;
        this.ccsfStatus = ccsfStatus;
        this.certificationNumber = certificationNumber;
        this.staAuthorizationKey = staAuthorizationKey;
    }
    
    public String getFacilityName() {
        return facilityName;
    }

    public void setFacilityName(String facilityName) {
        this.facilityName = facilityName;
    }
    
    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
    
    public String getIacNumber() {
        return iacNumber;
    }

    public void setIacNumber(String iacNumber) {
        this.iacNumber = iacNumber;
    }
    
    public String getCcsfStatus() {
        return ccsfStatus;
    }

    public void setCcsfStatus(String ccsfStatus) {
        this.ccsfStatus = ccsfStatus;
    }
    
    public String getStaAuthorizationKey() {
        return staAuthorizationKey;
    }

    public void setStaAuthorizationKey(String staAuthorizationKey) {
        this.staAuthorizationKey = staAuthorizationKey;
    }
    
    public String getCertificationNumber() {
        return certificationNumber;
    }

    public void setCertificationNumber(String certificationNumber) {
        this.certificationNumber = certificationNumber;
    }
    
    @Override
    public String toString() {
        return "CcsfModel{" + "facilityName=" + facilityName + ", type=" + type + ", iacNumber=" + iacNumber + 
                ", ccsfStatus=" + ccsfStatus + ", staAuthorizationKey=" + staAuthorizationKey + ", certificationNumber=" + certificationNumber + '}';
    }
    
}
