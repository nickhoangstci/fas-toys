function handleButton(param) {
    document.orghierarchyForm.basicBtnClicked.value = param;
    document.orghierarchyForm.submit();
}

function makeSubsidiary(e, obj) {
    document.orghierarchyForm.basicBtnClicked.value = null;
    document.orghierarchyForm.action.value = "makeSub";
    
    var name = $( "input[name='orgName']" ).val();
    var parentName = $( "input[name='parentOrgName']" ).val();
    
    var convText = "Do you want to convert " + name +" into a subsidiary of " + parentName + "? All " + name + " user accounts, locations, and" +
            " screening data will be moved under " + parentName + " and will be visible to " + parentName + " user." +
            " This action cannot be undone. <br><br>Please choose \"Convert\" or \"Cancel.\"";
    
    $(".bd").html(convText);
    
    YAHOO.message.container.panelConv.show();
}

function makeOrganization(e, obj) {
    document.orghierarchyForm.basicBtnClicked.value = null;
    document.orghierarchyForm.action.value = "makeOrg";
    
    var subName = $( "input[name='orgName']" ).val();
    var parentName = $( "input[name='parentOrgName']" ).val();
    
    var convText = "Do you want to convert " + subName + " from being a subsidiary of " + parentName + "? All " + 
                            subName + " user accounts, locations, and screening data will be moved from under " +
                            parentName + " and will be visible to " + subName + " user. This action cannot be undone. <br> "+
                            "<br>Please choose \"Convert\" or \"Cancel.\"";

    $(".bd").html(convText);
    
    YAHOO.message.container.panelConv.show();
}

function convert() {
    YAHOO.message.container.panelConv.hide();
    document.orghierarchyForm.submit();
}

function delOrgReference(index) {
    document.orghierarchyForm.basicBtnClicked.value = null;
    document.orghierarchyForm.refId.value = index;
    document.orghierarchyForm.action.value = "delRef";
    document.orghierarchyForm.submit();
}

function addOrgReference() {
    document.orghierarchyForm.basicBtnClicked.value = null;
    document.orghierarchyForm.action.value = "addRef";
    document.orghierarchyForm.submit();
}

function addEvent() {
    document.orghierarchyForm.basicBtnClicked.value = null;
    document.orghierarchyForm.action.value = "addEvent";
    document.orghierarchyForm.submit();
}

function delEvent(index) {
    document.orghierarchyForm.basicBtnClicked.value = null;
    document.orghierarchyForm.eventId.value = index;
    document.orghierarchyForm.action.value = "delEvent";
    document.orghierarchyForm.submit();
}

function roleSelected() {
    document.orghierarchyForm.basicBtnClicked.value = null;
    document.orghierarchyForm.action.value = "roleSelected";
    document.orghierarchyForm.submit();
}

function addAssoc() {
    document.orghierarchyForm.basicBtnClicked.value = null;
    document.orghierarchyForm.action.value = "addAssoc";
    document.orghierarchyForm.submit();
}
function addProfileAssoc() {
    document.orghierarchyForm.basicBtnClicked.value = null;
    document.orghierarchyForm.action.value = "addAssoc";
    document.orghierarchyForm.submit();
}

function delAssoc(index) {
    document.orghierarchyForm.basicBtnClicked.value = null;
    document.orghierarchyForm.orgAssocId.value = index;
    document.orghierarchyForm.action.value = "delAssoc";
    document.orghierarchyForm.submit();

}
function delApAcAssoc(index) {
    document.orghierarchyForm.basicBtnClicked.value = null;
    document.orghierarchyForm.orgAssocId.value = index;
    document.orghierarchyForm.action.value = "delApAcAssoc";
    document.orghierarchyForm.submit();

}
function assocRequiredEndDate (selectObject) {
	var relationship = selectObject.value;
	var name = selectObject.name;
	var index = name.length == 32 ? selectObject.name.substring(13,14) : selectObject.name.substring(13,15);
	var toggleField = "eventEndDateTimeRequired" + index;
	if (relationship == "NCSP" || relationship == "SEAS")
	{
		$("span[name='" + toggleField + "']").show();
	}else
	{
		$("span[name='" + toggleField + "']").hide();
	}
}
