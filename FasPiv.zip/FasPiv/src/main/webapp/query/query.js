function verifyDelete(param) {
	r=confirm("Are you sure you want to delete this query?");

	if (r==true)
	{
		document.queryForm.action.value = param;
		document.queryForm.submit();
	}
}

function handleLoad(id) {
	document.queryForm.queryID.value = id;
	handleButton("load");
}

function handleExport(param) {
	document.queryForm.action.value = param;
	document.queryForm.submit();
}

function handleButton(param) {
	document.queryForm.action.value = param;
	setHidden();
	
	if (document.queryForm.reportingStartDate.value == "mm/dd/yyyy")
	{
		document.queryForm.reportingStartDate.value = '';
	}
	if (document.queryForm.reportingEndDate.value == "mm/dd/yyyy")
	{
		document.queryForm.reportingEndDate.value = '';
	}

	if (document.queryForm.createdStartDate.value == "mm/dd/yyyy")
	{
		document.queryForm.createdStartDate.value = '';
	}
	if (document.queryForm.createdEndDate.value == "mm/dd/yyyy")
	{
		document.queryForm.createdEndDate.value = '';
	}

	if (document.queryForm.updatedStartDate.value == "mm/dd/yyyy")
	{
		document.queryForm.updatedStartDate.value = '';
	}
	if (document.queryForm.updatedEndDate.value == "mm/dd/yyyy")
	{
		document.queryForm.updatedEndDate.value = '';
	}

	document.queryForm.submit();
}
function overlay() {
    var content = document.getElementById("overlay");
    content.innerHTML = "";
    YAHOO.loading.container.wait = new YAHOO.widget.Panel("wait",  
                                                         { width: "80%", 
                                                           fixedcenter: true, 
                                                           close: false, 
                                                           draggable: false, 
                                                           zindex:4,
                                                           modal: true,
                                                           visible: false
                                                         });
    YAHOO.loading.container.wait.setHeader("Loading, please wait...");
    YAHOO.loading.container.wait.setBody("<img alt=\"Loading\" src=\"/resources/images/bar_loading.gif\"/>");
    YAHOO.loading.container.wait.render(document.body);
    YAHOO.loading.container.wait.show();

//  el = document.getElementById("overlay");
//	el.style.visibility = (el.style.visibility == "visible") ? "hidden" : "visible";
}

var table=function(){
	function sorter(n){
		this.n=n; this.t; this.b; this.r; this.d; this.p; this.w; this.a=[]; this.l=0; this.initalized = false; this.submitted = false;
	}
	sorter.prototype.init=function(t,f){
		this.t=document.getElementById(t);
		this.b=this.t.getElementsByTagName('tbody')[0];
		this.r=this.b.rows; var l=this.r.length;
		for(var i=0;i<l;i++){
			if(i==0){
				var c=this.r[i].cells; this.w=c.length;
				for(var x=0;x<this.w;x++){
					if(c[x].className!='nosort'){
						c[x].onclick=new Function(this.n+'.work(this.cellIndex)')
//						c[x].onclick=new Function(this.n+'.submitSort(this.cellIndex)')
					}
				}
			}else{
				this.a[i-1]={}; this.l++;
			}
		}
		if(f!=null){
			var a=new Function(this.n+'.work('+f+')'); a()
		}
	}
	sorter.prototype.submitSort=function(y){
		this.b=this.t.getElementsByTagName('tbody')[0]; this.r=this.b.rows;
		var x=this.r[0].cells[y],i;
		document.queryForm.sortColumn.value = $(x).text();
		
		if(this.p==y)
		{				
			document.queryForm.sortType.value = this.d ? "asc" : "desc";
		}else
		{
			document.queryForm.sortType.value = "asc"; 
		}
		
		handleButton('PREVIEW');
	}
	
	sorter.prototype.work=function(y){
		this.b=this.t.getElementsByTagName('tbody')[0]; this.r=this.b.rows;
		var x=this.r[0].cells[y],i;
		document.queryForm.sortColumn.value = $(x).text();
		
		for(i=0;i<this.l;i++){
			this.a[i].o=i+1; var v=this.r[i+1].cells[y].firstChild;
			this.a[i].value=(v!=null)?v.nodeValue:''
		}
		for(i=0;i<this.w;i++){
			var c=this.r[0].cells[i];
			if(c.className!='nosort'){$(c).removeClass('asc');$(c).removeClass('desc');}
		}
		
		document.queryForm.sortType.value = document.queryForm.sortType.value == "" ? "asc" : document.queryForm.sortType.value;
		this.d = document.queryForm.sortType.value == "asc" ? false : true;
		
		if(this.p==y){
			this.a.reverse();
			if (this.d)
			{
//				$(x).removeClass('desc').addClass('asc');
				document.queryForm.sortType.value = "asc";
			}
			else 
			{
//				$(x).removeClass('asc').addClass('desc');				
				document.queryForm.sortType.value = "desc";
			}
			this.d=(this.d)?false:true
			handleButton('PREVIEW');
			this.submitted = true;
		}else{
			this.p=y; this.a.sort(compare); 
			if (this.initalized)
			{
				document.queryForm.sortType.value = "asc";
//				$(x).addClass('asc');
				 this.d=false
				 handleButton('PREVIEW');
				 this.submitted = true;
			}
			else
			{
				this.initalized = true;
				
				if (document.queryForm.sortType.value == "desc")
				{
					this.a.reverse();
				}
				
				$(x).addClass(document.queryForm.sortType.value);				
			}
		}
		
		if (!this.submitted)
		{
			var n=document.createElement('tbody');
			n.appendChild(this.r[0]);
			for(i=0;i<this.l;i++){
				var r=this.r[this.a[i].o-1].cloneNode(true);
				n.appendChild(r); r.className=(i%2==0)?'listRow':'listRow2'
			}
			this.t.replaceChild(n,this.b)
		}
	}
	function compare(f,c){
		f=f.value,c=c.value;
		var i=parseFloat(f.replace(/(\$|\,)/g,'')),n=parseFloat(c.replace(/(\$|\,)/g,''));
		var d1 = new Date(f), d2=new Date(c);
		
		if(!isNaN(i)&&!isNaN(n)){f=i,c=n}
		else if (d1 != "Invalid Date" && d2 != "Invalid Date"){f=d1, c=d2}
		
		return (f>c?1:(f<c?-1:0))
	}
	return{sorter:sorter}
}();

function exportReport() {
	  // get the export format into the current report
	  //currReport.selectedFormat = document.getElementById("reportFormat").value;

	  // put param values into current report
	  currReport.params = getParamValues(currReport.params);
	  btnBusy();

	  // make the asynchronous call
	  ReportsUtil.exportReport(currReport, {
	    callback:function(data){
	      dwr.engine.openInDownload(data);
	      btnFree();
	    },
	    errorHandler:function(){
	      document.getElementById("error").style.display="block";
	      btnFree();
	    }
	  });
	}

function btnBusy() {
	  var span = document.getElementById("gReport");
	  span.setAttribute("class","working");
	  span.setAttribute("className","working");

	  document.getElementById("export").disabled = true;
	}

	function btnFree() {
	  document.getElementById("export").disabled = false;

	  var span = document.getElementById("gReport");
	  span.setAttribute("class","report");
	  span.setAttribute("className","report");
	  span.innerHTML="Export";
	}