package com.example.saml.action;


import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.ServletActionContext;
import org.springframework.security.core.context.SecurityContextHolder;

import com.opensymphony.xwork2.ActionSupport;

public class LandingPageAction  extends ActionSupport {
  
    private static final long serialVersionUID = 1L;
 
    @Override
    public java.lang.String execute() {
    	
    	System.out.println("LANDING PAGE ACTION  2");
    	
        HttpServletRequest request = ServletActionContext.getRequest();
        System.out.println("RESPONSE:" + request.getParameter("SAMLResponse"));

		System.out.println("NAME:" + SecurityContextHolder.getContext());
//		System.out.println("toString:" + SecurityContextHolder.getContext().getAuthentication().toString());
//		System.out.println("NAME:" + SecurityContextHolder.getContext().getAuthentication().getName());
//		System.out.println("Credentials:" + SecurityContextHolder.getContext().getAuthentication().getCredentials().toString());    	
         
        return "success";
    }
     
}